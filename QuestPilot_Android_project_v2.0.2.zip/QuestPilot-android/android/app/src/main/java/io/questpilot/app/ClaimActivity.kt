package io.questpilot.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.ImageButton
import android.widget.Toast
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/** Zealy WebView screen shared by the timed claim flow (A3) and normal "open in Zealy" taps. */
@SuppressLint("SetJavaScriptEnabled")
object ZealyWeb {
    @Volatile private var ua: String? = null

    /**
     * One User-Agent for the WebView and the HTTP client: the device's Chrome for Android string
     * without the WebView markers ("; wv", "Version/4.0"), ASCII only so it is a valid header.
     */
    fun userAgent(ctx: Context): String = ua ?: run {
        val raw = try { android.webkit.WebSettings.getDefaultUserAgent(ctx) } catch (_: Exception) { "" }
        var s = raw.replace("; wv)", ")").replace(Regex(" Version/\\d+(\\.\\d+)* "), " ")
        s = s.filter { it.code in 0x20..0x7e }.replace(Regex("\\s+"), " ").trim()
        if (!s.contains("Chrome/")) s = "Mozilla/5.0 (Linux; Android ${android.os.Build.VERSION.RELEASE}; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36"
        s.also { ua = it }
    }

    fun configure(w: WebView) {
        w.settings.userAgentString = userAgent(w.context)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.databaseEnabled = true
        w.settings.loadWithOverviewMode = true
        w.settings.useWideViewPort = true
        w.settings.mediaPlaybackRequiresUserGesture = true
        // v2.0.2 performance: normal HTTP caching (Zealy's scripts / styles / fonts come from the cache when they
        // are still valid; pages and API answers follow their own cache headers, so nothing stale is shown).
        w.settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        w.settings.setSupportZoom(false)
        w.settings.builtInZoomControls = false
        w.settings.displayZoomControls = false
        // GPU-composited page (smoother scrolling / tab switching); ignored when the window isn't hardware accelerated.
        try { w.setLayerType(View.LAYER_TYPE_HARDWARE, null) } catch (_: Exception) {}
        // Zealy's session (and Cloudflare's clearance cookie) need third-party cookies: unchanged.
        android.webkit.CookieManager.getInstance().setAcceptCookie(true)
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
    }

    fun isZealy(u: Uri?) = u?.host?.let { it == "zealy.io" || it.endsWith(".zealy.io") } == true
}

/** A3: a WebView created 3 seconds before unlock while the app is in the background. */
object ClaimPreloader {
    private var web: WebView? = null
    private var url: String? = null
    private var basis: Long = 0
    private val main = Handler(Looper.getMainLooper())

    fun preload(ctx: Context, u: String, unlockAt: Long) = main.post {
        try {
            release()
            SessionStore.injectIntoWebView(ctx)
            val w = WebView(MutableContextWrapper(ctx.applicationContext))
            ZealyWeb.configure(w)
            w.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) { android.webkit.CookieManager.getInstance().flush() }
            }
            w.loadUrl(u)
            web = w; url = u; basis = unlockAt
            main.postDelayed({ if (web === w) { release(); if (ClaimActivity.openCount <= 0 && ManualRunActivity.openCount <= 0) SessionStore.clearWebViewCookies() } }, 10 * 60_000L)
        } catch (_: Exception) {
        }
    }

    fun take(u: String, unlockAt: Long): WebView? {
        val w = web ?: return null
        if (url != u || basis != unlockAt) return null
        web = null; url = null
        return w
    }

    fun release() {
        web?.destroy()
        web = null; url = null
    }
}

class ClaimActivity : Activity(), LinkBannerHost {
    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_MODE = "mode"
        /** v2.4.3 mode "preclick": which button ("like" | "repost" | "follow"). */
        const val EXTRA_PRECLICK_KIND = "preclickKind"
        const val EXTRA_QUESTS = "questIds"
        const val EXTRA_UNLOCK = "unlockAt"
        const val EXTRA_TITLE = "title"
        const val EXTRA_QUEST_ID = "questId"
        /** Watches the page's own network calls: a successful POST to a ".../claim" URL is only a hint that starts the status check. */
        private const val CLAIM_HOOK_JS = "(function(){if(window.__qpClaimHook)return;window.__qpClaimHook=true;" +
            "var rx=/zealy\\.io\\/[^?#]*\\/claim(?:[/?#]|$)/i;" +
            "function hit(m,u,ok){try{if(ok&&/^(POST|PUT|PATCH)$/i.test(m||'GET')&&rx.test(String(u)))QPBridge.claimed(String(u));}catch(e){}}" +
            "var of=window.fetch;if(of)window.fetch=function(i,n){var u=(typeof i==='string')?i:(i&&i.url)||'';var m=(n&&n.method)||(i&&i.method)||'GET';" +
            "return of.apply(this,arguments).then(function(r){hit(m,u,r&&r.ok);return r;});};" +
            "var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;" +
            "XMLHttpRequest.prototype.open=function(m,u){this.__qpm=m;this.__qpu=u;return xo.apply(this,arguments);};" +
            "XMLHttpRequest.prototype.send=function(){var x=this;x.addEventListener('load',function(){hit(x.__qpm,x.__qpu,x.status>=200&&x.status<300);});return xs.apply(this,arguments);};})();"
        /** Notices your own tap on the page's Claim button (only starts a status check, never presses anything). */
        private const val CLAIM_TAP_JS = "(function(){if(window.__qpClaimTap)return;window.__qpClaimTap=true;" +
            "document.addEventListener('click',function(e){try{var b=e.target&&e.target.closest&&e.target.closest('button,[role=button]');" +
            "if(b&&/^\\s*claim\\b/i.test(b.innerText||b.textContent||''))QPBridge.claimTapped();}catch(x){}},true);})();"
        /** Real status check after a claim: one community's questboard, every ~4 s, for at most 40 s. */
        private const val CLAIM_CHECK_EVERY_MS = 4_000L
        private const val CLAIM_CHECK_MAX_MS = 40_000L
        private const val REQ_CHOOSER = 4711
        /** Retry the whole fill once if the page still wasn't unlocked right after the unlock second. */
        private const val UNLOCK_RETRY_WINDOW_MS = 20_000L
        @Volatile var openCount = 0
        /** Unlock time the open countdown screen is for (0 = none). The 3 s alarm skips its own preload when it matches. */
        @Volatile var activeBasis = 0L
        /** Fill retries (page reload + fill again) when the page wasn't ready, for every quest type. */
        private const val FILL_MAX_RETRIES = 2
        private const val FILL_RETRY_WINDOW_MS = 90_000L

        fun intent(ctx: Context, questIds: IntArray, unlockAt: Long, mode: String) =
            Intent(ctx, ClaimActivity::class.java).putExtra(EXTRA_QUESTS, questIds).putExtra(EXTRA_UNLOCK, unlockAt).putExtra(EXTRA_MODE, mode)
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private var web: WebView? = null
    private lateinit var overlay: LinearLayout
    private lateinit var countdown: TextView
    private lateinit var heading: TextView
    private lateinit var nextBtn: Button
    private var lastClaimEventAt = 0L
    @Volatile private var onScreen = false // true while this screen is visible and in use
    // ---- claim status check (reads the quest's real status from Zealy) ----
    @Volatile private var claimCheckGen = 0 // bumped to stop a running check
    private var claimCheckQuestId = -1 // quest the running check is for (-1 = none)
    @Volatile private var pageUrl: String? = null // URL currently shown in the visible page
    private var queue = mutableListOf<JSONObject>()
    private var index = 0
    private var unlockAt = 0L
    private var loadedBeforeUnlock = false
    private var revealed = false
    // ---- next-quest preload (2nd page waits ready while you claim the 1st) ----
    private var nextWeb: WebView? = null
    private var nextReady = false
    private var nextIndex = -1
    private var nextLoadedBeforeUnlock = false
    // autofill state of the waiting page (it is filled while hidden; you only tap Claim)
    private var nextJob: AutofillJob? = null
    private var nextFillPending = false
    private var nextRetried = false
    private var nextReportJson: String? = null
    private var nextPhotoCursor = 0
    // ---- autofill state ----
    private var job: AutofillJob? = null
    private var fillPending = false
    private var fillRetried = false
    private var photoCursor = 0
    private var armedPhoto: java.io.File? = null
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var banner: LinearLayout
    private lateinit var bannerText: TextView
    private lateinit var bannerPhoto: Button
    private val touchedSubs = mutableSetOf<String>()
    private lateinit var links: LinkOverlay
    /** v2.4.3: engaged-cookie hook; the request recorder part only when the Debug switch is on. */
    private val zHook by lazy { ZealyHookBridge.script(try { DbStore.pref(DbStore.read(), "debugZealyRecorder", false) } catch (_: Exception) { false }) }
    private lateinit var fillDebug: TextView
    private var pageRequestedAt = 0L
    private var pageOpenedAt = 0L
    private var fillRetries = 0
    private var nextRetries = 0
    private var pendingLoad: Runnable? = null
    private var linkBannerUrl: String? = null
    // ---- v2.0.2 safety update ----
    /** The visible page is loading (onPageStarted .. onPageFinished): the waiting page doesn't start meanwhile. */
    private var mainBusy = false
    /** Waiting-page load / reload held until the visible page finished (one page at a time). */
    private var afterMain: Runnable? = null
    private var afterMainFallback: Runnable? = null
    /** WebView showing a Cloudflare / human-verification page (null = none). */
    private var cfView: WebView? = null
    private val cfKey = "claim-" + System.identityHashCode(this)
    /** Bumped to stop a running soft update probe. */
    private var softGen = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openCount++
        SessionStore.cancelScheduledClear() // v2.4.7: a claim page is open again: keep the WebView cookies
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        getSystemService(KeyguardManager::class.java)?.requestDismissKeyguard(this, null)
        SiteCookies.restore(this) // C4: put back saved logins (X, Facebook, ...) that Android dropped
        buildUi()
        links = LinkOverlay(this, root) { web }
        handle(intent)
    }

    @Deprecated("Back press: close the in-app link first")
    override fun onBackPressed() {
        if (::links.isInitialized && links.onBack()) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    override fun onStop() {
        android.webkit.CookieManager.getInstance().flush()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        onScreen = true
    }

    override fun onPause() {
        android.webkit.CookieManager.getInstance().flush()
        onScreen = false
        stopClaimCheck()
        super.onPause()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0b0b0f")) }
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0b0b0f"))
            isClickable = true
        }
        heading = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(dp(24), 0, dp(24), dp(12)) }
        countdown = TextView(this).apply { setTextColor(Color.parseColor("#e05aae")); textSize = 44f; typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER }
        val hint = TextView(this).apply {
            setTextColor(Color.parseColor("#9a9aa5")); textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(24), dp(12), dp(24), 0)
            text = "The claim page starts loading 3 seconds before unlock and opens the second the quest unlocks."
        }
        overlay.addView(heading); overlay.addView(countdown); overlay.addView(hint)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#151519"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val close = Button(this).apply { text = "Close"; setOnClickListener { finish() } }
        nextBtn = Button(this).apply { text = "Next"; visibility = View.GONE; setOnClickListener { showNext() } }
        val spacer = View(this)
        bar.addView(close); bar.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f)); bar.addView(nextBtn)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val webHolder = FrameLayout(this).apply { id = View.generateViewId(); tag = "holder" }
        banner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#3a1030"))
            setPadding(dp(12), dp(6), dp(4), dp(6))
            visibility = View.GONE
        }
        bannerText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f
            text = "Couldn't autofill, tap to copy text"
            setOnClickListener { if (linkBannerUrl != null) copyLink() else copySavedText(true) }
        }
        bannerPhoto = Button(this).apply { text = "Saved photo"; textSize = 12f; isAllCaps = false; setOnClickListener { pickSavedPhoto() } }
        val bannerClose = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Dismiss"
            setOnClickListener { banner.visibility = View.GONE }
        }
        banner.addView(bannerText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        banner.addView(bannerPhoto)
        banner.addView(bannerClose, LinearLayout.LayoutParams(dp(40), dp(40)))
        fillDebug = TextView(this).apply {
            setTextColor(Color.parseColor("#9ef0b5")); textSize = 10.5f; typeface = Typeface.MONOSPACE
            setBackgroundColor(Color.parseColor("#101814")); setPadding(dp(8), dp(3), dp(8), dp(3)); maxLines = 3
            visibility = View.GONE
        }
        col.addView(fillDebug, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(banner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(webHolder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay.visibility = View.GONE
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, insets ->
            @Suppress("DEPRECATION")
            v.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
            insets
        }
    }

    private fun holder(): FrameLayout = root.findViewWithTag("holder")

    private fun attachWeb(w: WebView) {
        web?.let { old -> if (cfView === old && old !== w) onChallengeCleared(old) }
        mainBusy = false
        web?.let { holder().removeView(it); it.destroy() }
        stopClaimCheck()
        pageUrl = w.url
        (w.context as? MutableContextWrapper)?.baseContext = this
        ZealyWeb.configure(w)
        w.removeJavascriptInterface("QPBridge")
        w.addJavascriptInterface(Bridge(w), "QPBridge")
        installLinks(w)
        w.webChromeClient = chrome()
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if (ZealyWeb.isZealy(u) || u.scheme == "about" || u.scheme == "blob" || u.scheme == "data") return false
                // Cloudflare / captcha frames and /cdn-cgi/ always load untouched.
                if (!req.isForMainFrame && CfChallenge.isChallengeResource(u)) return false
                // D1: no link leaves the app. X / Discord / Telegram / any site opens in the in-app overlay.
                if (req.isForMainFrame || req.hasGesture()) links.open(u.toString(), null)
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                if (view === web) mainBusy = true
                if (CfChallenge.isChallengeUrl(url)) main.post { onChallenge(view, "challenge URL") }
                view.evaluateJavascript(LinkOverlay.LINKS_JS, null)
                view.evaluateJavascript(zHook, null)
            }

            override fun onReceivedHttpError(view: WebView, req: WebResourceRequest, resp: android.webkit.WebResourceResponse) {
                if (req.isForMainFrame && CfChallenge.isMitigated(resp)) main.post { onChallenge(view, "cf-mitigated ${resp.statusCode}") }
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                if (view === web) pageUrl = url
            }

            override fun onPageFinished(view: WebView, url: String) {
                android.webkit.CookieManager.getInstance().flush()
                view.evaluateJavascript(LinkOverlay.LINKS_JS, null)
                view.evaluateJavascript(zHook, null)
                try { EngagedLab.saveFromJar(this@ClaimActivity) } catch (_: Exception) {}
                view.evaluateJavascript(CLAIM_HOOK_JS, null)
                view.evaluateJavascript(CLAIM_TAP_JS, null)
                if (view === web) pageUrl = url
                checkChallenge(view) { if (view === web) { mainBusy = false; runAfterMain() } }
                if (!revealed) { loadedBeforeUnlock = true; return } // preloading: fill only after unlock + refresh
                maybeFill()
                schedulePreloadScan(view)
            }
        }
        holder().addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web = w
    }

    private fun handle(i: Intent) {
        // A new unlock while you are working through a list: it never interrupts the claim in progress.
        // Limited-slot ("First N only") tasks go first, then tasks whose sprint is about to end, then everything else in order.
        if ((i.getStringExtra(EXTRA_MODE) ?: "browse") == "claim" && onScreen && web != null && queue.isNotEmpty()) {
            val db = DbStore.read()
            val have = queue.map { it.optInt("id") }.toSet()
            val fresh = (i.getIntArrayExtra(EXTRA_QUESTS) ?: intArrayOf()).filter { it !in have }
                .mapNotNull { if (DevTools.isTestId(it)) DevTools.testQuest(this, it) else DbStore.quest(db, it) }
            if (fresh.isNotEmpty()) {
                fresh.forEach { touchedSubs.add(subOf(it.optString("url"))) }
                val nowMs = System.currentTimeMillis()
                val soonLimit = nowMs + 24 * 3_600_000L
                fun endOf(q: JSONObject): Long {
                    val e = UnlockClock.parseTime(DbStore.community(db, q.optInt("communityId"))?.opt("sprintEndsAt"))
                    return if (e != null && e > nowMs) e else Long.MAX_VALUE
                }
                // 0 = limited slots, 1 = sprint ends within 24 h, 2 = everything else
                fun tier(q: JSONObject) = when {
                    q.optInt("claimLimit") > 0 -> 0
                    endOf(q) <= soonLimit -> 1
                    else -> 2
                }
                // Inside a tier: same order as the home page (sprint ending first, daily before weekly, more XP, earlier unlock).
                val periods = mapOf("daily" to 0, "weekly" to 1, "monthly" to 2)
                val order = Comparator<JSONObject> { a, b ->
                    var r = tier(a).compareTo(tier(b))
                    if (r == 0) r = endOf(a).compareTo(endOf(b))
                    if (r == 0) r = (periods[a.optString("recurrence")] ?: 3).compareTo(periods[b.optString("recurrence")] ?: 3)
                    if (r == 0) r = b.optInt("xp").compareTo(a.optInt("xp"))
                    if (r == 0) r = a.optLong("unlockAt").compareTo(b.optLong("unlockAt"))
                    r
                }
                var nextChanged = false
                for (q in fresh.sortedWith(order)) {
                    var pos = index + 1
                    while (pos < queue.size && order.compare(queue[pos], q) <= 0) pos++
                    queue.add(pos, q)
                    if (pos == index + 1) nextChanged = true
                }
                updateNext()
                if (nextChanged) discardNext()
                if (nextWeb == null) preloadNext() // the next page is now a different task, or the list had ended
                val head = queue.getOrNull(index + 1)
                val name = head?.optString("title") ?: fresh[0].optString("title")
                toast(
                    if (nextChanged && head != null && tier(head) == 0) "Limited-slot task first: $name is next"
                    else if (nextChanged && head != null && tier(head) == 1) "Sprint ending soon: $name is next"
                    else "New claim added: ${fresh[0].optString("title")}"
                )
            }
            Notifications.cancel(this, Notifications.ID_CLAIM)
            if (DevTools.ENABLED) Notifications.cancel(this, DevTools.ID_TEST_CLAIM)
            return
        }
        SessionStore.injectIntoWebView(this)
        val mode = i.getStringExtra(EXTRA_MODE) ?: "browse"
        banner.visibility = View.GONE
        fillRetried = false
        if (mode == "claim") {
            unlockAt = i.getLongExtra(EXTRA_UNLOCK, 0L)
            val ids = i.getIntArrayExtra(EXTRA_QUESTS) ?: intArrayOf()
            val db = DbStore.read()
            queue = ids.toList().mapNotNull { if (DevTools.isTestId(it)) DevTools.testQuest(this, it) else DbStore.quest(db, it) }.toMutableList()
            index = 0
            if (queue.isEmpty()) { finish(); return }
            val first = queue[0]
            val url = first.optString("url").ifEmpty { "https://zealy.io" }
            touchedSubs.add(subOf(url))
            heading.text = first.optString("title")
            revealed = false
            loadedBeforeUnlock = false
            activeBasis = unlockAt
            pendingLoad?.let { main.removeCallbacks(it) }; pendingLoad = null
            val pre = ClaimPreloader.take(url, unlockAt)
            if (pre != null) { attachWeb(pre); loadedBeforeUnlock = true; pageRequestedAt = System.currentTimeMillis() - 1; checkChallenge(pre) {} }
            else { attachWeb(WebView(MutableContextWrapper(this))); loadWhenDue(url) }
            pageOpenedAt = System.currentTimeMillis()
            setJob(first.optInt("id"))
            updateNext()
            preloadNext()
            if (System.currentTimeMillis() < unlockAt) {
                overlay.visibility = View.VISIBLE
                tick()
                // reveal + refresh exactly at the unlock time
                main.postAtTime({ reveal() }, SystemClock.uptimeMillis() + (unlockAt - System.currentTimeMillis()))
            } else reveal()
            Notifications.cancel(this, Notifications.ID_CLAIM)
            if (DevTools.ENABLED) Notifications.cancel(this, DevTools.ID_TEST_CLAIM)
        } else if (mode == "preclick") {
            // v2.4.3 Part 2: only the X overlay for the button you pressed. Nothing is tapped for you.
            overlay.visibility = View.GONE
            revealed = true
            queue.clear(); updateNext()
            job = null; fillPending = false
            val qid = i.getIntExtra(EXTRA_QUEST_ID, 0)
            val kind = i.getStringExtra(EXTRA_PRECLICK_KIND) ?: "like"
            val url = i.getStringExtra(EXTRA_URL)
            if (url == null || qid <= 0) { finish(); return }
            // v2.4.6: the button was already marked when you pressed it (QuestPilotPlugin.preclick): closing just returns
            links.onClosed = { _, _ -> links.onClosed = null; finish() }
            main.post { links.open(url, null) }
            // in-app links switched off: the link went to the browser, nothing to record here
            main.postDelayed({ if (!links.isOpen && links.onClosed != null) { links.onClosed = null; finish() } }, 2_000)
        } else {
            val url = i.getStringExtra(EXTRA_URL) ?: "https://zealy.io"
            touchedSubs.add(subOf(url))
            overlay.visibility = View.GONE
            revealed = true
            val qid = i.getIntExtra(EXTRA_QUEST_ID, 0)
            if (qid > 0) setJob(qid) else { job = null; fillPending = false; fillStep("no quest id: autofill off for this page") }
            attachWeb(WebView(MutableContextWrapper(this)))
            web!!.loadUrl(url)
            pageRequestedAt = System.currentTimeMillis()
            pageOpenedAt = pageRequestedAt
            discardNext()
            val runIds = i.getIntArrayExtra(EXTRA_QUESTS)
            if (qid > 0 && runIds != null && runIds.size > 1 && runIds[0] == qid) {
                // Claim run from the home page: keep the rest of the list here so Next works.
                val db = DbStore.read()
                unlockAt = 0L
                queue = runIds.toList().mapNotNull { DbStore.quest(db, it) }.toMutableList()
                index = 0
                updateNext()
                preloadNext()
            } else {
                queue.clear(); updateNext()
            }
        }
        val alertId = i.getIntExtra("alertId", 0)
        if (alertId > 0) Executors.newSingleThreadExecutor().execute {
            DbStore.mutate { db -> DbStore.findById(db.getJSONArray("alerts"), alertId)?.put("read", 1) }
        }
    }

    private fun tick() {
        if (revealed) return
        val left = unlockAt - System.currentTimeMillis()
        countdown.text = if (left > 0) String.format("%.1fs", left / 1000.0) else "0.0s"
        main.postDelayed({ tick() }, 100)
    }

    private fun reveal() {
        if (revealed) return
        revealed = true
        overlay.visibility = View.GONE
        pendingLoad?.let { main.removeCallbacks(it); it.run() }; pendingLoad = null
        // Refresh at the exact unlock time if anything was requested before it. v2.0.2 safety: a page that already
        // finished loading gets a soft update first (nothing clicked); the full reload only if that didn't work.
        val w = web
        if (w != null && loadedBeforeUnlock && !mainBusy && cfView == null && samePage(w.url)) softUpdate(w)
        else if (loadedBeforeUnlock || (pageRequestedAt in 1 until unlockAt)) w?.reload()
        pageOpenedAt = System.currentTimeMillis()
        // The waiting page was loaded before unlock: refresh it too, so it is open and ready when you tap Next,
        // but only after the visible page is done (never two pages at the same second).
        if (nextLoadedBeforeUnlock) nextWeb?.let { nw ->
            nextReady = false
            whenMainIdle("next task page refresh") { if (nextWeb === nw) nw.reload() }
        }
        nextLoadedBeforeUnlock = false
    }

    // ------------------------------------------------------------------ v2.0.2 safety update

    /** The visible page still shows the current quest. */
    private fun samePage(u: String?): Boolean {
        val q = queue.getOrNull(index) ?: return false
        if (u.isNullOrEmpty()) return false
        val zid = q.optString("zealyId").takeIf { it.isNotEmpty() && !q.isNull("zealyId") }
        if (zid != null) return u.contains(zid, ignoreCase = true)
        fun norm(x: String) = x.substringBefore('#').substringBefore('?').trimEnd('/').lowercase()
        return norm(u) == norm(q.optString("url"))
    }

    /** Soft update at the unlock second, then (Claim button still missing after 3.5-4 s) the full reload. */
    private fun softUpdate(w: WebView) {
        val q = queue.getOrNull(index)
        val recurring = q?.optString("recurrence", "once").let { it != null && it != "once" }
        val limit = if (recurring) 4_000L else 3_500L
        val gen = ++softGen
        val t0 = SystemClock.uptimeMillis()
        var nativeSt = UnlockStatus.UNKNOWN
        var extended = false
        fillStep("unlock second: soft update tried")
        w.evaluateJavascript(SoftUpdate.SOFT_JS, null)
        if (q != null) UnlockStatus.check(applicationContext, q, manual = false) { st -> nativeSt = st; if (gen == softGen) fillStep("native status check: $st") }
        fun poll(lim: Long) {
            main.postDelayed({
                if (gen != softGen || web !== w || isFinishing) return@postDelayed
                w.evaluateJavascript(SoftUpdate.PROBE_JS) { res ->
                    if (gen != softGen || web !== w || isFinishing) return@evaluateJavascript
                    val el = SystemClock.uptimeMillis() - t0
                    when {
                        SoftUpdate.parse(res).claim -> {
                            fillStep("soft update worked: Claim button there after $el ms")
                            pageOpenedAt = System.currentTimeMillis()
                            maybeFill()
                            schedulePreloadScan(w)
                        }
                        el < lim -> poll(lim)
                        nativeSt == UnlockStatus.LOCKED && !extended -> {
                            extended = true
                            fillStep("Zealy still says locked: soft update tried again")
                            w.evaluateJavascript(SoftUpdate.SOFT_JS, null)
                            poll(lim + 3_000L)
                        }
                        else -> { fillStep("soft update failed, full reload"); w.reload() }
                    }
                }
            }, 500L)
        }
        poll(limit)
    }

    /** Runs [r] once the visible page isn't loading (and no human verification is up), 600 ms later; 10 s at the latest. */
    private fun whenMainIdle(what: String, r: () -> Unit) {
        afterMain?.let { main.removeCallbacks(it) }
        afterMainFallback?.let { main.removeCallbacks(it) }
        val run = Runnable { afterMain = null; afterMainFallback?.let { main.removeCallbacks(it) }; afterMainFallback = null; r() }
        afterMain = run
        if (!mainBusy && cfView == null) { main.postDelayed(run, 600L); return }
        fillStep("$what: starting after the visible page finished")
        val fb = Runnable { if (afterMain === run && cfView == null) { main.removeCallbacks(run); run.run() } }
        afterMainFallback = fb
        main.postDelayed(fb, 10_000L)
    }

    private fun runAfterMain() {
        val r = afterMain ?: return
        if (cfView != null) return
        main.removeCallbacks(r)
        main.postDelayed(r, 600L)
    }

    private fun checkChallenge(view: WebView, then: () -> Unit) {
        view.evaluateJavascript(CfChallenge.DETECT_JS) { res ->
            if (isFinishing) return@evaluateJavascript
            if (CfChallenge.parse(res)) onChallenge(view, "page content")
            else if (cfView === view && !CfChallenge.isChallengeUrl(view.url)) onChallengeCleared(view)
            then()
        }
    }

    /** Human verification on [view]: shown right away, extra work paused. Never solved or bypassed for you. */
    private fun onChallenge(view: WebView, where: String) {
        if (isFinishing || cfView === view) return
        if (view !== web && view !== nextWeb) return
        cfView = view
        CfChallenge.shown(cfKey, "claim screen, $where")
        softGen++ // no soft-update reload on top of the challenge
        stopClaimCheck()
        afterMainFallback?.let { main.removeCallbacks(it) }
        afterMain?.let { main.removeCallbacks(it) }
        linkBannerUrl = null
        bannerPhoto.visibility = View.GONE
        bannerText.isClickable = false
        if (view === web) {
            overlay.visibility = View.GONE // the page must be visible to solve it
            bannerText.text = "Human verification required – complete it in this window."
        } else {
            bannerText.text = "Human verification required on the next task's page – tap Next and complete it there."
        }
        banner.visibility = View.VISIBLE
        fillStep("human verification page ($where): next page and status checks paused")
        toast("Human verification required – complete it in this window.")
    }

    private fun onChallengeCleared(view: WebView) {
        if (cfView !== view) return
        cfView = null
        CfChallenge.cleared(cfKey, "claim screen")
        if (bannerText.text?.startsWith("Human verification") == true) banner.visibility = View.GONE
        if (!revealed && System.currentTimeMillis() < unlockAt) overlay.visibility = View.VISIBLE
        fillStep("human verification done: resuming")
        if (!mainBusy) runAfterMain()
    }

    /**
     * Load the following quest's page in a WebView that sits behind the visible one, and fill it
     * there (after unlock) so that tapping Next only leaves the Claim tap.
     */
    private fun preloadNext() {
        discardNext()
        val q = queue.getOrNull(index + 1) ?: return
        val url = q.optString("url").ifEmpty { "https://zealy.io" }
        try {
            val w = WebView(MutableContextWrapper(this))
            ZealyWeb.configure(w)
            w.removeJavascriptInterface("QPBridge")
            w.addJavascriptInterface(Bridge(w), "QPBridge")
            installLinks(w)
            w.webChromeClient = chrome()
            w.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                    val u = req.url
                    if (!req.isForMainFrame && CfChallenge.isChallengeResource(u)) return false // challenge frames load untouched
                    return !(ZealyWeb.isZealy(u) || u.scheme == "about") // never open other apps from the waiting page
                }

                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    if (CfChallenge.isChallengeUrl(url)) main.post { onChallenge(view, "challenge URL") }
                }

                override fun onReceivedHttpError(view: WebView, req: WebResourceRequest, resp: android.webkit.WebResourceResponse) {
                    if (req.isForMainFrame && CfChallenge.isMitigated(resp)) main.post { onChallenge(view, "cf-mitigated ${resp.statusCode}") }
                }

                override fun onPageFinished(view: WebView, url: String) {
                    checkChallenge(view) {}
                    view.evaluateJavascript(LinkOverlay.LINKS_JS, null)
                    view.evaluateJavascript(zHook, null)
                    view.evaluateJavascript(CLAIM_HOOK_JS, null)
                    view.evaluateJavascript(CLAIM_TAP_JS, null)
                    if (nextWeb !== view) return
                    nextReady = true
                    if (revealed) fillNext() // before unlock nothing is filled: the refresh at unlock comes first
                }
            }
            nextJob = try { Autofill.prepare(this, q.optInt("id"), markUsed = false) } catch (_: Exception) { null }
            nextFillPending = nextJob != null
            nextRetried = false
            nextRetries = 0
            nextReportJson = null
            nextPhotoCursor = 0
            nextWeb = w
            nextIndex = index + 1
            nextReady = false
            nextLoadedBeforeUnlock = false
            // Added at the bottom of the stack: the visible page covers it and keeps all touches.
            holder().addView(w, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            // v2.0.2 safety: one page at a time. The waiting page starts after the visible one finished loading.
            whenMainIdle("next task page") {
                if (nextWeb === w) { nextLoadedBeforeUnlock = System.currentTimeMillis() < unlockAt; w.loadUrl(url) }
            }
        } catch (_: Exception) {
            discardNext()
        }
    }

    private fun discardNext() {
        nextWeb?.let { nw -> if (cfView === nw) onChallengeCleared(nw) }
        afterMain?.let { main.removeCallbacks(it) }; afterMain = null
        afterMainFallback?.let { main.removeCallbacks(it) }; afterMainFallback = null
        nextWeb?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        nextWeb = null
        nextReady = false
        nextIndex = -1
        nextLoadedBeforeUnlock = false
        nextJob = null
        nextFillPending = false
        nextRetried = false
        nextReportJson = null
        nextPhotoCursor = 0
    }

    /** Same fill as maybeFill(), for the waiting page. */
    private fun fillNext() {
        val j = nextJob ?: return
        if (!nextFillPending || !revealed) return
        val w = nextWeb ?: return
        if (!Autofill.matches(j, w.url)) return // another page: never fill
        nextFillPending = false
        val js = Autofill.script(this) ?: return
        val cfg = Autofill.selectors(this)
        val payload = try { Autofill.payload(j) } catch (_: Exception) { Autofill.payload(j, emptyList()) }
        w.evaluateJavascript(js, null)
        w.evaluateJavascript("window.__qpFill($cfg, $payload)", null)
    }

    /** Fill result from the waiting page. Kept until you tap Next, then shown exactly like a normal result. */
    private fun onNextReport(json: String) {
        val j = nextJob ?: return
        val w = nextWeb ?: return
        if (!Autofill.matches(j, w.url)) return
        val r = try { JSONObject(json) } catch (_: Exception) { return }
        if (r.optBoolean("blocked")) return
        val missing = r.optString("text") == "missing" || r.optString("photo") == "missing"
        if (!r.optBoolean("manual") && missing && nextRetries < FILL_MAX_RETRIES &&
            System.currentTimeMillis() - maxOf(pageOpenedAt, unlockAt) in 0..FILL_RETRY_WINDOW_MS) {
            nextRetries++; nextRetried = true // the page wasn't ready (or still locked): refresh and try again
            nextFillPending = true
            w.reload()
            return
        }
        nextReportJson = json
    }

    /**
     * The status check confirmed the claim on Zealy. Only with Auto-next on and more claims waiting:
     * move on after a short pause. The Next button always works on its own.
     */
    private fun onClaimDetected() {
        val now = SystemClock.uptimeMillis()
        if (now - lastClaimEventAt < 5000) return // one claim = one move
        lastClaimEventAt = now
        // The Auto-next switch lives on the home page's claim run card (preference autoNextClaim).
        if (!DbStore.pref(DbStore.read(), "autoNextClaim", false) || index + 1 >= queue.size) return
        val at = index
        toast("Claimed. Moving to the next one…")
        main.postDelayed({ if (index == at) showNext() }, 1800)
    }

    /**
     * Real status check: after the network hint or your own Claim tap, read the quest's status from
     * Zealy's questboard (the same request and the same ZealySync.apply() that a sync uses, run on a
     * throwaway copy so nothing is saved). Confirmed when the status becomes done/pending or its
     * unlock time moves to the next day. Silent on any failure: never an auth failure, never a logout.
     */
    private fun startClaimCheck() {
        if (!onScreen || index + 1 >= queue.size) return // nothing to move to
        val q0 = queue.getOrNull(index) ?: return
        val qid = q0.optInt("id")
        if (claimCheckQuestId == qid) return // already checking this claim
        if (DevTools.isTestId(qid) || q0.optString("source") == "test") return
        val db = try { DbStore.read() } catch (_: Exception) { return }
        if (!DbStore.pref(db, "autoNextClaim", false)) return
        val local = DbStore.quest(db, qid) ?: return
        val zid = local.optString("zealyId").takeIf { it.isNotEmpty() && !local.isNull("zealyId") } ?: return
        val com = DbStore.community(db, local.optInt("communityId")) ?: return
        val sub = com.optString("subdomain").ifEmpty { return }
        val comName = com.optString("name", sub)
        val tz = db.optJSONObject("settings")?.optInt("tzOffset", 0) ?: 0
        val beforeStatus = local.optString("status")
        val beforeUnlock = try { UnlockClock.unlockAt(local, tz) } catch (_: Exception) { null }
        val gen = ++claimCheckGen
        claimCheckQuestId = qid
        val atIndex = index
        val ctx = applicationContext
        val started = SystemClock.uptimeMillis()
        fun live() = gen == claimCheckGen && onScreen && pageUrl?.contains(zid) == true
        Thread {
            try {
                while (SystemClock.uptimeMillis() - started < CLAIM_CHECK_MAX_MS) {
                    Thread.sleep(CLAIM_CHECK_EVERY_MS + kotlin.random.Random.nextLong(0, 800))
                    if (!live()) return@Thread // closed, Next tapped, or another task is showing: stop
                    val confirmed = try {
                        // v2.4.7 Fix 6a: you are waiting for this one: priority lane of the shared gate
                        val qb = ZealyGate.priority { ZealyApi.questboard(ctx, sub) }
                        val modules = ZealyApi.modules(qb)
                        if (!qb.ok || modules == null) false // silent: never Session.onAuthFailure here
                        else {
                            val copy = JSONObject(DbStore.read().toString())
                            ZealySync.apply(copy, JSONObject().put("subdomain", sub).put("name", comName).put("questboard", modules))
                            val now = System.currentTimeMillis()
                            val after = DbStore.quest(copy, qid)
                            val st = after?.optString("status")
                            val unlock = after?.let { UnlockClock.unlockAt(it, tz) }
                            val day = 86_400_000L
                            val baseDay = (beforeUnlock?.takeIf { it > now } ?: now) / day
                            (st != beforeStatus && (st == "done" || st == "pending")) ||
                                (unlock != null && unlock > now && unlock / day > baseDay)
                        }
                    } catch (_: Exception) { false }
                    if (confirmed) {
                        main.post { if (gen == claimCheckGen && index == atIndex) { stopClaimCheck(); onClaimDetected() } }
                        return@Thread
                    }
                }
            } catch (_: Exception) {
            } finally {
                main.post { if (gen == claimCheckGen) claimCheckQuestId = -1 }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun stopClaimCheck() {
        claimCheckGen++
        claimCheckQuestId = -1
    }

    private fun updateNext() {
        val more = queue.size - index - 1
        nextBtn.visibility = if (more > 0) View.VISIBLE else View.GONE
        nextBtn.text = "Next ($more)"
    }

    private fun showNext() {
        if (index + 1 >= queue.size) return
        stopClaimCheck()
        index++
        val q = queue[index]
        val url = q.optString("url").ifEmpty { "https://zealy.io" }
        touchedSubs.add(subOf(url))
        banner.visibility = View.GONE
        fillRetried = false
        val pre = nextWeb
        if (pre != null && nextIndex == index) {
            // The page is already loaded and filled: take over its autofill state and show it.
            val report = nextReportJson
            job = nextJob
            fillPending = nextFillPending
            fillRetried = nextRetried
            fillRetries = nextRetries
            photoCursor = nextPhotoCursor
            armedPhoto = null
            nextWeb = null; nextReady = false; nextIndex = -1; nextLoadedBeforeUnlock = false
            nextJob = null; nextFillPending = false; nextRetried = false; nextReportJson = null; nextPhotoCursor = 0
            (pre.parent as? ViewGroup)?.removeView(pre)
            attachWeb(pre)
            if (cfView === pre) bannerText.text = "Human verification required – complete it in this window."
            if (report != null) onFillReport(report) // "Filled in. Check it, then tap Claim yourself."
            else if (fillPending) maybeFill()        // not filled yet: finishes right away
        } else {
            setJob(q.optInt("id"))
            web?.loadUrl(url)
            pageRequestedAt = System.currentTimeMillis()
        }
        pageOpenedAt = System.currentTimeMillis()
        updateNext()
        preloadNext() // get the one after it ready too
    }

    // ------------------------------------------------------------------ autofill

    /**
     * v2.4: a "use once" saved entry is no longer marked used when the page opens, only once the fill
     * actually worked (or you tapped Claim). Before, a failed fill at unlock used the entry up, so the
     * saved photo was gone when you tried again or tapped the upload box yourself.
     */
    private fun setJob(questId: Int) {
        job = try { Autofill.prepare(this, questId, markUsed = false) } catch (_: Exception) { null }
        fillPending = job != null
        fillRetries = 0
        photoCursor = 0
        armedPhoto = null
        val j = job
        if (j == null) fillStep("no saved content for quest $questId")
        else fillStep("job found: quest $questId, text ${if (j.text.isNullOrBlank()) "no" else "yes"}, photos ${j.photos.size}" +
            j.photos.joinToString("") { " · ${it.name.takeLast(14)} ${if (it.isFile) "${it.length() / 1024}KB" else "MISSING FILE"}" })
    }

    private fun commitJob(j: AutofillJob?) { j?.let { try { Autofill.commitUsed(it) } catch (_: Exception) {} } }

    /** Debug line (Settings > Debug > Autofill steps on screen). Also goes to the event log. */
    fun fillStep(m: String) {
        EventLog.add("fill", m)
        val on = try { DbStore.pref(DbStore.read(), "debugFillSteps", false) } catch (_: Exception) { false }
        if (!on) { fillDebug.visibility = View.GONE; return }
        fillDebug.visibility = View.VISIBLE
        val lines = (fillDebug.text?.toString() ?: "").lines().filter { it.isNotBlank() }.takeLast(2) + m
        fillDebug.text = lines.joinToString("\n")
    }

    /** D3 fallback: link copied / post sent, but it couldn't be pasted for you. */
    override fun showLinkBanner(link: String?, text: String) {
        linkBannerUrl = link
        if (link != null) getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Post link", link))
        bannerText.text = text + if (link != null) " (tap to copy again)" else ""
        bannerText.isClickable = true
        bannerPhoto.visibility = View.GONE
        banner.visibility = View.VISIBLE
    }

    private fun copyLink() {
        val l = linkBannerUrl ?: return
        getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Post link", l))
        toast("Link copied. Long-press the task's link field and paste.")
    }

    /** Claim mode: the page loads 3 s before unlock (stage 4), or at unlock when that stage is off. */
    private fun loadWhenDue(url: String) {
        val w = web ?: return
        val stage3 = try { DbStore.pref(DbStore.read(), "stage3s", true) } catch (_: Exception) { true }
        val at = if (stage3) unlockAt - 3_000L else unlockAt
        val go = Runnable { if (web === w) { pendingLoad = null; pageRequestedAt = System.currentTimeMillis(); w.loadUrl(url); fillStep("claim page loading") } }
        val wait = at - System.currentTimeMillis()
        if (wait <= 0) go.run() else { pendingLoad = go; main.postDelayed(go, wait) }
    }

    /** D1: link capture on a Zealy WebView (document-start script when supported, page-start/finish injection otherwise). */
    private fun installLinks(w: WebView) {
        w.settings.setSupportMultipleWindows(true)
        w.settings.javaScriptCanOpenWindowsAutomatically = true
        w.removeJavascriptInterface("QPLinks")
        w.addJavascriptInterface(LinksBridge(w), "QPLinks")
        if (w.getTag(R.id.qp_links_installed) == null) {
            LinkOverlay.addStartScript(w, LinkOverlay.LINKS_JS, setOf("https://zealy.io", "https://www.zealy.io"))
            w.setTag(R.id.qp_links_installed, true)
        }
        // v2.4.3 Part 3: passive hook for Zealy's *-engaged* cookie writes (+ request recorder when switched on)
        w.removeJavascriptInterface("QPZ")
        w.addJavascriptInterface(ZealyHookBridge(applicationContext), "QPZ")
        if (w.getTag(R.id.qp_zhook_installed) == null) {
            LinkOverlay.addStartScript(w, zHook, setOf("https://zealy.io", "https://www.zealy.io"))
            w.setTag(R.id.qp_zhook_installed, true)
        }
    }

    inner class LinksBridge(private val owner: WebView) {
        @JavascriptInterface fun open(url: String, card: String) = main.post { if (owner === web) links.open(url, card) }
        @JavascriptInterface fun visible(json: String) = main.post {
            if (owner !== web) return@post
            val arr = try { org.json.JSONArray(json) } catch (_: Exception) { return@post }
            links.preloadVisible((0 until arr.length()).map { arr.optString(it) })
        }
    }

    private fun schedulePreloadScan(view: WebView) {
        val on = try { DbStore.pref(DbStore.read(), "featLikePreload", false) } catch (_: Exception) { false }
        if (!on) return
        fun scan() { if (view === web && !isFinishing) { view.evaluateJavascript("window.__qpScanIntents&&window.__qpScanIntents()", null); main.postDelayed({ scan() }, 2500) } }
        main.postDelayed({ scan() }, 1500)
    }

    /** File chooser + D1 onCreateWindow (target=_blank, window.open that bypassed the page script). */
    private fun chrome() = object : WebChromeClient() {
        override fun onReceivedTitle(view: WebView, title: String?) {
            if (CfChallenge.isChallengeTitle(title)) main.post { onChallenge(view, "page title") }
        }

        override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean =
            onFileChooser(view, cb, params)

        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
            val tmp = WebView(this@ClaimActivity)
            var handled = false
            tmp.webViewClient = object : WebViewClient() {
                fun take(u: String?) {
                    if (handled || u.isNullOrEmpty() || u == "about:blank") return
                    handled = true
                    EventLog.add("links", "onCreateWindow: ${Redact.path(u)}")
                    if (ZealyWeb.isZealy(Uri.parse(u))) web?.loadUrl(u) else links.open(u, null)
                    main.post { tmp.destroy() }
                }
                override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean { take(req.url.toString()); return true }
                override fun onPageStarted(v: WebView, url: String, favicon: android.graphics.Bitmap?) { take(url) }
            }
            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
            transport.webView = tmp
            resultMsg.sendToTarget()
            main.postDelayed({ if (!handled) tmp.destroy() }, 10_000)
            return true
        }
    }

    private fun maybeFill() {
        val j = job ?: return
        if (!fillPending || !revealed) return
        val w = web ?: return
        if (!Autofill.matches(j, w.url)) { fillStep("waiting: page is not the quest yet (${Redact.path(w.url ?: "")})"); return } // another page: never fill
        fillPending = false
        fillStep("filling (attempt ${fillRetries + 1})")
        val js = Autofill.script(this) ?: return
        val cfg = Autofill.selectors(this)
        val payload = try { Autofill.payload(j) } catch (_: Exception) { Autofill.payload(j, emptyList()) }
        w.evaluateJavascript(js, null)
        w.evaluateJavascript("window.__qpFill($cfg, $payload)", null)
    }

    /** Result from qp-fill.js. Only trusted while the main frame is the opened zealy.io quest. */
    inner class Bridge(private val owner: WebView? = null) {
        @JavascriptInterface
        fun claimed(url: String) {
            // Only a hint: it starts the real status check, which alone decides whether to move on.
            main.post { if (owner == null || owner === web) startClaimCheck() }
        }

        /** You tapped the page's Claim button yourself: start reading the real status. */
        @JavascriptInterface
        fun claimTapped() {
            main.post { if (owner == null || owner === web) { commitJob(job); startClaimCheck() } }
        }

        /** qp-fill.js progress line (Debug: autofill steps on screen). */
        @JavascriptInterface
        fun step(msg: String) {
            main.post { if (owner == null || owner === web) fillStep(msg) }
        }

        @JavascriptInterface
        fun report(json: String) {
            main.post {
                when {
                    owner == null || owner === web -> onFillReport(json)
                    owner === nextWeb -> onNextReport(json) // the waiting page, still hidden
                }
            }
        }
    }

    private fun onFillReport(json: String) {
        val j = job ?: return
        if (!Autofill.matches(j, web?.url)) return
        val r = try { JSONObject(json) } catch (_: Exception) { return }
        if (r.optBoolean("blocked")) return
        val textMissing = r.optString("text") == "missing"
        val photoMissing = r.optString("photo") == "missing"
        val photoUnsure = r.optString("photo") == "unconfirmed"
        fillStep("result: text ${r.optString("text")}, photo ${r.optString("photo")}")
        if (r.optBoolean("manual")) {
            if (!photoMissing && !photoUnsure) { banner.visibility = View.GONE; commitJob(j); toast("Saved photo attached. Check it, then tap Claim.") }
            else showBanner(false, true)
            return
        }
        if (!textMissing && !photoMissing && !photoUnsure) {
            banner.visibility = View.GONE
            commitJob(j)
            toast("Filled in. Check it, then tap Claim yourself.")
            return
        }
        // The page wasn't ready (or Zealy still served the locked page right after unlock): reload and fill
        // again. v2.4: for every quest, not only the ones with an unlock time.
        if ((textMissing || photoMissing) && fillRetries < FILL_MAX_RETRIES &&
            System.currentTimeMillis() - maxOf(pageOpenedAt, unlockAt) in 0..FILL_RETRY_WINDOW_MS) {
            fillRetries++
            fillRetried = true
            fillPending = true
            fillStep("retry ${fillRetries}: reloading the page")
            web?.reload()
            return
        }
        if (!textMissing && !photoMissing) commitJob(j) // text filled; photo set but not confirmed
        showBanner(textMissing, photoMissing || photoUnsure)
    }

    private fun showBanner(textMissing: Boolean, photoMissing: Boolean) {
        val j = job ?: return
        val hasText = !j.text.isNullOrBlank()
        linkBannerUrl = null
        bannerText.text = when {
            textMissing && hasText -> "Couldn't autofill, tap to copy text"
            else -> "Photo not attached yet. Tap the upload box on Zealy: your saved photo is picked automatically."
        }
        bannerText.isClickable = hasText
        bannerPhoto.visibility = if (j.photos.isNotEmpty()) View.VISIBLE else View.GONE
        bannerPhoto.text = if (j.photos.size > 1) "Saved photos" else "Saved photo"
        banner.visibility = View.VISIBLE
        if (textMissing && hasText) copySavedText(false)
    }

    private fun copySavedText(tapped: Boolean) {
        val t = job?.text?.takeIf { it.isNotBlank() } ?: return
        getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("QuestPilot saved text", t))
        if (tapped) toast("Saved text copied. Long-press the answer box on Zealy and paste.")
    }

    /** Banner button: choose a saved photo, attach it now if possible, and use it for the next file picker. */
    private fun pickSavedPhoto() {
        val j = job ?: return
        if (j.photos.isEmpty()) return
        val use = { f: java.io.File ->
            armedPhoto = f
            val w = web
            if (w != null && Autofill.matches(j, w.url)) {
                val js = Autofill.script(this)
                if (js != null) {
                    w.evaluateJavascript(js, null)
                    w.evaluateJavascript("window.__qpAttach(${Autofill.selectors(this)}, ${Autofill.payload(j, listOf(f))})", null)
                }
            }
            toast("If it isn't attached yet, tap the upload box on Zealy: your saved photo is picked automatically.")
        }
        if (j.photos.size == 1) use(j.photos[0])
        else AlertDialog.Builder(this)
            .setTitle("Saved photos")
            .setItems(j.photos.mapIndexed { i, f -> "Photo ${i + 1} (${f.name.takeLast(12)})" }.toTypedArray()) { _, which -> use(j.photos[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** WebView file picker: return the saved photo automatically, otherwise show the system picker. */
    private fun onFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
        val hidden = view === nextWeb
        if (!hidden) { chooserCallback?.onReceiveValue(null); chooserCallback = null }
        val j = if (hidden) nextJob else job
        val accept = params.acceptTypes.joinToString(",").lowercase()
        val acceptsImages = accept.isBlank() || accept.contains("image") || accept.contains("*") || Regex("\\.(jpe?g|png|webp)").containsMatchIn(accept)
        if (j != null && j.photos.isNotEmpty() && acceptsImages && Autofill.matches(j, view.url)) {
            val files = (if (hidden) null else armedPhoto?.let { listOf(it) })
                ?: if (params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) j.photos
                else listOf(j.photos[(if (hidden) nextPhotoCursor++ else photoCursor++) % j.photos.size])
            if (!hidden) armedPhoto = null
            try {
                cb.onReceiveValue(files.map { SavedPhotos.uri(this, it) }.toTypedArray())
                if (!hidden) {
                    fillStep("file chooser: returned saved photo ${files.joinToString { it.name.takeLast(14) }}")
                    commitJob(j)
                    banner.visibility = View.GONE
                    toast("Saved photo attached. Check it, then tap Claim.")
                }
                return true
            } catch (_: Exception) {
            }
        }
        if (hidden) { cb.onReceiveValue(null); return true } // never open the system picker from the waiting page
        fillStep(if (j == null) "file chooser: no saved content, system picker" else if (j.photos.isEmpty()) "file chooser: no saved photo, system picker"
            else if (!acceptsImages) "file chooser: page asks for '$accept', system picker" else "file chooser: not the quest page, system picker")
        chooserCallback = cb
        return try {
            @Suppress("DEPRECATION")
            startActivityForResult(params.createIntent(), REQ_CHOOSER)
            true
        } catch (_: Exception) {
            chooserCallback = null
            false
        }
    }

    @Deprecated("Activity result for the WebView file picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_CHOOSER) {
            chooserCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooserCallback = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    /** Test quests (debug builds) never trigger a sync of the real data. */
    private fun subOf(url: String) = if (queue.getOrNull(index)?.optString("source") == "test") "" else subOf0(url)
    private fun subOf0(url: String) = Regex("zealy\\.io/cw/([^/?#]+)").find(url)?.groupValues?.get(1) ?: ""

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        if (cfView != null) { cfView = null; CfChallenge.cleared(cfKey, "claim screen closed") }
        if (::links.isInitialized) links.destroy()
        activeBasis = 0L
        android.webkit.CookieManager.getInstance().flush()
        stopClaimCheck()
        SessionStore.captureFromWebView(this) // keep refreshed tokens
        try { EngagedLab.saveFromJar(this) } catch (_: Exception) {} // v2.4.3: keep *-engaged* flags
        web?.destroy()
        web = null
        discardNext()
        openCount--
        // v2.4.7 Fix 6d: cleared 60 s after the last claim page closed (cancelled if another one opens)
        if (openCount <= 0 && ManualRunActivity.openCount <= 0) SessionStore.scheduleClear()
        // A2: status only changes after a successful sync. Re-sync the communities we touched.
        // v2.4.7 Fix 6g: after 500 ms (was 2 s), in the priority lane of the gate.
        val subs = touchedSubs.filter { it.isNotEmpty() }
        val ctx = applicationContext
        if (subs.isNotEmpty() && SessionStore.hasSession(ctx)) Executors.newSingleThreadExecutor().execute {
            Thread.sleep(500)
            for (s in subs) ZealyGate.priority { ZealySync.syncAll(ctx, s) }
        }
        super.onDestroy()
    }
}
