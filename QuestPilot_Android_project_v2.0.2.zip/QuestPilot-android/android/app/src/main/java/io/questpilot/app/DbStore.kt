package io.questpilot.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors

/**
 * The app's data, stored in exactly the same shape the web app always used
 * (localStorage key "questpilot-db-v1"): {seq, communities, quests, alerts, submissions, settings}.
 * Only additive fields were introduced (quest.zealy, quest.unlockAt, alert.url, alert.unlockAt, settings.prefs/watchlist/...).
 */
object DbStore {
    const val FILE = "questpilot-db-v1.json"
    private lateinit var app: Context
    private val lock = Any()
    private val bg = Executors.newSingleThreadExecutor()

    fun init(ctx: Context) {
        app = ctx.applicationContext
        try { read() } catch (_: Exception) {} // v2.4.7: fills the in-memory copy and the prefs once at start
    }

    // ---- v2.4.7: in-memory copy of the parsed database ----
    // The parsed database is kept in memory and replaced (never modified in place) on every write, so read()
    // doesn't re-read and re-parse the file and doesn't wait for a sync that holds [lock]. The file is only
    // parsed again when it changed on disk (time / size differ from our own last write).
    // Never modify the object read() returns: mutate() / saveFromUi() work on their own copy.
    @Volatile private var cached: JSONObject? = null
    @Volatile private var cachedText: String? = null
    @Volatile private var cachedStamp = 0L to -2L
    /** Small separate copy of settings.prefs, refreshed on every write. pref() / prefs() only read this. */
    @Volatile private var cachedPrefs: JSONObject? = null

    private fun stampOf(f: File) = if (f.exists()) f.lastModified() to f.length() else 0L to -1L

    private fun remember(db: JSONObject, text: String, stamp: Pair<Long, Long>) {
        cached = db
        cachedText = text
        cachedStamp = stamp
        cachedPrefs = try { JSONObject(db.optJSONObject("settings")?.optJSONObject("prefs")?.toString() ?: "{}") } catch (_: Exception) { JSONObject() }
    }

    /** Under [lock]: the cached database, parsed again only when the file changed. */
    private fun current(): JSONObject {
        val f = file()
        val st = stampOf(f)
        cached?.let { if (st == cachedStamp) return it }
        val db = readRaw()
        remember(db, db.toString(), st)
        return db
    }

    /** A private copy to modify (from memory, not from the file). */
    private fun copyOfCurrent(): JSONObject {
        current()
        return try { normalize(JSONObject(cachedText ?: "{}")) } catch (_: Exception) { readRaw() }
    }

    private fun file() = File(app.filesDir, FILE)

    fun blank(): JSONObject = JSONObject()
        .put("seq", JSONObject().put("communities", 0).put("quests", 0).put("alerts", 0).put("submissions", 0))
        .put("communities", JSONArray()).put("quests", JSONArray()).put("alerts", JSONArray()).put("submissions", JSONArray())
        .put("settings", JSONObject().put("tgToken", "").put("tgChat", "").put("tzOffset", 0))

    private fun readRaw(): JSONObject = try {
        val f = file()
        if (f.exists()) normalize(JSONObject(f.readText())) else blank()
    } catch (e: Exception) {
        blank()
    }

    private fun normalize(o: JSONObject): JSONObject {
        val b = blank()
        for (k in listOf("communities", "quests", "alerts", "submissions")) if (o.optJSONArray(k) == null) o.put(k, b.getJSONArray(k))
        if (o.optJSONObject("seq") == null) o.put("seq", b.getJSONObject("seq"))
        if (o.optJSONObject("settings") == null) o.put("settings", b.getJSONObject("settings"))
        return o
    }

    /** Shared, read-only. Callers that want to change it must work on a copy (JSONObject(read().toString())). */
    fun read(): JSONObject {
        val t0 = System.nanoTime()
        val c = cached
        val out = if (c != null && stampOf(file()) == cachedStamp) c else synchronized(lock) { current() }
        val ms = (System.nanoTime() - t0) / 1_000_000L
        if (ms > 20) try { EventLog.add("perf", "DbStore.read() took $ms ms (file ${file().length() / 1024} KB, thread ${Thread.currentThread().name})") } catch (_: Exception) {}
        return out
    }

    /** v2.4.7: settings.prefs from memory. Never touches the file, never waits for a sync. Read-only. */
    fun prefs(): JSONObject = cachedPrefs ?: (try { prefs(read()) } catch (_: Exception) { JSONObject() })
    fun pref(k: String, def: Boolean) = prefs().optBoolean(k, def)

    fun load(): Pair<String, Long> = synchronized(lock) { current(); (cachedText ?: blank().toString()) to State.rev }

    /** Save from the web UI with optimistic concurrency. */
    fun saveFromUi(json: String, baseRev: Long): Triple<Boolean, String, Long> {
        val result: Triple<Boolean, String, Long>
        val newAlerts: List<JSONObject>
        synchronized(lock) {
            if (baseRev != State.rev) { current(); return Triple(false, cachedText ?: blank().toString(), State.rev) }
            val db = normalize(JSONObject(json))
            val before = db.getJSONObject("seq").optInt("alerts")
            postProcess(db)
            newAlerts = alertsAfter(db, before)
            writeRaw(db)
            result = Triple(true, cachedText ?: db.toString(), State.rev)
        }
        afterCommit(newAlerts)
        return result
    }

    /** Native-side mutation (sync, monitor, alarms, test mode). */
    fun <T> mutate(block: (JSONObject) -> T): T {
        val out: T
        val newAlerts: List<JSONObject>
        synchronized(lock) {
            val db = copyOfCurrent()
            val before = db.getJSONObject("seq").optInt("alerts")
            out = block(db)
            postProcess(db)
            newAlerts = alertsAfter(db, before)
            writeRaw(db)
        }
        afterCommit(newAlerts)
        return out
    }

    private fun writeRaw(db: JSONObject) {
        val tmp = File(app.filesDir, "$FILE.tmp")
        val text = db.toString()
        tmp.writeText(text)
        tmp.renameTo(file())
        remember(db, text, stampOf(file()))
        State.rev = State.rev + 1
    }

    private fun alertsAfter(db: JSONObject, beforeSeq: Int): List<JSONObject> {
        val arr = db.getJSONArray("alerts")
        val out = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) {
            val a = arr.getJSONObject(i)
            if (a.optInt("id") > beforeSeq && a.optInt("push", 1) == 1) out.add(a)
        }
        return out
    }

    /** Runs on every write: recompute unlock times (A1), scan sprint/deadline alerts. */
    /** Test-mode quests live only in DevTools' own debug file. Never in questpilot-db-v1. */
    private fun isTestQuest(q: JSONObject) = q.optString("source") == "test" || (q.has("testUnlockAt") && !q.isNull("testUnlockAt"))

    /** Removes any test quest (and its alerts / saved entries) from the real data. Returns true if anything changed. */
    private fun stripTestData(db: JSONObject): Boolean {
        val quests = db.getJSONArray("quests")
        val gone = mutableSetOf<Int>()
        val keep = JSONArray()
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            if (isTestQuest(q)) gone.add(q.optInt("id")) else keep.put(q)
        }
        val alerts = db.getJSONArray("alerts")
        val keepA = JSONArray()
        var droppedAlerts = false
        for (i in 0 until alerts.length()) {
            val a = alerts.getJSONObject(i)
            val qid = if (a.isNull("questId")) null else a.optInt("questId")
            if ((qid != null && qid in gone) || (qid != null && qid < 0)) droppedAlerts = true else keepA.put(a)
        }
        if (gone.isEmpty() && !droppedAlerts) return false
        db.put("quests", keep)
        db.put("alerts", keepA)
        val subs = db.getJSONArray("submissions")
        val keepS = JSONArray()
        for (i in 0 until subs.length()) subs.getJSONObject(i).let { if (it.optInt("questId") !in gone) keepS.put(it) }
        db.put("submissions", keepS)
        return true
    }

    /** One-time cleanup of test data written by older builds; runs at every start in all builds. */
    fun purgeTestData() {
        val needs = synchronized(lock) { stripTestData(copyOfCurrent()) }
        if (needs) mutate { stripTestData(it) }
    }

    private fun postProcess(db: JSONObject) {
        stripTestData(db) // guard: nothing test-related is ever saved to the real data
        val tz = db.getJSONObject("settings").optInt("tzOffset", 0)
        val quests = db.getJSONArray("quests")
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            val t = UnlockClock.unlockAt(q, tz)
            q.put("unlockAt", t ?: JSONObject.NULL)
            // v2.0.0: the reason, shown under the countdown
            val why = try { UnlockClock.explain(q, tz) } catch (_: Exception) { null }
            if (why != null) q.put("unlockWhy", why) else q.remove("unlockWhy")
        }
        AlertScanner.scan(db)
    }

    private fun afterCommit(newAlerts: List<JSONObject>) {
        val rev = State.rev
        bg.execute {
            try {
                AlarmScheduler.rescheduleAll(app)
            } catch (_: Exception) {
            }
            for (a in newAlerts) Notifications.postAlert(app, a)
            if (newAlerts.isNotEmpty()) Telegram.sendAlerts(app, newAlerts)
        }
        QuestPilotPlugin.emitDbChanged(rev)
    }

    // ---------- helpers shared by native code ----------
    fun nextId(db: JSONObject, table: String): Int {
        val seq = db.getJSONObject("seq")
        val n = seq.optInt(table) + 1
        seq.put(table, n)
        return n
    }

    fun findById(arr: JSONArray, id: Int): JSONObject? {
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optInt("id") == id) return arr.getJSONObject(i)
        return null
    }

    fun quest(db: JSONObject, id: Int) = findById(db.getJSONArray("quests"), id)
    fun community(db: JSONObject, id: Int) = findById(db.getJSONArray("communities"), id)

    fun prefs(db: JSONObject): JSONObject = db.getJSONObject("settings").optJSONObject("prefs") ?: JSONObject()
    fun pref(db: JSONObject, k: String, def: Boolean) = prefs(db).optBoolean(k, def)

    fun nowIso(): String = Instant.now().toString()

    private val clock = DateTimeFormatter.ofPattern("EEE HH:mm")
    fun localClock(ms: Long): String = clock.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

    /** Adds an alert (deduped). push=false when the caller posts its own notification. */
    fun addAlert(
        db: JSONObject, kind: String, title: String, body: String, questId: Int?, communityId: Int?,
        dedupeKey: String, url: String? = null, unlockAt: Long? = null, push: Boolean = true,
        time: ZealyTime.Stamp? = null,
    ): JSONObject? {
        val alerts = db.getJSONArray("alerts")
        for (i in 0 until alerts.length()) if (alerts.getJSONObject(i).optString("dedupeKey") == dedupeKey) return null
        // v2.4.7 Fix 5: "(Zealy 5:12 PM)" / "(detected 5:15 PM)" at the end of the text, the same in the
        // Alerts page entry and in the system notification (which shows this body)
        val text = if (time != null) "$body (${time.note})" else body
        val a = JSONObject()
            .put("id", nextId(db, "alerts")).put("kind", kind).put("title", title).put("body", text)
            .put("questId", questId ?: JSONObject.NULL).put("communityId", communityId ?: JSONObject.NULL)
            .put("dedupeKey", dedupeKey).put("createdAt", nowIso()).put("read", 0)
            .put("url", url ?: JSONObject.NULL).put("unlockAt", unlockAt ?: JSONObject.NULL)
            .put("push", if (push) 1 else 0)
        if (time != null) a.put("timeNote", time.note).put("timeField", time.field).put("zealyAt", time.at)
        val list = JSONArray().put(a)
        for (i in 0 until minOf(alerts.length(), 199)) list.put(alerts.get(i))
        db.put("alerts", list)
        return a
    }
}

object AlertScanner {
    /** Port of the original scanAlerts() for sprint ends and limited-task deadlines (24 h ahead). */
    fun scan(db: JSONObject) {
        val now = System.currentTimeMillis()
        val comms = db.getJSONArray("communities")
        for (i in 0 until comms.length()) {
            val c = comms.getJSONObject(i)
            if (c.optInt("notify", 1) != 1) continue
            val end = UnlockClock.parseTime(c.opt("sprintEndsAt")) ?: continue
            if (end > now && end - now <= 86_400_000L) {
                DbStore.addAlert(
                    db, "sprint", "${c.optString("name")}: sprint ends soon",
                    "${c.optString("sprintName").ifEmpty { "Sprint" }} ends ${DbStore.localClock(end)}",
                    null, c.optInt("id"), "sprint-24h-${c.optInt("id")}-${c.opt("sprintEndsAt")}",
                    "https://zealy.io/cw/${c.optString("subdomain")}/leaderboard",
                )
            }
        }
        val quests = db.getJSONArray("quests")
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            val c = DbStore.community(db, q.optInt("communityId")) ?: continue
            if (c.optInt("notify", 1) != 1 || q.optString("status") == "done") continue
            val dl = UnlockClock.parseTime(q.opt("deadline")) ?: continue
            if (dl > now && dl - now <= 86_400_000L) {
                DbStore.addAlert(
                    db, "deadline", q.optString("title"), "Deadline ${DbStore.localClock(dl)} · ${c.optString("name")}",
                    q.optInt("id"), c.optInt("id"), "deadline-${q.optInt("id")}-${q.opt("deadline")}", q.optString("url").ifEmpty { null },
                )
            }
        }
    }
}

/**
 * v2.4.7 Fix 5: the time a task or a message dropped on Zealy, in the phone's own time zone and 12 / 24 h format.
 * "Zealy 5:12 PM" for today, "Zealy Oct 17, 5:12 PM" for an earlier day; "detected 5:15 PM" when Zealy gave no time
 * (that is when QuestPilot first saw it).
 */
object ZealyTime {
    data class Stamp(val note: String, val field: String, val at: Long)

    fun clock(ms: Long): String {
        val ctx = QuestPilotApp.ctx
        val d = java.util.Date(ms)
        val time = if (ctx != null) android.text.format.DateFormat.getTimeFormat(ctx).format(d)
            else java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(d)
        val zone = ZoneId.systemDefault()
        val day = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
        val today = java.time.LocalDate.now(zone)
        if (day == today) return time
        val loc = java.util.Locale.getDefault()
        val skeleton = if (day.year == today.year) "MMMd" else "yMMMd"
        val datePart = java.text.SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(loc, skeleton), loc).format(d)
        return "$datePart, $time"
    }

    /** A Zealy time field ([field] = its name) as "Zealy <time>". */
    fun zealy(ms: Long, field: String, prefix: String = "Zealy") = Stamp("$prefix ${clock(ms)}", field, ms)

    /** No time from Zealy: when QuestPilot first saw it. */
    fun detected(ms: Long = System.currentTimeMillis()) = Stamp("detected ${clock(ms)}", "detected", ms)

    /** ISO / epoch value -> ms, or null. */
    fun parse(v: Any?): Long? = try { UnlockClock.parseTime(v) } catch (_: Exception) { null }
}
