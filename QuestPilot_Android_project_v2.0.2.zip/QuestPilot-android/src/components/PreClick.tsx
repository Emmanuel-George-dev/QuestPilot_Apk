import { useState } from "react";
import { Check, Globe, Heart, Repeat2, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { invalidateAll } from "@/lib/api";
import { refreshFromNative } from "@/lib/store";
import { QuestPilot, isNative } from "@/lib/native";
import { doneMark, needsLink, preclickButtons, type PreKind } from "@/lib/preclick";
import type { Quest } from "@/lib/types";

const ICON: Record<PreKind, typeof Heart> = { like: Heart, repost: Repeat2, follow: UserPlus, visit: Globe };

function clock(ms: number) {
  return new Date(ms).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

/**
 * v2.4.3 Part 2: "Pre-click" Like / Repost / Follow / Visit for a task: locked, unlocked or ready to claim.
 * Each button opens its link in the in-app overlay (you press everything on X / the site yourself).
 * v2.4.7: no paste field any more. Links come from the task details (sync / fast cycle) or the Find button.
 */
export function PreClick({ q, compact = false }: { q: Quest; compact?: boolean }) {
  const { toast } = useToast();
  const buttons = preclickButtons(q);
  const noLink = needsLink(q);
  // A Visit button is only a link: a missing Zealy id is no error there (it is marked on Zealy when the id arrives)
  const missing = noLink || buttons.some((b) => b.kind !== "visit" && doneMark(q, b.key)?.flag === "unavailable");
  const waiting = q.taskDetails?.state === "waiting";
  const [finding, setFinding] = useState(false);
  if (!buttons.length && !missing) return null;

  const press = async (key: string, url: string) => {
    if (!isNative) {
      toast({ title: "Pre-click works in the Android app" });
      return;
    }
    try {
      const r = await QuestPilot.preclick({ questId: q.id, kind: key, url });
      await refreshFromNative();
      invalidateAll();
      if (r && r.flag !== "written" && r.flag !== "already") toast({ title: "Opened, not marked on Zealy", description: r.note });
    } catch (e: any) {
      toast({ title: "Couldn't open the page", description: String(e?.message ?? e) });
    }
  };
  const findLink = async () => {
    if (!isNative) return;
    setFinding(true);
    try {
      const r = await QuestPilot.fetchTaskDetails({ questId: q.id });
      await refreshFromNative();
      invalidateAll();
      toast({ title: r.ok ? "Task details loaded" : "Couldn't load the task details", description: r.message });
    } catch (e: any) {
      toast({ title: "Couldn't load the task details", description: String(e?.message ?? e) });
    } finally {
      setFinding(false);
    }
  };
  const notes = buttons
    .filter((b) => b.kind !== "visit")
    .map((b) => doneMark(q, b.key))
    // an old "while locked" note on a task that is open now is out of date: not shown
    .filter((d) => d && (d.flag === "unavailable" || d.flag === "none") && !(q.locked === 0 && /while locked/i.test(d.note ?? "")));

  return (
    <div className={compact ? "mt-2" : "mt-3 rounded-xl border border-card-border bg-card p-3"} data-testid={`section-preclick-${q.id}`} onClick={(e) => e.stopPropagation()}>
      {!compact && <p className="text-sm font-semibold">Pre-click</p>}
      {buttons.length > 0 && (
        <div className="mt-1 flex flex-wrap gap-1.5">
          {buttons.map((b) => {
            // v2.0.0: a repeating task's marks reset with Zealy's daily / weekly reset
            const done = doneMark(q, b.key);
            const Icon = done ? Check : ICON[b.kind];
            return (
              <Button
                key={b.key}
                size="sm"
                variant={done ? "secondary" : "outline"}
                className="h-7 px-2.5 text-xs"
                onClick={() => press(b.key, b.url)}
                title={b.url}
                data-testid={`button-preclick-${b.key}-${q.id}`}
              >
                <Icon className={`mr-1 h-3.5 w-3.5 ${done ? "text-primary" : ""}`} />
                <span className="max-w-[9rem] truncate">{b.title}</span>
                {done ? <span className="ml-1 font-mono text-[10px] text-muted-foreground">{clock(done.at)}</span> : null}
                {done && (done.flag === "written" || done.flag === "already") ? <span className="ml-1 text-[10px] text-primary">on Zealy</span> : null}
              </Button>
            );
          })}
        </div>
      )}
      {notes.length > 0 && <p className="mt-1 text-[11px] text-amber-500" data-testid={`text-preclick-note-${q.id}`}>{notes[notes.length - 1]!.note}</p>}
      {(noLink || (missing && waiting)) && (
        <p className="mt-1 text-[11px] text-muted-foreground" data-testid={`text-preclick-hint-${q.id}`}>
          {waiting ? "Waiting for the next sync" : "No link yet. QuestPilot loads it with the next sync, or tap Find link and task id."}
        </p>
      )}
      {missing && isNative && (
        <Button size="sm" variant="ghost" className="mt-1 h-7 px-2 text-xs" onClick={findLink} disabled={finding} data-testid={`button-find-link-${q.id}`}>
          {finding ? "Loading..." : "Find link and task id"}
        </Button>
      )}
    </div>
  );
}
