import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowDown, ArrowUp, GripVertical, ListOrdered, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, invalidateAll } from "@/lib/api";
import { isNative, QuestPilot } from "@/lib/native";
import { fmtLeft, getUnlockTimestamp, isClaimableNow, isLockedNoTimer, isRecurring, manualRunNext, questStatus } from "@/lib/quest";
import type { Community, ManualRunPref, Quest } from "@/lib/types";

/**
 * v2.0.2 what a task is right now, from the same unlockAt as the claim run (UnlockClock):
 *   timed   known unlock in the future: a daily / weekly / monthly reset, or a one-time task locked until a date
 *   ready   claimable now
 *   locked  locked on Zealy with no unlock time known
 *   open / review / complete
 */
type Group = "timed" | "ready" | "locked" | "open" | "review" | "complete";
const GROUP_ORDER: Record<Group, number> = { timed: 0, ready: 1, locked: 2, open: 3, review: 4, complete: 5 };

function groupOf(q: Quest, now: number): Group {
  const t = getUnlockTimestamp(q);
  if (t !== null && t > now) return "timed";
  if (isClaimableNow(q, now)) return "ready";
  const s = questStatus(q);
  if (s === "complete") return "complete";
  if (s === "review") return "review";
  if (isLockedNoTimer(q) || s === "locked") return "locked";
  return "open";
}

const localTime = (ms: number) =>
  new Date(ms).toLocaleString([], { weekday: "short", hour: "2-digit", minute: "2-digit", second: "2-digit" });

function describe(q: Quest | undefined, now: number): string {
  if (!q) return "not found";
  const g = groupOf(q, now);
  const t = getUnlockTimestamp(q);
  if (g === "timed") {
    const when = `${fmtLeft(t! - now)} (${localTime(t!)})`;
    return isRecurring(q) ? `${q.recurrence} · resets in ${when}` : `locked · unlocks in ${when}`;
  }
  if (g === "ready") return isRecurring(q) ? `${q.recurrence} · ready` : "ready";
  if (g === "locked") return "locked · no unlock time known";
  if (g === "review") return "in review";
  if (g === "complete") return isRecurring(q) ? `${q.recurrence} · complete, next reset not known yet` : "complete";
  return isRecurring(q) ? `${q.recurrence} · open` : "open";
}

const FILTERS: { key: "all" | Group; label: string }[] = [
  { key: "all", label: "All" },
  { key: "timed", label: "Unlocking" },
  { key: "ready", label: "Ready" },
  { key: "locked", label: "Locked" },
  { key: "open", label: "Open" },
  { key: "complete", label: "Complete" },
];
const PAGE = 80;

/**
 * v2.0.2 Manual run: your own list of tasks from any community, locked or not, in your order. Start opens one
 * screen with a tab per task (all pages load at once); the claims you tap there go out one at a time. With
 * "Open automatically" on, the app opens it by itself 10 s before the earliest unlock among its tasks (daily /
 * weekly resets and dated locks, the same unlock time the claim run uses), also from the background.
 */
export function ManualRun({
  quests,
  byId,
  now,
  pref,
}: {
  quests: Quest[];
  byId: Map<number, Community>;
  now: number;
  pref: ManualRunPref | undefined;
}) {
  const { toast } = useToast();
  const stored = pref?.ids ?? [];
  const storedKey = stored.join(",");
  const auto = pref?.auto !== false;
  const [ids, setIds] = useState<number[]>(stored);
  const [picker, setPicker] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | Group>("all");
  const [shown, setShown] = useState(PAGE);
  const [drag, setDrag] = useState<number | null>(null);
  const rows = useRef<(HTMLLIElement | null)[]>([]);
  // Follow the stored list (another screen, the app), unless a drag is in progress.
  useEffect(() => {
    if (drag === null) setIds(stored);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storedKey]);

  const byQuest = useMemo(() => new Map(quests.map((q) => [q.id, q])), [quests]);
  const next = manualRunNext({ ids, auto }, quests, now);

  const saveIds = (list: number[]) => {
    setIds(list);
    apiRequest("POST", "/api/settings", { manualRunIds: list }).then(invalidateAll).catch(() => {});
  };
  const setAuto = (v: boolean) => {
    apiRequest("POST", "/api/settings", { manualRunAuto: v }).then(invalidateAll).catch(() => {});
  };
  const move = (from: number, to: number) => {
    if (to < 0 || to >= ids.length || from === to) return;
    const list = [...ids];
    const [x] = list.splice(from, 1);
    list.splice(to, 0, x);
    saveIds(list);
  };
  const remove = (id: number) => saveIds(ids.filter((x) => x !== id));
  const add = (id: number) => {
    if (!ids.includes(id)) saveIds([...ids, id]);
  };

  // Drag by the handle (pointer events): the row follows the finger, saved on release.
  const onDown = (i: number) => (e: React.PointerEvent) => {
    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setDrag(i);
  };
  const onMove = (e: React.PointerEvent) => {
    if (drag === null) return;
    const y = e.clientY;
    let target = drag;
    rows.current.forEach((el, j) => {
      if (!el) return;
      const r = el.getBoundingClientRect();
      if (y >= r.top && y <= r.bottom) target = j;
    });
    if (target !== drag) {
      setIds((cur) => {
        const list = [...cur];
        const [x] = list.splice(drag, 1);
        list.splice(target, 0, x);
        return list;
      });
      setDrag(target);
    }
  };
  const onUp = () => {
    if (drag === null) return;
    setDrag(null);
    if (ids.join(",") !== storedKey) saveIds(ids);
  };

  const start = async () => {
    if (!isNative) {
      toast({ title: "The manual run works in the Android app" });
      return;
    }
    try {
      await QuestPilot.startManualRun({ ids });
    } catch (e: any) {
      toast({ title: "Couldn't open the run", description: String(e?.message ?? e) });
    }
  };

  // Every task is offered (locked or not); the time-based order only matters while the picker is open.
  const slot = picker ? Math.floor(now / 5000) : 0;
  const candidates = useMemo(() => {
    const s = search.trim().toLowerCase();
    const t = slot ? slot * 5000 : now;
    return quests
      .filter((q) => !ids.includes(q.id))
      .map((q) => ({ q, g: groupOf(q, t) }))
      .filter(({ g }) => filter === "all" || g === filter)
      .filter(({ q }) => !s || q.title.toLowerCase().includes(s) || (byId.get(q.communityId)?.name ?? "").toLowerCase().includes(s))
      .sort(
        (a, b) =>
          GROUP_ORDER[a.g] - GROUP_ORDER[b.g] ||
          (getUnlockTimestamp(a.q) ?? Number.MAX_SAFE_INTEGER) - (getUnlockTimestamp(b.q) ?? Number.MAX_SAFE_INTEGER) ||
          a.q.title.localeCompare(b.q.title),
      )
      .map(({ q }) => q);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quests, ids, search, filter, byId, slot]);
  useEffect(() => setShown(PAGE), [search, filter, picker]);

  return (
    <section className="mt-3 rounded-xl border border-card-border bg-card p-3.5" data-testid="section-manual-run">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <ListOrdered className="h-4 w-4 text-primary" />
          <p className="text-sm font-bold">Manual run</p>
          {pref?.open && (
            <span className="rounded-md bg-accent px-1.5 py-0.5 text-[10px] font-semibold text-primary" data-testid="text-manual-run-open">
              Open
            </span>
          )}
        </div>
        <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => setPicker(true)} data-testid="button-manual-add">
          <Plus className="mr-1 h-3.5 w-3.5" /> Add tasks
        </Button>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        Your own order, any community, locked or not. Each task gets a tab; the claims you tap go out one at a time.
      </p>
      {ids.length > 0 ? (
        <ol className="mt-2 space-y-1.5" onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}>
          {ids.map((id, i) => {
            const q = byQuest.get(id);
            return (
              <li
                key={id}
                ref={(el) => (rows.current[i] = el)}
                className={`flex items-center gap-1.5 rounded-lg border p-1.5 ${drag === i ? "border-primary bg-accent/50" : "border-card-border"}`}
                data-testid={`row-manual-${id}`}
              >
                <span
                  className="grid h-8 w-6 shrink-0 cursor-grab touch-none place-items-center text-muted-foreground"
                  onPointerDown={onDown(i)}
                  aria-label="Drag to reorder"
                  data-testid={`handle-manual-${id}`}
                >
                  <GripVertical className="h-4 w-4" />
                </span>
                <span className="tabular w-5 shrink-0 text-center font-mono text-xs text-muted-foreground">{i + 1}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{q?.title ?? `Task ${id}`}</p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {q ? byId.get(q.communityId)?.name : ""} · {describe(q, now)}
                  </p>
                </div>
                <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === 0} onClick={() => move(i, i - 1)} aria-label="Move up" data-testid={`button-manual-up-${id}`}>
                  <ArrowUp className="h-3.5 w-3.5" />
                </Button>
                <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === ids.length - 1} onClick={() => move(i, i + 1)} aria-label="Move down" data-testid={`button-manual-down-${id}`}>
                  <ArrowDown className="h-3.5 w-3.5" />
                </Button>
                <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => remove(id)} aria-label="Remove" data-testid={`button-manual-remove-${id}`}>
                  <X className="h-3.5 w-3.5" />
                </Button>
              </li>
            );
          })}
        </ol>
      ) : (
        <p className="mt-2 text-xs text-muted-foreground">No tasks yet. Tap Add tasks.</p>
      )}
      {ids.length > 0 && (
        <>
          <div className="mt-3 flex items-center justify-between gap-3 rounded-lg bg-muted/40 p-2.5">
            <div className="min-w-0">
              <p className="text-xs font-semibold">Open automatically</p>
              <p className="text-[11px] text-muted-foreground" data-testid="text-manual-next">
                {!auto
                  ? "Off: the run only opens when you tap Start."
                  : next
                    ? `Opens ${localTime(next.opensAt)} (in ${fmtLeft(next.opensAt - now)}), 10 s before ${
                        next.quests.length === 1 ? `"${next.quests[0].title}"` : `${next.quests.length} tasks`
                      } unlock${next.quests.length === 1 ? "s" : ""}. Its tasks are left out of the normal claim run.`
                    : "No task here has a known unlock time yet. Tap Start, or add a task with a reset or unlock time."}
              </p>
            </div>
            <Switch checked={auto} onCheckedChange={setAuto} data-testid="switch-manual-auto" />
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            <Button size="sm" onClick={start} data-testid="button-manual-start">
              Start now
            </Button>
          </div>
        </>
      )}
      <Dialog open={picker} onOpenChange={setPicker}>
        <DialogContent className="max-h-[85dvh] max-w-[calc(100%-2rem)] grid-cols-[minmax(0,1fr)] overflow-y-auto overflow-x-hidden rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add to the manual run</DialogTitle>
            <DialogDescription>Every task of every community, locked or not. They run in the order you add them.</DialogDescription>
          </DialogHeader>
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tasks or communities" data-testid="input-manual-search" />
          <div className="mt-2 flex min-w-0 flex-wrap gap-1.5">
            {FILTERS.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold ${filter === f.key ? "border-primary bg-accent text-primary" : "border-card-border text-muted-foreground"}`}
                data-testid={`filter-manual-${f.key}`}
              >
                {f.label}
              </button>
            ))}
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground">{candidates.length} task{candidates.length === 1 ? "" : "s"}</p>
          <ul className="mt-1 min-w-0 space-y-1.5">
            {candidates.slice(0, shown).map((q) => (
              <li key={q.id} className="flex min-w-0 items-center gap-2 rounded-lg border border-card-border p-2">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{q.title}</p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {byId.get(q.communityId)?.name} · {describe(q, now)}
                  </p>
                </div>
                <Button size="sm" variant="secondary" className="h-7 shrink-0 px-2 text-xs" onClick={() => add(q.id)} data-testid={`button-manual-pick-${q.id}`}>
                  Add
                </Button>
              </li>
            ))}
            {!candidates.length && <li className="text-xs text-muted-foreground">Nothing else to add.</li>}
          </ul>
          {candidates.length > shown && (
            <Button variant="ghost" size="sm" className="mt-1 w-full text-xs" onClick={() => setShown((n) => n + PAGE)} data-testid="button-manual-more">
              Show more ({candidates.length - shown} left)
            </Button>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
