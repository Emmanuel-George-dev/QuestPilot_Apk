import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest, invalidateAll } from "@/lib/api";
import { chime, isClaimableNow, manualRunHandles, manualRunHolds, sortClaims } from "@/lib/quest";
import type { Prefs, Quest } from "@/lib/types";
import { useData } from "./useData";
import { useNow } from "./useNow";

// v2.4 defaults must match the native side (DbStore.pref(..., default)).
const DEFAULT_PREFS: Prefs = {
  autopilot: true, autoOpenTabs: true, autoNextClaim: false, sound: true, theme: "dark", onboarded: false,
  stage10m: true, stage5m: true, stage10s: true, stage3s: true,
  featInAppLinks: true, featLikeTimer: true, likeCloseSec: 3, featLikePreload: false, debugZealyRecorder: false, preclickWriteFlag: true, fetchTaskDetails: true, featPostSheet: true, featFollowSheet: true,
  debugFillSteps: false, allowedAppLinks: "", fullSyncMinutes: 30, sprintOnlyWatch: true,
};

interface Ctx {
  prefs: Prefs;
  setPref: <K extends keyof Prefs>(k: K, v: Prefs[K]) => void;
  autopilot: boolean;
  setAutopilot: (v: boolean) => void;
  autoOpenTabs: boolean;
  setAutoOpenTabs: (v: boolean) => void;
  autoNextClaim: boolean;
  setAutoNextClaim: (v: boolean) => void;
  sound: boolean;
  setSound: (v: boolean) => void;
  theme: "dark" | "light";
  setTheme: (v: "dark" | "light") => void;
  claimQueue: Quest[];
  takeoverOpen: boolean;
  dismissTakeover: () => void;
  skipClaim: (id: number) => void;
}

const AutopilotContext = createContext<Ctx | null>(null);
export const useAutopilot = () => useContext(AutopilotContext)!;

const CHIME_KINDS = new Set(["deadline", "sprint", "soon", "due", "quest-new", "quest-unlocked", "message", "session"]);

const NO_QUESTS: Quest[] = [];

export function AutopilotProvider({ children }: { children: ReactNode }) {
  // Preferences are now saved with the rest of the data (the old build kept them in memory only).
  const settings = useQuery<{ prefs: Partial<Prefs> }>({ queryKey: ["/api/settings"] });
  const [local, setLocal] = useState<Partial<Prefs>>({});
  // v2.0.2: manualRun always comes from the stored data, never from the local copy: the run screen writes
  // open / openedAt by itself, and a local copy would keep showing an old state.
  const prefs: Prefs = { ...DEFAULT_PREFS, ...(settings.data?.prefs ?? {}), ...local, manualRun: settings.data?.prefs?.manualRun };
  const setPref = <K extends keyof Prefs>(k: K, v: Prefs[K]) => {
    if (k === "manualRun") return; // written through manualRunIds / manualRunAuto and the app only
    setLocal((p) => ({ ...p, [k]: v }));
    apiRequest("POST", "/api/settings", { prefs: { [k]: v } }).then(invalidateAll).catch(() => {});
  };

  const [takeoverOpen, setTakeoverOpen] = useState(false);
  const [skipped, setSkipped] = useState<Set<string>>(new Set());
  const seenQueue = useRef<Set<string>>(new Set());
  const firstRun = useRef(false);
  const { quests, byId, alerts } = useData();
  const now = useNow(1000);
  const seenAlerts = useRef<Set<number> | null>(null);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", prefs.theme === "dark");
  }, [prefs.theme]);

  useEffect(() => {
    apiRequest("POST", "/api/settings", { tzOffset: -new Date().getTimezoneOffset() }).catch(() => {});
  }, []);

  // In-app chime for new alerts. System notifications are posted by the native side only.
  useEffect(() => {
    if (!alerts.length && seenAlerts.current) return;
    if (!seenAlerts.current) {
      seenAlerts.current = new Set(alerts.map((a) => a.id));
      return;
    }
    for (const a of alerts) {
      if (seenAlerts.current.has(a.id)) continue;
      seenAlerts.current.add(a.id);
      if (CHIME_KINDS.has(a.kind) && prefs.sound) chime();
    }
  }, [alerts, prefs.sound]);

  const key = (q: Quest) => `${q.id}-${q.unlockAt ?? ""}`;
  // v2.0.2 manual run: its tasks are left to it (open automatically on), and while its screen is open or opens
  // within 15 s the takeover waits. Same rules as the native alarms (ManualRun.handledIds / holdsClaimRun).
  const manualIdsKey = (prefs.manualRun?.auto !== false ? prefs.manualRun?.ids ?? [] : []).join(",");
  const manualIds = useMemo(() => manualRunHandles(prefs.manualRun), [manualIdsKey]); // eslint-disable-line react-hooks/exhaustive-deps
  const manualHold = manualRunHolds(prefs.manualRun, quests, now);
  const eligible = useMemo(
    () =>
      sortClaims(
        quests.filter((q) => isClaimableNow(q, now) && byId.get(q.communityId)?.notify && !manualIds.has(q.id) && !skipped.has(key(q))),
        byId,
        now,
      ),
    [quests, byId, now, skipped, manualIds],
  );
  const claimQueue = manualHold ? NO_QUESTS : eligible;

  useEffect(() => {
    if (takeoverOpen && !claimQueue.length) setTakeoverOpen(false);
  }, [claimQueue.length, takeoverOpen]);

  useEffect(() => {
    if (!quests.length) return;
    if (manualHold) {
      // Held: what opens meanwhile counts as seen, so the takeover does not cover the run when it closes.
      eligible.forEach((q) => seenQueue.current.add(key(q)));
      return;
    }
    const fresh = claimQueue.filter((q) => !seenQueue.current.has(key(q)));
    fresh.forEach((q) => seenQueue.current.add(key(q)));
    if (!firstRun.current) {
      firstRun.current = true;
      if (prefs.autopilot && claimQueue.length) setTakeoverOpen(true);
      return;
    }
    if (!prefs.autopilot || !fresh.length) return;
    if (prefs.sound) chime();
    setTakeoverOpen(true);
  }, [now, claimQueue, eligible, manualHold, prefs.autopilot, prefs.sound]);

  const value: Ctx = {
    prefs,
    setPref,
    autopilot: prefs.autopilot,
    setAutopilot: (v) => setPref("autopilot", v),
    autoOpenTabs: prefs.autoOpenTabs,
    setAutoOpenTabs: (v) => setPref("autoOpenTabs", v),
    autoNextClaim: !!prefs.autoNextClaim,
    setAutoNextClaim: (v) => setPref("autoNextClaim", v),
    sound: prefs.sound,
    setSound: (v) => setPref("sound", v),
    theme: prefs.theme,
    setTheme: (v) => setPref("theme", v),
    claimQueue,
    takeoverOpen,
    dismissTakeover: () => setTakeoverOpen(false),
    skipClaim: (id) => {
      const q = quests.find((x) => x.id === id);
      if (q) setSkipped((s) => new Set(s).add(key(q)));
    },
  };
  return <AutopilotContext.Provider value={value}>{children}</AutopilotContext.Provider>;
}
