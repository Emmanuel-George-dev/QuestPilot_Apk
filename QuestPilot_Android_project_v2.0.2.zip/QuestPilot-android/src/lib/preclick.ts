import type { Quest, XLink } from "@/lib/types";

/** v2.4.3: Pre-click button kinds. "visit" = any non-X link (website, Discord, Telegram, ...). */
export type PreKind = "like" | "repost" | "follow" | "visit";
export const PRE_LABEL: Record<PreKind, string> = { like: "Like", repost: "Repost", follow: "Follow", visit: "Visit" };

/** One button. [key] is unique per task ("follow", "follow-2", "visit-3"...) and stores its done state. */
export type PreButton = { key: string; kind: PreKind; url: string; label: string; title: string };

const STATUS_ID = /(?:x|twitter)\.com\/(?:[A-Za-z0-9_]+|i(?:\/web)?)\/status\/(\d+)/i;
const ORDER: PreKind[] = ["like", "repost", "follow", "visit"];

/** Tweet id from a pasted X post link, or null. */
export function tweetId(link: string | null | undefined): string | null {
  const m = (link ?? "").match(STATUS_ID);
  return m ? m[1] : null;
}

function short(url: string, kind: PreKind): string {
  try {
    const u = new URL(url);
    if (kind === "follow") {
      const n = u.searchParams.get("screen_name") ?? u.pathname.split("/").filter(Boolean)[0];
      return n ? `@${n}` : "";
    }
    if (kind === "visit") return u.hostname.replace(/^www\./, "");
  } catch {
    /* keep empty */
  }
  return "";
}

/** v2.4.7 Fix 4: tweet id from tweet_id= or /status/<id> (any host), or null. */
function anyTweetId(url: string): string | null {
  try {
    const u = new URL(url);
    const t = u.searchParams.get("tweet_id");
    if (t && /^\d+$/.test(t)) return t;
    const segs = u.pathname.split("/").filter(Boolean);
    const i = segs.findIndex((s) => /^status(es)?$/i.test(s));
    if (i >= 0 && segs[i + 1] && /^\d+$/.test(segs[i + 1])) return segs[i + 1];
  } catch {
    /* not a URL */
  }
  return null;
}

const HANDLE = /^[A-Za-z0-9_]{1,15}$/;
const RESERVED = new Set(["i", "intent", "home", "explore", "search", "hashtag", "settings", "messages", "notifications", "share", "compose"]);

function handleOf(url: string): string | null {
  const t = url.trim();
  if (t.startsWith("@")) return HANDLE.test(t.slice(1)) ? t.slice(1).toLowerCase() : null;
  try {
    const u = new URL(t);
    const sn = (u.searchParams.get("screen_name") ?? "").trim().replace(/^@/, "");
    if (sn && HANDLE.test(sn)) return sn.toLowerCase();
    const segs = u.pathname.split("/").filter(Boolean);
    if (segs.length === 1 && !RESERVED.has(segs[0].toLowerCase()) && HANDLE.test(segs[0])) return segs[0].toLowerCase();
  } catch {
    /* not a URL */
  }
  return null;
}

/** https, host lowercase without www., no #fragment, no utm_* / ref / s / t parameters (others sorted), no trailing slash. */
function cleanUrl(url: string): string {
  try {
    const u = new URL(url.trim());
    const keep: [string, string][] = [];
    u.searchParams.forEach((v, k) => {
      const n = k.toLowerCase();
      if (!n.startsWith("utm_") && n !== "ref" && n !== "s" && n !== "t") keep.push([k, v]);
    });
    keep.sort((a, b) => (a[0] === b[0] ? a[1].localeCompare(b[1]) : a[0].localeCompare(b[0])));
    const q = keep.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
    return `https://${u.host.toLowerCase().replace(/^www\./, "")}${u.pathname.replace(/\/+$/, "")}${q ? `?${q}` : ""}`;
  } catch {
    return url.trim().split("#")[0].replace(/\/+$/, "");
  }
}

/** discord.gg/<code>, discord.com/invite/<code> and t.me / telegram.me are one link each. */
function chatKey(url: string): string | null {
  try {
    const u = new URL(url.trim());
    const host = u.host.toLowerCase().replace(/^www\./, "");
    const segs = u.pathname.split("/").filter(Boolean);
    if (host === "discord.gg") return segs[0] ? `discord|${segs[0]}` : null;
    if ((host === "discord.com" || host === "discordapp.com") && segs.length >= 2 && segs[0].toLowerCase() === "invite") return `discord|${segs[1]}`;
    if ((host === "t.me" || host === "telegram.me" || host === "telegram.dog") && segs.length) return `telegram|${segs.join("/").toLowerCase()}`;
  } catch {
    /* not a URL */
  }
  return null;
}

/** v2.4.7 Fix 4: the same key the app uses (LinkKey): like / repost by tweet id, follow by handle, else clean URL. */
export function linkKey(kind: string, url: string): string {
  const k = kind === "other" ? "visit" : kind;
  if (k === "like" || k === "repost" || k === "post") return `${k}|${anyTweetId(url) ?? cleanUrl(url)}`;
  if (k === "follow") return `follow|${handleOf(url) ?? cleanUrl(url)}`;
  return `${k}|${chatKey(url) ?? cleanUrl(url)}`;
}

/** Task settings first, then the Zealy page, then the description. */
function rank(source?: string): number {
  return source === "task settings" ? 0 : source === "Zealy page" ? 1 : 2;
}

/**
 * Every Pre-click button of a task (locked, unlocked or ready): Like / Repost per post, Follow per profile,
 * Visit per other link, from the task details, the Zealy page and the description.
 * v2.4.7: the same link only once (canonical key); "Like 2" only for a genuinely different post.
 */
export function preclickButtons(q: Quest): PreButton[] {
  const byKey = new Map<string, XLink & { source?: string }>();
  // v2.0.0: a task whose task kinds are known and contain no X task (image upload, quiz, visit, ...) never gets
  // X buttons from the Zealy page scan (the page shows unrelated posts).
  const noX = hasKnownKinds(q) && !hasXTask(q);
  // The task settings name the task's own post. X links scanned from the Zealy page are then only noise.
  const hasSettings = (q.pageLinks ?? []).some((l) => (l as { source?: string }).source === "task settings");
  for (const l of [...(q.pageLinks ?? []), ...(q.xLinks ?? [])] as (XLink & { source?: string })[]) {
    if (noX && l.source === "Zealy page" && l.kind !== "other") continue;
    if (hasSettings && l.source === "Zealy page" && l.kind !== "other") continue;
    const k = linkKey(l.kind, l.url);
    const cur = byKey.get(k);
    if (!cur || rank(l.source) < rank(cur.source)) byKey.set(k, l);
  }
  // A link whose shown text is another link of the list is the same link: the copy pointing elsewhere is dropped.
  for (const [k, l] of [...byKey.entries()]) {
    if (l.kind !== "other") continue;
    const t = (l.label ?? "").trim();
    if (!t || /\s/.test(t)) continue;
    const shown = /^https?:\/\//i.test(t) ? t : /^[A-Za-z0-9.-]+\.[A-Za-z]{2,}(\/\S*)?$/.test(t) ? `https://${t}` : null;
    if (!shown) continue;
    const lk = linkKey("other", shown);
    if (lk !== k && byKey.has(lk)) byKey.delete(k);
  }
  const items: { kind: PreKind; url: string; label: string }[] = [];
  for (const l of byKey.values()) {
    if (l.kind === "post") continue;
    const kind: PreKind = l.kind === "other" ? "visit" : l.kind;
    items.push({ kind, url: l.url, label: l.label });
  }
  // Same order every time (by kind, then by link), so a button keeps its own done mark when the links are loaded again
  items.sort((a, b) => ORDER.indexOf(a.kind) - ORDER.indexOf(b.kind) || linkKey(a.kind, a.url).localeCompare(linkKey(b.kind, b.url)));
  const count: Record<string, number> = {};
  const total: Record<string, number> = {};
  items.forEach((i) => (total[i.kind] = (total[i.kind] ?? 0) + 1));
  return items.map((i) => {
    const n = (count[i.kind] = (count[i.kind] ?? 0) + 1);
    const s = short(i.url, i.kind);
    let title = total[i.kind] > 1 || i.kind === "visit" ? `${PRE_LABEL[i.kind]}${s ? ` ${s}` : n > 1 ? ` ${n}` : ""}` : PRE_LABEL[i.kind];
    // two different pages on the same site: show which page, so they are not mistaken for the same link
    if (i.kind === "visit" && s && items.filter((o) => o.kind === "visit" && short(o.url, "visit") === s).length > 1) {
      try {
        const u = new URL(i.url);
        const p = u.pathname.replace(/\/+$/, "");
        if (p) title = `${title}${p.length > 18 ? `${p.slice(0, 17)}…` : p}`;
      } catch {
        /* keep the host only */
      }
    }
    return { key: n === 1 ? i.kind : `${i.kind}-${n}`, kind: i.kind, url: i.url, label: i.label, title };
  });
}

function hasKnownKinds(q: Quest): boolean {
  return (q.taskKinds ?? "").split(",").some((k) => k.trim() !== "");
}

function hasXTask(q: Quest): boolean {
  return /twitter|tweet/i.test(q.taskKinds ?? "") || q.type === "twitter";
}

/** v2.0.0: a visit-link task without its Visit button yet. */
export function needsVisitLink(q: Quest): boolean {
  if (!/visit|link/i.test(q.taskKinds ?? "") && q.type !== "link") return false;
  return ![...(q.xLinks ?? []), ...(q.pageLinks ?? [])].some((x) => x.kind === "other");
}

/** v2.0.0: Find link / "No link yet" for X tasks without a post link and for visit tasks without their link. */
export function needsLink(q: Quest): boolean {
  return needsPostLink(q) || needsVisitLink(q);
}

/**
 * v2.0.0: start of the current Zealy period of a repeating task (daily 00:00 UTC, weekly Monday 00:00 UTC,
 * monthly the 1st 00:00 UTC). A Pre-click mark from before it belongs to the previous period. 0 for one-time.
 */
export function periodStart(q: Pick<Quest, "recurrence">, now = Date.now()): number {
  const d = new Date(now);
  const day = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
  if (q.recurrence === "daily") return day;
  if (q.recurrence === "weekly") return day - ((d.getUTCDay() + 6) % 7) * 86_400_000;
  if (q.recurrence === "monthly") return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1);
  return 0;
}

/** v2.0.0: the button's done mark, only when it is from the current period (repeating tasks reset). */
export function doneMark(q: Quest, key: string, now = Date.now()) {
  const m = q.preclick?.[key];
  if (!m) return undefined;
  return m.at >= periodStart(q, now) ? m : undefined;
}

/** True when the description had no post link (so Like / Repost can't be built) but the task looks like an X task. */
export function needsPostLink(q: Quest): boolean {
  if ([...(q.xLinks ?? []), ...(q.pageLinks ?? [])].some((x) => x.kind === "post" || x.kind === "like" || x.kind === "repost")) return false;
  const xTask = hasXTask(q);
  // v2.0.0: words in the description only count when the task kinds are unknown (an image task that says
  // "like" in its text is not an X task)
  const words = !hasKnownKinds(q) && /\b(like|repost|retweet|rt)\b/i.test(q.notes ?? "");
  return xTask || words;
}
