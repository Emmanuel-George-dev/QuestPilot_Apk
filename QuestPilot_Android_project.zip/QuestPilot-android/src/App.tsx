import { QueryClientProvider } from "@tanstack/react-query";
import { Route, Router, Switch } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ClaimTakeover } from "@/components/ClaimTakeover";
import { Layout } from "@/components/Layout";
import { Onboarding } from "@/components/Permissions";
import { AutopilotProvider } from "@/hooks/autopilot";
import { queryClient } from "@/lib/api";
import Alerts from "@/pages/Alerts";
import Monitor from "@/pages/Monitor";
import NotFound from "@/pages/NotFound";
import Settings from "@/pages/Settings";
import Sprints from "@/pages/Sprints";
import Sites from "@/pages/Sites";
import Debug from "@/pages/Debug";
import Tasks from "@/pages/Tasks";
import Today from "@/pages/Today";

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AutopilotProvider>
          <Router hook={useHashLocation}>
            <Layout>
              <Switch>
                <Route path="/" component={Today} />
                <Route path="/quests" component={Tasks} />
                <Route path="/sprints" component={Sprints} />
                <Route path="/alerts" component={Alerts} />
                <Route path="/settings" component={Settings} />
                <Route path="/monitor" component={Monitor} />
                <Route path="/sites" component={Sites} />
                <Route path="/debug" component={Debug} />
                <Route component={NotFound} />
              </Switch>
            </Layout>
            <ClaimTakeover />
            <Onboarding />
          </Router>
          <Toaster />
        </AutopilotProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
