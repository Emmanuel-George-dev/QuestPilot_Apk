import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { SectionTitle } from "@/components/common";
import { useAutopilot } from "@/hooks/autopilot";
import { useToast } from "@/hooks/use-toast";
import { isNative, QuestPilot } from "@/lib/native";

type Engaged = Awaited<ReturnType<typeof QuestPilot.getEngaged>>;
type Snap = { at: number; cookies: Record<string, string> };

const clock = (t: number) => new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
const snapOf = (e: Engaged): Snap => ({ at: e.at, cookies: Object.fromEntries(e.cookies.map((c: any) => [c.name, c.value])) });

function Toggle({ k, def, title, body }: { k: "debugZealyRecorder" | "preclickWriteFlag" | "fetchTaskDetails"; def: boolean; title: string; body: string }) {
  const ap = useAutopilot();
  const v = ap.prefs[k];
  return (
    <div className="flex items-center justify-between gap-3 p-3.5">
      <div>
        <p className="text-sm font-semibold">{title}</p>
        <p className="text-xs text-muted-foreground">{body}</p>
      </div>
      <Switch checked={typeof v === "boolean" ? v : def} onCheckedChange={(x) => ap.setPref(k, x as never)} data-testid={`switch-${k}`} />
    </div>
  );
}

const Pre = ({ v, testid }: { v: unknown; testid?: string }) => (
  <pre className="mt-1 max-h-64 overflow-auto whitespace-pre-wrap break-all rounded-lg bg-muted/50 p-2 font-mono text-[10px] leading-snug" data-testid={testid}>
    {typeof v === "string" ? v : JSON.stringify(v, null, 1)}
  </pre>
);

/** v2.4.3 Part 3: engaged cookie watcher, Match ids, Zealy page request recorder, raw quest data. */
export function EngagedDebug() {
  const { toast } = useToast();
  const [e, setE] = useState<Engaged | null>(null);
  const [before, setBefore] = useState<Snap | null>(null);
  const [after, setAfter] = useState<Snap | null>(null);
  const [rec, setRec] = useState<{ at: number; request: string; body: string }[]>([]);
  const [raw, setRaw] = useState<{ raw: Record<string, any>; taskIds: Record<string, any> } | null>(null);
  const [rawKey, setRawKey] = useState<string>("");

  const load = async () => {
    if (!isNative) return null;
    try {
      const r = await QuestPilot.getEngaged();
      setE(r);
      QuestPilot.getZealyRecorder().then((x) => setRec(x.entries)).catch(() => {});
      QuestPilot.getRawQuests().then(setRaw).catch(() => {});
      return r;
    } catch {
      return null;
    }
  };
  useEffect(() => {
    load();
  }, []);

  const snap = async (which: "before" | "after") => {
    const r = await load();
    if (!r) return;
    which === "before" ? (setBefore(snapOf(r)), setAfter(null)) : setAfter(snapOf(r));
  };

  const diff = (() => {
    if (!before || !after) return null;
    const names = new Set([...Object.keys(before.cookies), ...Object.keys(after.cookies)]);
    const rows: { name: string; change: string; before?: string; after?: string }[] = [];
    names.forEach((n) => {
      const a = before.cookies[n];
      const b = after.cookies[n];
      if (a === b) return;
      rows.push({ name: n, change: a === undefined ? "added" : b === undefined ? "removed" : "changed", before: a, after: b });
    });
    const overlay = (e?.overlay ?? []).filter((o: any) => o.at >= before.at && o.at <= after.at).reverse();
    const writes = (e?.writes ?? []).filter((w: any) => w.at >= before.at && w.at <= after.at).reverse();
    return { from: clock(before.at), to: clock(after.at), rows, overlay, writes };
  })();

  const report = () =>
    JSON.stringify(
      { diff, cookies: e?.cookies, matches: e?.matches, writes: e?.writes?.slice(0, 10), learned: e?.learned, overlay: e?.overlay?.slice(0, 12), recorder: rec.slice(0, 8) },
      null,
      1,
    );
  const copy = async () => {
    const t = report();
    try {
      await navigator.clipboard.writeText(t);
      toast({ title: "Report copied" });
    } catch {
      const ta = document.createElement("textarea");
      ta.value = t;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      toast({ title: "Report copied" });
    }
  };

  const rawKeys = Object.keys(raw?.raw ?? {});
  return (
    <div data-testid="section-engaged-debug">
      <SectionTitle>Pre-click: engaged cookie watcher</SectionTitle>
      <div className="rounded-xl border border-card-border bg-card p-3.5">
        <p className="text-xs text-muted-foreground">
          Zealy's own clicked flags (cookies named *-engaged*). They are harmless flags, so they are shown in full. Android only gives name and value; the
          attributes come from the write Zealy's page makes, seen by the app. Steps: Snapshot before, open an unlocked X task, tap Like on the Zealy page,
          come back here, Snapshot after, then Copy report.
        </p>
        <div className="mt-2 flex flex-wrap gap-1.5">
          <Button size="sm" variant="secondary" onClick={() => snap("before")} data-testid="button-engaged-before">Snapshot before</Button>
          <Button size="sm" variant="secondary" onClick={() => snap("after")} disabled={!before} data-testid="button-engaged-after">Snapshot after</Button>
          <Button size="sm" variant="ghost" onClick={load} data-testid="button-engaged-refresh">Refresh</Button>
          <Button size="sm" variant="ghost" onClick={copy} data-testid="button-engaged-copy">Copy report</Button>
        </div>
        {before && <p className="mt-1.5 text-[11px] text-muted-foreground">Before: {clock(before.at)} ({Object.keys(before.cookies).length} cookies){after ? ` · After: ${clock(after.at)}` : ""}</p>}
        {diff && (
          <div className="mt-2" data-testid="section-engaged-diff">
            <p className="text-xs font-semibold">Changed between {diff.from} and {diff.to}</p>
            {diff.rows.length ? <Pre v={diff.rows} /> : <p className="text-xs text-muted-foreground">No *-engaged* cookie changed.</p>}
            <p className="mt-1.5 text-xs font-semibold">X overlay opened / closed</p>
            {diff.overlay.length ? (
              <ul className="text-[11px] font-mono">
                {diff.overlay.map((o: any, i: number) => (
                  <li key={i}>{clock(o.at)} {o.what} {o.kind} {o.url}</li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-muted-foreground">No overlay in this window.</p>
            )}
            <p className="mt-1.5 text-xs font-semibold">Writes by Zealy's page in this window</p>
            {diff.writes.length ? <Pre v={diff.writes} /> : <p className="text-xs text-muted-foreground">None seen (if a cookie changed anyway, Zealy set it from its server).</p>}
          </div>
        )}
        <p className="mt-3 text-xs font-semibold">Now in the cookie jar ({e?.cookies.length ?? 0}, {e?.stored ?? 0} kept in encrypted storage)</p>
        {e?.cookies.length ? <Pre v={e.cookies} testid="text-engaged-cookies" /> : <p className="text-xs text-muted-foreground">No *-engaged* cookie yet.</p>}
        <p className="mt-3 text-xs font-semibold">Match ids</p>
        {e?.matches.length ? (
          <ul className="mt-1 space-y-1 text-[11px]" data-testid="list-engaged-matches">
            {e.matches.map((m: any) => (
              <li key={m.name}>
                <span className="font-mono">{m.uuid ?? m.name}</span>: {m.matches.length ? m.matches.join("; ") : <span className="text-amber-500">no match in quest ids, category ids, task ids or raw data</span>}
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-xs text-muted-foreground">Nothing to match yet.</p>
        )}
        <p className="mt-3 text-xs font-semibold">Learned writes (Part 4 replays only these)</p>
        {e?.learned.length ? <Pre v={e.learned} /> : <p className="text-xs text-muted-foreground">None yet: pre-click won't write Zealy's flag until one is seen.</p>}
      </div>
      <div className="mt-2 divide-y divide-border/60 rounded-xl border border-card-border bg-card">
        <Toggle k="preclickWriteFlag" def title="Pre-click: write Zealy's clicked flag" body="Only for the button you pressed, after you pressed it: the same cookie Zealy's page writes (task id from Zealy's quest data). Off = buttons only open the page." />
        <Toggle k="fetchTaskDetails" def title="Load task details for X / visit tasks" body="During sync: one request per task (the same one Zealy's quest page makes), once per task (repeating tasks once a day), at most 25 per sync, through the shared gate. Covers X / visit tasks and every locked task. Gives the post link and task id." />
        <Toggle
          k="debugZealyRecorder"
          def={false}
          title="Zealy page request recorder"
          body="Logs path, status and first 2 KB (masked) of the Zealy page's own quest requests, and keeps the task ids it sees. Applies to Zealy pages opened after switching."
        />
      </div>
      {rec.length > 0 && (
        <div className="mt-2 rounded-xl border border-card-border bg-card p-3.5" data-testid="section-zealy-recorder">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold">Recorded Zealy page requests ({rec.length})</p>
            <Button size="sm" variant="ghost" onClick={() => QuestPilot.clearZealyRecorder().then(load)} data-testid="button-recorder-clear">Clear</Button>
          </div>
          {rec.slice(0, 15).map((r, i) => (
            <div key={i} className="mt-2">
              <p className="font-mono text-[11px]">{clock(r.at)} {r.request}</p>
              <Pre v={r.body} />
            </div>
          ))}
        </div>
      )}
      <div className="mt-2 rounded-xl border border-card-border bg-card p-3.5" data-testid="section-raw-quests">
        <p className="text-sm font-semibold">Raw tasks + description ({rawKeys.length} quests with an X task or X link)</p>
        <select className="mt-2 w-full rounded-md border border-input bg-background p-2 text-xs" value={rawKey} onChange={(x) => setRawKey(x.target.value)} data-testid="select-raw-quest">
          <option value="">Pick a quest</option>
          {rawKeys.map((k) => (
            <option key={k} value={k}>{raw!.raw[k]?.title ?? k} ({raw!.raw[k]?.subdomain})</option>
          ))}
        </select>
        {rawKey && <Pre v={{ zealyId: rawKey, ...raw!.raw[rawKey], taskIdsSeenOnZealyPage: raw!.taskIds[rawKey] ?? null }} testid="text-raw-quest" />}
      </div>
    </div>
  );
}
