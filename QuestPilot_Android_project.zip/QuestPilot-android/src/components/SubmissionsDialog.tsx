import { useEffect, useRef, useState } from "react";
import { BookmarkCheck, ImagePlus, Pencil, Repeat, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { invalidateSubmissions, useSubmissions } from "@/hooks/useSubmissions";
import { apiRequest } from "@/lib/api";
import { acceptsPhoto, acceptsText } from "@/lib/quest";
import { cn } from "@/lib/utils";
import type { Quest, SavedImage, Submission } from "@/lib/types";

async function readImage(file: File): Promise<SavedImage> {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = rej;
      i.src = url;
    });
    const scaled = (max: number, quality: number) => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k);
      c.height = Math.round(img.height * k);
      c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
      return c.toDataURL("image/jpeg", quality);
    };
    const base = file.name.replace(/\.[^.]+$/, "") || "submission";
    return { data: scaled(1600, 0.85), thumb: scaled(160, 0.7), name: `${base}.jpg` };
  } finally {
    URL.revokeObjectURL(url);
  }
}

export const imagesOf = (s: Submission): SavedImage[] =>
  s.images?.length ? s.images : s.thumb || s.image ? [{ name: s.imageName || "submission.jpg", thumb: s.thumb || s.image || "", data: s.image }] : [];

/**
 * Saved submissions. The saved entry ("every claim") is kept forever and reused each time the
 * quest opens; optional one-time entries are used in order. Sync never touches these.
 */
export function SubmissionsDialog({ quest, open, onOpenChange }: { quest: Quest; open: boolean; onOpenChange: (v: boolean) => void }) {
  const { forQuest } = useSubmissions();
  const { toast } = useToast();
  const [editing, setEditing] = useState<number | null>(null); // submission id or null = new
  const [text, setText] = useState("");
  const [imgs, setImgs] = useState<SavedImage[]>([]);
  const [once, setOnce] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const wantText = acceptsText(quest);
  const wantPhoto = acceptsPhoto(quest);

  const list = forQuest(quest.id);
  const nextId = (list.find((s) => !s.repeat && !s.usedAt) ?? list.find((s) => s.repeat))?.id;

  const reset = () => {
    setEditing(null);
    setText("");
    setImgs([]);
    setOnce(false);
    if (fileRef.current) fileRef.current.value = "";
  };
  useEffect(() => {
    if (!open) reset();
  }, [open]);

  const pick = async (files: FileList | null) => {
    if (!files?.length) return;
    try {
      const read = await Promise.all([...files].map(readImage));
      setImgs((cur) => [...cur, ...read].slice(0, 10));
    } catch {
      toast({ title: "Couldn't read that image" });
    }
    if (fileRef.current) fileRef.current.value = "";
  };
  const edit = (s: Submission) => {
    setEditing(s.id);
    setText(s.text ?? "");
    setImgs(imagesOf(s));
    setOnce(!s.repeat);
  };
  const save = async () => {
    setSaving(true);
    try {
      const body = { text, images: imgs, repeat: !once };
      if (editing) await apiRequest("PATCH", `/api/submissions/${editing}`, body);
      else await apiRequest("POST", `/api/quests/${quest.id}/submissions`, body);
      reset();
      invalidateSubmissions();
      toast({ title: once ? "Queued for the next claim" : "Saved", description: "It fills in automatically when you open this quest." });
    } catch (e) {
      toast({ title: "Couldn't save", description: String((e as Error).message).slice(0, 100) });
    }
    setSaving(false);
  };
  const del = async (id: number) => {
    await apiRequest("DELETE", `/api/submissions/${id}`);
    if (editing === id) reset();
    invalidateSubmissions();
  };
  const requeue = async (id: number) => {
    await apiRequest("PATCH", `/api/submissions/${id}`, { used: false });
    invalidateSubmissions();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] max-w-[calc(100%-2rem)] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Saved submissions</DialogTitle>
          <DialogDescription className="line-clamp-2">
            {quest.title} · {[wantText && "text", wantPhoto && "photo"].filter(Boolean).join(" + ") || "any"} task
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2" data-testid="list-submissions">
          {!list.length && (
            <p className="rounded-lg border border-dashed border-border p-4 text-center text-sm text-muted-foreground">
              Nothing saved yet. Save your answer and photos once and they fill in every time you open this quest.
            </p>
          )}
          {list.map((s) => {
            const isNext = s.id === nextId;
            const used = !!s.usedAt && !s.repeat;
            const ims = imagesOf(s);
            return (
              <div
                key={s.id}
                data-testid={`row-submission-${s.id}`}
                className={cn(
                  "flex gap-3 rounded-lg border p-2.5",
                  isNext ? "border-primary/60 bg-accent/40" : "border-border",
                  used && "opacity-55",
                  editing === s.id && "ring-2 ring-primary/60",
                )}
              >
                {ims.length ? (
                  <div className="relative h-14 w-14 shrink-0">
                    <img src={ims[0].thumb} alt="" className="h-14 w-14 rounded-md object-cover" />
                    {ims.length > 1 && (
                      <span className="absolute bottom-0.5 right-0.5 rounded bg-black/70 px-1 text-[10px] font-bold text-white">+{ims.length - 1}</span>
                    )}
                  </div>
                ) : (
                  <span className="grid h-14 w-14 shrink-0 place-items-center rounded-md bg-muted text-xs text-muted-foreground">Text</span>
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] font-bold uppercase tracking-wider">
                    {used ? (
                      <span className="text-muted-foreground">Used {new Date(s.usedAt!).toLocaleDateString()}</span>
                    ) : s.repeat ? (
                      <span className="text-primary">Saved · every claim</span>
                    ) : (
                      <span className={isNext ? "text-primary" : "text-muted-foreground"}>{isNext ? "Next claim · once" : "Queued · once"}</span>
                    )}
                  </p>
                  <p className="mt-0.5 line-clamp-2 text-sm">
                    {s.text || <span className="text-muted-foreground">{ims.length} photo{ims.length === 1 ? "" : "s"}</span>}
                  </p>
                  <div className="mt-1 flex items-center gap-3 text-xs">
                    <button className="inline-flex items-center gap-1 font-semibold text-primary" onClick={() => edit(s)} data-testid={`button-edit-submission-${s.id}`}>
                      <Pencil className="h-3 w-3" />
                      Edit
                    </button>
                    {used && (
                      <button className="font-semibold text-primary" onClick={() => requeue(s.id)}>
                        Queue again
                      </button>
                    )}
                  </div>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 shrink-0"
                  aria-label="Delete saved submission"
                  onClick={() => del(s.id)}
                  data-testid={`button-delete-submission-${s.id}`}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            );
          })}
        </div>
        <div className="space-y-2.5 rounded-xl border border-border p-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold">{editing ? "Edit saved content" : "Save content"}</p>
            {editing && (
              <button className="text-xs font-semibold text-muted-foreground" onClick={reset}>
                Cancel
              </button>
            )}
          </div>
          <Textarea
            rows={3}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={wantText ? "Answer, link or caption to fill into the text box…" : "Optional text"}
            data-testid="input-submission-text"
          />
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => pick(e.target.files)}
            data-testid="input-submission-file"
          />
          <div className="flex flex-wrap items-center gap-2">
            {imgs.map((im, i) => (
              <div key={i} className="relative">
                <img src={im.thumb} alt={`Saved photo ${i + 1}`} className="h-16 w-16 rounded-md object-cover" />
                <button
                  className="absolute -right-2 -top-2 grid h-6 w-6 place-items-center rounded-full bg-foreground text-background"
                  aria-label="Remove photo"
                  onClick={() => setImgs((cur) => cur.filter((_, j) => j !== i))}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
            <Button variant="secondary" size="sm" onClick={() => fileRef.current?.click()} data-testid="button-pick-image">
              <ImagePlus className="mr-1.5 h-4 w-4" />
              {imgs.length ? "Add more" : "Add photos"}
            </Button>
          </div>
          <label className="flex items-center justify-between text-sm">
            <span className="inline-flex items-center gap-1.5">
              <Repeat className="h-3.5 w-3.5 text-muted-foreground" />
              Use once only (queue)
            </span>
            <Switch checked={once} onCheckedChange={setOnce} data-testid="switch-submission-once" />
          </label>
          <Button className="w-full" onClick={save} disabled={saving || (!text.trim() && !imgs.length)} data-testid="button-save-submission">
            <BookmarkCheck className="mr-1.5 h-4 w-4" />
            {saving ? "Saving…" : editing ? "Save changes" : "Save"}
          </Button>
        </div>
        <div className="rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">
          <p className="font-semibold text-foreground">How autofill works</p>
          <p className="mt-1">
            Opening this quest loads it in QuestPilot's signed-in Zealy view and fills in your text. When Zealy opens the file picker, your saved
            photo is returned automatically. For daily quests the page loads 3 seconds before unlock and fills as soon as it unlocks. QuestPilot
            never taps Claim or Submit. Check it and tap Claim yourself.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
