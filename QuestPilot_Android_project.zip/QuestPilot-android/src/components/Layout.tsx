import type { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Bell, Gauge, ListChecks, Settings2, Trophy } from "lucide-react";
import { Logo } from "@/components/Logo";
import { useAutopilot } from "@/hooks/autopilot";
import { useData } from "@/hooks/useData";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/", label: "Today", icon: Gauge },
  { href: "/quests", label: "Tasks", icon: ListChecks },
  { href: "/sprints", label: "Sprints", icon: Trophy },
  { href: "/alerts", label: "Alerts", icon: Bell },
];

export function Layout({ children }: { children: ReactNode }) {
  const [loc] = useLocation();
  const { alerts } = useData();
  const { autopilot } = useAutopilot();
  const unread = alerts.filter((a) => !a.read).length;
  return (
    <div className="min-h-dvh bg-background">
      <div className="mx-auto flex min-h-dvh max-w-md flex-col border-x border-border/60 bg-background">
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border/60 bg-background/85 px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))] backdrop-blur">
          <Link href="/" className="flex items-center gap-2 text-primary" data-testid="link-home">
            <Logo className="h-7 w-7" />
            <span className="font-display text-lg font-extrabold text-foreground">QuestPilot</span>
          </Link>
          <div className="flex items-center gap-2">
            <span
              data-testid="status-autopilot"
              className={cn(
                "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium",
                autopilot ? "border-primary/40 text-primary" : "border-border text-muted-foreground",
              )}
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", autopilot ? "bg-primary pulse-dot" : "bg-muted-foreground")} />
              {autopilot ? "Autopilot on" : "Autopilot off"}
            </span>
            <Link href="/settings" aria-label="Settings" data-testid="link-settings" className="rounded-md p-2 text-muted-foreground hover-elevate">
              <Settings2 className="h-5 w-5" />
            </Link>
          </div>
        </header>
        <main className="flex-1 px-4 pb-28 pt-4">{children}</main>
        <nav className="fixed bottom-0 left-1/2 z-30 w-full max-w-md -translate-x-1/2 border-t border-border/60 bg-background/90 pb-[env(safe-area-inset-bottom)] backdrop-blur">
          <ul className="grid grid-cols-4">
            {NAV.map(({ href, label, icon: Icon }) => {
              const active = href === "/" ? loc === "/" : loc.startsWith(href);
              return (
                <li key={href}>
                  <Link
                    href={href}
                    data-testid={`nav-${label.toLowerCase()}`}
                    className={cn(
                      "relative flex flex-col items-center gap-1 py-2.5 text-xs font-medium transition-colors",
                      active ? "text-primary" : "text-muted-foreground",
                    )}
                  >
                    <span className="relative">
                      <Icon className="h-5 w-5" />
                      {label === "Alerts" && unread > 0 && (
                        <span
                          data-testid="badge-unread"
                          className="absolute -right-2.5 -top-1.5 min-w-[18px] rounded-full bg-destructive px-1 text-center text-[11px] font-bold leading-[18px] text-white"
                        >
                          {unread > 99 ? "99+" : unread}
                        </span>
                      )}
                    </span>
                    {label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </div>
  );
}
