import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Field, fromLocalInput, toLocalInput } from "@/components/common";
import { useToast } from "@/hooks/use-toast";
import { useData } from "@/hooks/useData";
import { PreClick } from "@/components/PreClick";
import { apiRequest, invalidateAll } from "@/lib/api";
import { QUEST_TYPES, TYPE_META, parseZealyLink } from "@/lib/quest";
import type { Quest, QuestType, Recurrence } from "@/lib/types";

type Form = {
  communityId?: number;
  title: string;
  type: QuestType;
  recurrence: Recurrence;
  resetMode: "rolling" | "fixed";
  resetTime: string;
  xp: number | string;
  url: string;
  deadline: string;
  autoOpen: number;
  status: Quest["status"];
  notes: string;
  lastClaimedAt?: string | null;
};

export function QuestDialog({
  open,
  onOpenChange,
  editing,
  defaultCommunityId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing?: Quest | null;
  defaultCommunityId?: number;
}) {
  const { communities, quests } = useData();
  // v2.4.3: the live copy, so Pre-click "done" shows up while the dialog is open
  const live = editing ? quests.find((x) => x.id === editing.id) ?? editing : null;
  const { toast } = useToast();
  const blank: Form = {
    communityId: defaultCommunityId ?? communities[0]?.id,
    title: "",
    type: "daily",
    recurrence: "daily",
    resetMode: "rolling",
    resetTime: "00:00",
    xp: 0,
    url: "",
    deadline: "",
    autoOpen: 1,
    status: "todo",
    notes: "",
  };
  const [f, setF] = useState<Form>(blank);

  useEffect(() => {
    if (open)
      setF(
        editing
          ? { ...editing, url: editing.url ?? "", deadline: toLocalInput(editing.deadline), notes: editing.notes ?? "" }
          : { ...blank, communityId: defaultCommunityId ?? communities[0]?.id },
      );
  }, [open, editing]);

  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((p) => ({ ...p, [k]: v }));
  const onUrl = (v: string) => {
    set("url", v);
    const { subdomain } = parseZealyLink(v);
    const c = subdomain && communities.find((x) => x.subdomain.toLowerCase() === subdomain.toLowerCase());
    if (c) set("communityId", c.id);
  };
  const onType = (t: string) =>
    setF((p) => ({
      ...p,
      type: t as QuestType,
      recurrence: t === "daily" ? "daily" : p.recurrence === "daily" && t !== "daily" ? "once" : p.recurrence,
    }));

  const save = async () => {
    if (!f.title || !f.communityId) {
      toast({ title: "Pick a community and give the task a name" });
      return;
    }
    const body = {
      communityId: Number(f.communityId),
      title: f.title,
      type: f.type,
      recurrence: f.recurrence,
      resetMode: f.resetMode,
      resetTime: f.resetTime || "00:00",
      xp: Number(f.xp) || 0,
      url: f.url || null,
      deadline: fromLocalInput(f.deadline),
      autoOpen: f.autoOpen ? 1 : 0,
      status: f.status,
      notes: f.notes || null,
      lastClaimedAt: editing?.lastClaimedAt ?? null,
    };
    if (editing) await apiRequest("PATCH", `/api/quests/${editing.id}`, body);
    else await apiRequest("POST", "/api/quests", body);
    invalidateAll();
    onOpenChange(false);
    toast({
      title: editing ? "Task updated" : "Task added",
      description: f.recurrence !== "once" ? "Autopilot will open it every time it unlocks." : undefined,
    });
  };

  const recurring = f.recurrence !== "once";
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] max-w-[calc(100%-2rem)] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit task" : "Track a task"}</DialogTitle>
          <DialogDescription>Paste the quest link from Zealy so autopilot can open the exact claim page.</DialogDescription>
        </DialogHeader>
        {communities.length === 0 ? (
          <p className="text-sm text-muted-foreground">Add a community first from the Sprints tab.</p>
        ) : (
          <div className="space-y-3">
            <Field label="Quest link" hint="Open the quest on Zealy and copy its URL">
              <Input data-testid="input-quest-url" value={f.url} onChange={(e) => onUrl(e.target.value)} placeholder="https://zealy.io/cw/…/questboard/…" />
            </Field>
            <Field label="Task name">
              <Input data-testid="input-quest-title" value={f.title} onChange={(e) => set("title", e.target.value)} placeholder="Daily check-in" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Community">
                <Select value={String(f.communityId ?? "")} onValueChange={(v) => set("communityId", Number(v))}>
                  <SelectTrigger data-testid="select-quest-community">
                    <SelectValue placeholder="Pick" />
                  </SelectTrigger>
                  <SelectContent>
                    {communities.map((c) => (
                      <SelectItem key={c.id} value={String(c.id)}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Task type">
                <Select value={f.type} onValueChange={onType}>
                  <SelectTrigger data-testid="select-quest-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {QUEST_TYPES.map((t) => (
                      <SelectItem key={t} value={t}>
                        {TYPE_META[t].label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Repeats">
                <Select value={f.recurrence} onValueChange={(v) => set("recurrence", v as Recurrence)}>
                  <SelectTrigger data-testid="select-quest-recurrence">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="once">One time</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="XP">
                <Input data-testid="input-quest-xp" type="number" inputMode="numeric" value={f.xp} onChange={(e) => set("xp", e.target.value)} />
              </Field>
            </div>
            {recurring && (
              <div className="grid grid-cols-2 gap-3 rounded-lg border border-border p-3">
                {editing?.source === "zealy" ? (
                  <p className="col-span-2 text-xs text-muted-foreground">Unlock time comes from Zealy (quest date condition and recurrence reset at 00:00 UTC).</p>
                ) : (
                  <>
                    <Field label="Unlocks">
                      <Select value={f.resetMode} onValueChange={(v) => set("resetMode", v as Form["resetMode"])}>
                        <SelectTrigger data-testid="select-reset-mode">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="rolling">Cooldown</SelectItem>
                          <SelectItem value="fixed">Set time</SelectItem>
                        </SelectContent>
                      </Select>
                    </Field>
                    {f.resetMode === "fixed" ? (
                      <Field label="Reset time">
                        <Input data-testid="input-reset-time" type="time" value={f.resetTime} onChange={(e) => set("resetTime", e.target.value)} />
                      </Field>
                    ) : (
                      <p className="self-end pb-2 text-xs text-muted-foreground">
                        Counts {f.recurrence === "weekly" ? "7 days" : f.recurrence === "monthly" ? "30 days" : "24h"} from your last claim
                      </p>
                    )}
                  </>
                )}
                <div className="col-span-2 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold">Auto-open claim page</p>
                    <p className="text-xs text-muted-foreground">Loads the quest 3 seconds early and shows it the moment it unlocks</p>
                  </div>
                  <Switch data-testid="switch-auto-open" checked={!!f.autoOpen} onCheckedChange={(v) => set("autoOpen", v ? 1 : 0)} />
                </div>
              </div>
            )}
            <Field label="Deadline (limited tasks)">
              <Input data-testid="input-quest-deadline" type="datetime-local" value={f.deadline} onChange={(e) => set("deadline", e.target.value)} />
            </Field>
            <Field label="Notes / answer draft">
              <Textarea
                data-testid="input-quest-notes"
                rows={2}
                value={f.notes}
                onChange={(e) => set("notes", e.target.value)}
                placeholder="Tweet text, image to upload, quiz answers…"
              />
            </Field>
            {live && <PreClick q={live} paste />}
          </div>
        )}
        <DialogFooter>
          <Button data-testid="button-save-quest" className="w-full" onClick={save} disabled={!communities.length}>
            {editing ? "Save changes" : "Add task"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
