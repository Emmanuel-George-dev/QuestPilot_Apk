import { Link } from "wouter";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { setNativeStatus, useNativeStatus } from "@/hooks/useNative";
import { useNow } from "@/hooks/useNow";
import { isNative, QuestPilot } from "@/lib/native";
import { fmtLeft, timeAgo } from "@/lib/quest";
import { cn } from "@/lib/utils";

/** C: "Monitoring active / Paused / Session expired" + Last synced + start/stop toggle. */
export function StatusLine() {
  const s = useNativeStatus();
  const now = useNow(15000);
  const { toast } = useToast();
  if (!isNative) return null;

  const paused = s.pausedUntil > now;
  const state = !s.connected
    ? { label: s.sessionExpired ? "Session expired" : "Zealy not connected", tone: "bad" }
    : s.sessionExpired
      ? { label: "Session expired", tone: "bad" }
      : !s.monitoringEnabled
        ? { label: "Paused", tone: "idle" }
        : paused
          ? { label: `Paused${s.pauseReason ? ` (${s.pauseReason})` : ""} · resumes in ${fmtLeft(s.pausedUntil - now)}`, tone: "warn" }
          : { label: "Monitoring active", tone: "ok" };
  const last = Math.max(s.lastSyncAt, s.lastQuestPollAt);

  const toggle = async (v: boolean) => {
    try {
      setNativeStatus(await QuestPilot.setMonitoring({ enabled: v }));
    } catch (e) {
      toast({ title: "Couldn't change monitoring", description: String((e as Error).message).slice(0, 120) });
    }
  };

  return (
    <div className="mb-3 flex items-center justify-between gap-3 rounded-xl border border-card-border bg-card px-3.5 py-2.5" data-testid="status-monitoring">
      <div className="min-w-0">
        <p className="flex items-center gap-2 text-sm font-semibold">
          <span
            className={cn(
              "h-2 w-2 shrink-0 rounded-full",
              state.tone === "ok" && "bg-emerald-500 pulse-dot",
              state.tone === "warn" && "bg-amber-500",
              state.tone === "idle" && "bg-muted-foreground",
              state.tone === "bad" && "bg-destructive",
            )}
          />
          <span className="truncate" data-testid="text-monitor-state">
            {state.label}
          </span>
        </p>
        {s.monitoringEnabled && s.connected && !s.sessionExpired && s.watchText && (
          <p className="truncate text-xs text-muted-foreground" data-testid="text-watching">
            {s.watchText}
          </p>
        )}
        <p className="truncate text-xs text-muted-foreground" data-testid="text-last-synced">
          {s.syncing ? "Syncing…" : `Last synced ${last ? timeAgo(last, now) : "never"}`}
          {s.slowFullSync && " · full sync every 60 min (rate limit)"}
          {(!s.connected || s.sessionExpired) && (
            <>
              {" · "}
              <Link href="/settings" className="font-semibold text-primary">
                {s.sessionExpired ? "Reconnect Zealy" : "Connect Zealy"}
              </Link>
            </>
          )}
        </p>
      </div>
      <Switch
        checked={s.monitoringEnabled}
        onCheckedChange={toggle}
        disabled={!s.connected}
        aria-label="Start or stop monitoring"
        data-testid="switch-monitoring"
      />
    </div>
  );
}
