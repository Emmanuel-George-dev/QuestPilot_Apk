import { useEffect, useRef, useState } from "react";
import { AlertTriangle, ChevronDown, ChevronRight, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { usePermissions } from "@/components/Permissions";
import { isNative, QuestPilot } from "@/lib/native";
import { fmtLeft, getUnlockTimestamp, isClaimableNow, isLockedNoTimer, isWaitingUnlock, lockReason, openLink, questUrl } from "@/lib/quest";
import type { Community, Quest } from "@/lib/types";

const TAG: Record<string, string> = { daily: "Daily", weekly: "Weekly", monthly: "Monthly", once: "One-time" };
const PAGE = 10;

function exact(t: number) {
  return new Date(t).toLocaleString([], { weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

/** A6: homepage warning when exact alarms or full-screen notifications are off. */
export function AlarmPermissionWarning() {
  const { p } = usePermissions();
  if (!isNative || !p) return null;
  const missing = [!p.exactAlarm && "exact alarms", !p.fullScreenIntent && "full-screen notifications"].filter(Boolean) as string[];
  if (!missing.length) return null;
  return (
    <div className="mt-3 flex items-start gap-3 rounded-xl border border-amber-500/40 bg-amber-500/10 p-3" data-testid="warning-alarm-permissions">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold">Unlock alarms may be late or silent</p>
        <p className="text-xs text-muted-foreground">Allow {missing.join(" and ")} so the 10 s countdown and the claim page open on time.</p>
      </div>
      <div className="flex shrink-0 flex-col gap-1">
        {!p.exactAlarm && (
          <Button size="sm" variant="secondary" onClick={() => QuestPilot.openExactAlarmSettings().catch(() => {})} data-testid="button-fix-exact-alarm">
            Alarms
          </Button>
        )}
        {!p.fullScreenIntent && (
          <Button size="sm" variant="secondary" onClick={() => QuestPilot.openFullScreenIntentSettings().catch(() => {})} data-testid="button-fix-fsi">
            Full-screen
          </Button>
        )}
      </div>
    </div>
  );
}

/**
 * Part B: every quest waiting for an unlock (daily, weekly, monthly and one-time), soonest first, with a
 * live countdown and the exact unlock time. At zero the row shows "Unlocked, checking...", that one
 * community is synced, and the quest moves to the claim list once Zealy opens it.
 */
export function LockedTasks({ quests, byId, now }: { quests: Quest[]; byId: Map<number, Community>; now: number }) {
  const [showAll, setShowAll] = useState(false);
  const [noTimerOpen, setNoTimerOpen] = useState(false);
  const synced = useRef(new Set<string>());

  const waiting = quests
    .filter((q) => byId.get(q.communityId) && isWaitingUnlock(q, now))
    .sort((a, b) => getUnlockTimestamp(a)! - getUnlockTimestamp(b)!);
  const noTimer = quests.filter((q) => byId.get(q.communityId) && isLockedNoTimer(q));

  // countdown reached zero: sync only that community (the native side also re-checks every 30 s for 5 min)
  const dueSubs = [...new Set(waiting.filter((q) => getUnlockTimestamp(q)! <= now && q.source === "zealy").map((q) => byId.get(q.communityId)!.subdomain))];
  useEffect(() => {
    if (!isNative) return;
    for (const sub of dueSubs) {
      const k = `${sub}-${Math.floor(now / 60000)}`;
      if (synced.current.has(k)) continue;
      synced.current.add(k);
      QuestPilot.syncNow({ subdomain: sub, auto: true }).catch(() => {});
    }
  }, [dueSubs.join(","), Math.floor(now / 60000)]);

  const rows = showAll ? waiting : waiting.slice(0, PAGE);
  const open = (q: Quest) => {
    const c = byId.get(q.communityId);
    openLink(questUrl(q, c), { title: q.title, questId: q.id });
  };

  return (
    <div data-testid="section-locked-tasks">
      {waiting.length ? (
        <ul className="divide-y divide-border/60 overflow-hidden rounded-xl border border-card-border bg-card">
          {rows.map((q) => {
            const t = getUnlockTimestamp(q)!;
            const left = t - now;
            return (
              <li key={q.id}>
                <button onClick={() => open(q)} className="flex w-full items-center justify-between gap-3 px-3.5 py-3 text-left hover-elevate" data-testid={`row-locked-${q.id}`}>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{q.title}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      <span className={`mr-1.5 rounded px-1.5 py-px text-[10px] font-bold uppercase ${q.recurrence === "once" ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"}`}>
                        {TAG[q.recurrence] ?? q.recurrence}
                      </span>
                      {byId.get(q.communityId)?.name} · {exact(t)}
                    </p>
                  </div>
                  <span className="tabular shrink-0 font-mono text-sm" data-testid={`text-locked-left-${q.id}`}>
                    {left > 0 ? fmtLeft(left) : isClaimableNow(q, now) ? "Ready" : <span className="text-xs text-primary">Unlocked, checking...</span>}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="text-sm text-muted-foreground">Nothing counting down. Locked tasks with an unlock time show up here.</p>
      )}
      {waiting.length > PAGE && (
        <Button variant="ghost" size="sm" className="mt-1 w-full" onClick={() => setShowAll(!showAll)} data-testid="button-locked-show-all">
          {showAll ? "Show less" : `Show all ${waiting.length}`}
        </Button>
      )}
      {noTimer.length > 0 && (
        <div className="mt-2 rounded-xl border border-card-border bg-card">
          <button className="flex w-full items-center justify-between px-3.5 py-2.5 text-left" onClick={() => setNoTimerOpen(!noTimerOpen)} data-testid="button-locked-no-timer">
            <span className="flex items-center gap-2 text-sm font-semibold">
              <Lock className="h-3.5 w-3.5 text-muted-foreground" />
              Locked, no timer found ({noTimer.length})
            </span>
            {noTimerOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </button>
          {noTimerOpen && (
            <ul className="divide-y divide-border/60 border-t border-border/60">
              {noTimer.map((q) => (
                <li key={q.id}>
                  <button onClick={() => open(q)} className="w-full px-3.5 py-2.5 text-left hover-elevate" data-testid={`row-no-timer-${q.id}`}>
                    <p className="truncate text-sm font-semibold">{q.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {byId.get(q.communityId)?.name} · {lockReason(q)}
                    </p>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
