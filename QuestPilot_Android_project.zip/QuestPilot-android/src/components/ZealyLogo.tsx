import { useState } from "react";
import { Globe } from "lucide-react";

/**
 * Zealy's own mark. Put the official file at public/zealy-logo.png in the project.
 * Until it is there (or if it fails to load) a plain globe icon shows instead.
 */
export function ZealyLogo({ className = "h-5 w-5" }: { className?: string }) {
  const [ok, setOk] = useState(true);
  if (!ok) return <Globe className={className} aria-hidden />;
  return <img src="./zealy-logo.png" alt="" aria-hidden className={`${className} object-contain`} onError={() => setOk(false)} />;
}
