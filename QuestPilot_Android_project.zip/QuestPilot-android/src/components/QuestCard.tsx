import { useState } from "react";
import { BookmarkCheck, Check, Ellipsis, ExternalLink, Paperclip, Pencil, RotateCcw, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { TypeChip } from "@/components/common";
import { SubmissionsDialog } from "@/components/SubmissionsDialog";
import { useToast } from "@/hooks/use-toast";
import { useMarkClaimed } from "@/hooks/useData";
import { useLaunch } from "@/hooks/useSubmissions";
import { apiRequest, invalidateAll } from "@/lib/api";
import { cn } from "@/lib/utils";
import { STATUS_META, fmtLeft, getUnlockTimestamp, canSave, questStatus } from "@/lib/quest";
import type { Community, Quest } from "@/lib/types";

export function QuestCard({
  q,
  c,
  now,
  onEdit,
  compact,
}: {
  q: Quest;
  c?: Community;
  now: number;
  onEdit?: (q: Quest) => void;
  compact?: boolean;
}) {
  const markClaimed = useMarkClaimed();
  const unlockAt = getUnlockTimestamp(q);
  const recurring = q.recurrence !== "once";
  const claimable = recurring && unlockAt !== null && unlockAt <= now;
  const deadlineLeft = q.deadline ? new Date(q.deadline).getTime() - now : null;
  const status = questStatus(q);
  const manual = q.source !== "zealy";
  const [subsOpen, setSubsOpen] = useState(false);
  const { toast } = useToast();
  const { launch, prepared } = useLaunch(q, c, claimable || (!recurring && status === "open"));
  const saved = prepared.saved;
  const savable = canSave(q);

  // A2: opening a task only opens its link (in the app's Zealy view, with autofill). It never changes the status.
  const open = () => {
    launch();
    if (saved) toast({ title: "Opening quest", description: "Your saved content fills in on the Zealy page. Check it, then tap Claim." });
  };

  const setStatus = async (s: string) => {
    await apiRequest("PATCH", `/api/quests/${q.id}`, { status: s });
    invalidateAll();
  };

  return (
    <div
      data-testid={`card-quest-${q.id}`}
      className={cn("rounded-xl border bg-card p-3.5 transition-shadow", claimable ? "border-primary/50 glow-ready" : "border-card-border")}
    >
      <div className="flex items-start gap-3">
        <span className="mt-1 h-8 w-1 shrink-0 rounded-full" style={{ background: `hsl(${c?.hue ?? 322} 80% 62%)` }} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="truncate font-medium">{c?.name ?? "Unknown"}</span>
            {q.xp > 0 && <span className="tabular shrink-0 font-semibold text-primary">+{q.xp} XP</span>}
          </div>
          <p data-testid={`text-quest-title-${q.id}`} className="mt-0.5 font-semibold leading-snug">
            {q.title}
          </p>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <TypeChip type={q.type} />
            {recurring && !(q.type === "daily" && q.recurrence === "daily") && (
              <Badge variant="outline" className="text-[11px] capitalize">
                {q.recurrence}
              </Badge>
            )}
            {!recurring && (
              <span data-testid={`text-quest-status-${q.id}`} className={cn("text-[11px] font-semibold", STATUS_META[status].cls)}>
                {STATUS_META[status].label}
              </span>
            )}
            {recurring && status === "locked" && <span className="text-[11px] font-semibold text-muted-foreground">Locked</span>}
            {recurring && status === "review" && <span className="text-[11px] font-semibold text-amber-500">In review</span>}
            {saved ? (
              <button
                onClick={() => setSubsOpen(true)}
                className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-2 py-0.5 text-[11px] font-semibold text-primary"
                data-testid={`badge-saved-${q.id}`}
              >
                <BookmarkCheck className="h-3 w-3" />
                Saved
              </button>
            ) : (
              savable &&
              !compact &&
              status !== "complete" && (
                <button
                  onClick={() => setSubsOpen(true)}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-muted-foreground hover:text-foreground"
                  data-testid={`button-save-content-${q.id}`}
                >
                  <Paperclip className="h-3 w-3" />
                  Save for autofill
                </button>
              )
            )}
            {q.claimLimit > 0 && <span className="text-[11px] font-semibold text-amber-500">First {q.claimLimit} only</span>}
            {deadlineLeft !== null && status !== "complete" && (
              <span className={cn("tabular text-[11px] font-semibold", deadlineLeft < 36e5 * 3 ? "text-destructive" : "text-amber-500")}>
                {deadlineLeft > 0 ? `Ends in ${fmtLeft(deadlineLeft)}` : "Expired"}
              </span>
            )}
          </div>
        </div>
        {onEdit && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="icon" variant="ghost" className="-mr-1 h-8 w-8" aria-label="Quest options" data-testid={`button-quest-menu-${q.id}`}>
                <Ellipsis className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onEdit(q)}>
                <Pencil className="mr-2 h-4 w-4" />
                Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSubsOpen(true)} data-testid={`menu-submissions-${q.id}`}>
                <Paperclip className="mr-2 h-4 w-4" />
                Saved submissions{prepared.total ? ` (${prepared.total})` : ""}
              </DropdownMenuItem>
              {/* Status changes are manual-quest only; Zealy quests take their status from sync. */}
              {manual && recurring && (
                <DropdownMenuItem onClick={() => markClaimed.mutate({ id: q.id })} data-testid={`menu-mark-claimed-${q.id}`}>
                  <Check className="mr-2 h-4 w-4" />
                  Mark claimed
                </DropdownMenuItem>
              )}
              {manual && !recurring && (
                <DropdownMenuItem onClick={() => setStatus("done")}>
                  <Check className="mr-2 h-4 w-4" />
                  Mark done
                </DropdownMenuItem>
              )}
              {manual && !recurring && <DropdownMenuItem onClick={() => setStatus("pending")}>Mark in review</DropdownMenuItem>}
              {manual && !recurring && <DropdownMenuItem onClick={() => setStatus("failed")}>Mark rejected</DropdownMenuItem>}
              {manual && (recurring || q.status !== "todo") && (
                <DropdownMenuItem
                  onClick={async () => {
                    await apiRequest("PATCH", `/api/quests/${q.id}`, { status: "todo", lastClaimedAt: null });
                    invalidateAll();
                  }}
                >
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Reset
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={async () => {
                  await apiRequest("DELETE", `/api/quests/${q.id}`);
                  invalidateAll();
                }}
                className="text-destructive"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
      {!compact && (
        <div className="mt-3 flex items-center justify-between gap-2 border-t border-border/60 pt-3">
          <span className="tabular font-mono text-sm" data-testid={`text-quest-timer-${q.id}`}>
            {recurring && unlockAt === null ? (
              <span className="text-muted-foreground">Locked on Zealy until its conditions are met</span>
            ) : recurring ? (
              claimable ? (
                <span className="font-bold text-primary">Claimable now</span>
              ) : (
                <span className="text-muted-foreground">
                  Unlocks in <span className="text-foreground">{fmtLeft((unlockAt ?? now) - now)}</span>
                </span>
              )
            ) : (
              <span className="text-muted-foreground">
                {status === "open" && manual && q.claimCount > 0 ? "Submitted" : STATUS_META[status].line}
              </span>
            )}
          </span>
          <Button
            size="sm"
            variant={claimable || (!recurring && status === "open") ? "default" : "secondary"}
            onClick={open}
            data-testid={`button-open-quest-${q.id}`}
          >
            {claimable ? (saved ? "Claim with saved" : "Claim now") : "Open"} <ExternalLink className="ml-1.5 h-3.5 w-3.5" />
          </Button>
        </div>
      )}
      <SubmissionsDialog quest={q} open={subsOpen} onOpenChange={setSubsOpen} />
    </div>
  );
}
