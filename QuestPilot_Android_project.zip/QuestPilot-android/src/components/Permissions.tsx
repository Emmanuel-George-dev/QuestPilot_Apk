import { useEffect, useState } from "react";
import { BatteryCharging, Bell, Check, Clock, Maximize, Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useAutopilot } from "@/hooks/autopilot";
import { isNative, QuestPilot, type PermissionState } from "@/lib/native";
import { cn } from "@/lib/utils";

const AUTOSTART_NOTES: Array<{ brand: RegExp; name: string; note: string }> = [
  { brand: /xiaomi|redmi|poco/i, name: "Xiaomi / Redmi / POCO", note: "Security app → Permissions → Autostart → enable QuestPilot. Also App info → Battery saver → No restrictions, and lock the app in Recents (swipe down on its card)." },
  { brand: /oppo|realme|oneplus/i, name: "Oppo / Realme / OnePlus", note: "Settings → Battery → More settings → Optimize battery use → QuestPilot → Don't optimize. Then App management → QuestPilot → Allow auto launch / Allow background activity." },
  { brand: /samsung/i, name: "Samsung", note: "Settings → Battery → Background usage limits → remove QuestPilot from Sleeping / Deep sleeping apps, and add it to Never sleeping apps. App battery → Unrestricted." },
  { brand: /huawei|honor/i, name: "Huawei / Honor", note: "Settings → Battery → App launch → QuestPilot → turn off Manage automatically, then enable Auto-launch, Secondary launch and Run in background." },
];

function usePermissions() {
  const [p, setP] = useState<PermissionState | null>(null);
  const refresh = () => (isNative ? QuestPilot.getPermissionState().then(setP).catch(() => {}) : undefined);
  useEffect(() => {
    refresh();
    const onVis = () => !document.hidden && refresh();
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);
  return { p, refresh, setP };
}

function Row({ icon: Icon, title, body, ok, action, onAction }: { icon: typeof Bell; title: string; body: string; ok: boolean; action: string; onAction: () => void }) {
  return (
    <div className="flex items-start gap-3 rounded-lg border border-border p-3">
      <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg", ok ? "bg-emerald-500/10 text-emerald-500" : "bg-accent text-accent-foreground")}>
        {ok ? <Check className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold">{title}</p>
        <p className="text-xs text-muted-foreground">{body}</p>
      </div>
      {!ok && (
        <Button size="sm" variant="secondary" onClick={onAction} className="shrink-0">
          {action}
        </Button>
      )}
    </div>
  );
}

export function PermissionList() {
  const { p, refresh, setP } = usePermissions();
  if (!isNative) return <p className="text-sm text-muted-foreground">Permissions are managed in the Android app.</p>;
  if (!p) return null;
  const notes = AUTOSTART_NOTES.filter((n) => n.brand.test(p.manufacturer));
  return (
    <div className="space-y-2" data-testid="list-permissions">
      <Row
        icon={Bell}
        title="Notifications"
        body="Claim reminders, new quests, unlocks and community messages."
        ok={p.notifications === "granted"}
        action="Allow"
        onAction={() => QuestPilot.requestNotificationPermission().then(setP)}
      />
      <Row
        icon={Clock}
        title="Alarms & reminders (exact alarms)"
        body="Needed to open the claim page 3 seconds before a daily unlocks, to the second."
        ok={p.exactAlarm}
        action="Open"
        onAction={() => QuestPilot.openExactAlarmSettings().then(refresh)}
      />
      {p.sdk >= 34 && (
        <Row
          icon={Maximize}
          title="Full-screen notifications"
          body="Lets the claim alert show over the lock screen when the app is closed."
          ok={p.fullScreenIntent}
          action="Open"
          onAction={() => QuestPilot.openFullScreenIntentSettings().then(refresh)}
        />
      )}
      <Row
        icon={BatteryCharging}
        title="Battery usage: Unrestricted"
        body="Stops Android from pausing monitoring in the background. Choose Unrestricted (or Don't optimize)."
        ok={p.batteryUnrestricted}
        action="Open"
        onAction={() => QuestPilot.openBatterySettings().then(refresh)}
      />
      <div className="rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">
        <p className="font-semibold text-foreground">Autostart on some phones</p>
        <p className="mt-1">Some brands also stop apps from restarting after reboot unless autostart is on{notes.length ? " — this looks like your phone:" : ":"}</p>
        <ul className="mt-2 space-y-1.5">
          {(notes.length ? notes : AUTOSTART_NOTES).map((n) => (
            <li key={n.name}>
              <span className="font-semibold text-foreground">{n.name}:</span> {n.note}
            </li>
          ))}
        </ul>
        <Button size="sm" variant="secondary" className="mt-2" onClick={() => QuestPilot.openAutostartSettings()}>
          Open autostart settings
        </Button>
      </div>
    </div>
  );
}

/** First-launch guide (C). */
export function Onboarding() {
  const { prefs, setPref } = useAutopilot();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    if (isNative && prefs.onboarded === false) {
      const t = setTimeout(() => setOpen(true), 400);
      return () => clearTimeout(t);
    }
  }, [prefs.onboarded]);
  useEffect(() => {
    if (open) QuestPilot.requestNotificationPermission().catch(() => {});
  }, [open]);
  const done = () => {
    setPref("onboarded", true);
    setOpen(false);
  };
  return (
    <Dialog open={open} onOpenChange={(v) => !v && done()}>
      <DialogContent className="max-h-[90dvh] max-w-[calc(100%-2rem)] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Rocket className="h-5 w-5 text-primary" />
            Set up QuestPilot
          </DialogTitle>
          <DialogDescription>Four quick settings so reminders and the 3-second-early claim page work while the app is closed.</DialogDescription>
        </DialogHeader>
        <PermissionList />
        <Button className="w-full" onClick={done} data-testid="button-onboarding-done">
          Done
        </Button>
      </DialogContent>
    </Dialog>
  );
}
