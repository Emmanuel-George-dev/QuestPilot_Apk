import { Copy, ExternalLink, Paperclip, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Drawer, DrawerContent, DrawerDescription, DrawerTitle } from "@/components/ui/drawer";
import { useToast } from "@/hooks/use-toast";
import { useAutopilot } from "@/hooks/autopilot";
import { useData } from "@/hooks/useData";
import { useNow } from "@/hooks/useNow";
import { useLaunch } from "@/hooks/useSubmissions";
import { TYPE_META, sprintLine } from "@/lib/quest";

export function ClaimTakeover() {
  const { claimQueue, takeoverOpen, dismissTakeover, skipClaim } = useAutopilot();
  const { byId } = useData();
  const { toast } = useToast();
  const now = useNow(1000);
  const q = claimQueue[0];
  const c = q ? byId.get(q.communityId) : undefined;
  const { sub, launch } = useLaunch(q, c, takeoverOpen);
  if (!q) return null;
  const rest = claimQueue.slice(1);
  const sprint = sprintLine(c, now);
  const meta = TYPE_META[q.type] ?? TYPE_META.other;
  const Icon = meta.icon;

  return (
    <Drawer open={takeoverOpen} onOpenChange={(v) => !v && dismissTakeover()}>
      <DrawerContent className="mx-auto max-w-md" data-testid="sheet-claim-takeover">
        <div className="px-5 pb-6 pt-2">
          <div className="flex items-start justify-between">
            <span className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-primary">
              <span className="h-2 w-2 rounded-full bg-primary pulse-dot" />
              {claimQueue.length > 1 ? `Claim 1 of ${claimQueue.length}` : "Claim window open"}
            </span>
            <button onClick={dismissTakeover} aria-label="Dismiss" className="rounded-md p-1 text-muted-foreground hover-elevate" data-testid="button-dismiss-takeover">
              <X className="h-4 w-4" />
            </button>
          </div>
          <DrawerTitle className="mt-3 font-display text-xl font-extrabold">{q.title}</DrawerTitle>
          <DrawerDescription className="mt-1 flex items-center gap-2 text-sm">
            <Icon className="h-4 w-4" />
            {c?.name} · {meta.label}
            {q.xp ? ` · +${q.xp} XP` : ""}
          </DrawerDescription>
          {sprint && (
            <p className="mt-2 text-xs font-semibold text-amber-500" data-testid="text-takeover-sprint">
              {sprint}
            </p>
          )}
          {sub && (
            <div className="mt-4 flex gap-3 rounded-lg border border-primary/50 bg-accent/40 p-3" data-testid="preview-takeover-submission">
              {sub.thumb || sub.image ? (
                <img src={sub.thumb ?? sub.image!} alt="Saved photo" className="h-14 w-14 shrink-0 rounded-md object-cover" />
              ) : (
                <Paperclip className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              )}
              <div className="min-w-0 text-sm">
                <p className="text-[11px] font-bold uppercase tracking-wider text-primary">Saved · fills in automatically</p>
                <p className="line-clamp-2">{sub.text || `${sub.images?.length || 1} saved photo${(sub.images?.length || 1) > 1 ? "s" : ""}`}</p>
              </div>
            </div>
          )}
          {q.notes && (
            <button
              onClick={() => {
                navigator.clipboard?.writeText(q.notes!);
                toast({ title: "Copied to clipboard" });
              }}
              className="mt-4 flex w-full items-start gap-2 rounded-lg border border-border bg-muted/50 p-3 text-left text-sm hover-elevate"
              data-testid="button-copy-notes"
            >
              <Copy className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
              <span className="line-clamp-3">{q.notes}</span>
            </button>
          )}
          <Button
            size="lg"
            className="mt-5 w-full text-base"
            data-testid="button-takeover-claim"
            onClick={() => {
              launch();
              if (rest.length) skipClaim(q.id);
              else dismissTakeover();
            }}
          >
            {sub ? "Open with saved content" : "Open claim page"} <ExternalLink className="ml-2 h-4 w-4" />
          </Button>
          {rest.length > 0 && (
            <div className="mt-4 rounded-lg border border-border p-3" data-testid="list-claim-queue">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Up next</p>
                <button className="text-xs font-semibold text-primary" onClick={() => skipClaim(q.id)} data-testid="button-skip-claim">
                  Skip this one
                </button>
              </div>
              <ul className="mt-2 space-y-1.5">
                {rest.slice(0, 4).map((x, i) => (
                  <li key={x.id} className="flex items-center justify-between gap-2 text-sm">
                    <span className="truncate">
                      <span className="mr-1.5 font-mono text-xs text-muted-foreground">{i + 2}</span>
                      {x.title}
                    </span>
                    <span className="shrink-0 text-xs text-muted-foreground">{byId.get(x.communityId)?.name}</span>
                  </li>
                ))}
                {rest.length > 4 && <li className="text-xs text-muted-foreground">+{rest.length - 4} more</li>}
              </ul>
            </div>
          )}
          <p className="mt-3 text-center text-xs text-muted-foreground">
            Opens in QuestPilot's signed-in Zealy view. Status updates after the next Zealy sync, and the next claim moves up.
          </p>
        </div>
      </DrawerContent>
    </Drawer>
  );
}
