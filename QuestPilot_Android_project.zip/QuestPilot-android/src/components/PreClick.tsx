import { useState } from "react";
import { Check, Globe, Heart, Repeat2, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, invalidateAll } from "@/lib/api";
import { refreshFromNative } from "@/lib/store";
import { QuestPilot, isNative } from "@/lib/native";
import { needsPostLink, preclickButtons, tweetId, type PreKind } from "@/lib/preclick";
import type { Quest } from "@/lib/types";

const ICON: Record<PreKind, typeof Heart> = { like: Heart, repost: Repeat2, follow: UserPlus, visit: Globe };

function clock(ms: number) {
  return new Date(ms).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

/**
 * v2.4.3 Part 2: "Pre-click" Like / Repost / Follow / Visit for a task: locked, unlocked or ready to claim.
 * Each button opens its link in the in-app overlay (you press everything on X / the site yourself).
 * [paste] shows the "X post link" field when the description had no post link.
 */
export function PreClick({ q, paste = false, compact = false }: { q: Quest; paste?: boolean; compact?: boolean }) {
  const { toast } = useToast();
  const buttons = preclickButtons(q);
  const [link, setLink] = useState(q.xPostLink ?? "");
  const showPaste = paste && (needsPostLink(q) || !!q.xPostLink);
  if (!buttons.length && !showPaste) return null;

  const press = async (key: string, url: string) => {
    if (!isNative) {
      toast({ title: "Pre-click works in the Android app" });
      return;
    }
    try {
      const r = await QuestPilot.preclick({ questId: q.id, kind: key, url });
      await refreshFromNative();
      invalidateAll();
      if (r && r.flag !== "written" && r.flag !== "already") toast({ title: "Opened, not marked on Zealy", description: r.note });
    } catch (e: any) {
      toast({ title: "Couldn't open the page", description: String(e?.message ?? e) });
    }
  };
  const saveLink = async () => {
    const v = link.trim();
    if (v && !tweetId(v)) {
      toast({ title: "That isn't an X post link", description: "Paste a link like https://x.com/name/status/123..." });
      return;
    }
    await apiRequest("PATCH", `/api/quests/${q.id}`, { xPostLink: v || null });
    invalidateAll();
    toast({ title: v ? "X post link saved" : "X post link removed" });
  };

  const [finding, setFinding] = useState(false);
  const findLink = async () => {
    if (!isNative) return;
    setFinding(true);
    try {
      const r = await QuestPilot.fetchTaskDetails({ questId: q.id });
      await refreshFromNative();
      invalidateAll();
      toast({ title: r.ok ? "Task details loaded" : "Couldn't load the task details", description: r.message });
    } catch (e: any) {
      toast({ title: "Couldn't load the task details", description: String(e?.message ?? e) });
    } finally {
      setFinding(false);
    }
  };
  const missing = needsPostLink(q) || buttons.some((b) => q.preclick?.[b.key]?.flag === "unavailable");

  const notes = buttons.map((b) => q.preclick?.[b.key]).filter((d) => d && (d.flag === "unavailable" || d.flag === "none"));

  return (
    <div className={compact ? "mt-2" : "mt-3 rounded-xl border border-card-border bg-card p-3"} data-testid={`section-preclick-${q.id}`} onClick={(e) => e.stopPropagation()}>
      {!compact && <p className="text-sm font-semibold">Pre-click</p>}
      {buttons.length > 0 && (
        <div className="mt-1 flex flex-wrap gap-1.5">
          {buttons.map((b) => {
            const done = q.preclick?.[b.key];
            const Icon = done ? Check : ICON[b.kind];
            return (
              <Button
                key={b.key}
                size="sm"
                variant={done ? "secondary" : "outline"}
                className="h-7 px-2.5 text-xs"
                onClick={() => press(b.key, b.url)}
                title={b.url}
                data-testid={`button-preclick-${b.key}-${q.id}`}
              >
                <Icon className={`mr-1 h-3.5 w-3.5 ${done ? "text-primary" : ""}`} />
                <span className="max-w-[9rem] truncate">{b.title}</span>
                {done ? <span className="ml-1 font-mono text-[10px] text-muted-foreground">{clock(done.at)}</span> : null}
                {done && (done.flag === "written" || done.flag === "already") ? <span className="ml-1 text-[10px] text-primary">on Zealy</span> : null}
              </Button>
            );
          })}
        </div>
      )}
      {notes.length > 0 && <p className="mt-1 text-[11px] text-amber-500" data-testid={`text-preclick-note-${q.id}`}>{notes[notes.length - 1]!.note}</p>}
      {missing && isNative && (
        <Button size="sm" variant="ghost" className="mt-1 h-7 px-2 text-xs" onClick={findLink} disabled={finding} data-testid={`button-find-link-${q.id}`}>
          {finding ? "Loading..." : "Find link and task id"}
        </Button>
      )}
      {showPaste && (
        <div className="mt-2">
          <p className="text-xs text-muted-foreground">
            {buttons.some((b) => b.kind === "like" || b.kind === "repost")
              ? "X post link (optional, replaces the one found)"
              : "No X post link yet. QuestPilot loads it with the next sync, or tap Find link. Pasting one is optional."}
          </p>
          <div className="mt-1 flex gap-1.5">
            <Input value={link} onChange={(e) => setLink(e.target.value)} placeholder="https://x.com/name/status/..." className="h-8 text-xs" data-testid={`input-x-post-link-${q.id}`} />
            <Button size="sm" variant="secondary" className="h-8" onClick={saveLink} data-testid={`button-save-x-post-link-${q.id}`}>
              Save
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
