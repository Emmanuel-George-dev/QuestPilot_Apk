import { ChevronDown } from "lucide-react";

interface Topic {
  title: string;
  body: string[];
}

const TOPICS: Topic[] = [
  {
    title: "Getting started",
    body: [
      "1. Settings → Zealy account → Connect Zealy, and log in once. Only the session is kept, encrypted on your phone. Your password is never stored.",
      "2. Sprints → Add, then enter the community's subdomain (the part in zealy.io/cw/<name>). Its tasks and sprint appear after the first sync.",
      "3. Settings → Permissions: allow notifications, exact alarms and full-screen alerts, and set the battery for QuestPilot to \"Don't optimize\" so alarms are never delayed.",
    ],
  },
  {
    title: "The Today page",
    body: [
      "Ready now = tasks you can claim right now. Next unlock = time until the next daily or weekly task opens. Live sprints = communities with a sprint running.",
      "\"Claimable now\" lists each task you can claim. Claim now opens that task inside the app's signed-in Zealy view.",
      "Daily claim autopilot opens the claim page a few seconds before a task unlocks, so you're ready at the unlock second. When the app is closed you get a full-screen alert instead.",
    ],
  },
  {
    title: "Claim run, Next and Auto-next",
    body: [
      "Start claim run → Open & next opens the claim screen with your whole list loaded. The Next (n) button moves to the following task, so you never have to go back to the home page.",
      "The Auto-next switch on the claim run card moves on by itself about 2 seconds after Zealy accepts a claim. The Next button always stays, whatever the switch says.",
      "If Auto-next doesn't move on, the app didn't recognise the claim. Tap Next, nothing is lost.",
      "While you work on one task, the next page already loads and fills in behind it, so Next only leaves you the Claim tap.",
    ],
  },
  {
    title: "Saved answers (autofill)",
    body: [
      "Tap \"Save for autofill\" on a task to store text and photos for it. When the claim page opens, the app fills them in for you.",
      "Every claim = the same answer is used each time. Use once = the answer is used for one claim, then marked used. Queue it again to use it later.",
      "If a fill fails, a banner at the top lets you copy the text or pick the saved photo.",
      "The app never taps Claim. You check the page and press Claim yourself.",
    ],
  },
  {
    title: "Several tasks unlocking together",
    body: [
      "Tasks that unlock at the exact same second are grouped into one alert and one claim screen. Use Next to walk through them.",
      "Give them the same fixed reset time so they unlock together. If their times differ by even a few seconds, they get separate alerts.",
    ],
  },
  {
    title: "The Sprints page",
    body: [
      "Sprint ends = live countdown. Tasks done / total = how many of the community's tasks you've completed out of all the app found. XP earned = your XP in that community from Zealy; if Zealy didn't provide it, the app's own tally.",
      "The bar shows one-time tasks done. Task adds one by hand, Quests opens the questboard and Board opens the leaderboard.",
      "The Zealy icon at the top opens zealy.io so you can find new sprints. The search box filters your sprints by name, link or prize.",
      "The circular arrow on a card syncs only that community. Sync at the top syncs all of them.",
    ],
  },
  {
    title: "Alerts and notifications",
    body: [
      "You get alerts for unlocks, deadlines, new quests (Watchlist) and sprints: one 24 hours before a sprint ends and one when it ends.",
      "Sprint alarms are set on the phone from the saved end date, so they fire even if you're offline or a sync hasn't run. If a sync finds a new end date, the alarm is rescheduled.",
      "Telegram push (Settings) sends every alert to your Telegram too. Export calendar adds unlocks and deadlines to your phone's calendar.",
    ],
  },
  {
    title: "Watchlist and Zealy Monitor",
    body: [
      "Settings → Watchlist & Zealy Monitor checks up to 3 communities every 3 minutes for new and newly unlocked quests, even for communities you haven't joined.",
    ],
  },
  {
    title: "Good to know",
    body: [
      "Statuses only come from a successful Zealy sync. Opening a task never changes its status. Daily quests reset at 00:00 UTC.",
      "Zealy's terms may not allow automated access. Keep the Claim tap manual, use your own varied answers, and respect each community's rules. You use the app at your own risk.",
    ],
  },
  {
    title: "Troubleshooting",
    body: [
      "Nothing syncs: Settings → Sync now, or Reconnect Zealy if the session expired.",
      "Alerts arrive late: set the battery to \"Don't optimize\" for QuestPilot and allow exact alarms.",
      "Autofill didn't fill: use the banner to copy your text or attach the saved photo. Zealy may have changed its page.",
      "XP doesn't match Zealy: sync again. If the app can't read it from Zealy it shows its own tally.",
    ],
  },
];

/** Plain-language guide. Each topic opens and closes on tap. */
export function UserGuide() {
  return (
    <div className="divide-y divide-border/60 rounded-xl border border-card-border bg-card" data-testid="user-guide">
      {TOPICS.map((t) => (
        <details key={t.title} className="group px-3.5 py-3">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-sm font-semibold [&::-webkit-details-marker]:hidden">
            {t.title}
            <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-180" />
          </summary>
          <div className="mt-2 space-y-2 text-xs leading-relaxed text-muted-foreground">
            {t.body.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        </details>
      ))}
    </div>
  );
}
