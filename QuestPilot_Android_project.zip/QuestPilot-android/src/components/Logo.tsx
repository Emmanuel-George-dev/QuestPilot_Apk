export function Logo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" aria-label="QuestPilot" className={className}>
      <path d="M16 3.5 L28.5 16 L16 28.5 L3.5 16 Z" stroke="currentColor" strokeWidth="2.4" strokeLinejoin="round" />
      <path d="M16 10 L22 16 L16 22" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="11.5" cy="16" r="2" fill="currentColor" />
    </svg>
  );
}
