import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Field, fromLocalInput, toLocalInput } from "@/components/common";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, invalidateAll } from "@/lib/api";
import { parseZealyLink } from "@/lib/quest";
import type { Community } from "@/lib/types";

type Form = {
  name: string;
  subdomain: string;
  link?: string;
  sprintName: string | null;
  sprintEndsAt: string;
  prize: string | null;
  hue: number;
  notify: number;
  autoSync: number;
};

export function CommunityDialog({
  open,
  onOpenChange,
  editing,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing?: Community | null;
}) {
  const { toast } = useToast();
  const blank: Form = { name: "", subdomain: "", sprintName: "", sprintEndsAt: "", prize: "", hue: 322, notify: 1, autoSync: 1 };
  const [f, setF] = useState<Form>(blank);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open)
      setF(
        editing
          ? { ...editing, sprintEndsAt: toLocalInput(editing.sprintEndsAt) }
          : { ...blank, hue: Math.floor(Math.random() * 360) },
      );
  }, [open, editing]);

  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((p) => ({ ...p, [k]: v }));
  const onLink = (v: string) => {
    const { subdomain } = parseZealyLink(v);
    const t = v.trim();
    const sub = subdomain ?? (/[/:.\s]/.test(t) ? "" : t.replace(/^@/, ""));
    setF((p) => ({ ...p, link: v, subdomain: sub }));
  };

  const save = async () => {
    if (!f.subdomain) {
      toast({ title: "That link doesn't look like a Zealy community", description: "Paste a link like https://zealy.io/cw/yourproject/questboard" });
      return;
    }
    const name = f.name || f.subdomain;
    const body = {
      name,
      subdomain: f.subdomain,
      sprintName: f.sprintName || null,
      sprintEndsAt: fromLocalInput(f.sprintEndsAt),
      prize: f.prize || null,
      hue: Number(f.hue),
      notify: f.notify ? 1 : 0,
      autoSync: f.autoSync ? 1 : 0,
    };
    if (editing) {
      await apiRequest("PATCH", `/api/communities/${editing.id}`, body);
      invalidateAll();
      onOpenChange(false);
      toast({ title: "Community updated" });
      return;
    }
    setBusy(true);
    try {
      const r = await apiRequest<Community & { sync?: { ok: boolean; added: number; error?: string } }>("POST", "/api/communities", body);
      invalidateAll();
      onOpenChange(false);
      toast(
        r.sync?.ok
          ? { title: `Tracking ${r.name}`, description: `Found ${r.sync.added} tasks${r.sprintName ? ` · sprint "${r.sprintName}"` : ""}` }
          : {
              title: `Tracking ${name}`,
              description: r.sync?.error ? `Couldn't read its questboard yet: ${r.sync.error}` : "Add tasks manually or sync from Zealy.",
            },
      );
    } catch (e) {
      toast({ title: "Couldn't add it", description: String((e as Error).message).slice(0, 120) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] max-w-[calc(100%-2rem)] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit community" : "Add a community you joined"}</DialogTitle>
          <DialogDescription>Paste the Zealy community link. QuestPilot reads its questboard and current sprint automatically.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <Field label="Zealy link or subdomain" hint="e.g. https://zealy.io/cw/yourproject/questboard">
            <Input data-testid="input-community-link" value={f.link ?? f.subdomain} onChange={(e) => onLink(e.target.value)} placeholder="https://zealy.io/cw/…" />
          </Field>
          <Field label="Community name">
            <Input data-testid="input-community-name" value={f.name} onChange={(e) => set("name", e.target.value)} placeholder={f.subdomain || ""} />
          </Field>
          {editing ? (
            <div className="space-y-3 rounded-lg border border-border p-3">
              <div>
                <p className="text-sm font-semibold">Current sprint</p>
                <p className="text-xs text-muted-foreground">
                  The leaderboard competition this community is running now (not the community itself). Filled in from Zealy on every sync.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Sprint title">
                  <Input data-testid="input-sprint-name" value={f.sprintName ?? ""} onChange={(e) => set("sprintName", e.target.value)} placeholder="October Sprint" />
                </Field>
                <Field label="Prize">
                  <Input data-testid="input-prize" value={f.prize ?? ""} onChange={(e) => set("prize", e.target.value)} placeholder="$1k pool" />
                </Field>
              </div>
              <Field label="Sprint ends at">
                <Input data-testid="input-sprint-ends" type="datetime-local" value={f.sprintEndsAt ?? ""} onChange={(e) => set("sprintEndsAt", e.target.value)} />
              </Field>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground" data-testid="text-sprint-auto">
              The current sprint, prize and end time are read from Zealy automatically after you add it.
            </p>
          )}
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <p className="text-sm font-semibold">Notifications</p>
              <p className="text-xs text-muted-foreground">Claims, limited tasks, sprint end</p>
            </div>
            <Switch data-testid="switch-community-notify" checked={!!f.notify} onCheckedChange={(v) => set("notify", v ? 1 : 0)} />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <p className="text-sm font-semibold">Auto-detect tasks</p>
              <p className="text-xs text-muted-foreground">Read the questboard every 30 min; alert on new limited, daily, Twitter and image tasks</p>
            </div>
            <Switch data-testid="switch-community-autosync" checked={!!f.autoSync} onCheckedChange={(v) => set("autoSync", v ? 1 : 0)} />
          </div>
        </div>
        <DialogFooter>
          <Button data-testid="button-save-community" className="w-full" onClick={save} disabled={busy}>
            {editing ? "Save changes" : busy ? "Reading questboard…" : "Add community"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
