import { useEffect, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { SectionTitle } from "@/components/common";
import { useAutopilot } from "@/hooks/autopilot";
import { useNativeStatus } from "@/hooks/useNative";
import { isNative, QuestPilot, type AlarmEntry, type EventLogEntry, type LockedDebugEntry } from "@/lib/native";
import type { Prefs } from "@/lib/types";

function Row({ title, body, k, def = true }: { title: string; body: string; k: keyof Prefs; def?: boolean }) {
  const ap = useAutopilot();
  const v = ap.prefs[k];
  const checked = typeof v === "boolean" ? v : def;
  return (
    <div className="flex items-center justify-between gap-3 p-3.5">
      <div>
        <p className="text-sm font-semibold">{title}</p>
        <p className="text-xs text-muted-foreground">{body}</p>
      </div>
      <Switch checked={checked} onCheckedChange={(x) => ap.setPref(k, x as never)} data-testid={`switch-${String(k)}`} />
    </div>
  );
}

const clock = (t: number) => new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
const TAGS = ["all", "sync", "monitor", "links", "x-req", "fill", "recheck", "alarms", "cookies"];

/**
 * v2.4 Debug & experiments (both builds). Every risky Part D feature has its own switch here, so each can
 * be tested on its own. The logs never contain cookies, tokens or passwords.
 */
export default function Debug() {
  const ap = useAutopilot();
  const [events, setEvents] = useState<EventLogEntry[]>([]);
  const [locked, setLocked] = useState<LockedDebugEntry[]>([]);
  const [alarms, setAlarms] = useState<AlarmEntry[]>([]);
  const [req, setReq] = useState<{ lastMinute: number; last10Minutes: number; perMinuteCap: number; pauseReason: string | null; paused: boolean } | null>(null);
  const [tag, setTag] = useState("all");
  const [schemes, setSchemes] = useState(ap.prefs.allowedAppLinks ?? "");
  const sec = Math.min(10, Math.max(1, Number(ap.prefs.likeCloseSec ?? 3)));
  const status = useNativeStatus();
  const [simMatch, setSimMatch] = useState("");
  const sim = (code: number, challenge: boolean, count: number) =>
    QuestPilot.simulateZealy({ code, challenge, match: simMatch.trim(), count }).then(load).catch(() => {});

  const load = () => {
    if (!isNative) return;
    QuestPilot.getEventLog().then((r) => setEvents(r.entries)).catch(() => {});
    QuestPilot.getLockedDebug().then((r) => setLocked(r.entries)).catch(() => {});
    QuestPilot.getAlarms().then((r) => setAlarms(r.entries)).catch(() => {});
    QuestPilot.getRequestStats().then(setReq).catch(() => {});
  };
  useEffect(() => {
    load();
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, []);

  const shown = events.filter((e) => tag === "all" || e.tag === tag).slice(0, 150);
  return (
    <div>
      <Link href="/settings" className="mb-2 inline-flex items-center gap-1 text-sm font-semibold text-muted-foreground" data-testid="link-back-settings">
        <ArrowLeft className="h-4 w-4" /> Settings
      </Link>
      <h1 className="font-display text-xl font-extrabold">Debug & experiments</h1>
      <p className="mt-1 text-sm text-muted-foreground">QuestPilot never taps anything on X. Every like, repost, post and follow tap is yours.</p>

      <SectionTitle>Zealy requests</SectionTitle>
      <div className="grid grid-cols-2 gap-2" data-testid="section-request-counter">
        <div className="rounded-xl border border-card-border bg-card p-3">
          <p className="font-mono text-2xl font-bold" data-testid="text-req-1m">{req?.lastMinute ?? "—"}</p>
          <p className="text-xs text-muted-foreground">last 1 minute (cap {req?.perMinuteCap ?? 20})</p>
        </div>
        <div className="rounded-xl border border-card-border bg-card p-3">
          <p className="font-mono text-2xl font-bold" data-testid="text-req-10m">{req?.last10Minutes ?? "—"}</p>
          <p className="text-xs text-muted-foreground">last 10 minutes</p>
        </div>
      </div>
      {req?.paused && <p className="mt-1.5 text-xs font-semibold text-amber-500">Paused: {req.pauseReason ?? "Zealy rate limit"}. Automatic requests wait.</p>}
      {status.debugBuild && (
        <div className="mt-2 rounded-xl border border-card-border bg-card p-3.5" data-testid="section-simulator">
          <p className="text-sm font-semibold">Simulate Zealy answers (debug build)</p>
          <p className="text-xs text-muted-foreground">
            The next matching requests get a fake answer and are not sent. Match = part of the path, e.g. <span className="font-mono">questboard</span>,{" "}
            <span className="font-mono">leaderboard/sprint</span>, <span className="font-mono">l7exchange</span>; empty = any. Then tap Sync now.
          </p>
          <Input className="mt-2" value={simMatch} onChange={(e) => setSimMatch(e.target.value)} placeholder="any request" data-testid="input-sim-match" />
          <div className="mt-2 flex flex-wrap gap-1.5">
            <Button size="sm" variant="secondary" onClick={() => sim(429, false, 1)} data-testid="button-sim-429">429 once</Button>
            <Button size="sm" variant="secondary" onClick={() => sim(403, false, 1)} data-testid="button-sim-403">403 once</Button>
            <Button size="sm" variant="secondary" onClick={() => sim(403, false, 3)} data-testid="button-sim-403x3">403 x3</Button>
            <Button size="sm" variant="secondary" onClick={() => sim(403, true, 1)} data-testid="button-sim-challenge">Challenge page</Button>
            <Button size="sm" variant="ghost" onClick={() => sim(0, false, 0)} data-testid="button-sim-off">Off</Button>
          </div>
        </div>
      )}

      <SectionTitle>Links and X</SectionTitle>
      <div className="divide-y divide-border/60 rounded-xl border border-card-border bg-card">
        <Row k="featInAppLinks" title="Open links in the app" body="Every link from a Zealy task opens in a full-screen in-app page with a back arrow. Off: links go to the phone browser like before." />
        <Row k="featLikeTimer" title="Like / repost auto-close" body="X like and repost pages close by themselves a few seconds after loading." />
        <div className="p-3.5">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold">Close after</p>
            <span className="font-mono text-sm" data-testid="text-like-sec">{sec} s</span>
          </div>
          <input
            type="range"
            min={1}
            max={10}
            step={1}
            value={sec}
            onChange={(e) => ap.setPref("likeCloseSec", Number(e.target.value))}
            className="mt-2 w-full accent-[hsl(var(--primary))]"
            data-testid="slider-like-sec"
          />
        </div>
        <Row k="featLikePreload" def={false} title="Preload like / repost pages" body="Loads visible like and repost links in a hidden 1 px page so they open instantly. Off by default." />
        <Row k="featPostSheet" title="Reply / tweet / quote sheet" body="X opens in a 65% sheet. When the post is sent, its link is copied, the sheet closes and the link is pasted into the task." />
        <Row k="featFollowSheet" title="Follow overlay" body="Follow overlay: opens full screen and closes as soon as you follow" />
        <div className="p-3.5">
          <p className="text-sm font-semibold">Allowed app links</p>
          <p className="text-xs text-muted-foreground">
            Schemes that may open other apps, comma separated, e.g. <span className="font-mono">tg, discord, intent</span>. Everything else stays in QuestPilot.
          </p>
          <div className="mt-2 flex gap-2">
            <Input value={schemes} onChange={(e) => setSchemes(e.target.value)} placeholder="none" data-testid="input-allowed-schemes" />
            <Button size="sm" onClick={() => ap.setPref("allowedAppLinks", schemes.trim())} data-testid="button-save-schemes">
              Save
            </Button>
          </div>
        </div>
      </div>

      <SectionTitle>Autofill</SectionTitle>
      <div className="rounded-xl border border-card-border bg-card">
        <Row k="debugFillSteps" def={false} title="Show autofill steps on screen" body="A small line on the claim page: job found, photo file, input found, file set, upload started." />
      </div>

      <SectionTitle
        action={
          <Button size="sm" variant="ghost" onClick={() => QuestPilot.clearEventLog().then(load)} data-testid="button-clear-events">
            Clear
          </Button>
        }
      >
        Event log
      </SectionTitle>
      <div className="mb-2 flex flex-wrap gap-1">
        {TAGS.map((t) => (
          <button key={t} onClick={() => setTag(t)} className={`rounded-full px-2.5 py-1 text-xs font-semibold ${tag === t ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>
            {t}
          </button>
        ))}
      </div>
      <div className="max-h-96 overflow-auto rounded-xl border border-card-border bg-card p-2 font-mono text-[11px] leading-snug" data-testid="list-events">
        {shown.length ? (
          shown.map((e, i) => (
            <p key={i} className="border-b border-border/40 py-1 last:border-0">
              <span className="text-muted-foreground">{clock(e.at)}</span> <span className="text-primary">{e.tag}</span> {e.msg}
            </p>
          ))
        ) : (
          <p className="p-2 text-muted-foreground">Nothing logged yet.</p>
        )}
      </div>

      <SectionTitle>Scheduled alarms</SectionTitle>
      <div className="max-h-64 overflow-auto rounded-xl border border-card-border bg-card p-2 font-mono text-[11px]" data-testid="list-alarms">
        {alarms.length ? (
          [...alarms]
            .sort((a, b) => a.fireAt - b.fireAt)
            .slice(0, 60)
            .map((a) => (
              <p key={a.key} className="py-0.5">
                {new Date(a.fireAt).toLocaleString()} · <span className="text-primary">{a.kind}</span> · quests {a.questIds.join(", ") || "—"}
              </p>
            ))
        ) : (
          <p className="p-2 text-muted-foreground">No alarms scheduled.</p>
        )}
      </div>

      <SectionTitle
        action={
          <Button size="sm" variant="ghost" onClick={() => QuestPilot.clearLockedDebug().then(load)} data-testid="button-clear-locked">
            Clear
          </Button>
        }
      >
        Locked quests without a timer
      </SectionTitle>
      <p className="mb-2 text-xs text-muted-foreground">The raw conditions Zealy sent for each locked quest whose unlock time could not be read. Tokens and cookies are hidden.</p>
      <div className="space-y-2" data-testid="list-locked-debug">
        {locked.length ? (
          locked.map((l) => (
            <details key={l.zealyId} className="rounded-xl border border-card-border bg-card p-3">
              <summary className="cursor-pointer text-sm font-semibold">
                {l.title} <span className="text-xs font-normal text-muted-foreground">· {l.community} · {clock(l.at)}</span>
              </summary>
              <pre className="mt-2 overflow-auto whitespace-pre-wrap break-all text-[11px]">
                {JSON.stringify({ conditionOperator: l.conditionOperator, conditions: l.conditions, questFields: l.questFields }, null, 2)}
              </pre>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => navigator.clipboard?.writeText(JSON.stringify(l, null, 2)).catch(() => {})}
              >
                Copy
              </Button>
            </details>
          ))
        ) : (
          <p className="text-sm text-muted-foreground">Empty. Every locked quest has a timer, or no sync has run yet.</p>
        )}
      </div>
    </div>
  );
}
