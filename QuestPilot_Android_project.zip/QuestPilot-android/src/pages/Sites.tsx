import { useEffect, useState } from "react";
import { Link } from "wouter";
import { ArrowLeft, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/common";
import { useToast } from "@/hooks/use-toast";
import { isNative, QuestPilot } from "@/lib/native";

/** C5: sites with saved logins inside the app. Cookie values are never shown. */
export default function Sites() {
  const [sites, setSites] = useState<Array<{ site: string; cookies: number; savedAt: number }> | null>(null);
  const { toast } = useToast();
  const load = () => (isNative ? QuestPilot.getLoggedInSites().then((r) => setSites(r.sites)).catch(() => setSites([])) : setSites([]));
  useEffect(() => {
    load();
  }, []);
  return (
    <div>
      <Link href="/settings" className="mb-2 inline-flex items-center gap-1 text-sm font-semibold text-muted-foreground" data-testid="link-back-settings">
        <ArrowLeft className="h-4 w-4" /> Settings
      </Link>
      <h1 className="font-display text-xl font-extrabold">Logged-in sites</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Sites you logged into inside QuestPilot. All in-app pages share one login store, and these logins are also kept encrypted on the phone so they
        survive a restart. Zealy's own login is under Zealy account. Google sign-in does not work inside apps: use another login method there.
      </p>
      <div className="mt-4">
        {sites === null ? null : sites.length === 0 ? (
          <EmptyState icon={Globe} title="No saved logins yet" body="Log into X, Discord or another site from a Zealy task link and it appears here." />
        ) : (
          <ul className="divide-y divide-border/60 rounded-xl border border-card-border bg-card">
            {sites.map((s) => (
              <li key={s.site} className="flex items-center justify-between gap-3 p-3.5" data-testid={`row-site-${s.site}`}>
                <div className="min-w-0">
                  <p className="text-sm font-semibold">{s.site}</p>
                  <p className="text-xs text-muted-foreground">
                    {s.cookies} cookie{s.cookies === 1 ? "" : "s"} · saved {s.savedAt ? new Date(s.savedAt).toLocaleString() : "—"}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="secondary"
                  data-testid={`button-logout-${s.site}`}
                  onClick={async () => {
                    await QuestPilot.logoutSite({ site: s.site }).catch(() => {});
                    toast({ title: `Logged out of ${s.site}` });
                    load();
                  }}
                >
                  Log out
                </Button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
