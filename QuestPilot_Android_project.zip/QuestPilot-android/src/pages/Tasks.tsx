import { useState } from "react";
import { ListChecks, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/common";
import { QuestCard } from "@/components/QuestCard";
import { QuestDialog } from "@/components/QuestDialog";
import { useData } from "@/hooks/useData";
import { useNow } from "@/hooks/useNow";
import { TYPE_META, getUnlockTimestamp } from "@/lib/quest";
import { cn } from "@/lib/utils";
import type { Quest, QuestType } from "@/lib/types";

const FILTERS = ["all", "recurring", "daily", "limited", "twitter", "image", "pending"] as const;
const LABELS: Record<string, string> = { all: "All", recurring: "Recurring", pending: "In review" };

export default function Tasks() {
  const { quests, byId, communities } = useData();
  const now = useNow(1000);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");
  const [community, setCommunity] = useState<number | "all">("all");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Quest | null>(null);
  const [hideDone, setHideDone] = useState(true);
  const [limit, setLimit] = useState(60);

  const list = quests
    .filter((q) => {
      if (community !== "all" && q.communityId !== community) return false;
      if (search && !q.title.toLowerCase().includes(search.toLowerCase())) return false;
      if (hideDone && q.recurrence === "once" && q.status === "done") return false;
      if (filter === "all") return true;
      if (filter === "recurring") return q.recurrence !== "once";
      if (filter === "pending") return q.status === "pending";
      if (filter === "limited") return q.type === "limited" || !!q.deadline;
      return q.type === filter;
    })
    .sort((a, b) => {
      const ta = getUnlockTimestamp(a) ?? Infinity;
      const tb = getUnlockTimestamp(b) ?? Infinity;
      const rank = (q: Quest, t: number) => (q.recurrence !== "once" && t <= now ? 0 : q.status === "done" ? 3 : q.recurrence !== "once" ? 1 : 2);
      return rank(a, ta) - rank(b, tb) || ta - tb;
    });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-xl font-extrabold">Tasks</h1>
        <Button
          size="sm"
          data-testid="button-add-quest"
          onClick={() => {
            setEditing(null);
            setOpen(true);
          }}
        >
          <Plus className="mr-1 h-4 w-4" />
          Add task
        </Button>
      </div>
      <Input className="mt-3" placeholder="Search tasks" value={search} onChange={(e) => setSearch(e.target.value)} data-testid="input-search-quests" />
      <div className="-mx-4 mt-3 flex gap-1.5 overflow-x-auto px-4 pb-1">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            data-testid={`filter-${f}`}
            className={cn(
              "shrink-0 rounded-full border px-3 py-1.5 text-xs font-semibold",
              filter === f ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground hover-elevate",
            )}
          >
            {LABELS[f] ?? TYPE_META[f as QuestType]?.label}
          </button>
        ))}
      </div>
      {communities.length > 1 && (
        <div className="-mx-4 mt-2 flex gap-1.5 overflow-x-auto px-4 pb-1">
          {[{ id: "all" as const, name: "All communities", hue: 0 }, ...communities].map((c) => (
            <button
              key={c.id}
              onClick={() => setCommunity(c.id)}
              data-testid={`filter-community-${c.id}`}
              className={cn(
                "flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium",
                community === c.id ? "border-foreground/40 bg-secondary text-foreground" : "border-border text-muted-foreground",
              )}
            >
              {c.id !== "all" && <span className="h-2 w-2 rounded-full" style={{ background: `hsl(${c.hue} 80% 62%)` }} />}
              {c.name}
            </button>
          ))}
        </div>
      )}
      <div className="mt-4 space-y-2.5">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span data-testid="text-task-count">{list.length} tasks</span>
          <button className="font-semibold text-primary" onClick={() => setHideDone(!hideDone)} data-testid="button-toggle-done">
            {hideDone ? "Show completed" : "Hide completed"}
          </button>
        </div>
        {list.length ? (
          list.slice(0, limit).map((q) => (
            <QuestCard
              key={q.id}
              q={q}
              c={byId.get(q.communityId)}
              now={now}
              onEdit={(x) => {
                setEditing(x);
                setOpen(true);
              }}
            />
          ))
        ) : (
          <EmptyState icon={ListChecks} title="Nothing here" body={quests.length ? "No tasks match this filter." : "Paste a quest link from Zealy to start tracking it."} />
        )}
      </div>
      {list.length > limit && (
        <Button variant="secondary" className="mt-3 w-full" onClick={() => setLimit(limit + 60)} data-testid="button-show-more">
          Show {Math.min(60, list.length - limit)} more
        </Button>
      )}
      <QuestDialog open={open} onOpenChange={setOpen} editing={editing} />
    </div>
  );
}
