import { BellRing, CheckCheck, Clock, Hourglass, Info, KeyRound, MessageSquare, Sparkles, Trophy, Unlock, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/common";
import { useData } from "@/hooks/useData";
import { useNow } from "@/hooks/useNow";
import { apiRequest, invalidateAll } from "@/lib/api";
import { isNative, QuestPilot } from "@/lib/native";
import { fmtLeft, getUnlockTimestamp, leaderboardUrl, openLink, questUrl, timeAgo } from "@/lib/quest";
import { cn } from "@/lib/utils";
import type { Alert } from "@/lib/types";

export const ALERT_META: Record<string, { icon: typeof Zap; cls: string }> = {
  due: { icon: Zap, cls: "text-primary bg-accent" },
  soon: { icon: Clock, cls: "text-sky-500 bg-sky-500/10" },
  deadline: { icon: Hourglass, cls: "text-amber-500 bg-amber-500/10" },
  sprint: { icon: Trophy, cls: "text-rose-500 bg-rose-500/10" },
  system: { icon: Info, cls: "text-muted-foreground bg-muted" },
  "quest-new": { icon: Sparkles, cls: "text-emerald-500 bg-emerald-500/10" },
  "quest-unlocked": { icon: Unlock, cls: "text-primary bg-accent" },
  message: { icon: MessageSquare, cls: "text-violet-500 bg-violet-500/10" },
  session: { icon: KeyRound, cls: "text-destructive bg-destructive/10" },
};

export function AlertRow({ a, now }: { a: Alert; now: number }) {
  const { quests, byId } = useData();
  const meta = ALERT_META[a.kind] ?? ALERT_META.system;
  const Icon = meta.icon;
  const q = a.questId ? quests.find((x) => x.id === a.questId) : undefined;
  // A1: "soon" alerts show a live countdown read from the quest's unlock timestamp, never frozen text.
  const unlock = q ? getUnlockTimestamp(q) : null;
  const live = a.kind === "soon" && unlock && unlock > now ? `Unlocks in ${fmtLeft(unlock - now)}` : a.kind === "soon" && unlock !== null && unlock !== undefined && unlock <= now ? "Unlocked — claim it now" : null;

  const open = async () => {
    await apiRequest("POST", `/api/alerts/${a.id}/read`);
    invalidateAll();
    if (a.kind === "session") {
      if (isNative) QuestPilot.connectZealy().catch(() => {});
      return;
    }
    if (a.url) return openLink(a.url, { title: q?.title });
    const c = a.communityId ? byId.get(a.communityId) : undefined;
    if (q) openLink(questUrl(q, byId.get(q.communityId)), { title: q.title });
    else if (c) openLink(leaderboardUrl(c));
  };

  return (
    <li>
      <button
        onClick={open}
        data-testid={`row-alert-${a.id}`}
        className={cn("flex w-full items-start gap-3 rounded-xl border p-3 text-left hover-elevate", a.read ? "border-border/60 bg-transparent" : "border-card-border bg-card")}
      >
        <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg", meta.cls)}>
          <Icon className="h-4 w-4" />
        </span>
        <span className="min-w-0 flex-1">
          <span className={cn("block text-sm leading-snug", a.read ? "text-muted-foreground" : "font-semibold")}>{a.title}</span>
          <span className="block truncate text-xs text-muted-foreground">{live ?? a.body}</span>
        </span>
        <span className="flex shrink-0 flex-col items-end gap-1">
          <span className="text-[11px] text-muted-foreground">{timeAgo(a.createdAt, now)}</span>
          {!a.read && <span className="h-2 w-2 rounded-full bg-primary" />}
        </span>
      </button>
    </li>
  );
}

export default function Alerts() {
  const { alerts } = useData();
  const now = useNow(1000);
  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-xl font-extrabold">Alerts</h1>
        <Button
          size="sm"
          variant="ghost"
          data-testid="button-read-all"
          onClick={async () => {
            await apiRequest("POST", "/api/alerts/read-all");
            invalidateAll();
          }}
        >
          <CheckCheck className="mr-1 h-4 w-4" />
          Read all
        </Button>
      </div>
      <ul className="mt-4 space-y-2">
        {!alerts.length && (
          <EmptyState
            icon={BellRing}
            title="All quiet"
            body="Claim unlocks, new and unlocked quests, community messages, limited-task deadlines and sprint endings will show up here."
          />
        )}
        {alerts.map((a) => (
          <AlertRow key={a.id} a={a} now={now} />
        ))}
      </ul>
      {alerts.length > 0 && (
        <Button
          variant="ghost"
          size="sm"
          className="mt-4 w-full text-muted-foreground"
          data-testid="button-clear-alerts"
          onClick={async () => {
            await apiRequest("DELETE", "/api/alerts");
            invalidateAll();
          }}
        >
          Clear history
        </Button>
      )}
    </div>
  );
}
