import { useState } from "react";
import { BellOff, ExternalLink, Pencil, Plus, RefreshCw, RotateCw, Trash2, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { EmptyState } from "@/components/common";
import { CommunityDialog } from "@/components/CommunityDialog";
import { QuestDialog } from "@/components/QuestDialog";
import { ZealyLogo } from "@/components/ZealyLogo";
import { useToast } from "@/hooks/use-toast";
import { useData } from "@/hooks/useData";
import { useNativeStatus } from "@/hooks/useNative";
import { useNow } from "@/hooks/useNow";
import { apiRequest, invalidateAll } from "@/lib/api";
import { isNative, QuestPilot } from "@/lib/native";
import { fmtLeft, leaderboardUrl, openLink, questboardUrl, timeAgo } from "@/lib/quest";
import type { Community } from "@/lib/types";

export function useSyncAll() {
  const { toast } = useToast();
  const status = useNativeStatus();
  const [busy, setBusy] = useState(false);
  const run = async () => {
    if (!isNative) {
      toast({ title: "Zealy sync runs in the Android app" });
      return;
    }
    setBusy(true);
    try {
      if (!status.connected || status.sessionExpired) {
        const r = await QuestPilot.connectZealy();
        if (!r.connected) return;
      }
      const r = await QuestPilot.syncNow({});
      const added = (r.results ?? []).reduce((n, x) => n + x.added, 0);
      toast(
        r.ok
          ? { title: "Synced with Zealy", description: `${r.results?.length ?? 0} communities · ${added} new tasks` }
          : { title: "Sync failed", description: `${r.error ?? "Unknown error"}. Previous statuses were kept.` },
      );
    } catch (e) {
      toast({ title: "Sync failed", description: String((e as Error).message).slice(0, 120) });
    } finally {
      setBusy(false);
    }
  };
  return { run, busy };
}

export default function Sprints() {
  const { communities, quests } = useData();
  const now = useNow(1000);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Community | null>(null);
  const [addTaskFor, setAddTaskFor] = useState<number | null>(null);
  const [syncing, setSyncing] = useState<number | null>(null);
  const { toast } = useToast();
  const syncAll = useSyncAll();
  const [search, setSearch] = useState("");
  const term = search.trim().toLowerCase();
  const shown = term
    ? communities.filter((c) => [c.name, c.subdomain, c.sprintName, c.prize].some((v) => (v ?? "").toLowerCase().includes(term)))
    : communities;

  const syncOne = async (c: Community) => {
    setSyncing(c.id);
    try {
      const r = await apiRequest<{ ok: boolean; added: number; error?: string }>("POST", `/api/communities/${c.id}/sync`);
      invalidateAll();
      toast(r.ok ? { title: `${c.name} synced`, description: r.added ? `${r.added} new tasks found` : "No new tasks" } : { title: "Sync failed", description: r.error });
    } finally {
      setSyncing(null);
    }
  };

  return (
    <div>
      <div className="flex justify-end">
        <Button size="icon" variant="secondary" className="h-8 w-8" aria-label="Open Zealy" data-testid="button-open-zealy" onClick={() => openLink("https://zealy.io/")}>
          <ZealyLogo className="h-4 w-4" />
        </Button>
      </div>
      <div className="mt-2 flex items-center justify-between">
        <h1 className="font-display text-xl font-extrabold">Sprints joined</h1>
        <div className="flex gap-2">
          <Button size="sm" variant="secondary" data-testid="button-open-sync" onClick={syncAll.run} disabled={syncAll.busy}>
            <RefreshCw className={`mr-1 h-4 w-4 ${syncAll.busy ? "animate-spin" : ""}`} />
            Sync
          </Button>
          <Button
            size="sm"
            data-testid="button-add-community"
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="mr-1 h-4 w-4" />
            Add
          </Button>
        </div>
      </div>
      {communities.length > 0 && (
        <Input className="mt-3" placeholder="Search sprints" value={search} onChange={(e) => setSearch(e.target.value)} data-testid="input-search-sprints" />
      )}
      <div className="mt-4 space-y-3">
        {term && communities.length > 0 && !shown.length && (
          <p className="py-6 text-center text-sm text-muted-foreground" data-testid="text-no-sprint-match">
            No sprint matches "{search.trim()}"
          </p>
        )}
        {!communities.length && (
          <EmptyState icon={Trophy} title="No communities yet" body="Sync from your Zealy account to bring in every community you've joined, or add one by link.">
            <Button size="sm" onClick={syncAll.run}>
              Sync from Zealy
            </Button>
          </EmptyState>
        )}
        {shown.map((c) => {
          const cq = quests.filter((q) => q.communityId === c.id);
          const once = cq.filter((q) => q.recurrence === "once");
          const done = once.filter((q) => q.status === "done").length;
          const doneCount = cq.filter((q) => q.status === "done").length;
          const realXp = typeof c.userXp === "number" ? c.userXp : null;
          const xp = cq.reduce((n, q) => n + (q.recurrence === "once" ? (q.status === "done" ? q.xp : 0) : q.xp * q.claimCount), 0);
          const left = c.sprintEndsAt ? new Date(c.sprintEndsAt).getTime() - now : null;
          return (
            <article key={c.id} data-testid={`card-community-${c.id}`} className="overflow-hidden rounded-xl border border-card-border bg-card">
              <div className="h-1.5" style={{ background: `linear-gradient(90deg, hsl(${c.hue} 80% 60%), hsl(${(c.hue + 50) % 360} 80% 60%))` }} />
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-display text-lg font-extrabold">{c.name}</p>
                    <p className="truncate text-xs text-muted-foreground">zealy.io/cw/{c.subdomain}</p>
                    {c.syncError ? (
                      <p className="mt-0.5 text-xs text-destructive" data-testid={`text-sync-error-${c.id}`}>
                        {c.syncError}
                      </p>
                    ) : c.lastSyncAt ? (
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        Synced {timeAgo(c.lastSyncAt, now)}
                        {c.autoSync ? " · auto every 30 min" : ""}
                      </p>
                    ) : null}
                  </div>
                  <div className="flex shrink-0">
                    {!c.notify && <BellOff className="mr-1 mt-2 h-4 w-4 text-muted-foreground" aria-label="Muted" />}
                    <Button size="icon" variant="ghost" className="h-8 w-8" aria-label="Sync now" data-testid={`button-sync-community-${c.id}`} onClick={() => syncOne(c)} disabled={syncing === c.id}>
                      <RotateCw className={`h-4 w-4 ${syncing === c.id ? "animate-spin" : ""}`} />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      aria-label="Edit"
                      data-testid={`button-edit-community-${c.id}`}
                      onClick={() => {
                        setEditing(c);
                        setOpen(true);
                      }}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      aria-label="Remove"
                      data-testid={`button-delete-community-${c.id}`}
                      onClick={async () => {
                        await apiRequest("DELETE", `/api/communities/${c.id}`);
                        invalidateAll();
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg bg-muted/60 p-2">
                    <p className="text-[11px] text-muted-foreground">Sprint ends</p>
                    <p className={`tabular font-mono text-sm font-bold ${left !== null && left < 864e5 ? "text-destructive" : ""}`}>
                      {left === null ? "—" : left > 0 ? fmtLeft(left) : "Ended"}
                    </p>
                  </div>
                  <div className="rounded-lg bg-muted/60 p-2">
                    <p className="text-[11px] text-muted-foreground">Tasks done / total</p>
                    <p className="tabular text-sm font-bold" data-testid={`text-tasks-${c.id}`}>
                      {doneCount}/{cq.length}
                    </p>
                  </div>
                  <div className="rounded-lg bg-muted/60 p-2">
                    <p className="text-[11px] text-muted-foreground">XP earned</p>
                    <p className="tabular text-sm font-bold text-primary" data-testid={`text-xp-${c.id}`}>
                      {realXp !== null ? realXp.toLocaleString() : xp}
                    </p>
                  </div>
                </div>
                {(c.sprintName || c.prize) && (
                  <p className="mt-3 text-sm">
                    <span className="font-semibold">{c.sprintName}</span>
                    {c.prize && <span className="text-muted-foreground"> · {c.prize}</span>}
                  </p>
                )}
                {once.length > 0 && (
                  <div className="mt-3">
                    <div className="mb-1 flex justify-between text-xs text-muted-foreground">
                      <span>One-time tasks done</span>
                      <span className="tabular">
                        {done}/{once.length}
                      </span>
                    </div>
                    <Progress value={(done / once.length) * 100} className="h-1.5" />
                  </div>
                )}
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <Button size="sm" variant="secondary" onClick={() => setAddTaskFor(c.id)} data-testid={`button-add-task-${c.id}`}>
                    <Plus className="mr-1 h-3.5 w-3.5" />
                    Task
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => openLink(questboardUrl(c))} data-testid={`button-questboard-${c.id}`}>
                    Quests
                    <ExternalLink className="ml-1 h-3 w-3" />
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => openLink(leaderboardUrl(c))} data-testid={`button-leaderboard-${c.id}`}>
                    Board
                    <ExternalLink className="ml-1 h-3 w-3" />
                  </Button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
      <CommunityDialog open={open} onOpenChange={setOpen} editing={editing} />
      <QuestDialog open={addTaskFor !== null} onOpenChange={(v) => !v && setAddTaskFor(null)} defaultCommunityId={addTaskFor ?? undefined} />
    </div>
  );
}
