import { Link } from "wouter";
export default function NotFound() {
  return (
    <div className="pt-10 text-center">
      <p className="font-display text-xl font-extrabold">Page not found</p>
      <Link href="/" className="mt-3 inline-block text-sm font-semibold text-primary">
        Back to Today
      </Link>
    </div>
  );
}
