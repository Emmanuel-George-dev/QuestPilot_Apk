import { useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { ChevronRight, ExternalLink, Plus, Rocket, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { EmptyState, SectionTitle } from "@/components/common";
import { CommunityDialog } from "@/components/CommunityDialog";
import { QuestCard } from "@/components/QuestCard";
import { StatusLine } from "@/components/StatusLine";
import { useAutopilot } from "@/hooks/autopilot";
import { useData } from "@/hooks/useData";
import { useNativeStatus } from "@/hooks/useNative";
import { useNow } from "@/hooks/useNow";
import { useLaunch } from "@/hooks/useSubmissions";
import { isNative, QuestPilot } from "@/lib/native";
import { fmtLeft, getUnlockTimestamp, leaderboardUrl, openLink, sortClaims } from "@/lib/quest";

function Stat({ label, value, accent, mono, testid }: { label: string; value: string; accent?: boolean; mono?: boolean; testid: string }) {
  return (
    <div className={`rounded-xl border p-3 ${accent ? "border-primary/50 bg-accent/50" : "border-card-border bg-card"}`}>
      <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
      <p data-testid={testid} className={`tabular mt-1 text-lg font-bold ${mono ? "font-mono" : ""} ${accent ? "text-primary" : ""}`}>
        {value}
      </p>
    </div>
  );
}

export default function Today() {
  const { communities, quests, byId, loading } = useData();
  const now = useNow(1000);
  const { autopilot, setAutopilot, autoNextClaim, setAutoNextClaim } = useAutopilot();
  const status = useNativeStatus();
  const [, navigate] = useLocation();
  const [addOpen, setAddOpen] = useState(false);
  const [run, setRun] = useState<number | null>(null);

  const recurring = quests.filter((q) => q.recurrence !== "once");
  const ready = sortClaims(recurring.filter((q) => (getUnlockTimestamp(q) ?? Infinity) <= now), byId, now);
  const upcoming = recurring.filter((q) => (getUnlockTimestamp(q) ?? 0) > now).sort((a, b) => getUnlockTimestamp(a)! - getUnlockTimestamp(b)!);
  const limited = quests
    .filter((q) => q.deadline && q.status !== "done" && new Date(q.deadline).getTime() > now)
    .sort((a, b) => new Date(a.deadline!).getTime() - new Date(b.deadline!).getTime());
  const sprints = communities
    .filter((c) => c.sprintEndsAt && new Date(c.sprintEndsAt).getTime() > now)
    .sort((a, b) => new Date(a.sprintEndsAt!).getTime() - new Date(b.sprintEndsAt!).getTime());
  const nextIn = upcoming[0] ? getUnlockTimestamp(upcoming[0])! - now : null;
  const runIds = useMemo(() => ready.map((q) => q.id), [run === null ? ready.length : -1]);
  const runQuest = run !== null ? quests.find((q) => q.id === runIds[run]) : undefined;
  const runner = useLaunch(runQuest, runQuest ? byId.get(runQuest.communityId) : undefined, !!runQuest);

  if (loading)
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((i) => (
          <Skeleton key={i} className="h-28 w-full rounded-xl" />
        ))}
      </div>
    );

  if (!communities.length)
    return (
      <div className="pt-2">
        <StatusLine />
        <h1 className="mt-4 font-display text-xl font-extrabold">Never miss a Zealy claim again</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          QuestPilot reads the questboards of the communities you've joined, detects daily, limited, Twitter and image tasks, alerts you, and
          opens the claim page the moment a daily unlocks.
        </p>
        <div className="mt-6">
          <EmptyState icon={Trophy} title="No sprints yet" body="Connect your Zealy account to import every community you've joined, or add one by pasting its link.">
            <Button
              data-testid="button-connect-first"
              onClick={async () => {
                if (!isNative) return navigate("/settings");
                if (!status.connected || status.sessionExpired) await QuestPilot.connectZealy().catch(() => {});
                await QuestPilot.syncNow({}).catch(() => {});
              }}
            >
              {status.connected && !status.sessionExpired ? "Sync from Zealy" : status.sessionExpired ? "Reconnect Zealy" : "Connect Zealy"}
            </Button>
            <Button data-testid="button-add-first-community" variant="secondary" onClick={() => setAddOpen(true)}>
              <Plus className="mr-1.5 h-4 w-4" />
              Add by link
            </Button>
          </EmptyState>
        </div>
        <CommunityDialog open={addOpen} onOpenChange={setAddOpen} />
      </div>
    );

  return (
    <div>
      <StatusLine />
      <section className="grid grid-cols-3 gap-2">
        <Stat label="Ready now" value={String(ready.length)} accent={ready.length > 0} testid="stat-ready" />
        <Stat label="Next unlock" value={nextIn !== null ? fmtLeft(nextIn) : "—"} mono testid="stat-next" />
        <Stat label="Live sprints" value={String(sprints.length)} testid="stat-sprints" />
      </section>
      <div className="mt-3 flex items-center justify-between rounded-xl border border-card-border bg-card p-3.5">
        <div className="flex items-center gap-3">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-accent text-accent-foreground">
            <Rocket className="h-5 w-5" />
          </span>
          <div>
            <p className="text-sm font-bold">Daily claim autopilot</p>
            <p className="text-xs text-muted-foreground">{autopilot ? "Opens claim pages as soon as they unlock" : "Paused — you'll only see alerts"}</p>
          </div>
        </div>
        <Switch data-testid="switch-autopilot" checked={autopilot} onCheckedChange={setAutopilot} aria-label="Toggle autopilot" />
      </div>
      {ready.length > 0 && (
        <div className="mt-3 rounded-xl border border-primary/40 bg-accent/40 p-4">
          {runQuest ? (
            <>
              <div className="flex items-start justify-between gap-3">
                <p className="text-xs font-bold uppercase tracking-wider text-primary">
                  Claim run · {run! + 1} of {runIds.length}
                </p>
                <label className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
                  Auto-next
                  <Switch data-testid="switch-auto-next" checked={autoNextClaim} onCheckedChange={setAutoNextClaim} aria-label="Auto-next after a successful claim" />
                </label>
              </div>
              <p className="mt-1 font-semibold">{runQuest.title}</p>
              <p className="text-xs text-muted-foreground">{byId.get(runQuest.communityId)?.name}</p>
              <div className="mt-3 flex gap-2">
                <Button
                  className="flex-1"
                  data-testid="button-run-open"
                  onClick={() => {
                    // The claim screen keeps the rest of the run, so it has its own Next button.
                    runner.launch(runIds.slice(run!));
                    setRun(null);
                  }}
                >
                  Open & next <ExternalLink className="ml-1.5 h-4 w-4" />
                </Button>
                <Button variant="ghost" onClick={() => setRun(null)} data-testid="button-run-stop">
                  Stop
                </Button>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="font-semibold">
                  {ready.length} claim{ready.length > 1 ? "s" : ""} waiting
                </p>
                <p className="text-xs text-muted-foreground">Go through them one tap at a time</p>
              </div>
              <Button data-testid="button-start-run" onClick={() => setRun(0)}>
                Start claim run
              </Button>
            </div>
          )}
        </div>
      )}
      {ready.length > 0 && <SectionTitle>Claimable now</SectionTitle>}
      <div className="space-y-2.5">
        {ready.map((q) => (
          <QuestCard key={q.id} q={q} c={byId.get(q.communityId)} now={now} />
        ))}
      </div>
      <SectionTitle
        action={
          <Link href="/quests" className="flex items-center text-xs font-semibold text-primary" data-testid="link-all-tasks">
            All tasks
            <ChevronRight className="h-3.5 w-3.5" />
          </Link>
        }
      >
        Up next
      </SectionTitle>
      {upcoming.length ? (
        <ul className="divide-y divide-border/60 overflow-hidden rounded-xl border border-card-border bg-card">
          {upcoming.slice(0, 6).map((q) => (
            <li key={q.id} className="flex items-center justify-between gap-3 px-3.5 py-3" data-testid={`row-upcoming-${q.id}`}>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold">{q.title}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {byId.get(q.communityId)?.name} · {q.recurrence}
                </p>
              </div>
              <span className="tabular shrink-0 font-mono text-sm" data-testid={`text-upcoming-left-${q.id}`}>
                {fmtLeft(getUnlockTimestamp(q)! - now)}
              </span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-muted-foreground">No recurring tasks counting down. Add a daily task from the Tasks tab.</p>
      )}
      {limited.length > 0 && <SectionTitle>Limited — ending soon</SectionTitle>}
      <div className="space-y-2.5">
        {limited.slice(0, 4).map((q) => (
          <QuestCard key={q.id} q={q} c={byId.get(q.communityId)} now={now} />
        ))}
      </div>
      {sprints.length > 0 && <SectionTitle>Sprint deadlines</SectionTitle>}
      <div className="space-y-2.5">
        {sprints.map((c) => {
          const left = new Date(c.sprintEndsAt!).getTime() - now;
          return (
            <button
              key={c.id}
              onClick={() => openLink(leaderboardUrl(c))}
              data-testid={`button-sprint-${c.id}`}
              className="flex w-full items-center gap-3 rounded-xl border border-card-border bg-card p-3.5 text-left hover-elevate"
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg" style={{ background: `hsl(${c.hue} 70% 55% / .16)`, color: `hsl(${c.hue} 80% 65%)` }}>
                <Trophy className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">
                  {c.sprintName || "Sprint"} · {c.name}
                </p>
                <p className="truncate text-xs text-muted-foreground">{c.prize || "Leaderboard"}</p>
              </div>
              <span className={`tabular shrink-0 font-mono text-sm ${left < 24 * 36e5 ? "text-destructive" : ""}`}>{fmtLeft(left)}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
