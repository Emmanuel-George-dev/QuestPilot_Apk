import { UserGuide } from "@/components/UserGuide";
import { Suspense, lazy, useEffect, useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Bug, CalendarPlus, ChevronRight, Globe, Radar, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Field, SectionTitle } from "@/components/common";
import { PermissionList } from "@/components/Permissions";
import { StatusLine } from "@/components/StatusLine";
import { useToast } from "@/hooks/use-toast";
import { useAutopilot } from "@/hooks/autopilot";
import { useData } from "@/hooks/useData";
import { setNativeStatus, useNativeStatus } from "@/hooks/useNative";
import { useNow } from "@/hooks/useNow";
import { apiRequest, invalidateAll } from "@/lib/api";
import { isNative, QuestPilot } from "@/lib/native";
import { DEV_TOOLS } from "@/lib/devtools";
import { chime, fmtClock, fmtLeft, getUnlockTimestamp, timeAgo } from "@/lib/quest";
import type { Community, Quest } from "@/lib/types";
import { useSyncAll } from "./Sprints";

function Toggle({ title, body, checked, onChange, testid, extra }: { title: string; body?: string; checked: boolean; onChange: (v: boolean) => void; testid: string; extra?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 p-3.5">
      <div>
        <p className="text-sm font-semibold">{title}</p>
        {body && <p className="text-xs text-muted-foreground">{body}</p>}
      </div>
      <div className="flex items-center gap-2">
        {extra}
        <Switch checked={checked} onCheckedChange={onChange} data-testid={testid} />
      </div>
    </div>
  );
}

function icsDate(ms: number) {
  return new Date(ms).toISOString().replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
}
function buildIcs(communities: Community[], quests: Quest[]) {
  const now = Date.now();
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//QuestPilot//EN"];
  const ev = (uid: string, start: number, title: string) =>
    lines.push("BEGIN:VEVENT", `UID:${uid}@questpilot`, `DTSTAMP:${icsDate(now)}`, `DTSTART:${icsDate(start)}`, `DTEND:${icsDate(start + 30 * 6e4)}`, `SUMMARY:${title.replace(/[,;\n]/g, " ")}`, "END:VEVENT");
  communities.forEach((c) => c.sprintEndsAt && new Date(c.sprintEndsAt).getTime() > now && ev(`sprint-${c.id}`, new Date(c.sprintEndsAt).getTime(), `${c.name}: sprint ends`));
  quests.forEach((q) => {
    if (q.deadline && q.status !== "done" && new Date(q.deadline).getTime() > now) ev(`deadline-${q.id}`, new Date(q.deadline).getTime(), `Deadline: ${q.title}`);
    const t = getUnlockTimestamp(q); // A1: same single source as the countdown and notifications
    if (q.recurrence !== "once" && t && t > now) ev(`unlock-${q.id}-${t}`, t, `Claim: ${q.title}`);
  });
  lines.push("END:VCALENDAR");
  return lines.join("\r\n");
}

// Debug builds only: the whole module is left out of the release bundle (DEV_TOOLS is a build-time constant).
const DevToolsSection = DEV_TOOLS ? lazy(() => import("@/devtools/DevToolsSection")) : null;

export default function Settings() {
  const ap = useAutopilot();
  const { communities, quests } = useData();
  const status = useNativeStatus();
  const now = useNow(15000);
  const { toast } = useToast();
  const syncAll = useSyncAll();
  const settings = useQuery<{ tgChat: string; tgConfigured: boolean }>({ queryKey: ["/api/settings"] }).data;
  const [tgToken, setTgToken] = useState("");
  const [tgChat, setTgChat] = useState("");
  useEffect(() => {
    if (settings?.tgChat) setTgChat(settings.tgChat);
  }, [settings?.tgChat]);

  const saveTelegram = async () => {
    try {
      await apiRequest("POST", "/api/settings", { tgToken, tgChat });
      setTgToken("");
      invalidateAll();
      await apiRequest("POST", "/api/settings/test-telegram");
      toast({ title: "Telegram connected", description: "A test message was sent to your Telegram chat." });
    } catch (e) {
      toast({ title: "Telegram test failed", description: String((e as Error).message).slice(0, 140) });
    }
  };
  const downloadCalendar = async () => {
    const ics = buildIcs(communities, quests);
    if (isNative) await QuestPilot.shareText({ text: ics, fileName: "questpilot.ics", mime: "text/calendar" }).catch(() => {});
    else {
      const a = document.createElement("a");
      a.href = URL.createObjectURL(new Blob([ics], { type: "text/calendar" }));
      a.download = "questpilot.ics";
      a.click();
    }
  };
  return (
    <div>
      <h1 className="font-display text-xl font-extrabold">Settings</h1>

      <SectionTitle>Autopilot</SectionTitle>
      <div className="divide-y divide-border/60 rounded-xl border border-card-border bg-card">
        <Toggle title="Autopilot" body="Watch every daily/weekly task and act when it unlocks" checked={ap.autopilot} onChange={ap.setAutopilot} testid="switch-settings-autopilot" />
        <Toggle
          title="Auto-open claim pages"
          body="Loads the claim page 3 seconds early and shows it at the unlock second. When the app is closed you get a full-screen alert instead."
          checked={ap.autoOpenTabs}
          onChange={ap.setAutoOpenTabs}
          testid="switch-auto-open-tabs"
        />
        <Toggle
          title="Chime"
          checked={ap.sound}
          onChange={ap.setSound}
          testid="switch-sound"
          extra={
            <Button size="sm" variant="ghost" onClick={chime}>
              Test
            </Button>
          }
        />
        <Toggle title="Dark mode" checked={ap.theme === "dark"} onChange={(v) => ap.setTheme(v ? "dark" : "light")} testid="switch-theme" />
      </div>

      <SectionTitle>Zealy account</SectionTitle>
      <StatusLine />
      <div className="rounded-xl border border-card-border bg-card p-3.5">
        <p className="text-sm font-semibold" data-testid="text-zealy-account">
          {!isNative ? "Available in the Android app" : status.connected && !status.sessionExpired ? `Connected${status.userName ? ` as ${status.userName}` : ""}` : status.sessionExpired ? "Session expired" : "Not connected"}
        </p>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Log in to zealy.io once inside the app. Only the session cookie is kept, encrypted with the Android Keystore. Your password is never stored.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {(!status.connected || status.sessionExpired) && (
            <Button
              size="sm"
              data-testid="button-connect-zealy"
              disabled={!isNative}
              onClick={async () => {
                const r = await QuestPilot.connectZealy().catch(() => ({ connected: false }));
                if (r.connected) syncAll.run();
              }}
            >
              {status.sessionExpired ? "Reconnect Zealy" : "Connect Zealy"}
            </Button>
          )}
          {status.connected && !status.sessionExpired && (
            <Button size="sm" variant="secondary" onClick={syncAll.run} disabled={syncAll.busy} data-testid="button-sync-now">
              {syncAll.busy ? "Syncing…" : "Sync now"}
            </Button>
          )}
          {status.connected && (
            <Button
              size="sm"
              variant="ghost"
              data-testid="button-disconnect-zealy"
              onClick={async () => {
                await QuestPilot.disconnectZealy();
                setNativeStatus(await QuestPilot.getStatus());
              }}
            >
              Disconnect
            </Button>
          )}
        </div>
        {status.lastMessagePollAt > 0 && <p className="mt-2 text-xs text-muted-foreground">Messages checked {timeAgo(status.lastMessagePollAt, now)} · 5 min for tracked, 15 min for other communities</p>}
      </div>
      <Link href="/monitor" className="mt-2 flex items-center gap-3 rounded-xl border border-card-border bg-card p-3.5 hover-elevate" data-testid="link-monitor">
        <Radar className="h-5 w-5 text-primary" />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold">Watchlist & Zealy Monitor</p>
          <p className="text-xs text-muted-foreground">{status.watchText ?? "Communities checked every 3-4 min (staggered) for new and unlocked quests"}</p>
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
      </Link>
      <div className="mt-2 divide-y divide-border/60 rounded-xl border border-card-border bg-card" data-testid="section-polling">
        <Toggle
          title="Only watch communities with a running sprint"
          body="Fast checks (every 3-4 min) for communities with a running sprint, locked quests without a timer, and the watchlist. The others refresh with the full sync. Alarms work either way."
          checked={ap.prefs.sprintOnlyWatch !== false}
          onChange={(v) => ap.setPref("sprintOnlyWatch", v)}
          testid="switch-sprint-only"
        />
        <div className="flex items-center justify-between gap-3 p-3.5">
          <div>
            <p className="text-sm font-semibold">Full sync every</p>
            <p className="text-xs text-muted-foreground">
              {status.slowFullSync ? "Zealy rate-limited a sync: 60 min until the app restarts" : "Sprints, XP and every community"}
            </p>
          </div>
          <div className="flex gap-1">
            {[30, 60].map((m) => (
              <Button
                key={m}
                size="sm"
                variant={(ap.prefs.fullSyncMinutes ?? 30) === m ? "default" : "secondary"}
                onClick={() => ap.setPref("fullSyncMinutes", m)}
                data-testid={`button-full-sync-${m}`}
              >
                {m} min
              </Button>
            ))}
          </div>
        </div>
      </div>

      <SectionTitle>Notification stages</SectionTitle>
      <div className="divide-y divide-border/60 rounded-xl border border-card-border bg-card" data-testid="section-stages">
        <Toggle title="10 minutes before" body="Normal notification" checked={ap.prefs.stage10m !== false} onChange={(v) => ap.setPref("stage10m", v)} testid="switch-stage-10m" />
        <Toggle title="5 minutes before" body="Normal notification" checked={ap.prefs.stage5m !== false} onChange={(v) => ap.setPref("stage5m", v)} testid="switch-stage-5m" />
        <Toggle
          title="10 seconds before"
          body="Full-screen countdown screen (needs Autopilot)"
          checked={ap.prefs.stage10s !== false}
          onChange={(v) => ap.setPref("stage10s", v)}
          testid="switch-stage-10s"
        />
        <Toggle
          title="3 seconds before"
          body="The claim page loads behind the countdown and is shown and refreshed at zero (needs Autopilot)"
          checked={ap.prefs.stage3s !== false}
          onChange={(v) => ap.setPref("stage3s", v)}
          testid="switch-stage-3s"
        />
      </div>
      <p className="mt-1.5 text-xs text-muted-foreground">For every task with an unlock time: daily, weekly, monthly and one-time. Tasks unlocking in the same second share one alert. A community with notifications off gets none.</p>

      <SectionTitle>Logins</SectionTitle>
      <Link href="/sites" className="flex items-center gap-3 rounded-xl border border-card-border bg-card p-3.5 hover-elevate" data-testid="link-sites">
        <Globe className="h-5 w-5 text-primary" />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold">Logged-in sites</p>
          <p className="text-xs text-muted-foreground">X, Facebook, Discord and other sites you are logged into inside the app</p>
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
      </Link>

      <SectionTitle>Debug & experiments</SectionTitle>
      <Link href="/debug" className="flex items-center gap-3 rounded-xl border border-card-border bg-card p-3.5 hover-elevate" data-testid="link-debug">
        <Bug className="h-5 w-5 text-primary" />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold">In-app links, X actions, logs</p>
          <p className="text-xs text-muted-foreground">One switch per feature, the like/repost timer, autofill steps and the debug logs</p>
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground" />
      </Link>

      <SectionTitle>Permissions</SectionTitle>
      <PermissionList />

      <SectionTitle>Alerts when the app is closed</SectionTitle>
      <div className="space-y-3 rounded-xl border border-card-border bg-card p-3.5">
        <div>
          <p className="text-sm font-semibold">Phone calendar reminders</p>
          <p className="text-xs text-muted-foreground">
            A calendar file with the next unlock of every recurring task, limited-task deadlines and sprint ends. Re-export after adding tasks.
          </p>
          <Button size="sm" variant="secondary" className="mt-2" onClick={downloadCalendar} data-testid="link-download-ics">
            <CalendarPlus className="mr-1.5 h-4 w-4" />
            Export calendar
          </Button>
        </div>
        <div className="border-t border-border/60 pt-3">
          <p className="flex items-center gap-2 text-sm font-semibold">
            <Send className="h-4 w-4" />
            Telegram push {settings?.tgConfigured && <span className="text-xs font-semibold text-emerald-500">Connected</span>}
          </p>
          <p className="text-xs text-muted-foreground">
            Create a bot with @BotFather, send it any message, then paste its token and your chat ID (get it from @userinfobot). Every alert is pushed to Telegram.
          </p>
          <div className="mt-2 grid gap-2">
            <Field label="Bot token">
              <Input value={tgToken} onChange={(e) => setTgToken(e.target.value)} placeholder={settings?.tgConfigured ? "Saved — paste to replace" : "123456:ABC…"} data-testid="input-tg-token" />
            </Field>
            <Field label="Chat ID">
              <Input value={tgChat} onChange={(e) => setTgChat(e.target.value)} placeholder="123456789" data-testid="input-tg-chat" />
            </Field>
            <Button size="sm" onClick={saveTelegram} disabled={!isNative || (!tgToken && !settings?.tgConfigured)} data-testid="button-save-telegram">
              Save & send test
            </Button>
          </div>
        </div>
      </div>

      {DevToolsSection && status.debugBuild && (
        <Suspense fallback={null}>
          <DevToolsSection />
        </Suspense>
      )}

      <SectionTitle>How autopilot works</SectionTitle>
      <p className="text-sm text-muted-foreground">
        QuestPilot never stores your Zealy password. It reads questboards with your encrypted session and opens the exact quest page in its
        signed-in Zealy view when a claim unlocks, so you finish it with one tap. Nothing is ever submitted for you. Opening a task never changes its
        status — statuses only come from a successful Zealy sync. Daily quests reset at 00:00 UTC.
      </p>

      <SectionTitle>User guide</SectionTitle>
      <UserGuide />
    </div>
  );
}
