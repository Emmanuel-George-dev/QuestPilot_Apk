import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { History, Radar, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState, SectionTitle } from "@/components/common";
import { StatusLine } from "@/components/StatusLine";
import { useToast } from "@/hooks/use-toast";
import { useData } from "@/hooks/useData";
import { useNow } from "@/hooks/useNow";
import { apiRequest, invalidateAll } from "@/lib/api";
import { parseZealyLink } from "@/lib/quest";
import { WATCHLIST_MAX } from "@/lib/types";
import { AlertRow } from "./Alerts";

const MONITOR_KINDS = new Set(["quest-new", "quest-unlocked", "message", "session"]);

export default function Monitor() {
  const { alerts, communities } = useData();
  const now = useNow(1000);
  const { toast } = useToast();
  const watchlist = useQuery<{ watchlist: string[] }>({ queryKey: ["/api/settings"] }).data?.watchlist ?? [];
  const [input, setInput] = useState("");
  const history = alerts.filter((a) => MONITOR_KINDS.has(a.kind));

  const save = async (list: string[]) => {
    try {
      await apiRequest("POST", "/api/settings", { watchlist: list });
      invalidateAll();
      return true;
    } catch (e) {
      toast({ title: "Watchlist not changed", description: String((e as Error).message).replace(/^\d+:\s*/, "") });
      return false;
    }
  };
  const add = async (raw: string) => {
    const t = raw.trim();
    const sub = (parseZealyLink(t).subdomain ?? t.replace(/^@/, "")).toLowerCase();
    if (!sub || /[/:\s]/.test(sub)) {
      toast({ title: "Enter a community subdomain", description: 'For example "lynxcap" or a zealy.io/cw/… link' });
      return;
    }
    if (watchlist.includes(sub)) return;
    if (watchlist.length >= WATCHLIST_MAX) {
      toast({ title: `Watchlist is full (${WATCHLIST_MAX} max)`, description: "Remove a community before adding another one." });
      return;
    }
    if (await save([...watchlist, sub])) {
      setInput("");
      toast({ title: `Watching ${sub}`, description: "The first check saves a baseline. You'll be alerted on changes after that." });
    }
  };

  return (
    <div>
      <h1 className="font-display text-xl font-extrabold">Zealy Monitor</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Checks each watched questboard every 3 minutes and alerts you when a new quest appears or a quest unlocks. Messages from all your communities
        are checked every 5 minutes.
      </p>
      <div className="mt-3">
        <StatusLine />
      </div>
      <SectionTitle>
        Watchlist · {watchlist.length}/{WATCHLIST_MAX}
      </SectionTitle>
      <div className="rounded-xl border border-card-border bg-card p-3.5">
        <div className="flex gap-2">
          <Input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Subdomain, e.g. lynxcap" onKeyDown={(e) => e.key === "Enter" && add(input)} data-testid="input-watch-subdomain" />
          <Button onClick={() => add(input)} data-testid="button-watch-add">
            Add
          </Button>
        </div>
        {watchlist.length >= WATCHLIST_MAX && (
          <p className="mt-2 text-xs font-semibold text-amber-500" data-testid="text-watch-full">
            You're watching the maximum of {WATCHLIST_MAX} communities.
          </p>
        )}
        <ul className="mt-3 space-y-2">
          {watchlist.map((s) => (
            <li key={s} className="flex items-center justify-between rounded-lg bg-muted/60 px-3 py-2 text-sm" data-testid={`row-watch-${s}`}>
              <span>
                <span className="font-semibold">{communities.find((c) => c.subdomain.toLowerCase() === s)?.name ?? s}</span>
                <span className="text-muted-foreground"> · zealy.io/cw/{s}</span>
              </span>
              <button aria-label={`Stop watching ${s}`} className="rounded p-1 text-muted-foreground hover-elevate" onClick={() => save(watchlist.filter((x) => x !== s))}>
                <X className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
        {watchlist.length < WATCHLIST_MAX && communities.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {communities
              .filter((c) => !watchlist.includes(c.subdomain.toLowerCase()))
              .slice(0, 8)
              .map((c) => (
                <button key={c.id} onClick={() => add(c.subdomain)} className="rounded-full border border-border px-2.5 py-1 text-xs text-muted-foreground hover-elevate">
                  + {c.name}
                </button>
              ))}
          </div>
        )}
      </div>
      <SectionTitle>Alert history</SectionTitle>
      {history.length ? (
        <ul className="space-y-2">
          {history.map((a) => (
            <AlertRow key={a.id} a={a} now={now} />
          ))}
        </ul>
      ) : (
        <EmptyState icon={watchlist.length ? History : Radar} title="No monitor alerts yet" body="New quests, unlocks, messages and session warnings will be listed here." />
      )}
    </div>
  );
}
