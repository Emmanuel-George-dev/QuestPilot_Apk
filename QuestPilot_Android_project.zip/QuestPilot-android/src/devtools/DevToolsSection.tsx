/**
 * DEBUG BUILD ONLY. This module is imported only when DEV_TOOLS is true (vite --mode devtools),
 * so it is not part of the release bundle. The release Gradle build also fails if the marker
 * below shows up in its assets.
 */
import { useEffect, useState } from "react";
import { Bug, FlaskConical, Network, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SectionTitle } from "@/components/common";
import { useToast } from "@/hooks/use-toast";
import { useData } from "@/hooks/useData";
import { useNow } from "@/hooks/useNow";
import { useSubmissions } from "@/hooks/useSubmissions";
import { isNative, QuestPilot, type ConnectionCheck, type ConnectionTest, type DebugRow, type NetLogEntry, type TestQuest } from "@/lib/native";
import { fmtClock, fmtLeft, getUnlockTimestamp } from "@/lib/quest";

export const DEVTOOLS_MARKER = "QP_DEVTOOLS_BUNDLE";

/** A1 debug: per daily quest — unlock timestamp, time left, next scheduled notification. */
export function DebugPanel() {
  const now = useNow(1000);
  const { quests } = useData();
  const [info, setInfo] = useState<{ rows: DebugRow[]; exactAlarm: boolean } | null>(null);
  useEffect(() => {
    if (!isNative) return;
    const load = () => QuestPilot.getDebugInfo().then(setInfo).catch(() => {});
    load();
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [quests]);
  const rows: DebugRow[] =
    info?.rows ??
    quests.filter((q) => q.recurrence === "daily").map((q) => ({ questId: q.id, title: q.title, community: "", unlockAt: getUnlockTimestamp(q), nextNotifyAt: null, nextNotifyKind: null }));
  return (
    <div className="space-y-2 p-3.5" data-testid="panel-debug">
      <p className="text-xs text-muted-foreground">
        Every value below comes from the single unlock-time function. Time left = unlock timestamp − now. Exact alarms: {info ? (info.exactAlarm ? "allowed" : "NOT allowed") : "—"}
      </p>
      {!rows.length && <p className="text-xs text-muted-foreground">No daily quests yet.</p>}
      {rows.map((r) => (
        <div key={r.questId} className="rounded-md bg-muted/60 p-2 font-mono text-[11px] leading-relaxed" data-testid={`debug-row-${r.questId}`}>
          <p className="truncate font-sans text-xs font-semibold">
            {r.title}
            {r.community && <span className="font-normal text-muted-foreground"> · {r.community}</span>}
          </p>
          <p>unlock: {r.unlockAt === null ? "locked / unknown" : r.unlockAt === 0 ? "available now" : `${fmtClock(r.unlockAt)} (${r.unlockAt})`}</p>
          <p>left: {r.unlockAt ? fmtLeft(r.unlockAt - now) : "—"}</p>
          <p>
            next notify: {r.nextNotifyAt ? `${fmtClock(r.nextNotifyAt)} [${r.nextNotifyKind}] in ${fmtLeft(r.nextNotifyAt - now)}` : "none scheduled"}
          </p>
        </div>
      ))}
    </div>
  );
}


/** Test mode: a fake daily quest kept outside the real data (native DevTools file, negative id). */
function TestMode() {
  const now = useNow(250);
  const { toast } = useToast();
  const { quests } = useData();
  const { all: submissions } = useSubmissions();
  const savedQuests = quests.filter((q) => submissions.some((s) => s.questId === q.id && (s.repeat || !s.usedAt)));
  const [source, setSource] = useState("");
  const [tests, setTests] = useState<TestQuest[]>([]);
  const load = () => QuestPilot.getTestQuests().then((r) => setTests(r.quests)).catch(() => setTests([]));
  useEffect(() => {
    if (!isNative) return;
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, []);
  const start = async () => {
    try {
      const r = await QuestPilot.startTestUnlock({ seconds: 60, sourceQuestId: source ? Number(source) : null });
      load();
      toast({
        title: "[Test] Fake quest unlocks in 1 minute",
        description: `At ${new Date(r.unlockAt).toLocaleTimeString()}. ${
          source ? "Its page opens 3 s early and autofills at unlock." : "No saved content: you'll see the autofill banner."
        } Keep the app open, or close it to test the full-screen notification.`,
      });
    } catch (e) {
      toast({ title: "Couldn't start test", description: String((e as Error).message).slice(0, 140) });
    }
  };
  const clear = async () => {
    try {
      await QuestPilot.clearTest();
      setTests([]);
      toast({ title: "Test data cleared", description: "Fake quest, its alarms, test notifications and temp files removed." });
    } catch (e) {
      toast({ title: "Couldn't clear", description: String((e as Error).message).slice(0, 140) });
    }
  };
  return (
    <div className="rounded-xl border border-dashed border-amber-500/60 bg-card p-3.5" data-qp-devtools={DEVTOOLS_MARKER}>
      <p className="text-[11px] font-bold uppercase tracking-wider text-amber-500">Debug build only</p>
      <p className="mt-1 text-xs text-muted-foreground">
        Adds a fake daily quest that unlocks in 1 minute. It's kept apart from your real data: it never shows in your quest list or alert history,
        never goes to Telegram, and its notifications are marked [Test]. Check that the countdown below, the debug line and the [Test]
        notification agree, and that the claim page preloads 3 s early and opens at the unlock second.
      </p>
      {tests.map((t) => {
        const at = t.unlockAt ?? t.testUnlockAt;
        return (
          <div key={t.id} className="mt-3 rounded-lg bg-muted/60 p-2.5 text-sm" data-testid="row-test-quest">
            <p className="font-semibold">{t.title}</p>
            <p className="tabular font-mono text-xs">
              {at > now ? `Unlocks in ${fmtLeft(at - now)} (${fmtClock(at)})` : "Unlocked"} · {t.communityName}
            </p>
          </div>
        );
      })}
      <label className="mt-3 block text-xs font-semibold">Autofill test</label>
      <select
        value={source}
        onChange={(e) => setSource(e.target.value)}
        className="mt-1 h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
        data-testid="select-test-source"
      >
        <option value="">No saved content (tests the "Couldn't autofill" banner)</option>
        {savedQuests.map((q) => (
          <option key={q.id} value={q.id}>
            Use page + saved content of: {q.title}
          </option>
        ))}
      </select>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button size="sm" onClick={start} disabled={!isNative} data-testid="button-test-unlock">
          Fake unlock in 1 minute
        </Button>
        <Button size="sm" variant="secondary" onClick={clear} disabled={!isNative} data-testid="button-clear-test-data">
          <Trash2 className="mr-1.5 h-3.5 w-3.5" />
          Clear test data
        </Button>
      </div>
    </div>
  );
}

function statusClass(n: number) {
  if (n >= 200 && n < 300) return "text-emerald-500";
  if (n === 401 || n === 403) return "text-red-500";
  return "text-amber-500";
}

function CheckRow({ c }: { c: ConnectionCheck }) {
  return (
    <div className="border-t border-border/60 py-1.5 first:border-t-0">
      <div className="flex items-center justify-between gap-2">
        <span className="font-medium">{c.label}</span>
        <span className={"font-mono " + statusClass(c.status)}>{c.status}</span>
      </div>
      {c.snippet && <div className="mt-0.5 break-all font-mono text-[11px] text-muted-foreground">{c.snippet}</div>}
    </div>
  );
}

/** Connection log: every Zealy request (URL, status, response snippet; cookie values hidden) + "Test connection". */
function ConnectionLog() {
  const { toast } = useToast();
  const [entries, setEntries] = useState<NetLogEntry[]>([]);
  const [test, setTest] = useState<ConnectionTest | null>(null);
  const [busy, setBusy] = useState(false);
  const load = () => QuestPilot.getNetLog().then((r) => setEntries(r.entries)).catch(() => {});
  useEffect(() => {
    if (!isNative) return;
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, []);
  const run = async () => {
    setBusy(true);
    try {
      setTest(await QuestPilot.testConnection());
      load();
    } catch (e) {
      toast({ title: "Test failed", description: String(e) });
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="space-y-3 p-3 text-xs">
      <div className="flex gap-2">
        <Button size="sm" onClick={run} disabled={busy}>
          {busy ? "Testing…" : "Test connection"}
        </Button>
        <Button size="sm" variant="outline" onClick={() => QuestPilot.clearNetLog().then(load)}>
          Clear log
        </Button>
      </div>
      {test && (
        <div className="rounded-lg border border-border p-2">
          {test.error ? (
            <div className="text-red-500">{test.error}</div>
          ) : (
            <>
              <div className="text-muted-foreground">
                Cookies: {test.cookieNames.map((n) => n + "=…").join("; ") || "none"}
              </div>
              <div className="break-all text-muted-foreground">User-Agent: {test.userAgent}</div>
              <div className="text-muted-foreground">
                Auth: {test.authMode}
                {test.hasStorageToken ? " · token found in web storage" : " · no token in web storage"}
              </div>
              <div className="mt-2">
                {(test.okhttp ?? []).map((c) => <CheckRow key={c.label} c={c} />)}
                {(test.webview ?? []).map((c) => <CheckRow key={c.label} c={c} />)}
              </div>
            </>
          )}
        </div>
      )}
      <div className="max-h-96 overflow-y-auto rounded-lg border border-border">
        {entries.length === 0 && <div className="p-2 text-muted-foreground">No requests yet.</div>}
        {entries.map((e, i) => (
          <div key={i} className="border-t border-border/60 p-2 first:border-t-0">
            <div className="flex items-center justify-between gap-2">
              <span className="text-muted-foreground">
                {new Date(e.at).toLocaleTimeString()} · {e.source} · {e.method}
              </span>
              <span className={"font-mono " + statusClass(e.status)}>{e.status}</span>
            </div>
            <div className="break-all font-mono text-[11px]">{e.url}</div>
            {e.snippet && <div className="mt-0.5 break-all font-mono text-[11px] text-muted-foreground">{e.snippet}</div>}
            {e.cookies && <div className="mt-0.5 break-all text-[11px] text-muted-foreground">Cookie: {e.cookies}</div>}
            {e.extra && <div className="text-[11px] text-muted-foreground">{e.extra}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function DevToolsSection() {
  return (
    <>
      <SectionTitle>
        <span className="flex items-center gap-1.5">
          <FlaskConical className="h-4 w-4" />
          Test mode
        </span>
      </SectionTitle>
      <TestMode />
      <SectionTitle>
        <span className="flex items-center gap-1.5">
          <Bug className="h-4 w-4" />
          Debug: daily unlocks
        </span>
      </SectionTitle>
      <div className="rounded-xl border border-dashed border-amber-500/60 bg-card">
        <DebugPanel />
      </div>
      <SectionTitle>
        <span className="flex items-center gap-1.5">
          <Network className="h-4 w-4" />
          Debug: connection log
        </span>
      </SectionTitle>
      <div className="rounded-xl border border-dashed border-amber-500/60 bg-card">
        <ConnectionLog />
      </div>
    </>
  );
}
