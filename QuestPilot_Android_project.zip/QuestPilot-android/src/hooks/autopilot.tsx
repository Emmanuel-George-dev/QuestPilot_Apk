import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest, invalidateAll } from "@/lib/api";
import { chime, isClaimableNow, sortClaims } from "@/lib/quest";
import type { Prefs, Quest } from "@/lib/types";
import { useData } from "./useData";
import { useNow } from "./useNow";

const DEFAULT_PREFS: Prefs = { autopilot: true, autoOpenTabs: true, autoNextClaim: false, sound: true, theme: "dark", onboarded: false };

interface Ctx {
  prefs: Prefs;
  setPref: <K extends keyof Prefs>(k: K, v: Prefs[K]) => void;
  autopilot: boolean;
  setAutopilot: (v: boolean) => void;
  autoOpenTabs: boolean;
  setAutoOpenTabs: (v: boolean) => void;
  autoNextClaim: boolean;
  setAutoNextClaim: (v: boolean) => void;
  sound: boolean;
  setSound: (v: boolean) => void;
  theme: "dark" | "light";
  setTheme: (v: "dark" | "light") => void;
  claimQueue: Quest[];
  takeoverOpen: boolean;
  dismissTakeover: () => void;
  skipClaim: (id: number) => void;
}

const AutopilotContext = createContext<Ctx | null>(null);
export const useAutopilot = () => useContext(AutopilotContext)!;

const CHIME_KINDS = new Set(["deadline", "sprint", "soon", "due", "quest-new", "quest-unlocked", "message", "session"]);

export function AutopilotProvider({ children }: { children: ReactNode }) {
  // Preferences are now saved with the rest of the data (the old build kept them in memory only).
  const settings = useQuery<{ prefs: Partial<Prefs> }>({ queryKey: ["/api/settings"] });
  const [local, setLocal] = useState<Partial<Prefs>>({});
  const prefs: Prefs = { ...DEFAULT_PREFS, ...(settings.data?.prefs ?? {}), ...local };
  const setPref = <K extends keyof Prefs>(k: K, v: Prefs[K]) => {
    setLocal((p) => ({ ...p, [k]: v }));
    apiRequest("POST", "/api/settings", { prefs: { [k]: v } }).then(invalidateAll).catch(() => {});
  };

  const [takeoverOpen, setTakeoverOpen] = useState(false);
  const [skipped, setSkipped] = useState<Set<string>>(new Set());
  const seenQueue = useRef<Set<string>>(new Set());
  const firstRun = useRef(false);
  const { quests, byId, alerts } = useData();
  const now = useNow(1000);
  const seenAlerts = useRef<Set<number> | null>(null);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", prefs.theme === "dark");
  }, [prefs.theme]);

  useEffect(() => {
    apiRequest("POST", "/api/settings", { tzOffset: -new Date().getTimezoneOffset() }).catch(() => {});
  }, []);

  // In-app chime for new alerts. System notifications are posted by the native side only.
  useEffect(() => {
    if (!alerts.length && seenAlerts.current) return;
    if (!seenAlerts.current) {
      seenAlerts.current = new Set(alerts.map((a) => a.id));
      return;
    }
    for (const a of alerts) {
      if (seenAlerts.current.has(a.id)) continue;
      seenAlerts.current.add(a.id);
      if (CHIME_KINDS.has(a.kind) && prefs.sound) chime();
    }
  }, [alerts, prefs.sound]);

  const key = (q: Quest) => `${q.id}-${q.unlockAt ?? ""}`;
  const claimQueue = useMemo(
    () =>
      sortClaims(
        quests.filter((q) => isClaimableNow(q, now) && byId.get(q.communityId)?.notify && !skipped.has(key(q))),
        byId,
        now,
      ),
    [quests, byId, now, skipped],
  );

  useEffect(() => {
    if (takeoverOpen && !claimQueue.length) setTakeoverOpen(false);
  }, [claimQueue.length, takeoverOpen]);

  useEffect(() => {
    if (!quests.length) return;
    const fresh = claimQueue.filter((q) => !seenQueue.current.has(key(q)));
    fresh.forEach((q) => seenQueue.current.add(key(q)));
    if (!firstRun.current) {
      firstRun.current = true;
      if (prefs.autopilot && claimQueue.length) setTakeoverOpen(true);
      return;
    }
    if (!prefs.autopilot || !fresh.length) return;
    if (prefs.sound) chime();
    setTakeoverOpen(true);
  }, [now, claimQueue, prefs.autopilot, prefs.sound]);

  const value: Ctx = {
    prefs,
    setPref,
    autopilot: prefs.autopilot,
    setAutopilot: (v) => setPref("autopilot", v),
    autoOpenTabs: prefs.autoOpenTabs,
    setAutoOpenTabs: (v) => setPref("autoOpenTabs", v),
    autoNextClaim: !!prefs.autoNextClaim,
    setAutoNextClaim: (v) => setPref("autoNextClaim", v),
    sound: prefs.sound,
    setSound: (v) => setPref("sound", v),
    theme: prefs.theme,
    setTheme: (v) => setPref("theme", v),
    claimQueue,
    takeoverOpen,
    dismissTakeover: () => setTakeoverOpen(false),
    skipClaim: (id) => {
      const q = quests.find((x) => x.id === id);
      if (q) setSkipped((s) => new Set(s).add(key(q)));
    },
  };
  return <AutopilotContext.Provider value={value}>{children}</AutopilotContext.Provider>;
}
