import { useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/api";
import { openQuest } from "@/lib/quest";
import { isNative } from "@/lib/native";
import type { Community, Quest, Submission } from "@/lib/types";

export function useSubmissions() {
  const all = useQuery<Submission[]>({ queryKey: ["/api/submissions"] }).data ?? [];
  const forQuest = (id: number) => all.filter((s) => s.questId === id);
  return {
    all,
    forQuest,
    prepared: (id: number) => {
      const list = forQuest(id);
      return {
        left: list.filter((s) => !s.repeat && !s.usedAt).length,
        reusable: list.some((s) => !!s.repeat),
        total: list.length,
        /** Has content that autofill will use on the next open. */
        saved: list.some((s) => !!s.repeat || !s.usedAt),
      };
    },
  };
}

export const invalidateSubmissions = () => {
  queryClient.invalidateQueries({ queryKey: ["/api/submissions"] });
  queryClient.invalidateQueries({ predicate: (q) => String(q.queryKey[0]).includes("/next-submission") });
};

/**
 * Opens a quest. A2: this only opens the link in the app's Zealy view. The native side
 * looks up the saved content for this quest and autofills it (never clicks Claim/Submit),
 * and marks a one-time queued entry as used. It never changes the quest status.
 */
export function useLaunch(q: Quest | undefined, c: Community | undefined, enabled = true) {
  const { prepared } = useSubmissions();
  const cid = q?.id;
  const p = cid !== undefined ? prepared(cid) : { left: 0, reusable: false, total: 0, saved: false };
  const next = useQuery<Submission | null>({
    queryKey: [`/api/quests/${cid}/next-submission`],
    enabled: enabled && p.saved,
  });
  const sub = p.saved ? next.data ?? null : null;
  return {
    sub,
    prepared: p,
    loadingSub: p.saved && next.isLoading,
    /** `queue`: the quest ids of a claim run (this one first). The claim screen then gets a Next button. */
    launch: (queue?: number[]) => {
      if (!q) return { filled: false };
      openQuest(q, c, Array.isArray(queue) ? queue : undefined);
      if (!isNative && sub && !sub.repeat) {
        // browser preview has no native side to do this
        apiRequest("PATCH", `/api/submissions/${sub.id}`, { used: true }).then(invalidateSubmissions).catch(() => {});
      }
      return { filled: !!sub, sub };
    },
  };
}
