import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, invalidateAll } from "@/lib/api";
import type { Alert, Community, Quest } from "@/lib/types";

export function useData() {
  const communities = useQuery<Community[]>({ queryKey: ["/api/communities"] });
  const quests = useQuery<Quest[]>({ queryKey: ["/api/quests"] });
  const alerts = useQuery<Alert[]>({ queryKey: ["/api/alerts"] });
  const byId = new Map((communities.data ?? []).map((c) => [c.id, c]));
  return {
    communities: communities.data ?? [],
    quests: quests.data ?? [],
    alerts: alerts.data ?? [],
    byId,
    loading: communities.isLoading || quests.isLoading,
  };
}

/** Manual (non-Zealy) quests only: the user explicitly marks a claim. */
export function useMarkClaimed() {
  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status?: string }) =>
      apiRequest("POST", `/api/quests/${id}/claim`, status ? { status } : {}),
    onSuccess: invalidateAll,
  });
}
