import { useEffect, useState } from "react";
import { isNative, QuestPilot, type NativeStatus } from "@/lib/native";

const OFF: NativeStatus = {
  connected: false, sessionExpired: false, userName: null, monitoringEnabled: false,
  serviceRunning: false, pausedUntil: 0, pauseReason: null, lastSyncAt: 0,
  lastQuestPollAt: 0, lastMessagePollAt: 0, syncing: false,
};

let current: NativeStatus = OFF;
const subs = new Set<(s: NativeStatus) => void>();
let started = false;
function start() {
  if (started || !isNative) return;
  started = true;
  QuestPilot.getStatus().then(set).catch(() => {});
  QuestPilot.addListener("statusChanged", set);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) QuestPilot.getStatus().then(set).catch(() => {});
  });
}
function set(s: NativeStatus) {
  current = s;
  subs.forEach((f) => f(s));
}
export function setNativeStatus(s: NativeStatus) {
  set(s);
}

export function useNativeStatus() {
  const [s, setS] = useState(current);
  useEffect(() => {
    start();
    subs.add(setS);
    setS(current);
    return () => {
      subs.delete(setS);
    };
  }, []);
  return s;
}
