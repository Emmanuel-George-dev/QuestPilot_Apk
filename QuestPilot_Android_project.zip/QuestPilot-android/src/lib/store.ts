/*
 * Local store. Same JSON document and key as the original app ("questpilot-db-v1").
 * On Android the document lives in the app's private files dir and is owned by the
 * native side (so the background monitor can read/write it while the UI is closed).
 * In a plain browser (dev preview) it falls back to localStorage, exactly as before.
 */
import { isNative, QuestPilot } from "./native";
import type { Db } from "./types";

export const DB_KEY = "questpilot-db-v1";

export function blankDb(): Db {
  return {
    seq: { communities: 0, quests: 0, alerts: 0, submissions: 0 },
    communities: [],
    quests: [],
    alerts: [],
    submissions: [],
    settings: { tgToken: "", tgChat: "", tzOffset: 0 },
  };
}

function withBlanks(raw: unknown): Db {
  const db = (raw && typeof raw === "object" ? raw : {}) as Db;
  const b = blankDb() as unknown as Record<string, unknown>;
  for (const k in b) if (!(k in db)) (db as unknown as Record<string, unknown>)[k] = b[k];
  return db;
}

let db: Db = blankDb();
let rev = -1;
let loaded: Promise<void> | null = null;
const listeners = new Set<() => void>();

export function onStoreChange(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
const emit = () => listeners.forEach((l) => l());

async function reload() {
  if (isNative) {
    const r = await QuestPilot.loadDb();
    db = withBlanks(r.json ? JSON.parse(r.json) : null);
    rev = r.rev;
  } else {
    try {
      const raw = localStorage.getItem(DB_KEY);
      db = withBlanks(raw ? JSON.parse(raw) : null);
    } catch {
      db = blankDb();
    }
  }
}

export function ensureLoaded() {
  if (!loaded) {
    loaded = reload();
    if (isNative) {
      // The background monitor / sync changed the file: pick it up and refresh the UI.
      QuestPilot.addListener("dbChanged", async (e) => {
        if (e.rev !== rev) {
          await reload();
          emit();
        }
      });
      // v2.4.4: coming back from the X page (a Pre-click) the change event may have arrived while the
      // screen was in the background: read the file again so the button shows done right away.
      document.addEventListener("visibilitychange", async () => {
        if (document.visibilityState === "visible") {
          await reload();
          emit();
        }
      });
    }
  }
  return loaded;
}

export function getDb(): Db {
  return db;
}

/**
 * Apply a change and persist it. If the native side changed the document since we
 * last read it, reload and apply the same change again so nothing is overwritten.
 */
export async function commit<T>(mutate: (d: Db) => T): Promise<T> {
  await ensureLoaded();
  for (let attempt = 0; attempt < 3; attempt++) {
    const result = mutate(db);
    if (!isNative) {
      try {
        localStorage.setItem(DB_KEY, JSON.stringify(db));
      } catch {
        throw new Error("507: Storage is full on this device.");
      }
      emit();
      return result;
    }
    const r = await QuestPilot.saveDb({ json: JSON.stringify(db), baseRev: rev });
    db = withBlanks(JSON.parse(r.json));
    rev = r.rev;
    if (r.ok) {
      emit();
      return result;
    }
    // conflict: db now holds the fresh native copy; loop re-applies the change
  }
  throw new Error("Couldn't save, please try again");
}

export async function refreshFromNative() {
  if (!isNative) return;
  await reload();
  emit();
}
