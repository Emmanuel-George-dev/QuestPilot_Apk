/**
 * Debug tools (test mode, fake quest, A1 debug panel) exist only in the debug web bundle,
 * built with `vite build --mode devtools` (.env.devtools sets VITE_QP_DEVTOOLS=1).
 * In the release bundle this constant is `false`, so Vite/Rollup drops src/devtools entirely.
 */
export const DEV_TOOLS: boolean = import.meta.env.VITE_QP_DEVTOOLS === "1";
