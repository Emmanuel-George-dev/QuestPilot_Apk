/*
 * The original app talked to "/api/..." endpoints that local-api.js answered in the
 * browser. Same endpoints, same records, now as a typed module over the shared store.
 */
import { QueryClient, type QueryFunction } from "@tanstack/react-query";
import { commit, ensureLoaded, getDb, onStoreChange } from "./store";
import { isNative, QuestPilot } from "./native";
import type { Community, Db, Quest, SavedImage, Submission } from "./types";
import { WATCHLIST_MAX } from "./types";

class HttpError extends Error {}
const fail = (status: number, msg: string): never => {
  throw new HttpError(`${status}: ${msg}`);
};

const COMMUNITY_DEFAULTS = {
  sprintName: null, sprintEndsAt: null, prize: null, hue: 268,
  notify: 1, autoSync: 1, lastSyncAt: null, syncError: null,
};
const QUEST_DEFAULTS = {
  type: "other", recurrence: "once", resetMode: "rolling", resetTime: "09:00",
  xp: 0, url: null, deadline: null, autoOpen: 1, status: "todo",
  lastClaimedAt: null, claimCount: 0, notes: null, zealyId: null,
  categoryId: null, taskKinds: null, claimLimit: 0, locked: 0, source: "manual",
};

function withDefaults<T>(obj: Record<string, unknown>, defaults: Record<string, unknown>): T {
  const out: Record<string, unknown> = { ...defaults };
  for (const k in obj) if (obj[k] !== undefined) out[k] = obj[k];
  return out as T;
}
type Table = "communities" | "quests" | "alerts" | "submissions";
const nextId = (db: Db, t: Table) => (db.seq[t] = (db.seq[t] || 0) + 1);
const findById = <K extends Table>(db: Db, t: K, id: string | number) =>
  (db[t] as Array<{ id: number }>).find((r) => r.id === Number(id)) as Db[K][number] | undefined;
const patch = (rec: Record<string, unknown>, body: Record<string, unknown>) => {
  for (const k in body) if (k !== "id") rec[k] = body[k];
  return rec;
};
const nowIso = () => new Date().toISOString();
const clone = <T,>(v: T): T => JSON.parse(JSON.stringify(v ?? null));

function readOnly(method: string, path: string): unknown {
  const db = getDb();
  let m: RegExpMatchArray | null;
  if (path === "/api/communities" && method === "GET") return db.communities;
  if (path === "/api/quests" && method === "GET") return db.quests;
  if (path === "/api/submissions" && method === "GET") return db.submissions;
  if (path === "/api/alerts" && method === "GET") return db.alerts;
  if (path === "/api/settings" && method === "GET")
    return {
      tgChat: db.settings.tgChat || "",
      tgConfigured: !!(db.settings.tgToken && db.settings.tgChat),
      prefs: db.settings.prefs ?? {},
      watchlist: db.settings.watchlist ?? [],
    };
  if ((m = path.match(/^\/api\/quests\/(\d+)\/next-submission$/)) && method === "GET") {
    const qid = Number(m[1]);
    const list = db.submissions.filter((s) => s.questId === qid);
    return list.find((s) => !s.repeat && !s.usedAt) ?? list.find((s) => s.repeat) ?? null;
  }
  if (path.startsWith("/api/zealy/lookup/")) return {};
  return undefined;
}

async function write(method: string, path: string, body: Record<string, unknown> | null): Promise<unknown> {
  let m: RegExpMatchArray | null;
  const b = body ?? {};

  // communities
  if (path === "/api/communities" && method === "POST") {
    const created = await commit((db) => {
      const sub = String(b.subdomain || "").trim();
      const existing = db.communities.find((c) => c.subdomain.toLowerCase() === sub.toLowerCase());
      if (existing) return clone(existing);
      const com = withDefaults<Community>(b, COMMUNITY_DEFAULTS);
      com.id = nextId(db, "communities");
      db.communities.push(com);
      db.settings.ignoredSubdomains = (db.settings.ignoredSubdomains ?? []).filter((s) => s !== sub);
      return clone(com);
    });
    let sync: { ok: boolean; added: number; error?: string } = { ok: false, added: 0, error: "Connect Zealy in Settings to read its questboard." };
    if (isNative) {
      const r = await QuestPilot.syncNow({ subdomain: created.subdomain });
      const row = r.results?.[0];
      sync = r.ok && row && !row.error ? { ok: true, added: row.added } : { ok: false, added: 0, error: row?.error || r.error };
    }
    return { ...clone(getDb().communities.find((c) => c.id === created.id) ?? created), sync };
  }
  if ((m = path.match(/^\/api\/communities\/(\d+)\/sync$/)) && method === "POST") {
    const c = findById(getDb(), "communities", m[1]);
    if (!c) fail(404, "Not found");
    if (!isNative) return { ok: false, added: 0, error: "Syncing works in the Android app." };
    const r = await QuestPilot.syncNow({ subdomain: c!.subdomain });
    const row = r.results?.[0];
    return r.ok && row && !row.error ? { ok: true, added: row.added } : { ok: false, added: 0, error: row?.error || r.error };
  }
  if ((m = path.match(/^\/api\/communities\/(\d+)$/))) {
    const id = Number(m[1]);
    if (method === "PATCH")
      return commit((db) => {
        const c = findById(db, "communities", id);
        if (!c) fail(404, "Not found");
        return clone(patch(c as unknown as Record<string, unknown>, b));
      });
    if (method === "DELETE")
      return commit((db) => {
        const c = findById(db, "communities", id);
        if (!c) fail(404, "Not found");
        db.communities = db.communities.filter((x) => x.id !== id);
        const gone = db.quests.filter((q) => q.communityId === id).map((q) => q.id);
        db.quests = db.quests.filter((q) => q.communityId !== id);
        db.submissions = db.submissions.filter((s) => !gone.includes(s.questId));
        const ign = new Set(db.settings.ignoredSubdomains ?? []);
        ign.add(c!.subdomain);
        db.settings.ignoredSubdomains = [...ign];
        db.settings.watchlist = (db.settings.watchlist ?? []).filter((s) => s !== c!.subdomain);
        return { ok: true };
      });
  }

  // quests
  if (path === "/api/quests" && method === "POST")
    return commit((db) => {
      const q = withDefaults<Quest>(b, QUEST_DEFAULTS);
      q.id = nextId(db, "quests");
      db.quests.push(q);
      return clone(q);
    });
  // Manual quests only: the user explicitly says "I claimed it" (never triggered by opening a link).
  if ((m = path.match(/^\/api\/quests\/(\d+)\/claim$/)) && method === "POST")
    return commit((db) => {
      const q = findById(db, "quests", m![1]);
      if (!q) fail(404, "Not found");
      if (q!.source === "zealy") fail(400, "Status of Zealy quests comes from Zealy sync only");
      q!.lastClaimedAt = nowIso();
      q!.claimCount = (q!.claimCount || 0) + 1;
      if (b.status) q!.status = b.status as Quest["status"];
      return clone(q);
    });
  if ((m = path.match(/^\/api\/quests\/(\d+)\/submissions$/)) && method === "POST") {
    const images = await storeImages(b);
    return commit((db) => {
      const s = withDefaults<Submission>(b, { text: null, image: null, imageName: null, thumb: null, repeat: 0, usedAt: null });
      s.repeat = s.repeat ? 1 : 0;
      s.text = typeof s.text === "string" && s.text.trim() ? s.text : null;
      setImages(s, images);
      s.id = nextId(db, "submissions");
      s.questId = Number(m![1]);
      s.createdAt = nowIso();
      db.submissions.push(s);
      return clone(s);
    });
  }
  if ((m = path.match(/^\/api\/quests\/(\d+)$/))) {
    const id = Number(m[1]);
    if (method === "PATCH")
      return commit((db) => {
        const q = findById(db, "quests", id);
        if (!q) fail(404, "Not found");
        const body2 = { ...b };
        // A2: synced quests keep the status Zealy reported.
        if (q!.source === "zealy") delete body2.status;
        return clone(patch(q as unknown as Record<string, unknown>, body2));
      });
    if (method === "DELETE")
      return commit((db) => {
        db.quests = db.quests.filter((q) => q.id !== id);
        db.submissions = db.submissions.filter((s) => s.questId !== id);
        return { ok: true };
      });
  }

  // submissions
  if ((m = path.match(/^\/api\/submissions\/(\d+)$/))) {
    const id = Number(m[1]);
    if (method === "DELETE")
      return commit((db) => {
        db.submissions = db.submissions.filter((s) => s.id !== id);
        return { ok: true };
      });
    const images = method === "PATCH" && "images" in b ? await storeImages(b) : null;
    if (method === "PATCH")
      return commit((db) => {
        const s = findById(db, "submissions", id);
        if (!s) fail(404, "Not found");
        if ("repeat" in b) s!.repeat = b.repeat ? 1 : 0;
        if ("text" in b) s!.text = typeof b.text === "string" && b.text.trim() ? (b.text as string) : null;
        if (images) setImages(s!, images);
        if ("used" in b) s!.usedAt = b.used ? nowIso() : null;
        return clone(s);
      });
  }

  // alerts
  if (path === "/api/alerts" && method === "DELETE")
    return commit((db) => {
      db.alerts = [];
      return { ok: true };
    });
  if (path === "/api/alerts/read-all" && method === "POST")
    return commit((db) => {
      db.alerts.forEach((a) => (a.read = 1));
      return { ok: true };
    });
  if ((m = path.match(/^\/api\/alerts\/(\d+)\/read$/)) && method === "POST")
    return commit((db) => {
      const a = findById(db, "alerts", m![1]);
      if (a) a.read = 1;
      return { ok: true };
    });

  // settings
  if (path === "/api/settings" && method === "POST")
    return commit((db) => {
      if (typeof b.tgToken === "string" && b.tgToken) db.settings.tgToken = b.tgToken.trim();
      if (typeof b.tgChat === "string") db.settings.tgChat = b.tgChat.trim();
      if (typeof b.tzOffset === "number") db.settings.tzOffset = b.tzOffset;
      if (b.prefs && typeof b.prefs === "object") db.settings.prefs = { ...(db.settings.prefs ?? {}), ...(b.prefs as object) };
      if (Array.isArray(b.watchlist)) {
        const list = [...new Set((b.watchlist as string[]).map((s) => s.trim().toLowerCase()).filter(Boolean))];
        if (list.length > WATCHLIST_MAX) fail(400, `The watchlist holds at most ${WATCHLIST_MAX} communities.`);
        db.settings.watchlist = list;
      }
      return { ok: true };
    });
  if (path === "/api/settings/test-telegram" && method === "POST") {
    if (!isNative) fail(400, "Telegram works in the Android app.");
    const r = await QuestPilot.sendTelegramTest();
    if (!r.ok) fail(400, r.error || "Telegram rejected the message. Check the bot token and chat id.");
    return { ok: true };
  }

  return fail(404, `Unknown endpoint ${method} ${path}`);
}

/** Same signature as the original apiRequest(): throws "<status>: <message>" on errors. */
export async function apiRequest<T = unknown>(method: string, path: string, body?: unknown): Promise<T> {
  await ensureLoaded();
  if (method === "GET") {
    const r = readOnly(method, path);
    if (r === undefined) fail(404, `Unknown endpoint ${method} ${path}`);
    return clone(r) as T;
  }
  return (await write(method, path, (body as Record<string, unknown>) ?? null)) as T;
}

const queryFn: QueryFunction = async ({ queryKey }) => apiRequest("GET", queryKey.join("/"));

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: { queryFn, refetchInterval: false, refetchOnWindowFocus: false, staleTime: Infinity, retry: false },
    mutations: { retry: false },
  },
});

export const invalidateAll = () => {
  queryClient.invalidateQueries();
};

// Anything the native side writes (sync, monitor, alarms) refreshes every screen.
onStoreChange(() => invalidateAll());

/**
 * Saved photos. On Android the full image goes to app storage once (so it never travels with
 * every save of the data file) and only the id + thumbnail stay in questpilot-db-v1.
 */
async function storeImages(b: Record<string, unknown>): Promise<SavedImage[]> {
  let list = (Array.isArray(b.images) ? b.images : []) as SavedImage[];
  if (!list.length && typeof b.image === "string")
    list = [{ name: String(b.imageName || "submission.jpg"), thumb: String(b.thumb || b.image), data: b.image }];
  const out: SavedImage[] = [];
  for (const im of list) {
    if (isNative && im.data && !im.id) {
      const r = await QuestPilot.savePhoto({ data: im.data, name: im.name });
      out.push({ id: r.id, name: im.name, thumb: im.thumb });
    } else out.push({ id: im.id ?? null, name: im.name, thumb: im.thumb, data: im.id ? null : im.data ?? null });
  }
  return out;
}
function setImages(s: Submission, images: SavedImage[]) {
  s.images = images.length ? images : null;
  const first = images[0];
  s.image = first?.data ?? null;
  s.thumb = first?.thumb ?? null;
  s.imageName = first?.name ?? null;
}
