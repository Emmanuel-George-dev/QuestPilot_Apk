// Data format: identical to the original QuestPilot local store ("questpilot-db-v1").
// Fields marked "added in v2" are optional and additive, so old data still loads.

export type QuestType =
  | "daily" | "limited" | "twitter" | "image" | "discord" | "telegram"
  | "quiz" | "link" | "text" | "onchain" | "invite" | "other";
export type Recurrence = "once" | "daily" | "weekly" | "monthly";
export type QuestStatus = "todo" | "pending" | "done" | "failed";

export interface Community {
  id: number;
  name: string;
  subdomain: string;
  sprintName: string | null;
  sprintEndsAt: string | null;
  prize: string | null;
  hue: number;
  notify: number;
  autoSync: number;
  lastSyncAt: string | null;
  syncError: string | null;
  /** Your XP in this community as Zealy reports it (null/undefined until a sync could read it). */
  userXp?: number | null;
  userXpAt?: string | null;
}

/** Raw Zealy fields kept from the last successful sync (added in v2). */
export interface ZealyQuestState {
  claimed: boolean;
  completed: boolean;
  inReview: boolean;
  locked: boolean;
  opened: boolean | null;
  openAt: string | null;
  retryAt: string | null;
  conditionOperator: string | null;
  conditions: Array<{ type: string; value?: unknown; operator?: string; fulfilled?: boolean }>;
  syncedAt: string;
}

export interface Quest {
  id: number;
  communityId: number;
  title: string;
  type: QuestType;
  recurrence: Recurrence;
  resetMode: "rolling" | "fixed";
  resetTime: string;
  xp: number;
  url: string | null;
  deadline: string | null;
  autoOpen: number;
  status: QuestStatus;
  lastClaimedAt: string | null;
  claimCount: number;
  notes: string | null;
  zealyId: string | null;
  categoryId: string | null;
  taskKinds: string | null;
  claimLimit: number;
  locked: number;
  source: "manual" | "zealy";
  /** added in v2: synced Zealy state */
  zealy?: ZealyQuestState | null;
  /**
   * added in v2: absolute UTC unlock time in ms, written ONLY by the native
   * UnlockClock.unlockAt() every time the store is saved.
   * null = locked / unknown, 0 = available now, >0 = unlock moment.
   */
  unlockAt?: number | null;
}

export type AlertKind =
  | "due" | "soon" | "deadline" | "sprint" | "system"
  | "quest-new" | "quest-unlocked" | "message" | "session";

export interface Alert {
  id: number;
  kind: AlertKind | string;
  title: string;
  body: string;
  questId: number | null;
  communityId: number | null;
  dedupeKey: string;
  createdAt: string;
  read: number;
  /** added in v2: link opened on tap */
  url?: string | null;
  /** added in v2: for unlock alerts, the unlock timestamp they were based on */
  unlockAt?: number | null;
}

/** A saved photo. On Android the file lives in app storage (`id`); in the browser preview `data` holds it inline. */
export interface SavedImage {
  id?: string | null;
  name: string;
  thumb: string;
  data?: string | null;
}

export interface Submission {
  id: number;
  questId: number;
  text: string | null;
  image: string | null;
  imageName: string | null;
  thumb: string | null;
  /** Additive: one or more photos. `image`/`thumb`/`imageName` mirror the first one for older builds. */
  images?: SavedImage[] | null;
  repeat: number;
  usedAt: string | null;
  createdAt: string;
}

export interface Prefs {
  autopilot: boolean;
  autoOpenTabs: boolean;
  /** Claim run: move to the next claim by itself after a successful claim (the Next button always stays). */
  autoNextClaim?: boolean;
  sound: boolean;
  theme: "dark" | "light";
  onboarded: boolean;
}

export interface Settings {
  tgToken: string;
  tgChat: string;
  tzOffset: number;
  /** added in v2 */
  prefs?: Partial<Prefs>;
  /** added in v2: B1 watchlist, max 3 subdomains */
  watchlist?: string[];
  /** added in v2: communities removed by the user, skipped by sync */
  ignoredSubdomains?: string[];
}

export interface Db {
  seq: { communities: number; quests: number; alerts: number; submissions: number };
  communities: Community[];
  quests: Quest[];
  alerts: Alert[];
  submissions: Submission[];
  settings: Settings;
}

export const WATCHLIST_MAX = 3;
