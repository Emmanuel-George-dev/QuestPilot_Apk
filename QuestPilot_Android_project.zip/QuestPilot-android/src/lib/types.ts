// Data format: identical to the original QuestPilot local store ("questpilot-db-v1").
// Fields marked "added in v2" are optional and additive, so old data still loads.

export type QuestType =
  | "daily" | "limited" | "twitter" | "image" | "discord" | "telegram"
  | "quiz" | "link" | "text" | "onchain" | "invite" | "other";
export type Recurrence = "once" | "daily" | "weekly" | "monthly";
export type QuestStatus = "todo" | "pending" | "done" | "failed";

export interface Community {
  id: number;
  name: string;
  subdomain: string;
  sprintName: string | null;
  sprintEndsAt: string | null;
  prize: string | null;
  hue: number;
  notify: number;
  autoSync: number;
  lastSyncAt: string | null;
  syncError: string | null;
  /** Your XP in this community as Zealy reports it (null/undefined until a sync could read it). */
  userXp?: number | null;
  userXpAt?: string | null;
  /** v2.4.2: endpoints that answered 403 for your account here ({questboard|sprint|xp|community|notifications: markedAtMs}) */
  noAccess?: Record<string, number> | null;
  /** v2.4.2: when the sprint endpoint was last read (ms) */
  sprintCheckedAt?: number | null;
}

/** Raw Zealy fields kept from the last successful sync (added in v2). */
export interface ZealyQuestState {
  claimed: boolean;
  completed: boolean;
  inReview: boolean;
  locked: boolean;
  opened: boolean | null;
  openAt: string | null;
  retryAt: string | null;
  conditionOperator: string | null;
  conditions: Array<{ type: string; value?: unknown; operator?: string; fulfilled?: boolean }>;
  syncedAt: string | number;
  /** v2.4: any "opens at / unlocks at / starts at" field Zealy sent on the quest itself */
  questTimes?: Record<string, string | number>;
  /** v2.4: one-time quest that was locked and has unlocked: the moment it unlocked (ms) */
  lockedUntil?: number | string | null;
}

export interface XLink {
  kind: "like" | "repost" | "follow" | "post" | "other";
  url: string;
  label: string;
}

export interface Quest {
  id: number;
  communityId: number;
  title: string;
  type: QuestType;
  recurrence: Recurrence;
  resetMode: "rolling" | "fixed";
  resetTime: string;
  xp: number;
  url: string | null;
  deadline: string | null;
  autoOpen: number;
  status: QuestStatus;
  lastClaimedAt: string | null;
  claimCount: number;
  notes: string | null;
  zealyId: string | null;
  categoryId: string | null;
  taskKinds: string | null;
  /** v2.4.3: X links found in the description (sync): like | repost | follow | post | other */
  xLinks?: XLink[] | null;
  /** v2.4.3: X post link you pasted by hand (Like and Repost are built from it) */
  xPostLink?: string | null;
  /** v2.4.3: links picked up from the Zealy page itself (task settings, X buttons, embedded post) */
  pageLinks?: (XLink & { source?: string })[] | null;
  /** v2.4.3: Pre-click buttons you pressed: done time + whether Zealy's clicked flag was written */
  preclick?: Record<string, { at: number; flag: "written" | "already" | "none" | "unavailable" | "off"; note?: string }> | null;
  claimLimit: number;
  locked: number;
  source: "manual" | "zealy";
  /** added in v2: synced Zealy state */
  zealy?: ZealyQuestState | null;
  /**
   * added in v2: absolute UTC unlock time in ms, written ONLY by the native
   * UnlockClock.unlockAt() every time the store is saved.
   * null = locked / unknown, 0 = available now, >0 = unlock moment.
   */
  unlockAt?: number | null;
}

export type AlertKind =
  | "due" | "soon" | "deadline" | "sprint" | "system"
  | "quest-new" | "quest-unlocked" | "message" | "session";

export interface Alert {
  id: number;
  kind: AlertKind | string;
  title: string;
  body: string;
  questId: number | null;
  communityId: number | null;
  dedupeKey: string;
  createdAt: string;
  read: number;
  /** added in v2: link opened on tap */
  url?: string | null;
  /** added in v2: for unlock alerts, the unlock timestamp they were based on */
  unlockAt?: number | null;
}

/** A saved photo. On Android the file lives in app storage (`id`); in the browser preview `data` holds it inline. */
export interface SavedImage {
  id?: string | null;
  name: string;
  thumb: string;
  data?: string | null;
}

export interface Submission {
  id: number;
  questId: number;
  text: string | null;
  image: string | null;
  imageName: string | null;
  thumb: string | null;
  /** Additive: one or more photos. `image`/`thumb`/`imageName` mirror the first one for older builds. */
  images?: SavedImage[] | null;
  repeat: number;
  usedAt: string | null;
  createdAt: string;
}

export interface Prefs {
  autopilot: boolean;
  autoOpenTabs: boolean;
  /** Claim run: move to the next claim by itself after a successful claim (the Next button always stays). */
  autoNextClaim?: boolean;
  sound: boolean;
  theme: "dark" | "light";
  onboarded: boolean;
  /** v2.4 notification stages (all on by default) */
  stage10m?: boolean;
  stage5m?: boolean;
  stage10s?: boolean;
  stage3s?: boolean;
  /** v2.4 Debug & experiments. Each Part D feature has its own switch. */
  featInAppLinks?: boolean;
  featLikeTimer?: boolean;
  likeCloseSec?: number;
  featLikePreload?: boolean;
  /** v2.4.3 Debug: record the Zealy page's own quest requests (off by default) */
  debugZealyRecorder?: boolean;
  /** v2.4.3: Pre-click writes Zealy's clicked flag when a matching write was observed (on by default) */
  preclickWriteFlag?: boolean;
  /** v2.4.4: load task details (ids, X post link) for X / visit tasks during sync */
  fetchTaskDetails?: boolean;
  featPostSheet?: boolean;
  featFollowSheet?: boolean;
  debugFillSteps?: boolean;
  /** schemes allowed to leave the app, comma separated (e.g. "tg, discord, intent") */
  allowedAppLinks?: string;
  /** v2.4.1: automatic full sync every 30 or 60 min */
  fullSyncMinutes?: number;
  /** v2.4.1: fast quest polling only for communities with a running sprint (on by default) */
  sprintOnlyWatch?: boolean;
}

export interface Settings {
  tgToken: string;
  tgChat: string;
  tzOffset: number;
  /** added in v2 */
  prefs?: Partial<Prefs>;
  /** added in v2: B1 watchlist, max 3 subdomains */
  watchlist?: string[];
  /** added in v2: communities removed by the user, skipped by sync */
  ignoredSubdomains?: string[];
}

export interface Db {
  seq: { communities: number; quests: number; alerts: number; submissions: number };
  communities: Community[];
  quests: Quest[];
  alerts: Alert[];
  submissions: Submission[];
  settings: Settings;
}

export const WATCHLIST_MAX = 3;
