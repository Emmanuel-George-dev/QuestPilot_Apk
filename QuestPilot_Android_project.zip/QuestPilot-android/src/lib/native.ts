import { Capacitor, registerPlugin, type PluginListenerHandle } from "@capacitor/core";

export interface NetLogEntry {
  at: number;
  source: "okhttp" | "webview";
  method: string;
  url: string;
  status: number;
  snippet: string;
  cookies: string;
  extra?: string | null;
}

export interface ConnectionCheck {
  label: string;
  url: string;
  status: number;
  snippet: string;
}

export interface ConnectionTest {
  cookieNames: string[];
  userAgent: string;
  authMode: string;
  hasStorageToken: boolean;
  error?: string;
  okhttp?: ConnectionCheck[];
  webview?: ConnectionCheck[];
}

export interface NativeStatus {
  connected: boolean;
  sessionExpired: boolean;
  userName: string | null;
  monitoringEnabled: boolean;
  serviceRunning: boolean;
  pausedUntil: number;
  pauseReason: string | null;
  lastSyncAt: number;
  lastQuestPollAt: number;
  lastMessagePollAt: number;
  syncing: boolean;
  /** v2.4.1: a full sync hit 429/403, so automatic full syncs run every 60 min until the app restarts */
  slowFullSync?: boolean;
  /** v2.4.1: "Watching N communities with a running sprint, each about every X min" */
  watchText?: string;
  /** true only in debug APKs (BuildConfig.DEBUG); release never exposes test tools. */
  debugBuild?: boolean;
}

export interface PermissionState {
  sdk: number;
  manufacturer: string;
  notifications: "granted" | "denied" | "prompt";
  exactAlarm: boolean;
  fullScreenIntent: boolean;
  batteryUnrestricted: boolean;
}

export interface DebugRow {
  questId: number;
  title: string;
  community: string;
  unlockAt: number | null;
  nextNotifyAt: number | null;
  nextNotifyKind: string | null;
}

export interface TestQuest {
  id: number;
  title: string;
  communityName: string;
  url: string;
  unlockAt: number | null;
  testUnlockAt: number;
  testSourceQuestId: number | null;
}

export interface LockedDebugEntry {
  at: number;
  community: string;
  subdomain: string;
  zealyId: string;
  title: string;
  conditionOperator: string | null;
  conditions: unknown[];
  questFields: Record<string, unknown>;
}

export interface EventLogEntry {
  at: number;
  tag: string;
  msg: string;
}

export interface AlarmEntry {
  key: string;
  kind: string;
  basis: number;
  fireAt: number;
  questIds: number[];
  test?: boolean;
}

export interface SyncResult {
  ok: boolean;
  error?: string;
  results?: Array<{ subdomain: string; name: string; added: number; updated: number; error?: string }>;
}

export interface QuestPilotPlugin {
  loadDb(): Promise<{ json: string; rev: number }>;
  saveDb(o: { json: string; baseRev: number }): Promise<{ ok: boolean; conflict?: boolean; json: string; rev: number }>;
  getStatus(): Promise<NativeStatus>;
  connectZealy(): Promise<{ connected: boolean }>;
  disconnectZealy(): Promise<void>;
  syncNow(o: { subdomain?: string; auto?: boolean }): Promise<SyncResult>;
  setMonitoring(o: { enabled: boolean }): Promise<NativeStatus>;
  /** Opens a page in the signed-in in-app Zealy view. With questId, saved content for that quest is autofilled. */
  openZealy(o: { url: string; title?: string; questId?: number | null; queue?: number[] }): Promise<void>;
  /** Stores a photo (data URL) in app storage for autofill; returns its id. */
  savePhoto(o: { data: string; name: string }): Promise<{ id: string }>;
  getDebugInfo(): Promise<{ rows: DebugRow[]; exactAlarm: boolean; now: number }>;
  startTestUnlock(o: { seconds: number; sourceQuestId?: number | null }): Promise<{ questId: number; unlockAt: number }>;
  /** Debug builds only. */
  getTestQuests(): Promise<{ quests: TestQuest[] }>;
  /** Debug builds only: "Clear test data". */
  clearTest(): Promise<void>;
  /** Debug builds only: connection log (cookie values hidden). */
  getNetLog(): Promise<{ entries: NetLogEntry[] }>;
  clearNetLog(): Promise<void>;
  testConnection(): Promise<ConnectionTest>;
  getPermissionState(): Promise<PermissionState>;
  /** v2.4 (both builds): locked quests whose unlock time came out null, with their raw conditions (secrets hidden). */
  getLockedDebug(): Promise<{ entries: LockedDebugEntry[] }>;
  clearLockedDebug(): Promise<void>;
  /** v2.4: links / like timer / X requests / follow / autofill steps / unlock re-checks. */
  getEventLog(): Promise<{ entries: EventLogEntry[] }>;
  clearEventLog(): Promise<void>;
  getAlarms(): Promise<{ entries: AlarmEntry[]; exactAlarm: boolean }>;
  /** v2.4.2: Zealy requests sent through the shared gate (cap 20 per minute). */
  /** Debug builds only: the next [count] Zealy requests whose path contains [match] answer [code] without being sent. */
  simulateZealy(o: { code: number; challenge?: boolean; match?: string; count: number }): Promise<void>;
  /** v2.4.3: opens one Pre-click button's X link in the in-app X overlay. */
  /** v2.4.6: marks the pressed button right away (Zealy cookie + done), then opens the page */
  preclick(o: { questId: number; kind: string; url: string }): Promise<{ flag: string; note: string }>;
  /** v2.4.4: load this quest's task details (ids, X post link, actions) now: one request, manual gate */
  fetchTaskDetails(o: { questId: number }): Promise<{ ok: boolean; code: number; tasks: number; links: number; message: string }>;
  /** v2.4.3 Debug: engaged cookie watcher data. */
  getEngaged(): Promise<{ at: number; cookies: any[]; writes: any[]; overlay: any[]; learned: any[]; matches: any[]; stored: number }>;
  getRawQuests(): Promise<{ raw: Record<string, any>; taskIds: Record<string, any> }>;
  getZealyRecorder(): Promise<{ entries: { at: number; request: string; body: string }[] }>;
  clearZealyRecorder(): Promise<void>;
  getRequestStats(): Promise<{ lastMinute: number; last10Minutes: number; perMinuteCap: number; paused: boolean; pauseReason: string | null; pausedUntil: number }>;
  /** v2.4 C5: sites with saved logins (names and counts only, never cookie values). */
  getLoggedInSites(): Promise<{ sites: Array<{ site: string; cookies: number; savedAt: number }> }>;
  logoutSite(o: { site: string }): Promise<void>;
  requestNotificationPermission(): Promise<PermissionState>;
  openExactAlarmSettings(): Promise<void>;
  openFullScreenIntentSettings(): Promise<void>;
  openBatterySettings(): Promise<void>;
  openAutostartSettings(): Promise<{ opened: boolean }>;
  sendTelegramTest(): Promise<{ ok: boolean; error?: string }>;
  shareText(o: { text: string; fileName: string; mime: string }): Promise<void>;
  addListener(event: "dbChanged", fn: (e: { rev: number }) => void): Promise<PluginListenerHandle>;
  addListener(event: "statusChanged", fn: (e: NativeStatus) => void): Promise<PluginListenerHandle>;
}

export const isNative = Capacitor.isNativePlatform();
export const QuestPilot = registerPlugin<QuestPilotPlugin>("QuestPilot");
