import { Capacitor, registerPlugin, type PluginListenerHandle } from "@capacitor/core";

export interface NetLogEntry {
  at: number;
  source: "okhttp" | "webview";
  method: string;
  url: string;
  status: number;
  snippet: string;
  cookies: string;
  extra?: string | null;
}

export interface ConnectionCheck {
  label: string;
  url: string;
  status: number;
  snippet: string;
}

export interface ConnectionTest {
  cookieNames: string[];
  userAgent: string;
  authMode: string;
  hasStorageToken: boolean;
  error?: string;
  okhttp?: ConnectionCheck[];
  webview?: ConnectionCheck[];
}

export interface NativeStatus {
  connected: boolean;
  sessionExpired: boolean;
  userName: string | null;
  monitoringEnabled: boolean;
  serviceRunning: boolean;
  pausedUntil: number;
  pauseReason: string | null;
  lastSyncAt: number;
  lastQuestPollAt: number;
  lastMessagePollAt: number;
  syncing: boolean;
  /** true only in debug APKs (BuildConfig.DEBUG); release never exposes test tools. */
  debugBuild?: boolean;
}

export interface PermissionState {
  sdk: number;
  manufacturer: string;
  notifications: "granted" | "denied" | "prompt";
  exactAlarm: boolean;
  fullScreenIntent: boolean;
  batteryUnrestricted: boolean;
}

export interface DebugRow {
  questId: number;
  title: string;
  community: string;
  unlockAt: number | null;
  nextNotifyAt: number | null;
  nextNotifyKind: string | null;
}

export interface TestQuest {
  id: number;
  title: string;
  communityName: string;
  url: string;
  unlockAt: number | null;
  testUnlockAt: number;
  testSourceQuestId: number | null;
}

export interface SyncResult {
  ok: boolean;
  error?: string;
  results?: Array<{ subdomain: string; name: string; added: number; updated: number; error?: string }>;
}

export interface QuestPilotPlugin {
  loadDb(): Promise<{ json: string; rev: number }>;
  saveDb(o: { json: string; baseRev: number }): Promise<{ ok: boolean; conflict?: boolean; json: string; rev: number }>;
  getStatus(): Promise<NativeStatus>;
  connectZealy(): Promise<{ connected: boolean }>;
  disconnectZealy(): Promise<void>;
  syncNow(o: { subdomain?: string }): Promise<SyncResult>;
  setMonitoring(o: { enabled: boolean }): Promise<NativeStatus>;
  /** Opens a page in the signed-in in-app Zealy view. With questId, saved content for that quest is autofilled. */
  openZealy(o: { url: string; title?: string; questId?: number | null; queue?: number[] }): Promise<void>;
  /** Stores a photo (data URL) in app storage for autofill; returns its id. */
  savePhoto(o: { data: string; name: string }): Promise<{ id: string }>;
  getDebugInfo(): Promise<{ rows: DebugRow[]; exactAlarm: boolean; now: number }>;
  startTestUnlock(o: { seconds: number; sourceQuestId?: number | null }): Promise<{ questId: number; unlockAt: number }>;
  /** Debug builds only. */
  getTestQuests(): Promise<{ quests: TestQuest[] }>;
  /** Debug builds only: "Clear test data". */
  clearTest(): Promise<void>;
  /** Debug builds only: connection log (cookie values hidden). */
  getNetLog(): Promise<{ entries: NetLogEntry[] }>;
  clearNetLog(): Promise<void>;
  testConnection(): Promise<ConnectionTest>;
  getPermissionState(): Promise<PermissionState>;
  requestNotificationPermission(): Promise<PermissionState>;
  openExactAlarmSettings(): Promise<void>;
  openFullScreenIntentSettings(): Promise<void>;
  openBatterySettings(): Promise<void>;
  openAutostartSettings(): Promise<{ opened: boolean }>;
  sendTelegramTest(): Promise<{ ok: boolean; error?: string }>;
  shareText(o: { text: string; fileName: string; mime: string }): Promise<void>;
  addListener(event: "dbChanged", fn: (e: { rev: number }) => void): Promise<PluginListenerHandle>;
  addListener(event: "statusChanged", fn: (e: NativeStatus) => void): Promise<PluginListenerHandle>;
}

export const isNative = Capacitor.isNativePlatform();
export const QuestPilot = registerPlugin<QuestPilotPlugin>("QuestPilot");
