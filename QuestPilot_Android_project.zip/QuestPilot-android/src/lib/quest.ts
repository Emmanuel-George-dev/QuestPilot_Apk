import {
  CalendarCheck, Hourglass, Image, MessageCircle, Send, CircleHelp, Link2, FileText,
  Boxes, UserPlus, Sparkles, type LucideIcon,
} from "lucide-react";
import { SiX } from "react-icons/si";
import type { ComponentType } from "react";
import type { Community, Quest, QuestType } from "./types";
import { isNative, QuestPilot } from "./native";

export const QUEST_TYPES: QuestType[] = [
  "daily", "limited", "twitter", "image", "discord", "telegram",
  "quiz", "link", "text", "onchain", "invite", "other",
];

export const TYPE_META: Record<QuestType, { label: string; icon: LucideIcon | ComponentType<{ className?: string }> }> = {
  daily: { label: "Daily", icon: CalendarCheck },
  limited: { label: "Limited", icon: Hourglass },
  twitter: { label: "Twitter / X", icon: SiX },
  image: { label: "Image upload", icon: Image },
  discord: { label: "Discord", icon: MessageCircle },
  telegram: { label: "Telegram", icon: Send },
  quiz: { label: "Quiz", icon: CircleHelp },
  link: { label: "Visit link", icon: Link2 },
  text: { label: "Text answer", icon: FileText },
  onchain: { label: "On-chain", icon: Boxes },
  invite: { label: "Invite", icon: UserPlus },
  other: { label: "Other", icon: Sparkles },
};

export const localTzOffset = -new Date().getTimezoneOffset();

/**
 * A1 — THE unlock time of a quest, as an absolute UTC timestamp (ms).
 *
 * It is computed in exactly one place: the native UnlockClock.unlockAt() (Kotlin),
 * from the quest's Zealy date condition / openAt / recurrence data, and written to
 * quest.unlockAt every time the store is saved. The countdown, the in-app alerts and
 * the system notifications all read this value; nothing in the UI recalculates it.
 *
 *   null -> locked / no known unlock time
 *   0    -> available now
 *   > 0  -> unlock moment (compare with Date.now())
 */
export function getUnlockTimestamp(q: Pick<Quest, "unlockAt">): number | null {
  return q.unlockAt === undefined ? null : q.unlockAt;
}

/** Remaining time is always unlockTimestamp - Date.now(), never a stored relative value. */
export function msUntilUnlock(q: Pick<Quest, "unlockAt">, now = Date.now()): number | null {
  const t = getUnlockTimestamp(q);
  return t === null ? null : t - now;
}

export const isRecurring = (q: Quest) => q.recurrence !== "once";
export const isClaimableNow = (q: Quest, now: number) => {
  const t = getUnlockTimestamp(q);
  return isRecurring(q) && t !== null && t <= now;
};

/**
 * A2 — status comes only from the synced Zealy fields, in this order:
 * claimed/completed -> Complete, inReview -> In review, locked -> Locked, else Open.
 * Opening a task never changes it.
 */
export type DisplayStatus = "complete" | "review" | "locked" | "open" | "rejected";
export function questStatus(q: Quest): DisplayStatus {
  if (q.source === "zealy" && q.zealy) {
    if (q.zealy.claimed || q.zealy.completed) return "complete";
    if (q.zealy.inReview) return "review";
    if (q.zealy.locked) return "locked";
    return "open";
  }
  if (q.status === "done") return "complete";
  if (q.status === "pending") return "review";
  if (q.status === "failed") return "rejected";
  if (q.locked) return "locked";
  return "open";
}
export const STATUS_META: Record<DisplayStatus, { label: string; cls: string; line: string }> = {
  complete: { label: "Complete", cls: "text-emerald-500", line: "Completed" },
  review: { label: "In review", cls: "text-amber-500", line: "Awaiting review" },
  locked: { label: "Locked", cls: "text-muted-foreground", line: "Locked on Zealy until its conditions are met" },
  open: { label: "Open", cls: "text-muted-foreground", line: "Not started" },
  rejected: { label: "Rejected", cls: "text-destructive", line: "Rejected — retry" },
};

export function parseZealyLink(s: string): { subdomain?: string; questId?: string } {
  const m = s.match(/zealy\.io\/(?:cw|c)\/([^/?#\s]+)(?:\/questboard\/(?:[^/?#\s]+\/)?([0-9a-f-]{8,}))?/i);
  return m ? { subdomain: m[1], questId: m[2] } : {};
}
export const questboardUrl = (c?: Community) => (c ? `https://zealy.io/cw/${c.subdomain}/questboard` : "https://zealy.io");
export const questUrl = (q: Quest, c?: Community) => q.url || questboardUrl(c);
export const leaderboardUrl = (c: Community) => `https://zealy.io/cw/${c.subdomain}/leaderboard`;

const PERIOD_ORDER: Record<string, number> = { daily: 0, weekly: 1, monthly: 2 };
export function sortClaims(list: Quest[], byId: Map<number, Community>, now: number) {
  const sprintEnd = (q: Quest) => {
    const e = byId.get(q.communityId)?.sprintEndsAt;
    const t = e ? new Date(e).getTime() : NaN;
    return Number.isFinite(t) && t > now ? t : Infinity;
  };
  return [...list].sort(
    (a, b) =>
      sprintEnd(a) - sprintEnd(b) ||
      (PERIOD_ORDER[a.recurrence] ?? 3) - (PERIOD_ORDER[b.recurrence] ?? 3) ||
      (b.xp ?? 0) - (a.xp ?? 0) ||
      (getUnlockTimestamp(a) ?? 0) - (getUnlockTimestamp(b) ?? 0),
  );
}

export function fmtLeft(ms: number) {
  if (ms <= 0) return "now";
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return d > 0 ? `${d}d ${h}h` : h > 0 ? `${h}h ${String(m).padStart(2, "0")}m` : `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}

export function timeAgo(iso: string | number, now: number) {
  const d = now - new Date(iso).getTime();
  return d < 6e4 ? "just now" : d < 36e5 ? `${Math.floor(d / 6e4)}m ago` : d < 864e5 ? `${Math.floor(d / 36e5)}h ago` : `${Math.floor(d / 864e5)}d ago`;
}

export function sprintLine(c: Community | undefined, now: number) {
  if (!c?.sprintEndsAt) return null;
  const end = new Date(c.sprintEndsAt).getTime();
  if (!(end > now)) return null;
  return new Date(end).toDateString() === new Date(now).toDateString()
    ? `Sprint ends today · ${fmtLeft(end - now)} left`
    : `Sprint ends in ${fmtLeft(end - now)}`;
}

/** Opens a link. Zealy links open in the in-app logged-in Zealy view on Android. */
export function openLink(url: string, opts: { title?: string; questId?: number | null; queue?: number[] } = {}) {
  if (isNative && (opts.questId != null || /^https:\/\/([a-z0-9-]+\.)?zealy\.io\//i.test(url))) {
    // Quest links always open in the app's own signed-in WebView, never an external browser.
    QuestPilot.openZealy({ url, title: opts.title, questId: opts.questId ?? null, queue: opts.queue }).catch(() => window.open(url, "_blank"));
    return true;
  }
  return window.open(url, "_blank", "noopener,noreferrer") !== null;
}

export function chime() {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    [660, 880, 1320].forEach((f, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = f;
      o.type = "sine";
      g.gain.setValueAtTime(1e-4, ctx.currentTime + i * 0.12);
      g.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + i * 0.12 + 0.02);
      g.gain.exponentialRampToValueAtTime(1e-4, ctx.currentTime + i * 0.12 + 0.35);
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + i * 0.12);
      o.stop(ctx.currentTime + i * 0.12 + 0.4);
    });
  } catch {
    /* no audio */
  }
}

export function fmtClock(ms: number | null) {
  if (!ms) return "—";
  const d = new Date(ms);
  return `${d.toISOString().replace("T", " ").slice(0, 19)} UTC`;
}

/** Opens a quest page in the app. Saved content is autofilled there; the status never changes. */
export function openQuest(q: Quest, c: Community | undefined, queue?: number[]) {
  return openLink(questUrl(q, c), { title: q.title, questId: q.id, queue });
}

const kinds = (q: Quest) => (q.taskKinds ?? "").toLowerCase().split(",").filter(Boolean);
/** Quest has a task with a text box (text, url, number answers). Manual/test quests always allow it. */
export function acceptsText(q: Quest) {
  const k = kinds(q);
  if (!k.length) return q.source !== "zealy" || q.type === "text";
  return k.some((t) => /^(text|url|number|link|input|form)$/.test(t) || /text/.test(t));
}
/** Quest has a file / photo upload task. */
export function acceptsPhoto(q: Quest) {
  const k = kinds(q);
  if (!k.length) return q.source !== "zealy" || q.type === "image";
  return k.some((t) => /^(file|image|upload|screenshot)$/.test(t) || /image|file|upload/.test(t));
}
export const canSave = (q: Quest) => acceptsText(q) || acceptsPhoto(q);
