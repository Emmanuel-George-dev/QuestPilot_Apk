import type { Quest, XLink } from "@/lib/types";

/** v2.4.3: Pre-click button kinds. "visit" = any non-X link (website, Discord, Telegram, ...). */
export type PreKind = "like" | "repost" | "follow" | "visit";
export const PRE_LABEL: Record<PreKind, string> = { like: "Like", repost: "Repost", follow: "Follow", visit: "Visit" };

/** One button. [key] is unique per task ("follow", "follow-2", "visit-3"...) and stores its done state. */
export type PreButton = { key: string; kind: PreKind; url: string; label: string; title: string };

const STATUS_ID = /(?:x|twitter)\.com\/(?:[A-Za-z0-9_]+|i(?:\/web)?)\/status\/(\d+)/i;
const ORDER: PreKind[] = ["like", "repost", "follow", "visit"];

/** Tweet id from a pasted X post link, or null. */
export function tweetId(link: string | null | undefined): string | null {
  const m = (link ?? "").match(STATUS_ID);
  return m ? m[1] : null;
}

function short(url: string, kind: PreKind): string {
  try {
    const u = new URL(url);
    if (kind === "follow") {
      const n = u.searchParams.get("screen_name") ?? u.pathname.split("/").filter(Boolean)[0];
      return n ? `@${n}` : "";
    }
    if (kind === "visit") return u.hostname.replace(/^www\./, "");
  } catch {
    /* keep empty */
  }
  return "";
}

/**
 * Every Pre-click button of a task (locked, unlocked or ready): Like / Repost per post, Follow per profile,
 * Visit per other link, from the description (sync). A pasted X post link replaces the description's Like / Repost.
 */
export function preclickButtons(q: Quest): PreButton[] {
  // links from the Zealy page (task settings / X buttons) first, then the description; same link only once
  const links: XLink[] = [];
  const seen = new Set<string>();
  for (const l of [...(q.pageLinks ?? []), ...(q.xLinks ?? [])]) {
    const k = `${l.kind}|${l.url}`;
    if (!seen.has(k)) (seen.add(k), links.push(l));
  }
  const pasted = tweetId(q.xPostLink);
  const items: { kind: PreKind; url: string; label: string }[] = [];
  if (pasted) {
    items.push({ kind: "like", url: `https://x.com/intent/like?tweet_id=${pasted}`, label: "pasted link" });
    items.push({ kind: "repost", url: `https://x.com/intent/retweet?tweet_id=${pasted}`, label: "pasted link" });
  }
  for (const l of links) {
    if (l.kind === "post") continue;
    const kind: PreKind = l.kind === "other" ? "visit" : l.kind;
    if (pasted && (kind === "like" || kind === "repost")) continue;
    items.push({ kind, url: l.url, label: l.label });
  }
  items.sort((a, b) => ORDER.indexOf(a.kind) - ORDER.indexOf(b.kind));
  const count: Record<string, number> = {};
  const total: Record<string, number> = {};
  items.forEach((i) => (total[i.kind] = (total[i.kind] ?? 0) + 1));
  return items.map((i) => {
    const n = (count[i.kind] = (count[i.kind] ?? 0) + 1);
    const s = short(i.url, i.kind);
    const title = total[i.kind] > 1 || i.kind === "visit" ? `${PRE_LABEL[i.kind]}${s ? ` ${s}` : n > 1 ? ` ${n}` : ""}` : PRE_LABEL[i.kind];
    return { key: n === 1 ? i.kind : `${i.kind}-${n}`, kind: i.kind, url: i.url, label: i.label, title };
  });
}

/** True when the description had no post link (so Like / Repost can't be built) but the task looks like an X task. */
export function needsPostLink(q: Quest): boolean {
  if ([...(q.xLinks ?? []), ...(q.pageLinks ?? [])].some((x) => x.kind === "post" || x.kind === "like" || x.kind === "repost")) return false;
  const xTask = /twitter|tweet/i.test(q.taskKinds ?? "") || q.type === "twitter";
  const words = /\b(like|repost|retweet|rt)\b/i.test(q.notes ?? "");
  return xTask || words;
}
