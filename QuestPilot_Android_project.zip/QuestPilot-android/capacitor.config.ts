import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "io.questpilot.app",
  appName: "QuestPilot",
  webDir: "dist",
  android: {
    // The UI talks to zealy.io only through the native plugin, never from the WebView.
    allowMixedContent: false,
  },
};

export default config;
