// Copies the debug-only web bundle (dist-devtools/, built with `vite build --mode devtools`)
// into the Android *debug* source set. Android merges src/debug/assets over src/main/assets
// for debug builds only, so release APKs never contain it.
import { cpSync, existsSync, rmSync } from "node:fs";
import { resolve } from "node:path";

const from = resolve("dist-devtools");
const to = resolve("android/app/src/debug/assets/public");
rmSync(to, { recursive: true, force: true });
if (!existsSync(from)) {
  console.error("dist-devtools/ is missing: run `npm run build:devtools` first");
  process.exit(1);
}
cpSync(from, to, { recursive: true });
console.log("debug-only web bundle -> android/app/src/debug/assets/public");
