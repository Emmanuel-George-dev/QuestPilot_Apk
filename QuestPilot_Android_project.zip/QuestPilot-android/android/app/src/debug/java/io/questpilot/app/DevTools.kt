package io.questpilot.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * DEBUG BUILD ONLY (src/debug). The release build compiles src/release/DevTools.kt instead,
 * a stub with no test code.
 *
 * Test quests live in their own file (files/devtools/test-quests.json) with negative ids. They
 * are never written to questpilot-db-v1, never appear in the quest list, never create alerts
 * in the alert history, never go to Telegram and are never synced. Their notifications use a
 * separate "Test" channel and are labelled [Test].
 */
object DevTools {
    val ENABLED: Boolean = BuildConfig.DEBUG // true for this source set; release compiles the stub
    const val CH_TEST = "devtools-test"
    const val ID_TEST_SOON = 9101
    const val ID_TEST_CLAIM = 9102
    private const val TEST_ID = -1
    private val lock = Any()

    private fun dir(ctx: Context) = File(ctx.filesDir, "devtools")
    private fun file(ctx: Context) = File(dir(ctx), "test-quests.json")

    fun isTestId(id: Int) = id < 0

    fun testQuests(ctx: Context): List<JSONObject> = synchronized(lock) {
        try {
            val a = JSONArray(file(ctx).readText())
            (0 until a.length()).map { a.getJSONObject(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun testQuest(ctx: Context, id: Int): JSONObject? = if (!isTestId(id)) null else testQuests(ctx).firstOrNull { it.optInt("id") == id }

    fun createChannel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CH_TEST, "Test mode (debug build)", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Notifications from the fake test quest. Debug builds only."
            })
    }

    /** Fake daily quest unlocking in `seconds`. Reads the real data only to borrow a page URL. */
    fun start(ctx: Context, seconds: Int, sourceQuestId: Int): JSONObject {
        val db = DbStore.read()
        val src = if (sourceQuestId > 0) DbStore.quest(db, sourceQuestId) else null
        val comms = db.getJSONArray("communities")
        val c = src?.let { DbStore.community(db, it.optInt("communityId")) } ?: if (comms.length() > 0) comms.getJSONObject(0) else null
        val url = src?.optString("url")?.ifEmpty { null }
            ?: c?.let { "https://zealy.io/cw/${it.optString("subdomain")}/questboard" } ?: "https://zealy.io/"
        val unlock = System.currentTimeMillis() + seconds * 1000L
        val q = JSONObject()
            .put("id", TEST_ID).put("title", "[Test] Fake daily quest").put("source", "test")
            .put("type", "daily").put("recurrence", "daily").put("xp", 0).put("url", url)
            .put("communityId", c?.optInt("id") ?: 0).put("communityName", c?.optString("name") ?: "Test")
            .put("autoOpen", 1).put("testUnlockAt", unlock)
            .put("testSourceQuestId", src?.optInt("id") ?: JSONObject.NULL)
            .put("taskKinds", src?.opt("taskKinds") ?: "text,file")
        q.put("unlockAt", UnlockClock.unlockAt(q, 0)) // same single unlock function as real quests
        synchronized(lock) {
            dir(ctx).mkdirs()
            file(ctx).writeText(JSONArray().put(q).toString())
        }
        createChannel(ctx)
        AlarmScheduler.rescheduleAll(ctx)
        return q
    }

    /** "Clear test data": test quests, their alarms and notifications, temp files, and any legacy test rows. */
    fun clear(ctx: Context) {
        synchronized(lock) { dir(ctx).deleteRecursively() }
        AlarmScheduler.rescheduleAll(ctx)
        Notifications.cancel(ctx, ID_TEST_SOON)
        Notifications.cancel(ctx, ID_TEST_CLAIM)
        File(ctx.cacheDir, "autofill").deleteRecursively()
        DbStore.purgeTestData()
    }

    /** Debug panel rows: every daily quest plus the test quest, from the single unlock function. */
    fun debugInfo(ctx: Context): JSONObject {
        val db = DbStore.read()
        val next = AlarmScheduler.nextFor(ctx)
        val rows = JSONArray()
        val qs = db.getJSONArray("quests")
        val all = (0 until qs.length()).map { qs.getJSONObject(it) }.filter { it.optString("recurrence") == "daily" } + testQuests(ctx)
        for (q in all) {
            val id = q.optInt("id")
            val n = next[id]
            rows.put(JSONObject().put("questId", id).put("title", q.optString("title"))
                .put("community", if (isTestId(id)) q.optString("communityName") else DbStore.community(db, q.optInt("communityId"))?.optString("name") ?: "")
                .put("unlockAt", if (q.isNull("unlockAt")) JSONObject.NULL else q.optLong("unlockAt"))
                .put("nextNotifyAt", n?.first ?: JSONObject.NULL).put("nextNotifyKind", n?.second ?: JSONObject.NULL)
                .put("test", isTestId(id)))
        }
        return JSONObject().put("rows", rows).put("exactAlarm", AlarmScheduler.canExact(ctx)).put("now", System.currentTimeMillis())
    }

    /**
     * "Test connection" (debug log screen): the OkHttp checks and the same URLs fetched inside a
     * WebView holding the session (credentials: "include"), so you can see which side fails.
     * Results go to NetLog; cookie values are never included.
     */
    fun testConnection(ctx: Context, cb: (JSONObject) -> Unit) {
        val app = ctx.applicationContext
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        val out = JSONObject()
        val names = SessionStore.cookieNames(app)
        out.put("cookieNames", JSONArray(names))
        out.put("userAgent", ZealyWeb.userAgent(app))
        out.put("authMode", SessionStore.authMode)
        out.put("hasStorageToken", SessionStore.bearer(app) != null)
        if (names.isEmpty()) { cb(out.put("error", "Zealy is not connected")); return }
        val uid = SessionStore.userIdFromCookie(app)
        val urls = listOfNotNull("${ZealyApi.A2}/users/me", uid?.let { "${ZealyApi.A2}/users/$it" })
        Thread {
            val ok = JSONArray()
            fun add(label: String, r: ZealyApi.Resp) = ok.put(JSONObject().put("label", label).put("url", r.url).put("status", r.code).put("snippet", r.snippet))
            add("OkHttp cookie /users/me", ZealyApi.me(app, "cookie"))
            if (uid != null) add("OkHttp cookie /users/{id}", ZealyApi.user(app, uid, "cookie"))
            if (SessionStore.bearer(app) != null) {
                add("OkHttp bearer /users/me", ZealyApi.me(app, "bearer"))
                if (uid != null) add("OkHttp bearer /users/{id}", ZealyApi.user(app, uid, "bearer"))
            }
            out.put("okhttp", ok)
            main.post {
                val w = android.webkit.WebView(app)
                ZealyWeb.configure(w)
                WebCheck.install(w)
                SessionStore.injectIntoWebView(app)
                var started = false
                val done = { res: JSONObject ->
                    WebCheck.log(res, names)
                    val arr = JSONArray()
                    res.keys().forEach { u -> val o = res.optJSONObject(u); arr.put(JSONObject().put("label", "WebView fetch " + u.substringAfter("/api")).put("url", u).put("status", o?.optInt("status")).put("snippet", NetLog.mask(o?.optString("body") ?: ""))) }
                    out.put("webview", arr)
                    w.destroy()
                    if (ClaimActivity.openCount <= 0) SessionStore.clearWebViewCookies()
                    cb(out)
                }
                w.webViewClient = object : android.webkit.WebViewClient() {
                    override fun onPageFinished(view: android.webkit.WebView, url: String) {
                        if (started) return
                        started = true
                        WebCheck.run(w, urls, 15_000, done)
                    }
                }
                w.loadUrl("https://zealy.io/robots.txt") // any zealy.io page gives the fetch the right Origin
            }
        }.start()
    }
}
