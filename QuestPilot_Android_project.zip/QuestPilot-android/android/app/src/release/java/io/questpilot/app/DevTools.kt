package io.questpilot.app

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * RELEASE BUILD (src/release). No test mode, no fake quests, no debug data.
 * The real implementation exists only in src/debug and is not compiled into release APKs.
 */
object DevTools {
    const val ENABLED = false
    const val CH_TEST = Notifications.CH_ALERTS
    const val ID_TEST_SOON = 0
    const val ID_TEST_CLAIM = 0

    fun isTestId(id: Int) = false
    fun testQuests(ctx: Context): List<JSONObject> = emptyList()
    fun testQuest(ctx: Context, id: Int): JSONObject? = null
    fun createChannel(ctx: Context) {}
    fun start(ctx: Context, seconds: Int, sourceQuestId: Int): JSONObject = throw UnsupportedOperationException("Not available in release builds")
    fun debugInfo(ctx: Context): JSONObject = throw UnsupportedOperationException("Not available in release builds")
    fun testConnection(ctx: Context, cb: (JSONObject) -> Unit): Unit = throw UnsupportedOperationException("Not available in release builds")

    /** Removes anything a debug build may have left behind, if the same install is updated to release. */
    fun clear(ctx: Context) {
        File(ctx.filesDir, "devtools").deleteRecursively()
        DbStore.purgeTestData()
    }
}
