package io.questpilot.app

import android.Manifest
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.ActivityResult
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

@CapacitorPlugin(
    name = "QuestPilot",
    permissions = [Permission(alias = "notifications", strings = [Manifest.permission.POST_NOTIFICATIONS])],
)
class QuestPilotPlugin : Plugin() {
    companion object {
        @Volatile private var instance: QuestPilotPlugin? = null

        fun emitDbChanged(rev: Long) {
            instance?.notifyListeners("dbChanged", JSObject().put("rev", rev))
        }

        fun emitStatus(ctx: Context) {
            instance?.notifyListeners("statusChanged", status(ctx))
        }

        fun status(ctx: Context): JSObject = JSObject()
            .put("connected", SessionStore.hasSession(ctx))
            .put("sessionExpired", State.sessionExpired)
            .put("userName", State.userName ?: JSONObject.NULL)
            .put("monitoringEnabled", State.monitoringEnabled)
            .put("serviceRunning", MonitorService.running)
            .put("pausedUntil", State.pausedUntil)
            .put("pauseReason", State.pauseReason ?: JSONObject.NULL)
            .put("lastSyncAt", State.lastSyncAt)
            .put("lastQuestPollAt", State.lastQuestPollAt)
            .put("lastMessagePollAt", State.lastMessagePollAt)
            .put("syncing", State.syncing)
            .put("debugBuild", DevTools.ENABLED)
    }

    private val bg = Executors.newCachedThreadPool()

    override fun load() {
        instance = this
    }

    private fun async(call: PluginCall, work: () -> Unit) = bg.execute {
        try { work() } catch (e: Exception) { call.reject(e.message ?: "Error", e) }
    }

    // ---------- data ----------
    @PluginMethod
    fun loadDb(call: PluginCall) = async(call) {
        val (json, rev) = DbStore.load()
        call.resolve(JSObject().put("json", json).put("rev", rev))
    }

    @PluginMethod
    fun saveDb(call: PluginCall) = async(call) {
        val json = call.getString("json") ?: return@async call.reject("json missing")
        val base = call.getData().optLong("baseRev", -1)
        val (ok, out, rev) = DbStore.saveFromUi(json, base)
        call.resolve(JSObject().put("ok", ok).put("conflict", !ok).put("json", out).put("rev", rev))
    }

    // ---------- Zealy session ----------
    @PluginMethod
    fun getStatus(call: PluginCall) = call.resolve(status(context))

    @PluginMethod
    fun connectZealy(call: PluginCall) {
        startActivityForResult(call, Intent(context, ZealyLoginActivity::class.java), "onConnectResult")
    }

    @ActivityCallback
    private fun onConnectResult(call: PluginCall?, result: ActivityResult) {
        call ?: return
        val ok = SessionStore.hasSession(context) && !State.sessionExpired
        call.resolve(JSObject().put("connected", ok))
        emitStatus(context)
    }

    @PluginMethod
    fun disconnectZealy(call: PluginCall) {
        SessionStore.clear(context)
        State.userId = null
        State.userName = null
        State.sessionExpired = false
        MonitorService.stop(context)
        emitStatus(context)
        call.resolve()
    }

    @PluginMethod
    fun syncNow(call: PluginCall) = async(call) {
        val r = ZealySync.syncAll(context, call.getString("subdomain"))
        val arr = JSArray()
        r.results.forEach { arr.put(it) }
        call.resolve(JSObject().put("ok", r.ok).put("error", r.error ?: JSONObject.NULL).put("results", arr))
    }

    @PluginMethod
    fun setMonitoring(call: PluginCall) {
        val on = call.getBoolean("enabled", true)!!
        State.monitoringEnabled = on
        if (on) {
            Backoff.ok()
            MonitorService.start(context)
        } else MonitorService.stop(context)
        call.resolve(status(context))
        emitStatus(context)
    }

    // ---------- open Zealy pages in the signed-in view ----------
    @PluginMethod
    fun openZealy(call: PluginCall) {
        val url = call.getString("url") ?: return call.reject("url missing")
        val i = Intent(context, ClaimActivity::class.java).putExtra(ClaimActivity.EXTRA_URL, url).putExtra(ClaimActivity.EXTRA_MODE, "browse")
        // With a quest id, ClaimActivity autofills that quest's saved content (zealy.io pages only).
        val qid = call.getData().optInt("questId", 0)
        if (qid > 0) i.putExtra(ClaimActivity.EXTRA_QUEST_ID, qid)
        // Claim run: the rest of the list rides along, so the claim screen gets a Next button.
        try {
            val q = call.getArray("queue")
            if (qid > 0 && q != null && q.length() > 1) i.putExtra(ClaimActivity.EXTRA_QUESTS, IntArray(q.length()) { q.getInt(it) })
        } catch (_: Exception) {
        }
        activity.startActivity(i)
        call.resolve()
    }

    /** Saved submissions: store a photo in app storage and return its id. */
    @PluginMethod
    fun savePhoto(call: PluginCall) = async(call) {
        val data = call.getString("data") ?: return@async call.reject("data missing")
        val id = SavedPhotos.save(context, data, call.getString("name") ?: "photo.jpg")
        call.resolve(JSObject().put("id", id))
    }

    // ---------- debug builds only: A1 debug line + test mode (DevTools is a stub in release) ----------
    private fun debugOnly(call: PluginCall): Boolean {
        if (!DevTools.ENABLED) call.unavailable("Not available in release builds")
        return DevTools.ENABLED
    }

    @PluginMethod
    fun getDebugInfo(call: PluginCall) {
        if (debugOnly(call)) async(call) { call.resolve(JSObject.fromJSONObject(DevTools.debugInfo(context))) }
    }

    @PluginMethod
    fun startTestUnlock(call: PluginCall) {
        if (debugOnly(call)) async(call) {
            val q = DevTools.start(context, call.getInt("seconds", 60)!!, call.getData().optInt("sourceQuestId", 0))
            call.resolve(JSObject().put("questId", q.optInt("id")).put("unlockAt", q.optLong("testUnlockAt")))
        }
    }

    @PluginMethod
    fun getTestQuests(call: PluginCall) {
        if (debugOnly(call)) {
            val arr = JSArray()
            DevTools.testQuests(context).forEach { arr.put(it) }
            call.resolve(JSObject().put("quests", arr))
        }
    }

    /** "Clear test data" (debug build). */
    @PluginMethod
    fun clearTest(call: PluginCall) {
        if (debugOnly(call)) async(call) { DevTools.clear(context); call.resolve() }
    }

    /** Debug log screen: request log (cookie values hidden) and "Test connection". */
    @PluginMethod
    fun getNetLog(call: PluginCall) {
        if (debugOnly(call)) call.resolve(JSObject().put("entries", JSArray(NetLog.all().toString())))
    }

    @PluginMethod
    fun clearNetLog(call: PluginCall) {
        if (debugOnly(call)) { NetLog.clear(); call.resolve() }
    }

    @PluginMethod
    fun testConnection(call: PluginCall) {
        if (debugOnly(call)) DevTools.testConnection(context) { call.resolve(JSObject.fromJSONObject(it)) }
    }

    // ---------- permissions (first launch guide) ----------
    private fun permState(): JSObject {
        val ctx = context
        val notif = when {
            Build.VERSION.SDK_INT < 33 -> if (ctx.getSystemService(NotificationManager::class.java).areNotificationsEnabled()) "granted" else "denied"
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED -> "granted"
            else -> "prompt"
        }
        val fsi = Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        val battery = ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
        return JSObject().put("sdk", Build.VERSION.SDK_INT).put("manufacturer", Build.MANUFACTURER ?: "")
            .put("notifications", notif).put("exactAlarm", AlarmScheduler.canExact(ctx))
            .put("fullScreenIntent", fsi).put("batteryUnrestricted", battery)
    }

    @PluginMethod
    fun getPermissionState(call: PluginCall) = call.resolve(permState())

    @PluginMethod
    fun requestNotificationPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT < 33 || permState().getString("notifications") == "granted") return call.resolve(permState())
        requestPermissionForAlias("notifications", call, "onNotifPerm")
    }

    @PermissionCallback
    private fun onNotifPerm(call: PluginCall) = call.resolve(permState())

    private fun open(vararg intents: Intent) {
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
    }

    private val pkgUri get() = Uri.parse("package:${context.packageName}")

    @PluginMethod
    fun openExactAlarmSettings(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= 31) open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri), Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
        call.resolve()
    }

    @PluginMethod
    fun openFullScreenIntentSettings(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= 34) open(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkgUri), Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
        call.resolve()
    }

    @PluginMethod
    fun openBatterySettings(call: PluginCall) {
        @Suppress("BatteryLife")
        open(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri),
        )
        call.resolve()
    }

    @PluginMethod
    fun openAutostartSettings(call: PluginCall) {
        val candidates = listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
            ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"),
            ComponentName("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"),
        )
        var opened = false
        for (cn in candidates) {
            try {
                context.startActivity(Intent().setComponent(cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                opened = true
                break
            } catch (_: Exception) {
            }
        }
        if (!opened) open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
        call.resolve(JSObject().put("opened", opened))
    }

    // ---------- misc ----------
    @PluginMethod
    fun sendTelegramTest(call: PluginCall) = async(call) {
        val (ok, err) = Telegram.send(context, "QuestPilot is connected. Alerts will arrive here.")
        call.resolve(JSObject().put("ok", ok).put("error", err ?: JSONObject.NULL))
    }

    @PluginMethod
    fun shareText(call: PluginCall) {
        val text = call.getString("text") ?: ""
        val name = call.getString("fileName") ?: "questpilot.txt"
        val mime = call.getString("mime") ?: "text/plain"
        val f = File(context.cacheDir, name)
        f.writeText(text)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(send, "Add to calendar").putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(view)))
        call.resolve()
    }
}
