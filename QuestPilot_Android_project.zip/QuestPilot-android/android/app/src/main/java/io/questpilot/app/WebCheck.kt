package io.questpilot.app

import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import org.json.JSONTokener
import java.util.UUID

/**
 * Runs the session check inside a logged-in WebView itself: fetch(url, {credentials: "include"})
 * from a zealy.io page, exactly like zealy.io's own client. Used to compare with the OkHttp result.
 * The JS bridge must be installed before the page loads.
 */
object WebCheck {
    private val main = Handler(Looper.getMainLooper())
    private val pending = mutableMapOf<String, (JSONObject) -> Unit>()

    class Bridge {
        @JavascriptInterface
        fun report(id: String, json: String) {
            main.post {
                val cb = pending.remove(id) ?: return@post
                cb(try { JSONObject(json) } catch (_: Exception) { JSONObject() })
            }
        }
    }

    fun install(w: WebView) = w.addJavascriptInterface(Bridge(), "QPCheck")

    /** Result: { "<url>": {status, body} }. Status -1 = fetch threw (CORS / network); -2 = timed out. */
    fun run(w: WebView, urls: List<String>, timeoutMs: Long = 12_000, cb: (JSONObject) -> Unit) {
        val id = UUID.randomUUID().toString()
        pending[id] = cb
        val list = org.json.JSONArray(urls).toString()
        val js = """
            (async () => {
              const out = {};
              for (const u of $list) {
                try {
                  const r = await fetch(u, { method: "GET", credentials: "include", headers: { Accept: "application/json" } });
                  const t = await r.text();
                  out[u] = { status: r.status, body: t.slice(0, 300) };
                } catch (e) { out[u] = { status: -1, body: String(e).slice(0, 300) }; }
              }
              try { QPCheck.report("$id", JSON.stringify(out)); } catch (e) {}
            })();
        """.trimIndent()
        main.post { w.evaluateJavascript(js, null) }
        main.postDelayed({
            pending.remove(id)?.invoke(JSONObject().apply { urls.forEach { put(it, JSONObject().put("status", -2).put("body", "timed out (page not on zealy.io or bridge missing)")) } })
        }, timeoutMs)
    }

    /** Logs each WebView result next to the OkHttp ones (debug builds). */
    fun log(res: JSONObject, cookieNames: List<String>) {
        res.keys().forEach { u ->
            val o = res.optJSONObject(u) ?: return@forEach
            NetLog.record("webview", "GET", u, o.optInt("status"), o.optString("body"), cookieNames, "in-WebView fetch, credentials: include")
        }
    }

    private val JWT = Regex("^eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]*$")

    /**
     * Looks for a token zealy.io might keep in localStorage / sessionStorage (keys containing
     * token/auth/jwt/session/access). Returns the best JWT-looking value, plus the key names (for the log).
     */
    fun readStorageToken(w: WebView, cb: (token: String?, keys: List<String>) -> Unit) {
        val js = """
            (function () {
              const out = {}; const re = /token|auth|jwt|session|access/i;
              [["local", window.localStorage], ["session", window.sessionStorage]].forEach(([n, st]) => {
                try { for (let i = 0; i < st.length; i++) { const k = st.key(i); if (re.test(k)) out[n + ":" + k] = String(st.getItem(k) || "").slice(0, 8000); } } catch (e) {}
              });
              return JSON.stringify(out);
            })()
        """.trimIndent()
        main.post {
            w.evaluateJavascript(js) { raw ->
                val obj = try { JSONObject(JSONTokener(raw).nextValue() as String) } catch (_: Exception) { JSONObject() }
                var best: String? = null
                var bestScore = -1
                val keys = mutableListOf<String>()
                obj.keys().forEach { k ->
                    val v = obj.optString(k).trim().trim('"')
                    val token = when {
                        JWT.matches(v) -> v
                        v.startsWith("{") -> try {
                            val o = JSONObject(v)
                            listOf("access_token", "accessToken", "token", "jwt", "idToken").firstNotNullOfOrNull { f -> o.optString(f).takeIf { JWT.matches(it) } }
                        } catch (_: Exception) { null }
                        else -> null
                    }
                    keys.add(k + if (token != null) " (jwt)" else "")
                    if (token != null) {
                        val score = (if (k.contains("access", true)) 2 else 0) + (if (k.startsWith("local")) 1 else 0)
                        if (score > bestScore) { best = token; bestScore = score }
                    }
                }
                cb(best, keys)
            }
        }
    }
}
