package io.questpilot.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.locks.ReentrantLock
import kotlin.random.Random

/**
 * v2.4.2 Fix 1: one gate for every Zealy API request, from every thread (quest monitor, message monitor,
 * full sync, unlock re-checks, claim checks, manual syncs, login check).
 *   - 1.5 to 2.5 s (random) between the START of any two requests
 *   - at most [PER_MINUTE] requests in any 60 s window; extra requests wait, they are never dropped
 *   - while a pause is active (State.paused()) automatic requests don't pass: they return [ZealyApi.SKIPPED]
 *     without sending anything. Manual requests ("Sync now", per-community retry, login) pass, still spaced.
 * The per-community jitter sleeps in the monitors and the sync stay; this is the extra safety net.
 * A fair lock keeps waiting requests in order.
 */
object ZealyGate {
    const val PER_MINUTE = 20
    private val lock = ReentrantLock(true)
    private var lastStart = 0L
    private var gap = 0L
    private val starts = ArrayDeque<Long>() // last 10 minutes, for the cap and the Debug counter
    private val manualFlag = ThreadLocal<Boolean>()

    val isManual get() = manualFlag.get() == true

    /** Runs [block] with its Zealy requests marked manual (they pass a pause, still spaced). */
    fun <T> manual(block: () -> T): T {
        val was = manualFlag.get()
        manualFlag.set(true)
        try { return block() } finally { manualFlag.set(was) }
    }

    /** Waits for a slot. false = paused and this request is automatic: don't send it. */
    fun pass(): Boolean {
        val manual = isManual
        lock.lock()
        try {
            while (true) {
                if (!manual && State.paused()) return false
                val now = System.currentTimeMillis()
                val inMinute = synchronized(starts) {
                    while (starts.isNotEmpty() && now - starts.first() > 600_000L) starts.removeFirst()
                    starts.filter { now - it < 60_000L }
                }
                var wait = lastStart + gap - now
                if (inMinute.size >= PER_MINUTE) wait = maxOf(wait, inMinute.first() + 60_000L - now + 50)
                if (wait <= 0) break
                Thread.sleep(minOf(wait, 1_000L)) // wake up every second to notice a pause that started meanwhile
            }
            val now = System.currentTimeMillis()
            lastStart = now
            gap = Random.nextLong(1_500L, 2_501L)
            synchronized(starts) { starts.addLast(now) }
            return true
        } finally {
            lock.unlock()
        }
    }

    /** Requests started in the last [ms] milliseconds (Debug counter, Event log lines). */
    fun count(ms: Long): Int {
        val now = System.currentTimeMillis()
        return synchronized(starts) { starts.count { now - it <= ms } }
    }
}

/**
 * v2.4.2 Fix 4: communities whose endpoint answered 403 (no access for this account: private community,
 * hidden leaderboard, removed membership). That endpoint is skipped for that community for 6 hours, then
 * tried again automatically. Manual retries ignore the skip. A success clears the mark. Tracked
 * communities also get a `noAccess` field ({endpoint: markedAtMs}) and a readable syncError.
 */
object NoAccess {
    const val SKIP_MS = 6 * 60 * 60_000L
    private const val PREFS = "qp_noaccess"

    /** Readable endpoint names for the community list. */
    fun label(ep: String) = when (ep) {
        "questboard" -> "the questboard"
        "sprint" -> "the sprint leaderboard"
        "xp" -> "your XP in this community"
        "community" -> "the community details"
        "notifications" -> "the notifications"
        else -> ep
    }

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun key(sub: String, ep: String) = "${sub.lowercase()}|$ep"

    fun skip(ctx: Context, sub: String, ep: String): Boolean {
        if (ZealyGate.isManual) return false
        val at = sp(ctx).getLong(key(sub, ep), 0L)
        return at > 0 && System.currentTimeMillis() - at < SKIP_MS
    }

    fun has(ctx: Context, sub: String, ep: String) = sp(ctx).getLong(key(sub, ep), 0L) > 0

    fun mark(ctx: Context, sub: String, ep: String) {
        val first = !has(ctx, sub, ep)
        sp(ctx).edit().putLong(key(sub, ep), System.currentTimeMillis()).apply()
        mirror(ctx, sub)
        if (first) EventLog.add("sync", "$sub: no access to ${label(ep)} (403), skipped for 6 h")
    }

    fun clear(ctx: Context, sub: String, ep: String) {
        if (!has(ctx, sub, ep)) return
        sp(ctx).edit().remove(key(sub, ep)).apply()
        mirror(ctx, sub)
        EventLog.add("sync", "$sub: access to ${label(ep)} works again, mark cleared")
    }

    fun endpoints(ctx: Context, sub: String): JSONObject {
        val o = JSONObject()
        val p = "${sub.lowercase()}|"
        for ((k, v) in sp(ctx).all) if (k.startsWith(p) && v is Long) o.put(k.removePrefix(p), v)
        return o
    }

    fun text(ctx: Context, sub: String): String? {
        val o = endpoints(ctx, sub)
        if (o.length() == 0) return null
        return "No access to " + o.keys().asSequence().map { label(it) }.joinToString(", ") + " (403)"
    }

    /** Copies the marks into the tracked community so the community list can show them. */
    private fun mirror(ctx: Context, sub: String) {
        try {
            val o = endpoints(ctx, sub)
            DbStore.mutate { d ->
                val c = ZealySync.findCommunity(d, sub) ?: return@mutate
                if (o.length() == 0) c.remove("noAccess") else c.put("noAccess", o)
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * v2.4.2 Fix 6: one cached list of your joined communities (30 minutes), shared by the message monitor
 * and the full sync, so /users/<id>/communities is requested once, not twice. A manual "Sync now" forces it.
 */
object CommunityCache {
    const val MAX_AGE_MS = 30 * 60_000L
    private val lock = Any()
    private fun file(ctx: Context) = File(ctx.filesDir, "communities-cache.json")

    /** Returns (response or null when served from cache, list). Concurrent callers wait and share one fetch. */
    fun get(ctx: Context, userId: String, force: Boolean = false): Pair<ZealyApi.Resp?, List<Pair<String, String>>> = synchronized(lock) {
        val o = try { JSONObject(file(ctx).readText()) } catch (_: Exception) { JSONObject() }
        val arr = o.optJSONArray("list")
        if (!force && arr != null && o.optString("userId") == userId && System.currentTimeMillis() - o.optLong("at") < MAX_AGE_MS) {
            return null to (0 until arr.length()).map { arr.getJSONObject(it) }.map { it.optString("subdomain") to it.optString("name") }
        }
        val (r, list) = ZealyApi.myCommunities(ctx, userId)
        if (r.ok || list.isNotEmpty()) {
            val a = JSONArray().apply { list.forEach { put(JSONObject().put("subdomain", it.first).put("name", it.second)) } }
            file(ctx).writeText(JSONObject().put("userId", userId).put("at", System.currentTimeMillis()).put("list", a).toString())
        }
        r to list
    }
}

/**
 * Debug builds only (DevTools.ENABLED is a constant false in release): fake Zealy answers for testing the
 * 429 / 403 rules without waiting for Zealy. The request still goes through the gate (it counts), but
 * nothing is sent. [match] = a piece of the URL path ("questboard", "leaderboard/sprint", "/users/",
 * a subdomain...) or "" for any request. [count] answers, then it switches itself off.
 */
object ZealySimulator {
    @Volatile var code = 0
    @Volatile var challenge = false
    @Volatile var match = ""
    @Volatile var left = 0

    fun set(code: Int, challenge: Boolean, match: String, count: Int) {
        this.code = code; this.challenge = challenge; this.match = match.trim(); left = count
        EventLog.add("sync", if (count > 0) "simulator: next $count request(s) matching '${match.ifEmpty { "any" }}' answer $code${if (challenge) " (challenge page)" else ""}" else "simulator off")
    }

    fun take(url: String): ZealyApi.Resp? {
        if (!DevTools.ENABLED || left <= 0) return null
        val path = Zealy403.path(url)
        if (match.isNotEmpty() && !path.contains(match, ignoreCase = true)) return null
        synchronized(this) { if (left <= 0) return null; left-- }
        val text = if (challenge) "<html><head><title>Just a moment...</title></head><body>cf-chl simulated</body></html>" else "{\"message\":\"simulated $code\"}"
        return ZealyApi.Resp(code, null, text, url)
    }
}

/** v2.4.2 Fix 4: how a 403 / 429 is read. */
object Zealy403 {
    private val CHALLENGE = Regex("(?i)just a moment|cf-chl|cf_chl|challenge-platform|/cdn-cgi/challenge|attention required|captcha|checking your browser|cf-ray")

    fun isChallenge(r: ZealyApi.Resp) = r.code == 403 && CHALLENGE.containsMatchIn(r.text.take(4000))

    fun path(url: String) = try { Uri.parse(url).path ?: url } catch (_: Exception) { url.substringBefore('?') }

    /** "Zealy answered 403 on /communities/x/questboard/v2, 14 requests in the last 60 s, <what>" */
    fun line(r: ZealyApi.Resp, what: String) =
        "Zealy answered ${r.code} on ${path(r.url)}, ${ZealyGate.count(60_000L)} requests in the last 60 s, $what"
}
