package io.questpilot.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject

/**
 * Part D: every non-Zealy link opens inside the app.
 *
 *   OTHER   : full-screen overlay WebView, small back arrow top-left closes it (D1)
 *   LIKE / REPOST : same overlay, auto-closes N seconds after the page loaded (D2, N = Debug slider)
 *   POST (reply, tweet, quote): X in a bottom sheet over 65% of the screen; when the post succeeds the
 *            link is copied, the sheet closes and the link is pasted into the task card you tapped (D3)
 *   FOLLOW  : full-screen overlay like LIKE / REPOST (v2.4.1, so the Zealy page behind it updates
 *            normally); closes as soon as the follow succeeds or you already follow (D4). No timer.
 *
 * QuestPilot never taps anything on X: every like, repost, post and follow tap is yours.
 * Each feature has its own Debug switch (prefs); with a switch off the link falls back to the plain overlay.
 */
@SuppressLint("SetJavaScriptEnabled")
class LinkOverlay(private val act: Activity, private val root: FrameLayout, private val zealy: () -> WebView?) {
    enum class Kind { OTHER, LIKE, REPOST, POST, FOLLOW }

    companion object {
        private val X_HOSTS = setOf("x.com", "twitter.com", "mobile.x.com", "mobile.twitter.com", "www.x.com", "www.twitter.com")
        private val X_RESERVED = setOf(
            "home", "explore", "i", "search", "notifications", "messages", "settings", "intent", "compose", "share", "login", "logout",
            "signup", "hashtag", "tos", "privacy", "account", "download", "jobs", "lists", "bookmarks", "communities", "premium", "verified-choose",
        )

        fun isX(u: Uri?) = u?.host?.lowercase() in X_HOSTS

        fun classify(url: String): Kind {
            val u = try { Uri.parse(url) } catch (_: Exception) { return Kind.OTHER }
            if (!isX(u)) return Kind.OTHER
            val segs = u.pathSegments.map { it.lowercase() }
            val p = "/" + segs.joinToString("/")
            return when {
                p.startsWith("/intent/like") || p.startsWith("/intent/favorite") -> Kind.LIKE
                p.startsWith("/intent/retweet") -> Kind.REPOST
                p.startsWith("/intent/tweet") || p.startsWith("/intent/post") || p.startsWith("/compose/tweet") || p.startsWith("/compose/post") || p == "/share" -> Kind.POST
                p.startsWith("/intent/follow") || p.startsWith("/intent/user") -> Kind.FOLLOW
                segs.size == 1 && segs[0] !in X_RESERVED && Regex("^[a-z0-9_]{1,15}$").matches(segs[0]) -> Kind.FOLLOW
                else -> Kind.OTHER
            }
        }

        /** Hooks X's own network calls in the X page. Reports only paths and status codes, never cookies or tokens. */
        val X_HOOK_JS = """
(function(){if(window.__qpx)return;window.__qpx=1;
function rep(m,a,b){try{QPX[m](String(a||''),String(b||''));}catch(e){}}
function path(u){try{return new URL(u,location.href).pathname;}catch(e){return String(u).split('?')[0];}}
function handleOf(){try{var a=document.querySelector('[data-testid="AppTabBar_Profile_Link"]');if(a){var m=a.getAttribute('href').match(/^\/([A-Za-z0-9_]{1,15})/);if(m)return m[1];}}catch(e){}return '';}
function parsePost(t){try{var j=typeof t==='string'?JSON.parse(t):t;var d=j&&j.data||{};var c=d.create_tweet||d.notetweet_create||d.create_note_tweet||{};var r=(c.tweet_results||{}).result||{};if(r.tweet)r=r.tweet;
var id=r.rest_id||(r.legacy&&r.legacy.id_str);var h='';try{var us=r.core.user_results.result;h=(us.core&&us.core.screen_name)||(us.legacy&&us.legacy.screen_name)||'';}catch(e){}
if(id)rep('posted',id,h||handleOf());else rep('postFailed',(j&&j.errors?JSON.stringify(j.errors).slice(0,160):'no post id'),'');}catch(e){rep('postFailed','unreadable response','');}}
function seen(u,st,body){var p=path(u);if(/\/i\/api\/|\/1\.1\/|\/2\/|graphql/.test(p))rep('req',p,st);
var ok=st>=200&&st<300;
if(/CreateTweet|CreateNoteTweet/.test(p)){if(ok)parsePost(body);else rep('postFailed','HTTP '+st,'');}
if(/friendships\/create/.test(p)&&ok)rep('followed','api','');
if(/CreateRetweet|FavoriteTweet/.test(p)&&ok)rep('engaged',p,'');}
var of=window.fetch;if(of)window.fetch=function(i,n){var u=(typeof i==='string')?i:(i&&i.url)||'';return of.apply(this,arguments).then(function(r){try{if(/CreateTweet|CreateNoteTweet/.test(u))r.clone().text().then(function(t){seen(u,r.status,t);});else seen(u,r.status,'');}catch(e){}return r;});};
var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open=function(m,u){this.__qpu=u;return xo.apply(this,arguments);};
XMLHttpRequest.prototype.send=function(){var x=this;x.addEventListener('load',function(){var b='';try{if(/CreateTweet|CreateNoteTweet/.test(x.__qpu)){b=(x.responseType===''||x.responseType==='text')?x.responseText:(x.responseType==='json'?x.response:'');}}catch(e){}seen(x.__qpu,x.status,b);});return xs.apply(this,arguments);};
var last='';function scan(){try{var t=document.querySelector('[data-testid="toast"]');if(t){var tx=(t.innerText||'');if(/sent|posted|reply|replied/i.test(tx)){var a=t.querySelector('a[href*="/status/"]');var k='toast'+(a?a.href:'')+tx;if(k!==last){last=k;rep('toast',a?a.href:'',tx.slice(0,80));}}}
var uf=document.querySelector('[data-testid$="-unfollow"]');if(uf){if(last!=='following'){last='following';rep('following','button','');}return;}
var b=[].slice.call(document.querySelectorAll('[role=button],button')).find(function(x){return /^\s*Following\s*$/i.test(x.innerText||'');});if(b&&last!=='following'){last='following';rep('following','text','');}}catch(e){}}
function start(){try{new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true,characterData:true});}catch(e){}scan();}
if(document.documentElement)start();else document.addEventListener('DOMContentLoaded',start);
})();
""".trimIndent()

        /**
         * Zealy page: reports every window.open / outside link with the task card you tapped. Cards get a
         * data-qp-card id so the post link can later be pasted into the same card. Zealy's own click
         * handlers still run (no stopPropagation), and window.open returns a stand-in window that turns
         * `closed` and fires focus when the overlay closes, so Zealy notices you came back.
         */
        val LINKS_JS = """
(function(){if(window.__qpLinks)return;window.__qpLinks=1;
var seq=0,lastCard='',lastAt=0,wins=[];
var IN='input[type=url],input[type=text],input:not([type]),textarea,[contenteditable=true]';
function cardOf(el){var n=el;for(var i=0;i<14&&n&&n!==document.body;i++){try{if(n.querySelector&&n.querySelector(IN)&&n.offsetHeight<1400)return n;}catch(e){}n=n.parentElement;}
n=el;for(var j=0;j<5&&n&&n.parentElement;j++)n=n.parentElement;return n;}
function idOf(el){var c=cardOf(el);if(!c||!c.dataset)return '';if(!c.dataset.qpCard)c.dataset.qpCard='c'+(++seq);return c.dataset.qpCard;}
function outside(h){try{var u=new URL(h,location.href);if(!/^https?:$/.test(u.protocol))return false;return !/(^|\.)zealy\.io$/i.test(u.hostname);}catch(e){return false;}}
document.addEventListener('click',function(e){try{lastCard=idOf(e.target);lastAt=Date.now();var a=e.target.closest&&e.target.closest('a[href]');
if(a&&outside(a.href)){QPLinks.open(a.href,lastCard);e.preventDefault();}}catch(x){}},true);
var wo=window.open;window.open=function(u){try{var abs=new URL(u||'',location.href).href;if(outside(abs)){var card=(Date.now()-lastAt<3000)?lastCard:'';QPLinks.open(abs,card);
var w={closed:false,opener:window,focus:function(){},blur:function(){},close:function(){w.closed=true;},postMessage:function(){},location:{href:abs,replace:function(){},assign:function(){}},document:{write:function(){},close:function(){}}};wins.push(w);return w;}}catch(x){}
return wo.apply(window,arguments);};
window.__qpOverlayClosed=function(){wins.forEach(function(w){w.closed=true;});wins=[];try{window.dispatchEvent(new Event('focus'));document.dispatchEvent(new Event('visibilitychange'));}catch(e){}};
window.__qpScanIntents=function(){try{var out=[];document.querySelectorAll('a[href*="intent/like"],a[href*="intent/retweet"],a[href*="intent/favorite"]').forEach(function(a){var r=a.getBoundingClientRect();if(r.width>0&&r.bottom>0&&r.top<innerHeight)out.push(a.href);});QPLinks.visible(JSON.stringify(out.slice(0,3)));}catch(e){}};
window.__qpPaste=function(card,link){function vis(e){return e&&e.getClientRects().length>0;}
var sels='input[type=url],input[type=text],input:not([type]),textarea';var el=null;
if(card){var r=document.querySelector('[data-qp-card="'+card+'"]');if(r)el=[].slice.call(r.querySelectorAll(sels)).find(function(x){return vis(x)&&!x.disabled&&!x.readOnly;});}
if(!el)el=[].slice.call(document.querySelectorAll('input[type=url]')).find(function(x){return vis(x)&&!x.value;});
if(!el)el=[].slice.call(document.querySelectorAll(sels)).find(function(x){return vis(x)&&!x.value&&/http|link|url|tweet|post/i.test((x.placeholder||'')+(x.name||'')+(x.getAttribute('aria-label')||''));});
if(!el)return 'none';el.focus();var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
Object.getOwnPropertyDescriptor(proto,'value').set.call(el,link);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
setTimeout(function(){el.dispatchEvent(new Event('blur',{bubbles:true}));},0);return (el.value===link)?'ok':'unconfirmed';};
})();
""".trimIndent()

        /** Installs [js] at document start when the WebView supports it (falls back to onPageStarted/Finished injection). */
        fun addStartScript(w: WebView, js: String, origins: Set<String>): Boolean = try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) { WebViewCompat.addDocumentStartJavaScript(w, js, origins); true } else false
        } catch (_: Exception) { false }
    }

    private val main = Handler(Looper.getMainLooper())
    private var box: FrameLayout? = null
    private var web: WebView? = null
    private var kind = Kind.OTHER
    private var card: String? = null
    private var openedUrl: String? = null
    private var openedAt = 0L
    private var firstFinish = false
    private var closing = false
    private var timerLabel: TextView? = null
    private var lastOpen: Pair<String, Long>? = null
    private var googleHits = mutableListOf<Long>()
    private var posted = false
    // D2 preload: hidden WebViews for the like / repost buttons currently visible
    private val preloaded = linkedMapOf<String, WebView>()

    val isOpen get() = box != null

    private fun prefs() = try { DbStore.prefs(DbStore.read()) } catch (_: Exception) { JSONObject() }
    private fun on(k: String, def: Boolean = true) = prefs().optBoolean(k, def)
    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()
    private fun log(m: String) = EventLog.add("links", m)
    private fun toast(t: String) = Toast.makeText(act, t, Toast.LENGTH_LONG).show()

    /** Entry point for every outside link from the Zealy page (JS bridge, onCreateWindow, shouldOverrideUrlLoading). */
    fun open(url: String, cardId: String?) {
        val now = SystemClock.uptimeMillis()
        lastOpen?.let { (u, at) -> if (u == url && now - at < 1500) return } // same link reported twice (anchor + window.open)
        lastOpen = url to now
        val u = Uri.parse(url)
        val scheme = u.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") { openScheme(url); return }
        if (!on("featInAppLinks")) {
            log("in-app links off: $url sent to the browser")
            try { act.startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
            return
        }
        var k = classify(url)
        if ((k == Kind.LIKE || k == Kind.REPOST) && !on("featLikeTimer")) k = Kind.OTHER
        if (k == Kind.POST && !on("featPostSheet")) k = Kind.OTHER
        if (k == Kind.FOLLOW && !on("featFollowSheet")) k = Kind.OTHER
        close(silent = true)
        kind = k
        card = cardId?.ifEmpty { null }
        openedUrl = url
        openedAt = System.currentTimeMillis()
        firstFinish = false
        closing = false
        posted = false
        log("captured ${k.name.lowercase()} link: ${Redact.path(url)}${if (card != null) " (card $card)" else ""}")
        // v2.4.1: only reply / tweet / quote use the 65% sheet; Follow is full screen with the back arrow.
        if (k == Kind.POST) buildSheet() else buildFull()
        if (k == Kind.FOLLOW) timerLabel?.text = "closes when you follow"
        val w = takePreloaded(url) ?: newWeb()
        attach(w)
        if (w.url == null) w.loadUrl(url) else { log("preloaded page swapped in"); onFinished(w, w.url ?: url) }
    }

    // ------------------------------------------------------------------ layout

    private fun buildFull() {
        val b = FrameLayout(act).apply { setBackgroundColor(Color.parseColor("#0b0b0f")); isClickable = true }
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#151519")); setPadding(dp(4), 0, dp(12), 0)
        }
        val back = ImageButton(act).apply {
            setImageResource(R.drawable.ic_qp_back); setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Back"; setOnClickListener { close() }
        }
        val title = TextView(act).apply { setTextColor(Color.parseColor("#c9c9d1")); textSize = 13f; maxLines = 1; text = Uri.parse(openedUrl).host ?: "" }
        timerLabel = TextView(act).apply { setTextColor(Color.parseColor("#e05aae")); textSize = 13f; typeface = Typeface.MONOSPACE }
        bar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(timerLabel)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        col.addView(FrameLayout(act).apply { tag = "webslot" }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        b.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(b, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box = b
    }

    /** 65% bottom sheet over the Zealy page. Root padding follows the keyboard, so the composer stays above it. */
    private fun buildSheet() {
        val b = FrameLayout(act).apply { setBackgroundColor(Color.parseColor("#66000000")); isClickable = true }
        val sheet = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.parseColor("#0b0b0f")); cornerRadii = floatArrayOf(dp(14).toFloat(), dp(14).toFloat(), dp(14).toFloat(), dp(14).toFloat(), 0f, 0f, 0f, 0f) }
            clipToOutline = true
        }
        val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(6), dp(6), dp(6)) }
        val title = TextView(act).apply {
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            text = if (kind == Kind.FOLLOW) "Follow on X · tap Follow yourself" else "Post on X · the link is pasted when it's sent"
        }
        timerLabel = TextView(act).apply { setTextColor(Color.parseColor("#9a9aa5")); textSize = 12f }
        val done = TextView(act).apply {
            text = "Done"; setTextColor(Color.parseColor("#e05aae")); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { log("sheet closed with Done"); close() }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(timerLabel)
        bar.addView(done)
        sheet.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sheet.addView(FrameLayout(act).apply { tag = "webslot" }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (root.height * 0.65f).toInt().coerceAtLeast(dp(320)), Gravity.BOTTOM)
        b.addView(sheet, lp)
        // keep the sheet at 65% of the screen, but never taller than the space left above the keyboard
        val full = root.height
        b.addOnLayoutChangeListener { v, _, top, _, bottom, _, _, _, _ ->
            val want = minOf((full * 0.65f).toInt(), bottom - top)
            if (want > 0 && sheet.layoutParams.height != want) { sheet.layoutParams.height = want; v.post { sheet.requestLayout() } }
        }
        root.addView(b, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box = b
    }

    private fun slot(): FrameLayout? = box?.findViewWithTag("webslot")

    // ------------------------------------------------------------------ WebView

    private fun newWeb(): WebView {
        val w = WebView(act)
        ZealyWeb.configure(w)
        w.settings.setSupportMultipleWindows(false) // target=_blank inside the overlay stays in the overlay
        w.settings.javaScriptCanOpenWindowsAutomatically = false
        w.addJavascriptInterface(XBridge(w), "QPX")
        addStartScript(w, X_HOOK_JS, setOf("https://x.com", "https://twitter.com", "https://mobile.x.com", "https://mobile.twitter.com"))
        return w
    }

    private fun attach(w: WebView) {
        (w.parent as? ViewGroup)?.removeView(w)
        w.alpha = 1f
        w.webChromeClient = WebChromeClient()
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                val s = u.scheme?.lowercase()
                if (s == "http" || s == "https" || s == "about" || s == "blob" || s == "data") { googleCheck(u); return false }
                openScheme(u.toString())
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                if (view !== web) return
                log("load start ${Redact.path(url)} +${System.currentTimeMillis() - openedAt} ms")
                if (isX(Uri.parse(url))) view.evaluateJavascript(X_HOOK_JS, null)
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (view !== web) return
                onFinished(view, url)
            }
        }
        slot()?.addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web = w
    }

    private fun onFinished(view: WebView, url: String) {
        CookieManager.getInstance().flush()
        SiteCookies.snapshot(act, url)
        if (isX(Uri.parse(url))) view.evaluateJavascript(X_HOOK_JS, null)
        if (firstFinish) return
        firstFinish = true
        log("load finish ${Redact.path(url)} +${System.currentTimeMillis() - openedAt} ms")
        if (kind == Kind.LIKE || kind == Kind.REPOST) startAutoClose()
    }

    /** D2: close N seconds after the like / repost page finished loading (N from the Debug slider, 1-10 s, default 3). */
    private fun startAutoClose() {
        val n = prefs().optInt("likeCloseSec", 3).coerceIn(1, 10)
        val end = SystemClock.uptimeMillis() + n * 1000L
        val owner = web
        fun tick() {
            if (web !== owner || closing) return
            val left = end - SystemClock.uptimeMillis()
            if (left <= 0) { log("${kind.name.lowercase()} overlay auto-closed after $n s"); close(); return }
            timerLabel?.text = "closes in ${(left + 999) / 1000} s"
            main.postDelayed({ tick() }, 200)
        }
        tick()
    }

    fun close(silent: Boolean = false) {
        val b = box ?: return
        closing = true
        if (!silent) log("overlay closed (${kind.name.lowercase()}) after ${System.currentTimeMillis() - openedAt} ms")
        CookieManager.getInstance().flush()
        web?.let { SiteCookies.snapshot(act, it.url); (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        web = null
        root.removeView(b)
        box = null
        timerLabel = null
        zealy()?.evaluateJavascript("window.__qpOverlayClosed&&window.__qpOverlayClosed()", null)
    }

    fun onBack(): Boolean {
        if (!isOpen) return false
        val w = web
        if (kind == Kind.OTHER && w != null && w.canGoBack()) { w.goBack(); return true }
        close()
        return true
    }

    fun destroy() {
        close(silent = true)
        preloaded.values.forEach { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        preloaded.clear()
        main.removeCallbacksAndMessages(null)
    }

    // ------------------------------------------------------------------ app links / Google

    /** intent:// and app deep links only leave the app when their scheme is in Settings > Allowed app links. */
    fun openScheme(url: String) {
        val allowed = prefs().optString("allowedAppLinks", "").split(",", " ", ";").map { it.trim().lowercase().removeSuffix("://").removeSuffix(":") }.filter { it.isNotEmpty() }.toSet()
        val scheme = Uri.parse(url).scheme?.lowercase() ?: return
        if (scheme == "intent") {
            val i = try { Intent.parseUri(url, Intent.URI_INTENT_SCHEME) } catch (_: Exception) { null }
            if (i != null && "intent" in allowed) {
                i.addCategory(Intent.CATEGORY_BROWSABLE); i.component = null; i.selector = null
                try { act.startActivity(i); log("intent:// opened outside (allowed)"); return } catch (_: Exception) {}
            }
            val fb = i?.getStringExtra("browser_fallback_url")
            if (fb != null && fb.startsWith("http")) { log("intent:// -> fallback page in app"); open(fb, card); return }
            toast("Blocked an app link (intent://). Allow \"intent\" under Settings > Allowed app links to open it.")
            log("blocked intent:// link")
            return
        }
        if (scheme in allowed) {
            try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)); log("$scheme: link opened outside (allowed)"); return } catch (_: Exception) {}
        }
        log("blocked $scheme: link")
        toast("Blocked an app link ($scheme:). Add \"$scheme\" under Settings > Allowed app links to open it in its app.")
    }

    /** C6: Google refuses sign-in in embedded WebViews. Say so clearly instead of looping. */
    private fun googleCheck(u: Uri) {
        if (u.host?.lowercase() != "accounts.google.com") return
        val now = System.currentTimeMillis()
        googleHits.add(now); googleHits.removeAll { now - it > 60_000 }
        val rejected = u.toString().contains("disallowed_useragent") || (u.path ?: "").contains("/rejected")
        if (rejected || googleHits.size >= 6) {
            googleHits.clear()
            web?.stopLoading()
            showGoogleMessage(act, u.toString())
        }
    }

    // ------------------------------------------------------------------ D2 preload (optional, Debug switch)

    fun preloadVisible(urls: List<String>) {
        if (!on("featLikePreload", false) || !on("featLikeTimer")) { if (preloaded.isNotEmpty()) dropPreloads(); return }
        val want = urls.filter { classify(it) == Kind.LIKE || classify(it) == Kind.REPOST }.take(3).toSet()
        preloaded.keys.filter { it !in want }.forEach { k -> preloaded.remove(k)?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() } }
        for (u in want) if (!preloaded.containsKey(u)) {
            val w = newWeb()
            w.alpha = 0.01f
            w.webViewClient = WebViewClient()
            // 1 px, almost transparent, attached to the window so it renders fully
            root.addView(w, 0, FrameLayout.LayoutParams(1, 1))
            w.loadUrl(u)
            preloaded[u] = w
            log("preloading ${Redact.path(u)}")
        }
    }

    private fun takePreloaded(url: String): WebView? = preloaded.remove(url)?.also { (it.parent as? ViewGroup)?.removeView(it) }
    private fun dropPreloads() { preloaded.values.forEach { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }; preloaded.clear() }

    // ------------------------------------------------------------------ D3 / D4 signals from X

    inner class XBridge(private val owner: WebView) {
        @JavascriptInterface fun req(path: String, status: String) = EventLog.add("x-req", "$path -> $status")

        @JavascriptInterface fun posted(id: String, handle: String) = main.post {
            if (owner !== web || kind != Kind.POST || posted) return@post
            val clean = handle.trim().removePrefix("@")
            val link = if (clean.matches(Regex("^[A-Za-z0-9_]{1,15}$"))) "https://x.com/$clean/status/$id" else "https://x.com/i/status/$id"
            onPostSuccess(link, "CreateTweet")
        }

        @JavascriptInterface fun postFailed(why: String, b: String) = main.post {
            if (owner !== web) return@post
            log("post failed: $why (sheet stays open)")
            this@LinkOverlay.toast("X didn't accept the post: the sheet stays open.")
        }

        @JavascriptInterface fun toast(link: String, text: String) = main.post {
            if (owner !== web || kind != Kind.POST || posted) return@post
            if (link.contains("/status/")) onPostSuccess(link.substringBefore('?'), "toast")
            else {
                log("\"$text\" seen but no link in it")
                (act as? ClaimActivity)?.showLinkBanner(null, "Your post was sent. Copy its link from X and paste it into the task.")
            }
        }

        @JavascriptInterface fun engaged(path: String, b: String) = log("X confirmed ${path.substringAfterLast('/')}")

        @JavascriptInterface fun followed(src: String, b: String) = main.post {
            if (owner !== web || kind != Kind.FOLLOW) return@post
            log("follow detected (source: api)"); close()
        }

        @JavascriptInterface fun following(src: String, b: String) = main.post {
            if (owner !== web || kind != Kind.FOLLOW) return@post
            log("follow detected (source: button${if (src == "text") ", Following text" else ""}), already following or just followed"); close()
        }
    }

    private fun onPostSuccess(link: String, via: String) {
        posted = true
        act.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Post link", link))
        log("post success via $via: ${Redact.path(link)}, copied")
        val c = card
        close() // immediately, no delay
        val z = zealy() ?: return
        val js = "window.__qpPaste?window.__qpPaste(${JSONObject.quote(c ?: "")},${JSONObject.quote(link)}):'none'"
        z.evaluateJavascript(js) { r ->
            val res = r?.trim('"') ?: "none"
            log("paste into card ${c ?: "(none)"}: $res")
            if (res == "none") (act as? ClaimActivity)?.showLinkBanner(link, "Link copied. Paste it into the task's link field.")
            else Toast.makeText(act, "Post link pasted. Check it, then tap Submit yourself.", Toast.LENGTH_LONG).show()
        }
    }
}

/** C6 message, shared by the overlay and the Zealy login screen. */
fun showGoogleMessage(act: Activity, url: String) {
    EventLog.add("links", "Google sign-in refused in the in-app browser")
    AlertDialog.Builder(act)
        .setTitle("Google sign-in doesn't work here")
        .setMessage("Google blocks sign-in inside apps' built-in browsers. Log in to this site another way (email, X, Discord), or open this one page in your phone's browser.")
        .setPositiveButton("OK", null)
        .setNegativeButton("Open in browser") { _, _ -> try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} }
        .show()
}
