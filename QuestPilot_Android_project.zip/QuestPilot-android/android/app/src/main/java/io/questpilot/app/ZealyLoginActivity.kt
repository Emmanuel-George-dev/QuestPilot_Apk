package io.questpilot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * "Connect Zealy". The user logs in to zealy.io here. Once the WebView is on a logged-in page
 * (not a login / OTP / verify page) and Zealy has set `user_metadata`, the cookie jar is flushed,
 * cookies are read for zealy.io, api-v2 and api-v1, and the session is checked two ways:
 * the app's own request (OkHttp) and a fetch(credentials: "include") inside this WebView.
 * Only 401/403 mean "not logged in"; other errors are shown with their status and response.
 */
class ZealyLoginActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var retry: Button
    private enum class Phase { WAITING, CHECKING, FAILED, DONE }
    private var phase = Phase.WAITING
    private var verified = false
    private var captured = false
    private val bg = Executors.newSingleThreadExecutor()

    companion object {
        /** Pages where the user is still logging in. */
        private val AUTH_PATH = Regex("^/(login|log-in|signin|sign-in|signup|sign-up|register|otp|verify|verification|auth|magic|callback|confirm|reset|forgot)(/|$)", RegexOption.IGNORE_CASE)

        fun isLoggedInPage(url: String?): Boolean {
            val u = url?.let { Uri.parse(it) } ?: return false
            val host = u.host ?: return false
            if (host != "zealy.io" && host != "www.zealy.io") return false
            val path = u.path ?: "/"
            if (AUTH_PATH.containsMatchIn(path)) return false
            val q = u.query ?: ""
            return !Regex("(?i)(otp|code|token|verify)=").containsMatchIn(q)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SessionStore.clearWebViewCookies() // fresh login
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0b0b0f")) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(24, 8, 8, 8) }
        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; maxLines = 8
            text = "Log in to Zealy. QuestPilot only keeps the session, encrypted."
        }
        retry = Button(this).apply { text = "Retry"; visibility = View.GONE; setOnClickListener { beginCheck() } }
        val cancel = Button(this).apply { text = "Cancel"; setOnClickListener { finishWith(false) } }
        bar.addView(status, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(retry)
        bar.addView(cancel)
        web = WebView(this)
        ZealyWeb.configure(web)
        WebCheck.install(web) // before the first load, so the bridge exists on every page
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest) = false
            override fun onPageFinished(view: WebView, url: String) = maybeBegin()
        }
        col.addView(bar)
        col.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(col)
        col.setOnApplyWindowInsetsListener { v, insets ->
            @Suppress("DEPRECATION")
            v.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
            insets
        }
        web.loadUrl(intent.getStringExtra("url") ?: "https://zealy.io/login")
        poll()
    }

    private fun poll() {
        if (phase == Phase.DONE) return
        maybeBegin()
        main.postDelayed({ poll() }, 1500)
    }

    /** Start only on a logged-in page with Zealy's login cookie present. */
    private fun maybeBegin() {
        if (phase != Phase.WAITING) return
        if (!isLoggedInPage(web.url)) return
        if (!SessionStore.readWebViewCookies().containsKey("user_metadata")) return
        beginCheck()
    }

    private fun beginCheck() {
        phase = Phase.CHECKING
        retry.visibility = View.GONE
        status.text = "Logged in. Saving the session…"
        CookieManager.getInstance().flush()
        // give the page a moment to finish its own post-login requests (token refresh cookies)
        main.postDelayed({
            CookieManager.getInstance().flush()
            WebCheck.readStorageToken(web) { token, keys ->
                if (keys.isNotEmpty()) NetLog.record("webview", "STORAGE", web.url ?: "", 0, "web storage keys: " + keys.joinToString(), emptyList())
                if (!SessionStore.captureFromWebView(this)) {
                    phase = Phase.WAITING
                    status.text = "Waiting for Zealy to finish logging you in…"
                    return@readStorageToken
                }
                captured = true
                SessionStore.setBearer(this, token)
                runChecks()
            }
        }, 1200)
    }

    private fun runChecks() {
        status.text = "Checking your Zealy session…"
        val names = SessionStore.cookieNames(this)
        val uid = SessionStore.userIdFromCookie(this)
        val urls = listOfNotNull("${ZealyApi.A2}/users/me", uid?.let { "${ZealyApi.A2}/users/$it" })
        var okhttp: Pair<String?, ZealyApi.Resp>? = null
        var inWeb: JSONObject? = null
        val finish = {
            val o = okhttp
            val w = inWeb
            if (o != null && w != null) decide(o, w)
        }
        bg.execute {
            val r = ZealySync.ensureUser(this)
            main.post { okhttp = r; finish() }
        }
        WebCheck.run(web, urls) { res ->
            WebCheck.log(res, names)
            inWeb = res
            finish()
        }
    }

    private fun decide(okhttp: Pair<String?, ZealyApi.Resp>, inWeb: JSONObject) {
        val (userId, r) = okhttp
        if (userId != null) {
            verified = true
            State.sessionExpired = false
            State.authFailures = 0
            State.backoffLevel = 0
            State.pausedUntil = 0
            Notifications.cancel(this, Notifications.ID_SESSION)
            finishWith(true)
            return
        }
        val webLine = inWeb.keys().asSequence().joinToString(" · ") { u ->
            "${u.substringAfter("/api")} → ${inWeb.optJSONObject(u)?.optInt("status")}"
        }
        val webOk = inWeb.keys().asSequence().any { inWeb.optJSONObject(it)?.optInt("status") in 200..299 }
        if (r.authError) {
            // 401/403: Zealy really doesn't see a login yet
            phase = Phase.WAITING
            status.text = "Zealy didn't accept the session (HTTP ${r.code}). Finish logging in.\nIn-app WebView check: $webLine"
        } else {
            // 400 / network / other: a request problem, not a login problem
            phase = Phase.FAILED
            retry.visibility = View.VISIBLE
            status.text = buildString {
                append("Zealy request error (HTTP ${r.code}): ")
                append(r.snippet.ifEmpty { "(empty response)" })
                append("\nIn-app WebView check: ").append(webLine)
                if (webOk) append("\nThe WebView is signed in; the app's request is what fails.")
            }
        }
    }

    private fun finishWith(ok: Boolean) {
        phase = Phase.DONE
        if (!ok && captured && !verified) SessionStore.clear(this) // half-finished login: keep nothing
        setResult(if (ok) RESULT_OK else RESULT_CANCELED, Intent().putExtra("connected", ok))
        if (ok) MonitorService.start(this)
        QuestPilotPlugin.emitStatus(this)
        finish()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        web.destroy()
        SessionStore.clearWebViewCookies() // the session now only lives in encrypted storage
        super.onDestroy()
    }
}
