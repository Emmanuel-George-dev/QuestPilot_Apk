package io.questpilot.app

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Zealy HTTP client (OkHttp). Sends what zealy.io's own pages send: the session cookies, the
 * same Chrome-for-Android User-Agent as the WebView, Origin/Referer https://zealy.io, and
 * Accept: application/json. GET requests have no body.
 */
object ZealyApi {
    const val A1 = "https://api-v1.zealy.io"
    const val A2 = "https://api-v2.zealy.io/api"
    /** Not sent: an automatic request during a pause (see ZealyGate). */
    const val SKIPPED = -2

    class Resp(val code: Int, val body: Any?, val text: String = "", val url: String = "") {
        val ok get() = code in 200..299
        /** Only 401/403 mean the session is not accepted. 400 is a request error. */
        val authError get() = code == 401 || code == 403
        val rateLimited get() = code == 429 || code == 403
        /** Not sent because a pause is active (automatic requests only). */
        val skipped get() = code == SKIPPED
        val snippet get() = NetLog.mask(text.replace(Regex("\\s+"), " ").trim().take(300))
        fun describe() = if (code < 0) "network error: $snippet" else "HTTP $code${if (snippet.isNotEmpty()) ": $snippet" else ""}"
    }

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(false) // a redirect to /login is an answer, not something to follow
            .build()
    }

    fun get(ctx: Context, url: String, auth: String? = null): Resp = request(ctx, "GET", url, null, auth)

    /**
     * [auth] "cookie" or "bearer"; null = the mode that worked at login (SessionStore.authMode).
     */
    fun request(ctx: Context, method: String, url: String, body: JSONObject?, auth: String? = null): Resp {
        // v2.4.2: every request from every thread passes the one shared gate (spacing, 20/min cap, pause).
        if (!ZealyGate.pass()) return Resp(SKIPPED, null, "paused: not sent", url)
        ZealySimulator.take(url)?.let { NetLog.record("simulated", method, url, it.code, it.snippet, emptyList()); return it }
        val mode = auth ?: SessionStore.authMode
        val cookie = SessionStore.cookieHeader(ctx)
        val b = Request.Builder().url(url)
            .header("Accept", "application/json")
            .header("Origin", "https://zealy.io")
            .header("Referer", "https://zealy.io/")
            .header("User-Agent", ZealyWeb.userAgent(ctx))
        if (cookie.isNotEmpty()) b.header("Cookie", cookie)
        if (mode == "bearer") SessionStore.bearer(ctx)?.let { b.header("Authorization", "Bearer $it") }
        if (method == "GET") b.get()
        else b.method(method, (body?.toString() ?: "").toRequestBody("application/json".toMediaType()))
        val names = SessionStore.cookieNames(ctx)
        return try {
            client.newCall(b.build()).execute().use { res ->
                SessionStore.mergeSetCookie(ctx, res.headers("Set-Cookie"))
                val text = res.body?.string() ?: ""
                val parsed: Any? = try { if (text.isBlank()) null else JSONTokener(text).nextValue() } catch (_: Exception) { null }
                val r = Resp(res.code, parsed, text, url)
                NetLog.record("okhttp", method, url, r.code, r.snippet, names, if (mode == "bearer") "auth: bearer (hidden)" else null)
                r
            }
        } catch (e: Exception) {
            val r = Resp(-1, null, "${e.javaClass.simpleName}: ${e.message ?: ""}", url)
            NetLog.record("okhttp", method, url, -1, r.snippet, names)
            r
        }
    }

    /** Exactly GET https://api-v2.zealy.io/api/users/me */
    fun me(ctx: Context, auth: String? = null) = get(ctx, "$A2/users/me", auth)

    /** What zealy.io itself calls: its client turns "me" into the userId from the user_metadata cookie. */
    fun user(ctx: Context, userId: String, auth: String? = null) = get(ctx, "$A2/users/$userId", auth)

    /** Every community the user has joined (paged). */
    fun myCommunities(ctx: Context, userId: String): Pair<Resp, List<Pair<String, String>>> {
        val out = mutableListOf<Pair<String, String>>()
        var page = 0
        var last: Resp
        while (true) {
            last = get(ctx, "$A2/users/$userId/communities?page=$page&limit=50")
            if (!last.ok) break
            val arr = (last.body as? JSONObject)?.optJSONArray("communities") ?: break
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val sub = c.optString("subdomain")
                if (sub.isNotEmpty()) out.add(sub to c.optString("name", sub))
            }
            if (arr.length() < 50 || page >= 10) break
            page++ // the gate spaces the next page
        }
        return last to out
    }

    /** Your own profile inside one community (Zealy's web app shows your XP and level from this). */
    fun communityUser(ctx: Context, sub: String, userId: String) = get(ctx, "$A2/communities/$sub/users/$userId")

    fun questboard(ctx: Context, sub: String) = get(ctx, "$A1/communities/$sub/questboard/v2")
    /** v2.4.4: one quest with its tasks (ids, X post link, actions). The same request Zealy's quest page makes. */
    fun questDetail(ctx: Context, sub: String, questId: String) = get(ctx, "$A1/communities/$sub/quests/v2/$questId")
    fun sprint(ctx: Context, sub: String) = get(ctx, "$A2/communities/$sub/leaderboard/sprint?onlyCurrent=true")
    fun community(ctx: Context, sub: String) = get(ctx, "$A2/communities/$sub")

    /**
     * B3: the endpoint zealy.io's own notification bell uses (ts-rest contract `notification.list`):
     * GET /api/communities/:subdomain/users/:userId/notifications?limit=20 -> {items, nextCursor, totalUnread}
     */
    fun notifications(ctx: Context, sub: String, userId: String) = get(ctx, "$A2/communities/$sub/users/$userId/notifications?limit=20")

    fun modules(r: Resp): JSONArray? = when (val b = r.body) {
        is JSONArray -> b
        is JSONObject -> b.optJSONArray("data") ?: b.optJSONArray("modules")
        else -> null
    }
}
