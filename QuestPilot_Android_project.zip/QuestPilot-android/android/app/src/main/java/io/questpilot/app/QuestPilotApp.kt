package io.questpilot.app

import android.app.Activity
import android.app.Application
import android.os.Bundle
import java.util.concurrent.Executors

class QuestPilotApp : Application() {
    companion object {
        @Volatile private var started = 0
        val isForeground get() = started > 0
    }

    override fun onCreate() {
        super.onCreate()
        State.init(this)
        SessionStore.loadAuthMode(this)
        DbStore.init(this)
        Notifications.createChannels(this)
        DevTools.createChannel(this)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(a: Activity) { started++ }
            override fun onActivityStopped(a: Activity) { started = (started - 1).coerceAtLeast(0) }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
        Executors.newSingleThreadExecutor().execute {
            try { AlarmScheduler.rescheduleAll(this) } catch (_: Exception) {}
            try { SavedPhotos.gc(this) } catch (_: Exception) {}
            // Test quests never live in the real data; remove any an older build left there.
            try { DbStore.purgeTestData() } catch (_: Exception) {}
            if (!DevTools.ENABLED) try { DevTools.clear(this) } catch (_: Exception) {}
        }
    }
}
