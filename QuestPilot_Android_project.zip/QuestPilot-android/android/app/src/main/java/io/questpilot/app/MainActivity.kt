package io.questpilot.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(QuestPilotPlugin::class.java)
        super.onCreate(savedInstanceState)
        MonitorService.start(this)
    }
}
