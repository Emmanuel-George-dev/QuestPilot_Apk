package io.questpilot.app

import org.json.JSONObject
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

/**
 * A1 — THE single source of a quest's unlock time.
 *
 * Returns an absolute UTC timestamp in ms (may be in the past = available), 0 for
 * "available now", or null for "locked / unknown". The result never depends on the
 * current time, so a notification scheduled from it can be checked again right before
 * it fires: if the recomputed value differs, the data changed and the alarm is dropped.
 *
 * The web UI never recomputes this: DbStore writes the value to quest.unlockAt on every
 * save, and the countdown / in-app alerts / system notifications all read that.
 *
 * Zealy rules (https://zealy.io/docs/quest-properties/recurrence): daily quests reset at
 * 00:00 UTC, weekly on Mondays 00:00 UTC, monthly on the 1st 00:00 UTC. The questboard
 * reports `opened=false` + `openAt` while a recurring quest is waiting for its reset, and
 * date conditions (https://zealy.io/docs/quest-properties/conditions) lock a quest until a date.
 */
object UnlockClock {
    private const val DAY = 86_400_000L
    private val PERIOD = mapOf("daily" to DAY, "weekly" to 7 * DAY, "monthly" to 30 * DAY)

    fun unlockAt(q: JSONObject, tzOffsetMin: Int): Long? {
        // Debug-build test quests only (they live outside the real data, see DevTools).
        if (q.has("testUnlockAt") && !q.isNull("testUnlockAt")) return if (DevTools.ENABLED) q.getLong("testUnlockAt") else null
        val recurrence = q.optString("recurrence", "once")
        val z = q.optJSONObject("zealy")
        return if (q.optString("source") == "zealy" && z != null) fromZealy(z, recurrence) else manual(q, recurrence, tzOffsetMin)
    }

    private fun fromZealy(z: JSONObject, recurrence: String): Long? {
        val done = z.optBoolean("claimed") || z.optBoolean("completed")
        if (z.optBoolean("locked")) {
            if (done) return null
            // 1. a date / timestamp inside the conditions, 2. any "opens at / unlocks at" field on the quest itself
            return dateConditionUnlock(z) ?: questLevelTime(z)
        }
        val opened: Boolean? = if (z.has("opened") && !z.isNull("opened")) z.optBoolean("opened") else null
        val openAt = parseTime(z.opt("openAt"))
        if (opened == false) {
            if (openAt != null) return openAt
            questLevelTime(z)?.let { return it }
            if (recurrence != "once") return nextReset(recurrence, z.optLong("syncedAt", 0L))
            return null
        }
        if (recurrence == "once") {
            if (done) return null
            // A one-time quest that was locked and has now unlocked keeps the moment it unlocked (a fixed past
            // timestamp, never "now"), so it shows up as claimable instead of disappearing among the open tasks.
            val was = parseTime(z.opt("lockedUntil"))
            return was ?: 0L
        }
        if (done) return nextReset(recurrence, z.optLong("syncedAt", 0L))
        // failed claim with a cooldown
        val retryAt = parseTime(z.opt("retryAt"))
        if (retryAt != null && z.opt("canRetry") != true) return retryAt
        return 0L
    }

    /** Field names that mean "this is when it opens", on the quest itself. */
    private val QUEST_TIME_KEYS = listOf(
        "unlockAt", "unlocksAt", "unlockDate", "unlockedAt", "opensAt", "openingAt", "openDate", "startAt", "startsAt",
        "startDate", "startingAt", "availableAt", "availableFrom", "lockedUntil", "visibleFrom",
    )

    /** The `zealy.questTimes` object written by the sync: any opens-at / unlocks-at field Zealy sent. */
    private fun questLevelTime(z: JSONObject): Long? {
        val t = z.optJSONObject("questTimes") ?: return null
        for (k in QUEST_TIME_KEYS) plausible(t.opt(k))?.let { return it }
        return null
    }

    /** Keys inside a condition that can carry the date. */
    private val COND_TIME_KEYS = listOf("value", "date", "unlockAt", "unlocksAt", "startAt", "startDate", "startsAt", "from", "after", "at", "time", "timestamp", "openAt", "since")
    private val BEFORE_OPS = setOf("<", "<=", "before", "lt", "lte", "until")

    /**
     * Locked quest: unlock time from a date condition. Tolerant on purpose: any condition that carries a
     * date or timestamp (ISO string, epoch seconds, epoch milliseconds, in any of the usual field names, or
     * nested one level) counts, whatever its operator is called, unless the operator says "before".
     * Conditions without a date (level, role, other quest, ...) are ignored instead of hiding the timer.
     * AND: the latest date. OR: the earliest date.
     */
    fun dateConditionUnlock(z: JSONObject): Long? {
        val conds = z.optJSONArray("conditions") ?: return null
        val isOr = z.optString("conditionOperator", "and").equals("or", true)
        val dates = mutableListOf<Long>()
        for (i in 0 until conds.length()) {
            val c = conds.optJSONObject(i) ?: continue
            if (c.optBoolean("fulfilled", false)) continue
            val op = c.optString("operator").lowercase().trim()
            if (op in BEFORE_OPS) continue
            conditionTime(c)?.let { dates.add(it) }
        }
        if (dates.isEmpty()) return null
        return if (isOr) dates.min() else dates.max()
    }

    private fun conditionTime(c: JSONObject): Long? {
        val type = c.optString("type").lowercase()
        val dateLike = type.contains("date") || type.contains("time") || type.contains("schedule")
        for (k in COND_TIME_KEYS) {
            val v = c.opt(k) ?: continue
            // A bare number in "value" is only a time when the condition is a date condition (or it is clearly a timestamp).
            if (k == "value" && v is Number && !dateLike && v.toLong() < 1_000_000_000L) continue
            plausible(v)?.let { return it }
            (v as? JSONObject)?.let { o -> for (k2 in COND_TIME_KEYS) plausible(o.opt(k2))?.let { return it } }
        }
        return null
    }

    /** A time between 2020 and 2100, from ISO text, epoch seconds or epoch milliseconds. */
    private fun plausible(v: Any?): Long? {
        val t = parseTime(v) ?: return null
        return t.takeIf { it in 1_577_836_800_000L..4_102_444_800_000L }
    }

    /** Next Zealy reset strictly after [from] (fallback when the API gives no openAt). */
    fun nextReset(recurrence: String, from: Long): Long? {
        if (from <= 0) return null
        val t = ZonedDateTime.ofInstant(Instant.ofEpochMilli(from), ZoneOffset.UTC).truncatedTo(ChronoUnit.DAYS)
        val next = when (recurrence) {
            "daily" -> t.plusDays(1)
            "weekly" -> t.with(TemporalAdjusters.next(DayOfWeek.MONDAY))
            "monthly" -> t.with(TemporalAdjusters.firstDayOfNextMonth())
            else -> return null
        }
        return next.toInstant().toEpochMilli()
    }

    /** Manual (non-Zealy) quests: same rule the original app used, with the user's timezone. */
    private fun manual(q: JSONObject, recurrence: String, tzOffsetMin: Int): Long? {
        if (recurrence == "once") return if (q.optString("status") == "done") null else 0L
        if (q.optInt("locked", 0) == 1) return null
        val last = parseTime(q.opt("lastClaimedAt")) ?: return 0L
        val period = PERIOD[recurrence] ?: DAY
        if (q.optString("resetMode") == "fixed") {
            val parts = q.optString("resetTime", "00:00").split(":").map { it.toIntOrNull() ?: 0 }
            val off = tzOffsetMin * 60_000L
            val u = ZonedDateTime.ofInstant(Instant.ofEpochMilli(last + off), ZoneOffset.UTC)
            var d = u.truncatedTo(ChronoUnit.DAYS).withHour(parts.getOrElse(0) { 0 }).withMinute(parts.getOrElse(1) { 0 })
                .toInstant().toEpochMilli() - off
            while (d <= last) d += DAY
            if (recurrence != "daily") d += period - DAY
            return d
        }
        return last + period
    }

    /** ISO text (with or without zone), or a number in epoch seconds / milliseconds. */
    fun parseTime(v: Any?): Long? = when (v) {
        null, JSONObject.NULL -> null
        is Number -> epoch(v.toDouble())
        is String -> if (v.isBlank()) null else v.trim().toDoubleOrNull()?.let { epoch(it) } ?: try {
            Instant.parse(v.trim()).toEpochMilli()
        } catch (e: Exception) {
            try {
                ZonedDateTime.parse(v.trim()).toInstant().toEpochMilli()
            } catch (e2: Exception) {
                try {
                    java.time.OffsetDateTime.parse(v.trim()).toInstant().toEpochMilli()
                } catch (e3: Exception) {
                    try {
                        java.time.LocalDateTime.parse(v.trim().removeSuffix("Z")).toInstant(ZoneOffset.UTC).toEpochMilli()
                    } catch (e4: Exception) {
                        null
                    }
                }
            }
        }
        else -> null
    }

    /** Seconds (10 digits) or milliseconds (13 digits). */
    private fun epoch(d: Double): Long? {
        if (d <= 0) return null
        val l = d.toLong()
        return if (l < 100_000_000_000L) l * 1000 else l
    }
}
