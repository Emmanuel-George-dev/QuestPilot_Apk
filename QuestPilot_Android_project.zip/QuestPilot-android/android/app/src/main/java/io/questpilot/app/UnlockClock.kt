package io.questpilot.app

import org.json.JSONObject
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters

/**
 * A1 — THE single source of a quest's unlock time.
 *
 * Returns an absolute UTC timestamp in ms (may be in the past = available), 0 for
 * "available now", or null for "locked / unknown". The result never depends on the
 * current time, so a notification scheduled from it can be checked again right before
 * it fires: if the recomputed value differs, the data changed and the alarm is dropped.
 *
 * The web UI never recomputes this: DbStore writes the value to quest.unlockAt on every
 * save, and the countdown / in-app alerts / system notifications all read that.
 *
 * Zealy rules (https://zealy.io/docs/quest-properties/recurrence): daily quests reset at
 * 00:00 UTC, weekly on Mondays 00:00 UTC, monthly on the 1st 00:00 UTC. The questboard
 * reports `opened=false` + `openAt` while a recurring quest is waiting for its reset, and
 * date conditions (https://zealy.io/docs/quest-properties/conditions) lock a quest until a date.
 */
object UnlockClock {
    private const val DAY = 86_400_000L
    private val PERIOD = mapOf("daily" to DAY, "weekly" to 7 * DAY, "monthly" to 30 * DAY)

    fun unlockAt(q: JSONObject, tzOffsetMin: Int): Long? {
        // Debug-build test quests only (they live outside the real data, see DevTools).
        if (q.has("testUnlockAt") && !q.isNull("testUnlockAt")) return if (DevTools.ENABLED) q.getLong("testUnlockAt") else null
        val recurrence = q.optString("recurrence", "once")
        val z = q.optJSONObject("zealy")
        return if (q.optString("source") == "zealy" && z != null) fromZealy(z, recurrence) else manual(q, recurrence, tzOffsetMin)
    }

    private fun fromZealy(z: JSONObject, recurrence: String): Long? {
        val done = z.optBoolean("claimed") || z.optBoolean("completed")
        if (z.optBoolean("locked")) return dateConditionUnlock(z)
        val opened: Boolean? = if (z.has("opened") && !z.isNull("opened")) z.optBoolean("opened") else null
        val openAt = parseTime(z.opt("openAt"))
        if (opened == false) {
            if (openAt != null) return openAt
            if (recurrence != "once") return nextReset(recurrence, z.optLong("syncedAt", 0L))
            return null
        }
        if (recurrence == "once") return if (done) null else 0L
        if (done) return nextReset(recurrence, z.optLong("syncedAt", 0L))
        // failed claim with a cooldown
        val retryAt = parseTime(z.opt("retryAt"))
        if (retryAt != null && z.opt("canRetry") != true) return retryAt
        return 0L
    }

    /** Locked quest: unlock time only if what is still unfulfilled is a "after date" condition. */
    private fun dateConditionUnlock(z: JSONObject): Long? {
        val conds = z.optJSONArray("conditions") ?: return null
        val isOr = z.optString("conditionOperator", "and").equals("or", true)
        val dates = mutableListOf<Long>()
        var otherUnfulfilled = false
        for (i in 0 until conds.length()) {
            val c = conds.optJSONObject(i) ?: continue
            if (c.optBoolean("fulfilled", false)) {
                if (isOr) return null // already unlocked by another branch; the sync will clear `locked`
                continue
            }
            val op = c.optString("operator")
            if (c.optString("type") == "date" && (op == ">" || op == ">=")) {
                parseTime(c.opt("value"))?.let { dates.add(it) } ?: run { otherUnfulfilled = true }
            } else otherUnfulfilled = true
        }
        if (dates.isEmpty()) return null
        return if (isOr) dates.min() else if (otherUnfulfilled) null else dates.max()
    }

    /** Next Zealy reset strictly after [from] (fallback when the API gives no openAt). */
    fun nextReset(recurrence: String, from: Long): Long? {
        if (from <= 0) return null
        val t = ZonedDateTime.ofInstant(Instant.ofEpochMilli(from), ZoneOffset.UTC).truncatedTo(ChronoUnit.DAYS)
        val next = when (recurrence) {
            "daily" -> t.plusDays(1)
            "weekly" -> t.with(TemporalAdjusters.next(DayOfWeek.MONDAY))
            "monthly" -> t.with(TemporalAdjusters.firstDayOfNextMonth())
            else -> return null
        }
        return next.toInstant().toEpochMilli()
    }

    /** Manual (non-Zealy) quests: same rule the original app used, with the user's timezone. */
    private fun manual(q: JSONObject, recurrence: String, tzOffsetMin: Int): Long? {
        if (recurrence == "once") return if (q.optString("status") == "done") null else 0L
        if (q.optInt("locked", 0) == 1) return null
        val last = parseTime(q.opt("lastClaimedAt")) ?: return 0L
        val period = PERIOD[recurrence] ?: DAY
        if (q.optString("resetMode") == "fixed") {
            val parts = q.optString("resetTime", "00:00").split(":").map { it.toIntOrNull() ?: 0 }
            val off = tzOffsetMin * 60_000L
            val u = ZonedDateTime.ofInstant(Instant.ofEpochMilli(last + off), ZoneOffset.UTC)
            var d = u.truncatedTo(ChronoUnit.DAYS).withHour(parts.getOrElse(0) { 0 }).withMinute(parts.getOrElse(1) { 0 })
                .toInstant().toEpochMilli() - off
            while (d <= last) d += DAY
            if (recurrence != "daily") d += period - DAY
            return d
        }
        return last + period
    }

    fun parseTime(v: Any?): Long? = when (v) {
        null, JSONObject.NULL -> null
        is Number -> v.toLong().takeIf { it > 0 }
        is String -> if (v.isBlank()) null else v.toLongOrNull() ?: try {
            Instant.parse(v).toEpochMilli()
        } catch (e: Exception) {
            try {
                ZonedDateTime.parse(v).toInstant().toEpochMilli()
            } catch (e2: Exception) {
                null
            }
        }
        else -> null
    }
}
