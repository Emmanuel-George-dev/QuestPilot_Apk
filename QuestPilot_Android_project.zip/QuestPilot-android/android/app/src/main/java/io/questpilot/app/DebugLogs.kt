package io.questpilot.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Removes anything secret-looking from text before it is stored in a debug log. */
object Redact {
    private val SECRET_KEY = Regex("(?i)token|cookie|auth|secret|password|session|jwt|bearer|apikey|api_key|signature")
    private val JWT = Regex("eyJ[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]+")
    private val LONG_HEX = Regex("\\b[A-Fa-f0-9]{40,}\\b")

    fun text(s: String): String = NetLog.mask(LONG_HEX.replace(JWT.replace(s, "eyJ…(hidden)"), "…(hidden)"))

    /** Deep copy of a JSON value with secret-looking keys replaced by "(hidden)". */
    fun json(v: Any?, depth: Int = 0): Any? = when {
        depth > 6 -> "…"
        v is JSONObject -> JSONObject().also { o -> v.keys().forEach { k -> o.put(k, if (SECRET_KEY.containsMatchIn(k)) "(hidden)" else json(v.opt(k), depth + 1)) } }
        v is JSONArray -> JSONArray().also { a -> for (i in 0 until minOf(v.length(), 50)) a.put(json(v.opt(i), depth + 1)) }
        v is String -> text(v.take(500))
        else -> v
    }

    /** Only the path of a URL (no query string: it can hold ids or tokens). */
    fun path(url: String): String = try {
        val u = android.net.Uri.parse(url)
        (u.host ?: "") + (u.path ?: "")
    } catch (_: Exception) { url.substringBefore('?') }
}

/**
 * A2 debug log: the raw `conditions` JSON of every locked quest whose unlock time came out null, so
 * you can see what Zealy actually sends. Written by the sync, kept in its own file (never in the data),
 * newest first, one row per quest. Secrets are hidden.
 */
object LockedDebug {
    private const val MAX = 150
    private val lock = Any()
    private fun file(ctx: Context) = File(ctx.filesDir, "locked-debug.json")

    fun all(ctx: Context): JSONArray = synchronized(lock) { try { JSONArray(file(ctx).readText()) } catch (_: Exception) { JSONArray() } }

    fun clear(ctx: Context) = synchronized(lock) { file(ctx).delete(); Unit }

    /** [rows] = quests checked in one community sync; ids of quests with a known time drop out of the log. */
    fun record(ctx: Context, sub: String, rows: List<JSONObject>, resolvedZealyIds: Set<String>) = synchronized(lock) {
        val old = all(ctx)
        val keep = JSONArray()
        val fresh = rows.map { it.optString("zealyId") }.toSet()
        for (r in rows) keep.put(r)
        for (i in 0 until old.length()) {
            val o = old.optJSONObject(i) ?: continue
            val zid = o.optString("zealyId")
            if (zid in fresh || zid in resolvedZealyIds) continue
            if (keep.length() >= MAX) break
            keep.put(o)
        }
        file(ctx).writeText(keep.toString())
    }

    fun row(sub: String, communityName: String, zq: JSONObject): JSONObject {
        val extra = JSONObject()
        zq.keys().forEach { k ->
            val v = zq.opt(k)
            if (k in setOf("conditions", "description", "tasks", "rewards", "name", "id")) return@forEach
            if (v is String || v is Number || v is Boolean || v == JSONObject.NULL) extra.put(k, Redact.json(v))
        }
        return JSONObject()
            .put("at", System.currentTimeMillis())
            .put("community", communityName).put("subdomain", sub)
            .put("zealyId", zq.optString("id")).put("title", zq.optString("name"))
            .put("conditionOperator", zq.opt("conditionOperator") ?: JSONObject.NULL)
            .put("conditions", Redact.json(zq.optJSONArray("conditions") ?: JSONArray()))
            .put("questFields", extra)
    }
}

/**
 * Event log for the Debug screen: in-app links, like/repost timer, X requests (path + status only),
 * follow detection, autofill steps, unlock re-checks. Ring buffer kept in memory and in a small file.
 */
object EventLog {
    private const val MAX = 300
    private val lock = Any()
    private var cache: ArrayDeque<JSONObject>? = null
    private var app: Context? = null

    fun init(ctx: Context) { app = ctx.applicationContext }
    private fun file() = app?.let { File(it.filesDir, "event-log.json") }

    private fun load(): ArrayDeque<JSONObject> {
        cache?.let { return it }
        val d = ArrayDeque<JSONObject>()
        try { val a = JSONArray(file()?.readText() ?: "[]"); for (i in 0 until a.length()) a.optJSONObject(i)?.let { d.addLast(it) } } catch (_: Exception) {}
        cache = d
        return d
    }

    fun add(tag: String, msg: String) {
        val e = JSONObject().put("at", System.currentTimeMillis()).put("tag", tag).put("msg", Redact.text(msg).take(600))
        synchronized(lock) {
            val d = load()
            d.addFirst(e)
            while (d.size > MAX) d.removeLast()
            try { file()?.writeText(JSONArray().apply { d.forEach { put(it) } }.toString()) } catch (_: Exception) {}
        }
    }

    fun all(): JSONArray = synchronized(lock) { JSONArray().apply { load().forEach { put(it) } } }
    fun clear() = synchronized(lock) { load().clear(); try { file()?.delete() } catch (_: Exception) {}; Unit }
}
