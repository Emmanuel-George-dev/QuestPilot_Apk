package io.questpilot.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors

/**
 * The app's data, stored in exactly the same shape the web app always used
 * (localStorage key "questpilot-db-v1"): {seq, communities, quests, alerts, submissions, settings}.
 * Only additive fields were introduced (quest.zealy, quest.unlockAt, alert.url, alert.unlockAt, settings.prefs/watchlist/...).
 */
object DbStore {
    const val FILE = "questpilot-db-v1.json"
    private lateinit var app: Context
    private val lock = Any()
    private val bg = Executors.newSingleThreadExecutor()

    fun init(ctx: Context) {
        app = ctx.applicationContext
    }

    private fun file() = File(app.filesDir, FILE)

    fun blank(): JSONObject = JSONObject()
        .put("seq", JSONObject().put("communities", 0).put("quests", 0).put("alerts", 0).put("submissions", 0))
        .put("communities", JSONArray()).put("quests", JSONArray()).put("alerts", JSONArray()).put("submissions", JSONArray())
        .put("settings", JSONObject().put("tgToken", "").put("tgChat", "").put("tzOffset", 0))

    private fun readRaw(): JSONObject = try {
        val f = file()
        if (f.exists()) normalize(JSONObject(f.readText())) else blank()
    } catch (e: Exception) {
        blank()
    }

    private fun normalize(o: JSONObject): JSONObject {
        val b = blank()
        for (k in listOf("communities", "quests", "alerts", "submissions")) if (o.optJSONArray(k) == null) o.put(k, b.getJSONArray(k))
        if (o.optJSONObject("seq") == null) o.put("seq", b.getJSONObject("seq"))
        if (o.optJSONObject("settings") == null) o.put("settings", b.getJSONObject("settings"))
        return o
    }

    fun read(): JSONObject = synchronized(lock) { readRaw() }

    fun load(): Pair<String, Long> = synchronized(lock) { readRaw().toString() to State.rev }

    /** Save from the web UI with optimistic concurrency. */
    fun saveFromUi(json: String, baseRev: Long): Triple<Boolean, String, Long> {
        val result: Triple<Boolean, String, Long>
        val newAlerts: List<JSONObject>
        synchronized(lock) {
            if (baseRev != State.rev) return Triple(false, readRaw().toString(), State.rev)
            val db = normalize(JSONObject(json))
            val before = db.getJSONObject("seq").optInt("alerts")
            postProcess(db)
            newAlerts = alertsAfter(db, before)
            writeRaw(db)
            result = Triple(true, db.toString(), State.rev)
        }
        afterCommit(newAlerts)
        return result
    }

    /** Native-side mutation (sync, monitor, alarms, test mode). */
    fun <T> mutate(block: (JSONObject) -> T): T {
        val out: T
        val newAlerts: List<JSONObject>
        synchronized(lock) {
            val db = readRaw()
            val before = db.getJSONObject("seq").optInt("alerts")
            out = block(db)
            postProcess(db)
            newAlerts = alertsAfter(db, before)
            writeRaw(db)
        }
        afterCommit(newAlerts)
        return out
    }

    private fun writeRaw(db: JSONObject) {
        val tmp = File(app.filesDir, "$FILE.tmp")
        tmp.writeText(db.toString())
        tmp.renameTo(file())
        State.rev = State.rev + 1
    }

    private fun alertsAfter(db: JSONObject, beforeSeq: Int): List<JSONObject> {
        val arr = db.getJSONArray("alerts")
        val out = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) {
            val a = arr.getJSONObject(i)
            if (a.optInt("id") > beforeSeq && a.optInt("push", 1) == 1) out.add(a)
        }
        return out
    }

    /** Runs on every write: recompute unlock times (A1), scan sprint/deadline alerts. */
    /** Test-mode quests live only in DevTools' own debug file. Never in questpilot-db-v1. */
    private fun isTestQuest(q: JSONObject) = q.optString("source") == "test" || (q.has("testUnlockAt") && !q.isNull("testUnlockAt"))

    /** Removes any test quest (and its alerts / saved entries) from the real data. Returns true if anything changed. */
    private fun stripTestData(db: JSONObject): Boolean {
        val quests = db.getJSONArray("quests")
        val gone = mutableSetOf<Int>()
        val keep = JSONArray()
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            if (isTestQuest(q)) gone.add(q.optInt("id")) else keep.put(q)
        }
        val alerts = db.getJSONArray("alerts")
        val keepA = JSONArray()
        var droppedAlerts = false
        for (i in 0 until alerts.length()) {
            val a = alerts.getJSONObject(i)
            val qid = if (a.isNull("questId")) null else a.optInt("questId")
            if ((qid != null && qid in gone) || (qid != null && qid < 0)) droppedAlerts = true else keepA.put(a)
        }
        if (gone.isEmpty() && !droppedAlerts) return false
        db.put("quests", keep)
        db.put("alerts", keepA)
        val subs = db.getJSONArray("submissions")
        val keepS = JSONArray()
        for (i in 0 until subs.length()) subs.getJSONObject(i).let { if (it.optInt("questId") !in gone) keepS.put(it) }
        db.put("submissions", keepS)
        return true
    }

    /** One-time cleanup of test data written by older builds; runs at every start in all builds. */
    fun purgeTestData() {
        val needs = synchronized(lock) { stripTestData(JSONObject(readRaw().toString())) }
        if (needs) mutate { stripTestData(it) }
    }

    private fun postProcess(db: JSONObject) {
        stripTestData(db) // guard: nothing test-related is ever saved to the real data
        val tz = db.getJSONObject("settings").optInt("tzOffset", 0)
        val quests = db.getJSONArray("quests")
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            val t = UnlockClock.unlockAt(q, tz)
            q.put("unlockAt", t ?: JSONObject.NULL)
        }
        AlertScanner.scan(db)
    }

    private fun afterCommit(newAlerts: List<JSONObject>) {
        val rev = State.rev
        bg.execute {
            try {
                AlarmScheduler.rescheduleAll(app)
            } catch (_: Exception) {
            }
            for (a in newAlerts) Notifications.postAlert(app, a)
            if (newAlerts.isNotEmpty()) Telegram.sendAlerts(app, newAlerts)
        }
        QuestPilotPlugin.emitDbChanged(rev)
    }

    // ---------- helpers shared by native code ----------
    fun nextId(db: JSONObject, table: String): Int {
        val seq = db.getJSONObject("seq")
        val n = seq.optInt(table) + 1
        seq.put(table, n)
        return n
    }

    fun findById(arr: JSONArray, id: Int): JSONObject? {
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optInt("id") == id) return arr.getJSONObject(i)
        return null
    }

    fun quest(db: JSONObject, id: Int) = findById(db.getJSONArray("quests"), id)
    fun community(db: JSONObject, id: Int) = findById(db.getJSONArray("communities"), id)

    fun prefs(db: JSONObject): JSONObject = db.getJSONObject("settings").optJSONObject("prefs") ?: JSONObject()
    fun pref(db: JSONObject, k: String, def: Boolean) = prefs(db).optBoolean(k, def)

    fun nowIso(): String = Instant.now().toString()

    private val clock = DateTimeFormatter.ofPattern("EEE HH:mm")
    fun localClock(ms: Long): String = clock.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))

    /** Adds an alert (deduped). push=false when the caller posts its own notification. */
    fun addAlert(
        db: JSONObject, kind: String, title: String, body: String, questId: Int?, communityId: Int?,
        dedupeKey: String, url: String? = null, unlockAt: Long? = null, push: Boolean = true,
    ): JSONObject? {
        val alerts = db.getJSONArray("alerts")
        for (i in 0 until alerts.length()) if (alerts.getJSONObject(i).optString("dedupeKey") == dedupeKey) return null
        val a = JSONObject()
            .put("id", nextId(db, "alerts")).put("kind", kind).put("title", title).put("body", body)
            .put("questId", questId ?: JSONObject.NULL).put("communityId", communityId ?: JSONObject.NULL)
            .put("dedupeKey", dedupeKey).put("createdAt", nowIso()).put("read", 0)
            .put("url", url ?: JSONObject.NULL).put("unlockAt", unlockAt ?: JSONObject.NULL)
            .put("push", if (push) 1 else 0)
        val list = JSONArray().put(a)
        for (i in 0 until minOf(alerts.length(), 199)) list.put(alerts.get(i))
        db.put("alerts", list)
        return a
    }
}

object AlertScanner {
    /** Port of the original scanAlerts() for sprint ends and limited-task deadlines (24 h ahead). */
    fun scan(db: JSONObject) {
        val now = System.currentTimeMillis()
        val comms = db.getJSONArray("communities")
        for (i in 0 until comms.length()) {
            val c = comms.getJSONObject(i)
            if (c.optInt("notify", 1) != 1) continue
            val end = UnlockClock.parseTime(c.opt("sprintEndsAt")) ?: continue
            if (end > now && end - now <= 86_400_000L) {
                DbStore.addAlert(
                    db, "sprint", "${c.optString("name")}: sprint ends soon",
                    "${c.optString("sprintName").ifEmpty { "Sprint" }} ends ${DbStore.localClock(end)}",
                    null, c.optInt("id"), "sprint-24h-${c.optInt("id")}-${c.opt("sprintEndsAt")}",
                    "https://zealy.io/cw/${c.optString("subdomain")}/leaderboard",
                )
            }
        }
        val quests = db.getJSONArray("quests")
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            val c = DbStore.community(db, q.optInt("communityId")) ?: continue
            if (c.optInt("notify", 1) != 1 || q.optString("status") == "done") continue
            val dl = UnlockClock.parseTime(q.opt("deadline")) ?: continue
            if (dl > now && dl - now <= 86_400_000L) {
                DbStore.addAlert(
                    db, "deadline", q.optString("title"), "Deadline ${DbStore.localClock(dl)} · ${c.optString("name")}",
                    q.optInt("id"), c.optInt("id"), "deadline-${q.optInt("id")}-${q.opt("deadline")}", q.optString("url").ifEmpty { null },
                )
            }
        }
    }
}
