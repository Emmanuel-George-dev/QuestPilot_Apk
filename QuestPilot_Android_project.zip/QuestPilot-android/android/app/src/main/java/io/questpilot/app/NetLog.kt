package io.questpilot.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Request log for the debug-only "Connection log" screen. Records nothing in release builds
 * (DevTools.ENABLED is a constant false there). Cookie values and tokens are never stored:
 * only cookie names, and anything that looks like a JWT in a response is masked.
 */
object NetLog {
    private const val MAX = 80
    private val entries = ArrayDeque<JSONObject>()

    private val JWT = Regex("eyJ[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]+")
    fun mask(s: String) = JWT.replace(s, "eyJ…(hidden)")

    fun record(source: String, method: String, url: String, status: Int, snippet: String, cookieNames: List<String>, extra: String? = null) {
        if (!DevTools.ENABLED) return
        val e = JSONObject()
            .put("at", System.currentTimeMillis())
            .put("source", source)
            .put("method", method)
            .put("url", url)
            .put("status", status)
            .put("snippet", mask(snippet.take(300)))
            .put("cookies", cookieNames.joinToString(", ") { "$it=…" })
            .put("extra", extra ?: JSONObject.NULL)
        synchronized(entries) {
            entries.addFirst(e)
            while (entries.size > MAX) entries.removeLast()
        }
    }

    fun all(): JSONArray = synchronized(entries) { JSONArray().apply { entries.forEach { put(it) } } }
    fun clear() = synchronized(entries) { entries.clear() }
}
