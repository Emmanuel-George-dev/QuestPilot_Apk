package io.questpilot.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Request log for the debug-only "Connection log" screen. Records nothing in release builds
 * (DevTools.ENABLED is a constant false there). Cookie values and tokens are never stored:
 * only cookie names, and anything that looks like a JWT in a response is masked.
 */
object NetLog {
    private const val MAX = 80
    private val entries = ArrayDeque<JSONObject>()

    private val JWT = Regex("eyJ[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]{8,}\\.[A-Za-z0-9_-]+")
    /** "field": value for sensitive field names (string, number, array or a value cut off by the 300-char snippet). */
    private val FIELD = Regex(
        "(\"[A-Za-z_]*(?:authentification|authentication|token|secret|email|password|passwd|address|addresses|wallet|ethWallet|solWallet|phone|apiKey|privateKey|seed|mnemonic)[A-Za-z_]*\")\\s*:\\s*" +
            "(\"(?:[^\"\\\\]|\\\\.)*\"?|\\[[^\\]]*\\]?|\\{[^}]*\\}?|[^,}\\]]*)",
        RegexOption.IGNORE_CASE,
    )
    private val EMAIL = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val HEX_ADDR = Regex("0x[A-Fa-f0-9]{16,}")
    /** Base58 / Base64-ish wallet keys (Solana, Bitcoin, Tron, ...): 32+ chars, letters and digits mixed. */
    private val LONG_KEY = Regex("(?<![A-Za-z0-9/._-])(?=[A-Za-z0-9]*[0-9])(?=[A-Za-z0-9]*[A-Za-z])[A-Za-z0-9]{32,}(?![A-Za-z0-9/._-])")

    private fun short(v: String) = if (v.length <= 12) "(hidden)" else v.take(6) + "…" + v.takeLast(4)

    /**
     * v2.4.2: hides tokens (JWT), values of authentification / token / secret / email / password / address /
     * wallet fields, e-mail addresses and wallet addresses (first 6 and last 4 characters kept).
     * Cookie values are never logged at all (only cookie names).
     */
    fun mask(s: String): String {
        var t = JWT.replace(s, "eyJ…(hidden)")
        t = FIELD.replace(t) { m -> m.groupValues[1] + ":\"(hidden)\"" }
        t = EMAIL.replace(t, "(email hidden)")
        t = HEX_ADDR.replace(t) { short(it.value) }
        t = LONG_KEY.replace(t) { short(it.value) }
        return t
    }

    fun record(source: String, method: String, url: String, status: Int, snippet: String, cookieNames: List<String>, extra: String? = null) {
        if (!DevTools.ENABLED) return
        val e = JSONObject()
            .put("at", System.currentTimeMillis())
            .put("source", source)
            .put("method", method)
            .put("url", url)
            .put("status", status)
            .put("snippet", mask(snippet.take(300)))
            .put("cookies", cookieNames.joinToString(", ") { "$it=…" })
            .put("extra", extra ?: JSONObject.NULL)
        synchronized(entries) {
            entries.addFirst(e)
            while (entries.size > MAX) entries.removeLast()
        }
    }

    fun all(): JSONArray = synchronized(entries) { JSONArray().apply { entries.forEach { put(it) } } }
    fun clear() = synchronized(entries) { entries.clear() }
}
