package io.questpilot.app

import android.content.Context
import android.content.SharedPreferences

/** Small runtime state (not user data). User data lives in DbStore in the app's original format. */
object State {
    private lateinit var sp: SharedPreferences
    fun init(ctx: Context) {
        if (!::sp.isInitialized) sp = ctx.applicationContext.getSharedPreferences("qp_state", Context.MODE_PRIVATE)
    }

    private fun l(k: String) = sp.getLong(k, 0L)
    private fun setL(k: String, v: Long) = sp.edit().putLong(k, v).apply()

    var monitoringEnabled: Boolean
        get() = sp.getBoolean("monitoringEnabled", true)
        set(v) = sp.edit().putBoolean("monitoringEnabled", v).apply()
    var rev: Long
        get() = l("rev")
        set(v) = setL("rev", v)
    var lastSyncAt: Long
        get() = l("lastSyncAt")
        set(v) = setL("lastSyncAt", v)
    var lastFullSyncAt: Long
        get() = l("lastFullSyncAt")
        set(v) = setL("lastFullSyncAt", v)
    var lastQuestPollAt: Long
        get() = l("lastQuestPollAt")
        set(v) = setL("lastQuestPollAt", v)
    var lastMessagePollAt: Long
        get() = l("lastMessagePollAt")
        set(v) = setL("lastMessagePollAt", v)
    var pausedUntil: Long
        get() = l("pausedUntil")
        set(v) = setL("pausedUntil", v)
    var pauseReason: String?
        get() = sp.getString("pauseReason", null)
        set(v) = sp.edit().putString("pauseReason", v).apply()
    /** number of consecutive 429/403 pauses; wait = 5 min * 2^(n-1) */
    var backoffLevel: Int
        get() = sp.getInt("backoffLevel", 0)
        set(v) = sp.edit().putInt("backoffLevel", v).apply()
    /** consecutive 401/403 responses */
    var authFailures: Int
        get() = sp.getInt("authFailures", 0)
        set(v) = sp.edit().putInt("authFailures", v).apply()
    var sessionExpired: Boolean
        get() = sp.getBoolean("sessionExpired", false)
        set(v) = sp.edit().putBoolean("sessionExpired", v).apply()
    var userId: String?
        get() = sp.getString("userId", null)
        set(v) = sp.edit().putString("userId", v).apply()
    var userName: String?
        get() = sp.getString("userName", null)
        set(v) = sp.edit().putString("userName", v).apply()
    @Volatile var syncing = false
}
