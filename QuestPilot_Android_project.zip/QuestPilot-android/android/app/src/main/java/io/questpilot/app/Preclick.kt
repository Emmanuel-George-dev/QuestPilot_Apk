package io.questpilot.app

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLDecoder

/**
 * v2.4.3 pre-click for locked tasks.
 *
 *  Part 1  ZealySync.docLinks / xLinks: Like / Repost / Follow links from the quest description already in
 *          the questboard response (no extra Zealy request). [RawQuests] keeps the raw tasks + description of
 *          every quest with an X task, for Debug.
 *  Part 2  The buttons open the X link in the in-app overlay (ClaimActivity mode "preclick"); when it closes the
 *          quest's `preclick.<kind>` entry is saved (done + time).
 *  Part 3  Discovery (Debug): [EngagedLab] lists Zealy's `*-engaged*` cookies, records every write Zealy's page
 *          makes to them (document.cookie / cookieStore hook: the only place the attributes are visible, Android's
 *          CookieManager returns name=value only), the overlay open/close times, and matches the cookie ids
 *          against the ids the app has. [ZealyRecorder] logs the Zealy page's own quest requests (switch, off).
 *  Part 4  [EngagedLab.write] replays exactly a write Zealy's page was SEEN making for the same button kind and the
 *          same previous value, with the observed name format, value and attributes, and the id taken from the same
 *          source (quest id / task id) for the quest you pre-click. Nothing is written when that has not been
 *          observed or the id is not available: the reason is shown instead. Never automatic, never in bulk.
 */
object RawQuests {
    private const val MAX = 300
    private val lock = Any()
    private fun file(ctx: Context) = File(ctx.filesDir, "raw-quests.json")

    fun all(ctx: Context): JSONObject = synchronized(lock) { try { JSONObject(file(ctx).readText()) } catch (_: Exception) { JSONObject() } }

    fun putAll(ctx: Context, rows: Map<String, JSONObject>) = synchronized(lock) {
        if (rows.isEmpty()) return@synchronized
        val o = all(ctx)
        rows.forEach { (k, v) -> o.put(k, v) }
        if (o.length() > MAX) {
            val keys = o.keys().asSequence().toList().sortedBy { o.optJSONObject(it)?.optLong("at") ?: 0L }
            keys.take(o.length() - MAX).forEach { o.remove(it) }
        }
        file(ctx).writeText(o.toString())
    }

    /** Every uuid-looking string inside a raw quest (for "Match ids"). */
    fun uuids(v: Any?, out: MutableSet<String> = mutableSetOf(), depth: Int = 0): MutableSet<String> {
        if (depth > 12) return out
        when (v) {
            is JSONObject -> v.keys().forEach { uuids(v.opt(it), out, depth + 1) }
            is JSONArray -> for (i in 0 until v.length()) uuids(v.opt(i), out, depth + 1)
            is String -> UUID.findAll(v).forEach { out.add(it.value.lowercase()) }
        }
        return out
    }

    val UUID = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
}

/** Task ids the Zealy page itself received for a quest (seen by the request recorder hook). questZealyId -> tasks. */
object TaskIds {
    private val lock = Any()
    private fun file(ctx: Context) = File(ctx.filesDir, "task-ids.json")
    fun all(ctx: Context): JSONObject = synchronized(lock) { try { JSONObject(file(ctx).readText()) } catch (_: Exception) { JSONObject() } }

    fun put(ctx: Context, questId: String, tasks: JSONArray, source: String = "page") = synchronized(lock) {
        val o = all(ctx)
        o.put(questId, JSONObject().put("at", System.currentTimeMillis()).put("tasks", tasks).put("source", source))
        if (o.length() > 400) o.keys().asSequence().toList().sortedBy { o.optJSONObject(it)?.optLong("at") ?: 0L }.take(o.length() - 400).forEach { o.remove(it) }
        file(ctx).writeText(o.toString())
    }

    /** The task-detail request failed: remembered so it is retried only after a while. Saved tasks are kept. */
    fun markError(ctx: Context, questId: String, code: Int) = synchronized(lock) {
        val o = all(ctx)
        val e = o.optJSONObject(questId) ?: JSONObject().put("tasks", JSONArray())
        e.put("errorAt", System.currentTimeMillis()).put("error", code)
        o.put(questId, e)
        file(ctx).writeText(o.toString())
    }

    fun entry(ctx: Context, questId: String?): JSONObject? = questId?.let { all(ctx).optJSONObject(it) }

    fun tasks(ctx: Context, questId: String?): JSONArray? = questId?.let { all(ctx).optJSONObject(it)?.optJSONArray("tasks") }

    /** The id of the task of [type] in [questId] (exact type match), null when the app doesn't have it. */
    fun idOf(ctx: Context, questId: String?, type: String?): String? {
        val t = tasks(ctx, questId) ?: return null
        val matches = (0 until t.length()).mapNotNull { t.optJSONObject(it) }.filter { type == null || it.optString("type") == type }
        return if (matches.size == 1) matches[0].optString("id").ifEmpty { null } else null // never guess between several
    }
}

/** Part 3: the Zealy page's own quest requests (path, status, first 2 KB masked). Debug switch, off by default. */
object ZealyRecorder {
    private const val MAX = 60
    private val lock = Any()
    private fun file(ctx: Context) = File(ctx.filesDir, "zealy-recorder.json")
    fun all(ctx: Context): JSONArray = synchronized(lock) { try { JSONArray(file(ctx).readText()) } catch (_: Exception) { JSONArray() } }
    fun clear(ctx: Context) = synchronized(lock) { file(ctx).delete(); Unit }
    fun add(ctx: Context, pathStatus: String, snippet: String) = synchronized(lock) {
        val a = all(ctx)
        val out = JSONArray().put(JSONObject().put("at", System.currentTimeMillis()).put("request", pathStatus.take(300)).put("body", NetLog.mask(snippet.take(2048))))
        for (i in 0 until minOf(a.length(), MAX - 1)) out.put(a.get(i))
        file(ctx).writeText(out.toString())
    }
}

object EngagedLab {
    private const val PREFS = "qp_engaged"
    private val lock = Any()
    /**
     * Zealy's per-task clicked flags: "*-engaged*" names, and (v2.4.3 visit links etc.) any cookie whose name ends
     * with ":<uuid>" / "%3A<uuid>" (an id-keyed flag). Plain session / analytics cookies don't match.
     */
    private val ENGAGED = Regex("(?i)engaged|(?:%3A|:)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$|^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
    /** Name + the uuid at its end: "tweet-react-engaged%3A<uuid>" or "...:<uuid>". */
    private val NAME_ID = Regex("^(.*?(?:%3A|:))([0-9a-fA-F-]{8,})$")

    fun isEngaged(name: String) = ENGAGED.containsMatchIn(name)

    private fun dir(ctx: Context) = ctx.filesDir
    private fun readArr(ctx: Context, f: String) = try { JSONArray(File(dir(ctx), f).readText()) } catch (_: Exception) { JSONArray() }
    private fun writeArr(ctx: Context, f: String, a: JSONArray, max: Int) {
        val out = JSONArray(); for (i in 0 until minOf(a.length(), max)) out.put(a.get(i)); File(dir(ctx), f).writeText(out.toString())
    }
    private fun prepend(ctx: Context, f: String, e: JSONObject, max: Int) = synchronized(lock) {
        val a = readArr(ctx, f); val out = JSONArray().put(e); for (i in 0 until a.length()) out.put(a.get(i)); writeArr(ctx, f, out, max)
    }

    // ------------------------------------------------------------------ jar

    /** Every *-engaged* cookie visible to zealy.io in the WebView jar: name -> value. */
    fun jar(): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        val cm = CookieManager.getInstance()
        for (u in listOf("https://zealy.io", "https://www.zealy.io")) {
            cm.getCookie(u)?.split(";")?.forEach { kv ->
                val i = kv.indexOf('=')
                if (i > 0) {
                    val n = kv.substring(0, i).trim()
                    if (isEngaged(n) && !out.containsKey(n)) out[n] = kv.substring(i + 1).trim()
                }
            }
        }
        return out
    }

    fun decode(n: String) = try { URLDecoder.decode(n, "UTF-8") } catch (_: Exception) { n }
    fun idOf(name: String): String? = NAME_ID.find(name)?.groupValues?.get(2)
    fun prefixOf(name: String): String? = NAME_ID.find(name)?.groupValues?.get(1)

    // ------------------------------------------------------------------ encrypted copy (survives restart + logout)

    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun stored(ctx: Context): JSONObject = sp(ctx).getString("all", null)?.let { SessionStoreCrypto.dec(it) }?.let { try { JSONObject(it) } catch (_: Exception) { null } } ?: JSONObject()
    private fun saveStored(ctx: Context, o: JSONObject) = sp(ctx).edit().putString("all", SessionStoreCrypto.enc(o.toString())).apply()

    /** Copies the jar's *-engaged* cookies into encrypted storage (with the attributes last seen for that name). */
    fun saveFromJar(ctx: Context) = synchronized(lock) {
        val j = jar()
        if (j.isEmpty()) return@synchronized
        val o = stored(ctx)
        var changed = false
        for ((n, v) in j) {
            val e = o.optJSONObject(n) ?: JSONObject().also { o.put(n, it) }
            if (e.optString("value") != v) { e.put("value", v).put("at", System.currentTimeMillis()); changed = true }
        }
        if (changed) saveStored(ctx, o)
    }

    /** Puts back saved *-engaged* cookies that are missing from the jar (cold start, Zealy logout, ...). */
    fun restore(ctx: Context) = synchronized(lock) {
        val o = stored(ctx)
        if (o.length() == 0) return@synchronized
        val have = jar()
        val cm = CookieManager.getInstance()
        var put = 0
        val now = System.currentTimeMillis()
        for (n in o.keys().asSequence().toList()) {
            val e = o.optJSONObject(n) ?: continue
            if (now - e.optLong("at") > 45L * 86_400_000L) { o.remove(n); continue } // old flags are dropped
            if (have.containsKey(n)) continue
            cm.setCookie("https://zealy.io", "$n=${e.optString("value")}; " + e.optString("attrs", "Path=/").ifEmpty { "Path=/" })
            put++
        }
        if (put > 0) { cm.flush(); EventLog.add("engaged", "re-injected $put saved engaged cookie(s)") }
    }

    // ------------------------------------------------------------------ Part 3: writes seen on Zealy's page

    /** Overlay opened / closed (kind, X url, the Zealy page it came from). */
    fun overlayEvent(ctx: Context, what: String, kind: String, url: String, zealyPage: String?) {
        prepend(ctx, "engaged-overlay.json", JSONObject().put("at", System.currentTimeMillis()).put("what", what).put("kind", kind)
            .put("url", Redact.path(url)).put("page", zealyPage?.let { Redact.path(it) } ?: JSONObject.NULL), 60)
    }

    fun overlayEvents(ctx: Context) = readArr(ctx, "engaged-overlay.json")
    fun writes(ctx: Context) = readArr(ctx, "engaged-writes.json")
    fun observations(ctx: Context) = readArr(ctx, "engaged-learned.json")

    /** Quest id in a Zealy page URL: /questboard/<category>/<quest> or /quests/<quest>. */
    fun questIdFromPage(url: String?): Pair<String?, String?> {
        val segs = try { Uri.parse(url ?: "").pathSegments } catch (_: Exception) { emptyList<String>() }
        val qb = segs.indexOf("questboard")
        if (qb >= 0 && segs.size > qb + 2) return segs[qb + 2] to segs[qb + 1]
        val qi = segs.indexOf("quests")
        if (qi >= 0 && segs.size > qi + 1) return segs[qi + 1] to null
        return null to null
    }

    /** "name=value; a=b; ..." -> (name, value, attributes with Expires turned into a Max-Age duration). */
    private fun parseSet(set: String, at: Long): Triple<String, String, String> {
        val parts = set.split(";").map { it.trim() }
        val nv = parts.firstOrNull() ?: ""
        val i = nv.indexOf('=')
        val name = if (i > 0) nv.substring(0, i).trim() else nv
        val value = if (i > 0) nv.substring(i + 1) else ""
        val attrs = parts.drop(1).filter { it.isNotEmpty() }.map { a ->
            if (a.lowercase().startsWith("expires=")) {
                val t = try { java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", java.util.Locale.US).parse(a.substringAfter('='))?.time } catch (_: Exception) { null }
                if (t != null) "Max-Age=${maxOf(0L, (t - at) / 1000)}" else a
            } else a
        }
        return Triple(name, value, attrs.joinToString("; "))
    }

    /**
     * A write Zealy's own page made (document.cookie or cookieStore). Records it, and when it can be tied to the
     * Like / Repost / Follow overlay that opened within 30 s and to an id source, learns that transition.
     */
    fun onPageWrite(ctx: Context, raw: String, via: String, pageUrl: String) {
        val now = System.currentTimeMillis()
        val (name, value, attrs) = if (via == "cookieStore") {
            val o = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
            val a = mutableListOf<String>()
            o.optString("path").ifEmpty { null }?.let { a.add("Path=$it") }
            o.optString("domain").ifEmpty { null }?.let { a.add("Domain=$it") }
            if (o.has("expires") && !o.isNull("expires")) a.add("Max-Age=${maxOf(0L, (o.optLong("expires") - now) / 1000)}")
            o.optString("sameSite").ifEmpty { null }?.let { a.add("SameSite=$it") }
            Triple(o.optString("name"), o.optString("value"), a.joinToString("; "))
        } else parseSet(raw, now)
        if (!isEngaged(name)) return
        val old = jar()[name] // the hook runs BEFORE the write reaches the jar
        val (pageQuest, pageCat) = questIdFromPage(pageUrl)
        val uuid = idOf(name)
        val removed = attrs.contains("Max-Age=0", true) || (attrs.contains("max-age=-", true))
        // kind: the Like / Repost / Follow overlay opened closest to this write (within 30 s)
        val ev = overlayEvents(ctx)
        var kind = "unknown"
        var best = Long.MAX_VALUE
        for (i in 0 until ev.length()) {
            val e = ev.getJSONObject(i)
            if (e.optString("what") != "open") continue
            val d = kotlin.math.abs(e.optLong("at") - now)
            if (d < 30_000L && d < best && e.optString("kind") in setOf("like", "repost", "follow", "visit")) { best = d; kind = e.optString("kind") }
        }
        val idSource = idSource(ctx, uuid, pageQuest, pageCat)
        val w = JSONObject().put("at", now).put("via", via).put("raw", raw.take(600)).put("name", decode(name)).put("encodedName", name)
            .put("uuid", uuid ?: JSONObject.NULL).put("oldValue", old ?: JSONObject.NULL).put("newValue", value).put("attributes", attrs)
            .put("page", Redact.path(pageUrl)).put("pageQuestId", pageQuest ?: JSONObject.NULL).put("kind", kind).put("idSource", idSource)
        prepend(ctx, "engaged-writes.json", w, 80)
        EventLog.add("engaged", "Zealy wrote ${decode(name)}=$value ($attrs) kind=$kind id=$idSource")
        // encrypted copy keeps the attributes for re-injection; a deletion removes it
        synchronized(lock) {
            val o = stored(ctx)
            if (removed) o.remove(name) else o.put(name, JSONObject().put("value", value).put("attrs", attrs).put("at", now))
            saveStored(ctx, o)
        }
        if (!removed && kind != "unknown" && idSource != "unknown" && prefixOf(name) != null) {
            val obs = JSONObject().put("at", now).put("kind", kind).put("prefix", prefixOf(name)).put("idSource", idSource)
                .put("oldValue", old ?: JSONObject.NULL).put("newValue", value.replace(uuid ?: "\u0000", "{id}")).put("attrs", attrs)
                .put("sampleName", name)
            prepend(ctx, "engaged-learned.json", obs, 40)
        }
    }

    /**
     * localStorage / sessionStorage writes by Zealy's page with an id-like or "engaged / visit / clicked" key.
     * Recorded for discovery only (shown in Debug), never replayed: the app can't write Zealy's storage safely.
     */
    fun onStorageWrite(ctx: Context, key: String, value: String, pageUrl: String) {
        val (pageQuest, pageCat) = questIdFromPage(pageUrl)
        val uuid = RawQuests.UUID.find(key)?.value
        val ev = overlayEvents(ctx)
        val now = System.currentTimeMillis()
        var kind = "unknown"
        for (i in 0 until ev.length()) {
            val e = ev.getJSONObject(i)
            if (e.optString("what") == "open" && kotlin.math.abs(e.optLong("at") - now) < 30_000L) { kind = e.optString("kind"); break }
        }
        prepend(ctx, "engaged-writes.json", JSONObject().put("at", now).put("via", "storage").put("name", key).put("encodedName", key)
            .put("uuid", uuid ?: JSONObject.NULL).put("newValue", NetLog.mask(value)).put("page", Redact.path(pageUrl))
            .put("pageQuestId", pageQuest ?: JSONObject.NULL).put("kind", kind).put("idSource", idSource(ctx, uuid, pageQuest, pageCat)), 80)
    }

    /** Where a cookie uuid comes from: questId | categoryId | taskId:<type> | unknown. */
    fun idSource(ctx: Context, uuid: String?, pageQuest: String?, pageCat: String?): String {
        val u = uuid?.lowercase() ?: return "unknown"
        if (pageQuest != null && u == pageQuest.lowercase()) return "questId"
        if (pageCat != null && u == pageCat.lowercase()) return "categoryId"
        val t = TaskIds.tasks(ctx, pageQuest)
        if (t != null) for (i in 0 until t.length()) {
            val o = t.optJSONObject(i) ?: continue
            if (o.optString("id").lowercase() == u) return "taskId:${o.optString("type")}"
        }
        return "unknown"
    }

    /** Debug "Match ids": each engaged cookie uuid against quest ids, category ids, captured task ids and raw data. */
    fun matchIds(ctx: Context): JSONArray {
        val db = DbStore.read()
        val quests = db.getJSONArray("quests")
        val raw = RawQuests.all(ctx)
        val tasks = TaskIds.all(ctx)
        val out = JSONArray()
        for ((n, _) in jar()) {
            val u = idOf(n)?.lowercase()
            val hits = JSONArray()
            if (u != null) {
                for (i in 0 until quests.length()) {
                    val q = quests.getJSONObject(i)
                    if (q.optString("zealyId").lowercase() == u) hits.put("quest zealyId: ${q.optString("title")}")
                    if (q.optString("categoryId").lowercase() == u) hits.put("category id of: ${q.optString("title")}")
                }
                tasks.keys().forEach { qid ->
                    val t = tasks.optJSONObject(qid)?.optJSONArray("tasks") ?: return@forEach
                    for (i in 0 until t.length()) if (t.optJSONObject(i)?.optString("id")?.lowercase() == u) hits.put("task id (${t.optJSONObject(i)?.optString("type")}) of quest $qid")
                }
                raw.keys().forEach { zid -> if (u in RawQuests.uuids(raw.opt(zid))) hits.put("inside raw tasks/description of ${raw.optJSONObject(zid)?.optString("title") ?: zid}") }
            }
            out.put(JSONObject().put("name", decode(n)).put("uuid", u ?: JSONObject.NULL).put("matches", hits))
        }
        return out
    }

    /** Debug watcher rows: name, uuid, value, and the attributes of the last write seen (the jar has none). */
    fun watcher(ctx: Context): JSONArray {
        val st = stored(ctx)
        val ws = writes(ctx)
        val out = JSONArray()
        for ((n, v) in jar()) {
            var last: JSONObject? = null
            for (i in 0 until ws.length()) { val w = ws.getJSONObject(i); if (w.optString("encodedName") == n) { last = w; break } }
            val attrs = last?.optString("attributes") ?: st.optJSONObject(n)?.optString("attrs")
            out.put(JSONObject().put("name", decode(n)).put("encodedName", n).put("uuid", idOf(n) ?: JSONObject.NULL).put("value", v)
                .put("attributes", attrs?.ifEmpty { null } ?: "not visible: no write by Zealy's page seen yet (Android shows name=value only)")
                .put("seenAt", last?.optLong("at") ?: JSONObject.NULL))
        }
        return out
    }

    // ------------------------------------------------------------------ Part 4

    /**
     * v2.4.4: writes Zealy's clicked flag exactly the way Zealy's quest page does (read from Zealy's web code):
     *   tweetReact     cookie "tweet-react-engaged:<taskId>"    value JSON list of done actions, e.g. ["like","retweet"]
     *   twitterFollow  cookie "twitter-follow-engaged:<taskId>" value "1"
     *   visitLink      cookie "<taskId>"                        value the task's link
     * Names / values encoded like js-cookie 2 (the library Zealy uses), path=/. Zealy keeps them 1 day; here they
     * last until 1 day after the unlock so a flag set early is still there when the task opens.
     * The task id comes only from Zealy's quest data (task details); it is never guessed.
     * Returns (flag, note): written | already | none | unavailable.
     */
    fun write(ctx: Context, q: JSONObject, kindKey: String, url: String?): Pair<String, String> {
        val kind = kindKey.substringBefore('-') // "follow-2" -> "follow"
        val zid = q.optString("zealyId").ifEmpty { null }
            ?: return "unavailable" to "Cannot pre-click this task: Zealy id not available while locked"
        val tasks = TaskIds.tasks(ctx, zid)
        val list = (0 until (tasks?.length() ?: 0)).mapNotNull { tasks!!.optJSONObject(it) }.filter { it.optString("id").isNotEmpty() }
        fun settingsOf(t: JSONObject): JSONObject = when (val s = t.opt("settings")) {
            is JSONObject -> s
            is String -> try { JSONObject(s) } catch (_: Exception) { JSONObject() }
            else -> JSONObject()
        }
        val u = try { url?.let { Uri.parse(it) } } catch (_: Exception) { null }
        fun pick(type: String, match: (JSONObject) -> Boolean): JSONObject? {
            val c = list.filter { it.optString("type") == type }
            if (c.size == 1) return c[0]
            return c.filter { match(settingsOf(it)) }.singleOrNull() // several: only an exact match, never a guess
        }
        val now = System.currentTimeMillis()
        val unlock = q.optLong("unlockAt", 0L)
        val expires = maxOf(now, unlock) + 86_400_000L
        val noId = "unavailable" to "Cannot pre-click this task: Zealy id not available while locked. QuestPilot loads it with the next sync (or tap Find link)."
        return when (kind) {
            "like", "repost" -> {
                val action = if (kind == "like") "like" else "retweet"
                val tweetId = u?.getQueryParameter("tweet_id") ?: u?.pathSegments?.let { s -> s.indexOf("status").takeIf { it >= 0 }?.let { s.getOrNull(it + 1) } }
                val t = pick("tweetReact") { s -> tweetId != null && s.optString("tweetUrl").contains("/status/$tweetId") } ?: return noId
                val acts = settingsOf(t).optJSONArray("actions")
                if (acts != null && acts.length() > 0 && (0 until acts.length()).none { acts.optString(it) == action })
                    return "none" to "This task doesn't ask for ${if (action == "like") "a like" else "a repost"}: nothing to mark on Zealy."
                val name = "tweet-react-engaged:" + t.optString("id")
                val cur = jarDecoded(name)?.let { try { JSONArray(it) } catch (_: Exception) { null } } ?: JSONArray()
                val have = (0 until cur.length()).map { cur.optString(it) }.filter { it == "like" || it == "retweet" }.toMutableList()
                if (action in have) return "already" to "Already marked on Zealy."
                have.add(action)
                put(ctx, name, JSONArray(have).toString(), expires, q)
                "written" to "Marked ${if (action == "like") "Like" else "Repost"} on Zealy."
            }
            "follow" -> {
                val handle = (u?.getQueryParameter("screen_name") ?: u?.pathSegments?.firstOrNull())?.lowercase()
                val t = pick("twitterFollow") { s -> handle != null && s.optString("username").trim().removePrefix("@").lowercase() == handle } ?: return noId
                val name = "twitter-follow-engaged:" + t.optString("id")
                if (jarDecoded(name) == "1") return "already" to "Already marked on Zealy."
                put(ctx, name, "1", expires, q)
                "written" to "Marked Follow on Zealy."
            }
            "visit" -> {
                fun norm(x: String) = x.trim().trimEnd('/').lowercase()
                val t = pick("visitLink") { s -> url != null && norm(s.optString("linkUrl")) == norm(url) } ?: return noId
                val link = settingsOf(t).optString("linkUrl").ifEmpty { url ?: "" }
                val name = t.optString("id")
                if (jarDecoded(name) == link) return "already" to "Already marked on Zealy."
                put(ctx, name, link, expires, q)
                "written" to "Marked the visit on Zealy."
            }
            else -> "none" to "Nothing to mark on Zealy for this button."
        }
    }

    /** The current value of cookie [plainName] on zealy.io, decoded (null = not set). */
    private fun jarDecoded(plainName: String): String? = jar()[JsCookie.name(plainName)]?.let { JsCookie.read(it) }

    private fun put(ctx: Context, plainName: String, value: String, expiresAt: Long, q: JSONObject) {
        val name = JsCookie.name(plainName)
        val v = JsCookie.value(value)
        val attrs = "path=/; expires=" + JsCookie.utc(expiresAt)
        val cm = CookieManager.getInstance()
        cm.setCookie("https://zealy.io", "$name=$v; $attrs")
        cm.flush()
        synchronized(lock) { val s = stored(ctx); s.put(name, JSONObject().put("value", v).put("attrs", attrs).put("at", System.currentTimeMillis())); saveStored(ctx, s) }
        prepend(ctx, "engaged-writes.json", JSONObject().put("at", System.currentTimeMillis()).put("name", plainName).put("value", value)
            .put("quest", q.optString("title")).put("by", "QuestPilot pre-click"), 60)
        EventLog.add("engaged", "pre-click wrote $plainName=$value for '${q.optString("title")}'")
    }
}

/** js-cookie 2.x encoding, as used by Zealy's page (names, values) and its reading back. */
object JsCookie {
    private const val KEEP = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.!~*'()"
    fun encodeURIComponent(s: String): String {
        val sb = StringBuilder()
        for (b in s.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xff
            if (c < 128 && KEEP.indexOf(c.toChar()) >= 0) sb.append(c.toChar()) else sb.append('%').append(String.format("%02X", c))
        }
        return sb.toString()
    }
    private fun decodeSome(s: String, codes: Set<String>) =
        Regex("%([0-9A-F]{2})").replace(s) { if (it.groupValues[1] in codes) it.groupValues[1].toInt(16).toChar().toString() else it.value }
    private val VALUE_KEEP = setOf("23", "24", "26", "2B", "3A", "3C", "3E", "3D", "2F", "3F", "40", "5B", "5D", "5E", "60", "7B", "7D", "7C")
    private val NAME_KEEP = setOf("23", "24", "26", "2B", "5E", "60", "7C")
    fun value(v: String) = decodeSome(encodeURIComponent(v), VALUE_KEEP)
    fun name(n: String) = decodeSome(encodeURIComponent(n), NAME_KEEP).replace("(", "%28").replace(")", "%29")
    fun read(raw: String): String {
        val r = if (raw.length >= 2 && raw.startsWith("\"") && raw.endsWith("\"")) raw.substring(1, raw.length - 1) else raw
        return Regex("(%[0-9A-Fa-f]{2})+").replace(r) { m -> try { URLDecoder.decode(m.value, "UTF-8") } catch (_: Exception) { m.value } }
    }
    fun utc(ms: Long): String = java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", java.util.Locale.US)
        .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.format(java.util.Date(ms))
}

/** v2.4.4: task details (ids, X post link, actions, visit link) for one quest, from Zealy's quest data. */
object TaskDetails {
    private val TYPES = setOf("tweetreact", "twitterfollow", "visitlink", "tweet")
    private const val REFRESH_RECURRING_MS = 20 * 3_600_000L
    private const val RETRY_ERROR_MS = 6 * 3_600_000L

    fun wants(types: List<String>) = types.any { it.lowercase() in TYPES }

    fun due(ctx: Context, zid: String, recurring: Boolean): Boolean {
        val e = TaskIds.entry(ctx, zid) ?: return true
        val now = System.currentTimeMillis()
        if (e.has("errorAt") && now - e.optLong("errorAt") < RETRY_ERROR_MS) return false
        if (e.optString("source") != "detail") return true
        return recurring && now - e.optLong("at") > REFRESH_RECURRING_MS
    }

    fun fetch(ctx: Context, sub: String, zid: String): ZealyApi.Resp {
        val r = ZealyApi.questDetail(ctx, sub, zid)
        if (r.skipped) return r
        if (!r.ok) {
            TaskIds.markError(ctx, zid, r.code)
            EventLog.add("preclick", "task details for quest $zid: HTTP ${r.code} (retried in 6 h)")
            return r
        }
        val found = find(r.body, 0)
        if (found == null) { TaskIds.markError(ctx, zid, -1); EventLog.add("preclick", "task details for quest $zid: no tasks in the answer"); return r }
        val arr = JSONArray()
        for (i in 0 until found.length()) {
            val t = found.optJSONObject(i) ?: continue
            val id = t.optString("id").ifEmpty { null } ?: continue
            val st = t.opt("settings")
            arr.put(JSONObject().put("id", id).put("type", t.optString("type"))
                .put("settings", (if (st is JSONObject) st.toString() else st?.toString() ?: "{}").take(2000)))
        }
        TaskIds.put(ctx, zid, arr, "detail")
        PageLinks.fromDetails(ctx, zid, arr)
        return r
    }

    private fun find(v: Any?, depth: Int): JSONArray? {
        if (depth > 4) return null
        when (v) {
            is JSONObject -> {
                val t = v.optJSONArray("tasks")
                if (t != null && t.length() > 0 && t.optJSONObject(0)?.has("id") == true && t.optJSONObject(0)?.has("type") == true) return t
                for (k in v.keys()) find(v.opt(k), depth + 1)?.let { return it }
            }
            is JSONArray -> for (i in 0 until minOf(v.length(), 20)) find(v.opt(i), depth + 1)?.let { return it }
        }
        return null
    }
}

/** QPZ bridge on the Zealy WebView: engaged cookie writes, recorded quest requests, task ids. */
class ZealyHookBridge(private val ctx: Context) {
    @JavascriptInterface fun cookie(raw: String, page: String) = try { EngagedLab.onPageWrite(ctx, raw, "document.cookie", page) } catch (_: Exception) {}
    @JavascriptInterface fun cookieStore(raw: String, page: String) = try { EngagedLab.onPageWrite(ctx, raw, "cookieStore", page) } catch (_: Exception) {}
    @JavascriptInterface fun storage(key: String, value: String, page: String) = try { EngagedLab.onStorageWrite(ctx, key, value, page) } catch (_: Exception) {}
    @JavascriptInterface fun req(pathStatus: String, body: String) = try { ZealyRecorder.add(ctx, pathStatus, body) } catch (_: Exception) {}
    @JavascriptInterface fun tasks(questId: String, json: String) = try {
        val a = JSONArray(json)
        TaskIds.put(ctx, questId, a)
        PageLinks.fromDetails(ctx, questId, a)
    } catch (_: Exception) {}
    @JavascriptInterface fun links(page: String, json: String) = try {
        val a = JSONArray(json)
        PageLinks.fromPage(ctx, page, (0 until a.length()).map { a.getJSONObject(it).let { o -> o.optString("url") to o.optString("label") } })
    } catch (_: Exception) {}

    companion object {
        /** Engaged cookie hook always (passive, only *engaged* names); the request recorder only when [rec]. */
        fun script(rec: Boolean) = """
(function(){if(window.__qpz)return;window.__qpz=1;var REC=${if (rec) "true" else "false"};
var UU=/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i,FL=/engaged|(%3A|:)[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function q(m,a,b){try{QPZ[m](String(a),String(b||''));}catch(e){}}
try{var d=Object.getOwnPropertyDescriptor(Document.prototype,'cookie');if(d&&d.set){Object.defineProperty(document,'cookie',{configurable:true,
get:function(){return d.get.call(document);},set:function(v){try{if(FL.test(String(v).split('=')[0].trim()))q('cookie',v,location.href);}catch(e){}d.set.call(document,v);}});}}catch(e){}
try{if(window.cookieStore&&cookieStore.set){var cs=cookieStore.set.bind(cookieStore);cookieStore.set=function(a,b){try{var o=typeof a==='string'?{name:a,value:b}:a;if(o&&FL.test(o.name))q('cookieStore',JSON.stringify(o),location.href);}catch(e){}return cs.apply(null,arguments);};}}catch(e){}
try{var si=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){try{if(UU.test(String(k))||/engaged|visit|clicked/i.test(String(k)))QPZ.storage(String(k),String(v).slice(0,300),location.href);}catch(e){}return si.apply(this,arguments);};}catch(e){}
function path(u){try{return new URL(u,location.href).pathname;}catch(e){return String(u).split('?')[0];}}
function scan(t){try{var j=JSON.parse(t),n=0;(function w(o,dp){if(!o||typeof o!=='object'||dp>9||n>400)return;n++;if(Array.isArray(o)){o.forEach(function(x){w(x,dp+1);});return;}
if(o.id&&Array.isArray(o.tasks)&&o.tasks.some(function(t){return t&&t.id;}))q('tasks',o.id,JSON.stringify(o.tasks.map(function(t){return {id:t.id,type:t.type,settings:t.settings?JSON.stringify(t.settings).slice(0,400):null};})));
for(var k in o)w(o[k],dp+1);})(j,0);}catch(e){}}
function got(u,st,t){var p=path(u);if(!/quest/i.test(p))return;if(REC)q('req',p+' '+st,(t||'').slice(0,2048));if(t)scan(t);}
function qid(){var m=location.pathname.match(/\/questboard\/[^\/]+\/([0-9a-f-]{36})/i)||location.pathname.match(/\/quests\/([0-9a-f-]{36})/i);return m?m[1]:null;}
var lastK='',runs=0,lastP='';
function scanDom(){try{if(location.pathname!==lastP){lastP=location.pathname;runs=0;lastK='';}if(!qid()||runs>40||!document.body)return;runs++;
var out=[],seen={};function add(u,l){u=String(u).replace(/&amp;/g,'&');if(seen[u])return;seen[u]=1;out.push({url:u,label:String(l||'').trim().slice(0,60)});}
document.querySelectorAll('a[href]').forEach(function(a){var h=a.href;if(/(x|twitter)\.com\/(intent\/|[^\/?#]+\/status\/|i\/(web\/)?status\/)/i.test(h))add(h,a.innerText||a.getAttribute('aria-label'));});
document.querySelectorAll('iframe[src]').forEach(function(f){var m=f.src.match(/[?&]id=(\d{8,})/);if(/twitter|x\.com/i.test(f.src)&&m)add('https://x.com/i/status/'+m[1],'embedded post');});
var h=document.body.innerHTML,re=/https?:\/\/(?:www\.|mobile\.)?(?:x|twitter)\.com\/(?:[A-Za-z0-9_]+|i(?:\/web)?)\/status\/\d+/g,m,n=0;while((m=re.exec(h))&&n<10){add(m[0],'');n++;}
var re2=/(?:x|twitter)\.com\/intent\/(?:like|favorite|retweet)\?tweet_id=\d+|(?:x|twitter)\.com\/intent\/(?:tweet|post)\?[^"'\s<>]*?in_reply_to=\d+/g;n=0;while((m=re2.exec(h))&&n<10){add('https://'+m[0],'');n++;}
var k=JSON.stringify(out);if(out.length&&k!==lastK){lastK=k;q('links',location.href,k);}}catch(e){}}
var tmr=null;try{new MutationObserver(function(){if(tmr)return;tmr=setTimeout(function(){tmr=null;scanDom();},1500);}).observe(document.documentElement,{childList:true,subtree:true});}catch(e){}
setTimeout(scanDom,1500);
var of=window.fetch;if(of)window.fetch=function(i,n){var u=(typeof i==='string')?i:(i&&i.url)||'';return of.apply(this,arguments).then(function(r){try{if(/quest/i.test(path(u)))r.clone().text().then(function(t){got(u,r.status,t);});}catch(e){}return r;});};
var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open=function(m,u){this.__qpzu=u;return xo.apply(this,arguments);};
XMLHttpRequest.prototype.send=function(){var x=this;x.addEventListener('load',function(){try{if(!/quest/i.test(path(x.__qpzu)))return;var b=(x.responseType===''||x.responseType==='text')?x.responseText:(x.responseType==='json'?JSON.stringify(x.response):'');got(x.__qpzu,x.status,b);}catch(e){}});return xs.apply(this,arguments);};
})();
""".trimIndent()
    }
}

/**
 * v2.4.3: links picked up from the Zealy page itself, for tasks whose X post link is in the task settings
 * (Like / Reply / Retweet buttons on the page) and not in the description:
 *   - the task settings in the quest data the page loads (fetch / XHR hook, passive)
 *   - the X links, buttons and embedded post on the quest page (DOM scan, passive)
 *   - the X link you tap on the page (the overlay sees it)
 * Saved on the quest as `pageLinks` (the sync never overwrites them). No request is sent to Zealy for this.
 */
object PageLinks {
    private val USER_KEYS = listOf("username", "twitterUsername", "accountName", "handle", "screenName", "twitterHandle")

    /**
     * v2.4.6: links straight from each task's settings (fields read from Zealy's web code):
     * tweetReact tweetUrl + actions -> Like / Repost, twitterFollow username -> Follow, visitLink linkUrl -> Visit.
     * Replaces the links saved from earlier task details (a daily task gets a new post every day).
     */
    fun fromDetails(ctx: Context, questId: String, tasks: JSONArray) {
        val out = JSONArray()
        val seen = mutableSetOf<String>()
        fun add(kind: String, url: String, label: String) { if (seen.add("$kind|$url")) out.put(JSONObject().put("kind", kind).put("url", url).put("label", label)) }
        val other = mutableListOf<Pair<String, String>>()
        for (i in 0 until tasks.length()) {
            val t = tasks.optJSONObject(i) ?: continue
            val type = t.optString("type")
            val s = when (val st = t.opt("settings")) { is JSONObject -> st; is String -> try { JSONObject(st) } catch (_: Exception) { JSONObject() }; else -> JSONObject() }
            when (type) {
                "tweetReact" -> {
                    val tu = s.optString("tweetUrl")
                    val id = Regex("/status(?:es)?/(\\d+)").find(tu)?.groupValues?.get(1)
                    if (id != null) {
                        val acts = s.optJSONArray("actions")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: listOf("like", "retweet")
                        add("post", tu, "tweetReact")
                        if ("like" in acts) add("like", "https://x.com/intent/like?tweet_id=$id", "tweetReact")
                        if ("retweet" in acts) add("repost", "https://x.com/intent/retweet?tweet_id=$id", "tweetReact")
                    }
                }
                "twitterFollow" -> s.optString("username").trim().removePrefix("@").takeIf { Regex("^[A-Za-z0-9_]{1,15}$").matches(it) }
                    ?.let { add("follow", "https://x.com/intent/follow?screen_name=$it", "twitterFollow") }
                "visitLink" -> s.optString("linkUrl").trim().takeIf { it.startsWith("http") && !it.contains("zealy.io") }?.let { add("other", it, "visitLink") }
                else -> ZealySync.docLinks(s).forEach { other.add(it.first to type.lowercase()) }
            }
        }
        if (other.isNotEmpty()) {
            val c = ZealySync.classifyLinks(other.map { it.second }, other, other.joinToString(" ") { it.second })
            for (i in 0 until c.length()) c.getJSONObject(i).let { add(it.optString("kind"), it.optString("url"), it.optString("label")) }
        }
        save(ctx, questId, out, "task settings", replace = true)
    }

    fun fromTasks(ctx: Context, questId: String, tasks: JSONArray) {
        val types = mutableListOf<String>()
        val links = mutableListOf<Pair<String, String>>()
        for (i in 0 until tasks.length()) {
            val t = tasks.optJSONObject(i) ?: continue
            val type = t.optString("type").lowercase()
            val st = t.opt("settings")
            val settings: Any? = when (st) { is String -> try { JSONObject(st) } catch (_: Exception) { st }; else -> st }
            // an X react task lists its actions (like / retweet / reply): then only those buttons
            val actions = (settings as? JSONObject)?.optJSONArray("actions")
            if ("react" in type && actions != null && actions.length() > 0) {
                for (k in 0 until actions.length()) types.add(actions.optString(k).lowercase())
            } else types.add(type)
            ZealySync.docLinks(settings).forEach { links.add(it.first to type) }
            if ("follow" in type && settings is JSONObject) USER_KEYS.forEach { k ->
                settings.optString(k).trim().removePrefix("@").takeIf { Regex("^[A-Za-z0-9_]{1,15}$").matches(it) }?.let { links.add("https://x.com/$it" to "follow") }
            }
        }
        if (links.isEmpty()) return
        save(ctx, questId, ZealySync.classifyLinks(types, links, types.joinToString(" ")), "task settings")
    }

    /** [trusted] = the exact link a task button opened (a Follow profile link is then kept too). */
    fun fromPage(ctx: Context, pageUrl: String?, items: List<Pair<String, String>>, trusted: Boolean = false) {
        val qid = EngagedLab.questIdFromPage(pageUrl).first ?: return
        val q = findQuest(DbStore.read(), qid)
        val types = (q?.optString("taskKinds") ?: "").lowercase().split(',').filter { it.isNotEmpty() }
        val arr = ZealySync.classifyLinks(types, items, items.joinToString(" ") { it.second }, fromPage = !trusted)
        if (arr.length() > 0) save(ctx, qid, arr, "Zealy page")
    }

    private fun findQuest(d: JSONObject, zid: String): JSONObject? {
        val qs = d.getJSONArray("quests")
        for (i in 0 until qs.length()) if (qs.getJSONObject(i).optString("zealyId").equals(zid, true)) return qs.getJSONObject(i)
        return null
    }

    private fun save(ctx: Context, questId: String, arr: JSONArray, source: String, replace: Boolean = false) {
        if (findQuest(DbStore.read(), questId) == null) return
        var added = 0
        DbStore.mutate { d ->
            val q = findQuest(d, questId) ?: return@mutate
            val old = q.optJSONArray("pageLinks") ?: JSONArray()
            val cur = JSONArray()
            for (i in 0 until old.length()) old.optJSONObject(i)?.let { if (!replace || it.optString("source") != source) cur.put(it) }
            if (replace && cur.length() != old.length()) added = -1 // something was replaced: save even if nothing is new
            val seen = (0 until cur.length()).map { cur.getJSONObject(it).let { o -> o.optString("kind") + "|" + o.optString("url") } }.toMutableSet()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (seen.add(o.optString("kind") + "|" + o.optString("url"))) { cur.put(o.put("source", source)); added = if (added < 0) -1 else added + 1 }
            }
            if (added != 0) q.put("pageLinks", cur).put("pageLinksAt", System.currentTimeMillis())
        }
        if (added > 0) EventLog.add("preclick", "picked up $added link(s) from the $source for quest $questId")
    }
}

/** Part 2: a Pre-click button's overlay closed. Saves done + time, and (Part 4) the clicked flag when possible. */
object Preclick {
    /**
     * [awayMs]: how long the X page was open. Zealy's own page only counts a click after you were away at least
     * 1.5 s, so the flag follows the same rule.
     */
    /** v2.4.6: runs the moment you press the button (before the X page opens): marks it right away. */
    fun onPress(ctx: Context, questId: Int, kind: String, url: String?): Pair<String, String> {
        val q = DbStore.quest(DbStore.read(), questId) ?: return "none" to "Task not found"
        val writeOn = DbStore.pref(DbStore.read(), "preclickWriteFlag", true)
        val (flag, note) = when {
            !writeOn -> "off" to "Writing Zealy's clicked flag is off (Debug)."
            else -> try { EngagedLab.write(ctx, q, kind, url) } catch (e: Exception) { "none" to "Clicked flag not written: ${e.message}" }
        }
        DbStore.mutate { d ->
            val qq = DbStore.quest(d, questId) ?: return@mutate
            val pc = qq.optJSONObject("preclick") ?: JSONObject().also { qq.put("preclick", it) }
            pc.put(kind, JSONObject().put("at", System.currentTimeMillis()).put("flag", flag).put("note", note))
        }
        EventLog.add("preclick", "${q.optString("title")}: $kind pressed, flag $flag")
        return flag to note
    }
}
