package io.questpilot.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts monitoring after a reboot/app update and rebuilds alarms when the clock changes. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        Thread {
            try {
                // A6: alarms rebuilt after reboot, app update, clock change and timezone change.
                AlarmScheduler.rescheduleAll(ctx)
                EventLog.init(ctx)
                EventLog.add("alarms", "rebuilt after ${intent.action?.substringAfterLast('.')}")
                when (intent.action) {
                    Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_LOCKED_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED,
                    "android.intent.action.QUICKBOOT_POWERON", "com.htc.intent.action.QUICKBOOT_POWERON",
                    "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" -> MonitorService.start(ctx)
                }
            } finally {
                pending.finish()
            }
        }.start()
    }
}
