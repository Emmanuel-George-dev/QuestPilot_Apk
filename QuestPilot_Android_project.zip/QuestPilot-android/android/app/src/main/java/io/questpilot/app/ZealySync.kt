package io.questpilot.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

/**
 * Reads the user's Zealy communities and questboards and merges them into the local data
 * (port of the original importPayload()). A2: statuses come only from Zealy fields, and are
 * written only after a successful fetch. A failed fetch keeps every old status.
 */
object ZealySync {
    data class Result(val ok: Boolean, val error: String? = null, val results: List<JSONObject> = emptyList())

    private val QUEST_DEFAULTS = JSONObject(
        """{"type":"other","recurrence":"once","resetMode":"rolling","resetTime":"09:00","xp":0,"url":null,"deadline":null,
        "autoOpen":1,"status":"todo","lastClaimedAt":null,"claimCount":0,"notes":null,"zealyId":null,"categoryId":null,
        "taskKinds":null,"claimLimit":0,"locked":0,"source":"manual"}"""
    )
    private val COMMUNITY_DEFAULTS = JSONObject(
        """{"sprintName":null,"sprintEndsAt":null,"prize":null,"hue":268,"notify":1,"autoSync":1,"lastSyncAt":null,"syncError":null}"""
    )

    /**
     * Session check. First exactly GET /api/users/me. zealy.io itself never calls "me" on api-v2:
     * its client reads userId from the `user_metadata` cookie and calls /api/users/{userId}, so on a
     * non-auth failure (e.g. 400) we try that too. If the cookie isn't accepted and zealy.io kept a
     * token in web storage, the same two calls are retried with Authorization: Bearer.
     * Only 401/403 count as "session expired"; anything else is reported as a request error.
     */
    fun ensureUser(ctx: Context): Pair<String?, ZealyApi.Resp> {
        val cookieId = SessionStore.userIdFromCookie(ctx)
        val modes = buildList {
            add(SessionStore.authMode)
            if (SessionStore.bearer(ctx) != null) add(if (SessionStore.authMode == "bearer") "cookie" else "bearer")
        }
        var first: ZealyApi.Resp? = null
        var allAuth = true
        for (mode in modes) {
            val attempts = mutableListOf<() -> ZealyApi.Resp>({ ZealyApi.me(ctx, mode) })
            if (cookieId != null) attempts.add { ZealyApi.user(ctx, cookieId, mode) }
            for (call in attempts) {
                val r = call()
                if (first == null) first = r
                if (r.ok) {
                    val me = r.body as? JSONObject
                    val id = me?.optString("id")?.ifEmpty { null } ?: cookieId
                    State.userId = id
                    State.userName = me?.optString("name")?.ifEmpty { null } ?: me?.optString("displayName")?.ifEmpty { null }
                    if (mode != SessionStore.authMode) SessionStore.saveAuthMode(ctx, mode)
                    Session.onSuccess(ctx)
                    return id to r
                }
                if (!r.authError) allAuth = false
            }
        }
        val r = first!!
        if (allAuth && r.authError) Session.onAuthFailure(ctx)
        return null to r
    }

    /** User-facing text: only 401/403 say "expired"; 400 etc. show the status and the first 300 chars. */
    fun describeFailure(r: ZealyApi.Resp) =
        if (r.authError) "Zealy session expired (${r.code})" else "Zealy request error: ${r.describe()}"

    /** Full sync. [only] restricts it to one subdomain. */
    fun syncAll(ctx: Context, only: String? = null, onlyAutoSync: Boolean = false): Result {
        if (!SessionStore.hasSession(ctx)) return Result(false, "Zealy is not connected")
        if (State.syncing) return Result(false, "A sync is already running")
        State.syncing = true
        QuestPilotPlugin.emitStatus(ctx)
        try {
            val (userId, meResp) = ensureUser(ctx)
            if (userId == null) {
                return Result(false, describeFailure(meResp))
            }
            val db = DbStore.read()
            val ignored = db.getJSONObject("settings").optJSONArray("ignoredSubdomains").toStringSet()
            val targets = linkedMapOf<String, String>()
            if (only == null) {
                val (lr, list) = ZealyApi.myCommunities(ctx, userId)
                if (!lr.ok && list.isEmpty()) return Result(false, "Couldn't list your communities: ${lr.describe()}")
                list.filter { it.first.lowercase() !in ignored }.forEach { targets[it.first] = it.second }
            }
            val comms = db.getJSONArray("communities")
            for (i in 0 until comms.length()) {
                val c = comms.getJSONObject(i)
                val sub = c.optString("subdomain")
                if (only != null && !sub.equals(only, true)) continue
                if (onlyAutoSync && c.optInt("autoSync", 1) != 1) { targets.remove(sub); continue }
                if (!targets.containsKey(sub)) targets[sub] = c.optString("name", sub)
            }
            if (only != null && targets.isEmpty()) targets[only] = only

            val fetched = mutableListOf<JSONObject>()
            val failed = mutableMapOf<String, String>()
            for ((sub, name0) in targets) {
                val qb = ZealyApi.questboard(ctx, sub)
                val modules = ZealyApi.modules(qb)
                if (!qb.ok || modules == null) {
                    failed[sub] = "Couldn't read questboard: ${qb.describe()}"
                    if (qb.authError) Session.onAuthFailure(ctx)
                    Thread.sleep(Random.nextLong(1000, 2000))
                    continue
                }
                val sp = ZealyApi.sprint(ctx, sub)
                var name = name0
                if (name == sub) (ZealyApi.community(ctx, sub).body as? JSONObject)?.optString("name")?.ifEmpty { null }?.let { name = it }
                // Your real XP in this community. Best effort: any failure just keeps the previous value and the estimate.
                Thread.sleep(Random.nextLong(500, 1000))
                val xp = try { xpFromProfile(ZealyApi.communityUser(ctx, sub, userId).body) } catch (_: Exception) { null }
                fetched.add(JSONObject().put("subdomain", sub).put("name", name).put("questboard", modules).put("sprint", sp.body ?: JSONObject.NULL)
                    .put("userXp", xp ?: JSONObject.NULL))
                Thread.sleep(Random.nextLong(1000, 2000))
            }
            val results = DbStore.mutate { d ->
                val out = mutableListOf<JSONObject>()
                for (p in fetched) out.add(apply(d, p))
                for ((sub, err) in failed) {
                    findCommunity(d, sub)?.put("syncError", err) // old statuses are kept
                    out.add(JSONObject().put("subdomain", sub).put("name", sub).put("added", 0).put("updated", 0).put("error", err))
                }
                out
            }
            State.lastSyncAt = System.currentTimeMillis()
            if (only == null) State.lastFullSyncAt = State.lastSyncAt
            val ok = fetched.isNotEmpty() || targets.isEmpty()
            return Result(ok, if (ok) null else failed.values.firstOrNull(), results)
        } finally {
            State.syncing = false
            QuestPilotPlugin.emitStatus(ctx)
        }
    }

    fun findCommunity(db: JSONObject, sub: String): JSONObject? {
        val arr = db.getJSONArray("communities")
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("subdomain").equals(sub, true)) return arr.getJSONObject(i)
        return null
    }

    private fun docText(n: Any?): String = when (n) {
        null, JSONObject.NULL -> ""
        is String -> n
        is JSONObject -> if (n.has("text")) n.optString("text") else {
            val content = n.optJSONArray("content")
            val sep = if (n.optString("type") == "paragraph" || n.optString("type") == "listItem") "\n" else ""
            if (content == null) "" else (0 until content.length()).joinToString(sep) { docText(content.opt(it)) }
        }
        else -> ""
    }

    private fun taskType(tasks: JSONArray?, recurrence: String): String {
        val kinds = (0 until (tasks?.length() ?: 0)).map { tasks!!.optJSONObject(it)?.optString("type") ?: "" }
        fun has(re: String) = kinds.any { Regex(re, RegexOption.IGNORE_CASE).containsMatchIn(it) }
        return when {
            has("^file$|image|upload") -> "image"
            has("twitter|tweet") -> "twitter"
            has("discord") -> "discord"
            has("telegram") -> "telegram"
            has("quiz") -> "quiz"
            has("invite") -> "invite"
            has("evm|solana|onchain|nft|token|wallet") -> "onchain"
            has("^text$|input|number|poll|^form$") -> "text"
            has("url|link|visit") -> "link"
            recurrence != "once" -> "daily"
            else -> "other"
        }
    }

    fun questUrl(sub: String, zq: JSONObject): String {
        val cat = zq.optString("categoryId")
        return "https://zealy.io/cw/$sub/questboard" + (if (cat.isNotEmpty() && cat != "null") "/$cat" else "") + "/" + zq.optString("id")
    }

    fun xpOf(zq: JSONObject): Int {
        var xp = 0
        val r = zq.optJSONArray("rewards") ?: return 0
        for (i in 0 until r.length()) r.optJSONObject(i)?.let { if (it.optString("type") == "xp") xp += it.optInt("value") }
        return xp
    }

    /** XP out of a community profile response: top level, or inside one wrapper object. Null when it isn't there. */
    fun xpFromProfile(body: Any?): Int? {
        val o = body as? JSONObject ?: return null
        fun num(j: JSONObject?): Int? {
            val v = j?.opt("xp")
            return if (v is Number) v.toInt() else null
        }
        num(o)?.let { return it }
        for (k in listOf("data", "user", "member", "me", "result")) num(o.optJSONObject(k))?.let { return it }
        return null
    }

    /** Merge one community payload {subdomain,name,questboard,sprint,userXp?}. */
    fun apply(db: JSONObject, p: JSONObject): JSONObject {
        val sub = p.getString("subdomain")
        val name = p.optString("name", sub)
        var com = findCommunity(db, sub)
        val sprintArr = (p.opt("sprint") as? JSONObject)?.optJSONArray("data")
        val sprint = sprintArr?.optJSONObject(0)
        if (com == null) {
            com = JSONObject(COMMUNITY_DEFAULTS.toString())
                .put("id", DbStore.nextId(db, "communities")).put("name", name).put("subdomain", sub).put("hue", Random.nextInt(360))
            db.getJSONArray("communities").put(com)
        } else if (name.isNotEmpty() && name != sub) com.put("name", name)
        (p.opt("userXp") as? Number)?.let { com.put("userXp", it.toInt()).put("userXpAt", DbStore.nowIso()) }
        if (p.has("sprint")) {
            com.put("sprintName", sprint?.optString("name")?.trim()?.ifEmpty { null } ?: JSONObject.NULL)
            com.put("sprintEndsAt", sprint?.opt("endingAt") ?: JSONObject.NULL)
            var prize: Any = JSONObject.NULL
            if (sprint != null) {
                val rt = docText(sprint.opt("rewards")).trim()
                if (rt.isNotEmpty()) prize = if (rt.length > 120) rt.take(117) + "..." else rt
                else if (sprint.optLong("usdcPool") > 0) prize = "$" + "%,d".format(sprint.optLong("usdcPool") / 100)
            }
            com.put("prize", prize)
        }
        com.put("lastSyncAt", DbStore.nowIso()).put("syncError", JSONObject.NULL)

        val comId = com.getInt("id")
        val quests = db.getJSONArray("quests")
        val now = System.currentTimeMillis()
        var added = 0
        var updated = 0
        val modules = p.optJSONArray("questboard") ?: JSONArray()
        for (m in 0 until modules.length()) {
            val list = modules.optJSONObject(m)?.optJSONArray("quests") ?: continue
            for (k in 0 until list.length()) {
                val zq = list.optJSONObject(k) ?: continue
                val zid = zq.optString("id")
                if (zid.isEmpty()) continue
                var rec: JSONObject? = null
                for (j in 0 until quests.length()) {
                    val q = quests.getJSONObject(j)
                    if (q.optInt("communityId") == comId && q.optString("zealyId") == zid) { rec = q; break }
                }
                val recurrence = zq.optString("recurrence").let { if (it in setOf("daily", "weekly", "monthly")) it else "once" }
                val claimed = zq.optBoolean("claimed")
                val completed = zq.optBoolean("completed")
                val inReview = zq.optBoolean("inReview")
                val locked = zq.optBoolean("locked")
                val done = claimed || completed
                // A2 order: claimed/completed -> done, inReview -> pending, otherwise todo (locked is shown from zealy.locked)
                val status = if (done) "done" else if (inReview) "pending" else "todo"
                val zealy = JSONObject()
                    .put("claimed", claimed).put("completed", completed).put("inReview", inReview).put("locked", locked)
                    .put("opened", if (zq.has("opened")) zq.opt("opened") else JSONObject.NULL)
                    .put("openAt", zq.opt("openAt") ?: JSONObject.NULL)
                    .put("retryAt", zq.opt("retryAt") ?: JSONObject.NULL)
                    .put("canRetry", zq.opt("canRetry") ?: JSONObject.NULL)
                    .put("conditionOperator", zq.opt("conditionOperator") ?: JSONObject.NULL)
                    .put("conditions", zq.optJSONArray("conditions") ?: JSONArray())
                    .put("syncedAt", now)
                val kinds = zq.optJSONArray("tasks")?.let { t -> (0 until t.length()).joinToString(",") { t.optJSONObject(it)?.optString("type") ?: "" } }
                val fields = JSONObject()
                    .put("title", zq.optString("name").ifEmpty { "Quest" })
                    .put("type", taskType(zq.optJSONArray("tasks"), recurrence))
                    .put("recurrence", recurrence).put("xp", xpOf(zq)).put("url", questUrl(sub, zq))
                    .put("zealyId", zid).put("categoryId", zq.optString("categoryId").ifEmpty { null } ?: JSONObject.NULL)
                    .put("taskKinds", kinds?.ifEmpty { null } ?: JSONObject.NULL)
                    .put("claimLimit", zq.optInt("claimLimit")).put("locked", if (locked) 1 else 0)
                    .put("source", "zealy").put("zealy", zealy).put("status", status)
                val descr = docText(zq.opt("description")).trim()
                if (descr.isNotEmpty()) fields.put("notes", descr.take(1500))
                if (rec == null) {
                    rec = JSONObject(QUEST_DEFAULTS.toString())
                    fields.keys().forEach { rec.put(it, fields.get(it)) }
                    rec.put("id", DbStore.nextId(db, "quests")).put("communityId", comId)
                    if (done) rec.put("claimCount", 1)
                    if (done && recurrence != "once") rec.put("lastClaimedAt", DbStore.nowIso())
                    quests.put(rec)
                    added++
                } else {
                    val wasDone = rec.optString("status") == "done"
                    fields.keys().forEach { rec.put(it, fields.get(it)) }
                    if (done && !wasDone) {
                        rec.put("claimCount", rec.optInt("claimCount") + 1)
                        rec.put("lastClaimedAt", DbStore.nowIso())
                    }
                    updated++
                }
            }
        }
        return JSONObject().put("subdomain", sub).put("name", com.optString("name")).put("added", added).put("updated", updated)
    }
}

fun JSONArray?.toStringSet(): Set<String> {
    if (this == null) return emptySet()
    return (0 until length()).map { optString(it).lowercase() }.filter { it.isNotEmpty() }.toSet()
}

/** Session health shared by sync and the monitors. */
object Session {
    fun onSuccess(ctx: Context) {
        State.authFailures = 0
        if (State.sessionExpired) {
            State.sessionExpired = false
            QuestPilotPlugin.emitStatus(ctx)
        }
    }

    /** B2: repeated 401/403 = expired session -> "Zealy session expired, tap to reconnect." */
    fun onAuthFailure(ctx: Context) {
        State.authFailures = State.authFailures + 1
        if (State.authFailures >= 3 && !State.sessionExpired) {
            State.sessionExpired = true
            DbStore.mutate { db ->
                DbStore.addAlert(db, "session", "Zealy session expired, tap to reconnect.", "Monitoring is paused until you reconnect Zealy.",
                    null, null, "session-" + System.currentTimeMillis() / 60000, null, null, push = false)
            }
            Notifications.sessionExpired(ctx)
            QuestPilotPlugin.emitStatus(ctx)
        }
    }
}
