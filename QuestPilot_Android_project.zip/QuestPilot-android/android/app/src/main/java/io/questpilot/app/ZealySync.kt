package io.questpilot.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

/**
 * Reads the user's Zealy communities and questboards and merges them into the local data
 * (port of the original importPayload()). A2: statuses come only from Zealy fields, and are
 * written only after a successful fetch. A failed fetch keeps every old status.
 */
object ZealySync {
    data class Result(val ok: Boolean, val error: String? = null, val results: List<JSONObject> = emptyList())

    private val QUEST_DEFAULTS = JSONObject(
        """{"type":"other","recurrence":"once","resetMode":"rolling","resetTime":"09:00","xp":0,"url":null,"deadline":null,
        "autoOpen":1,"status":"todo","lastClaimedAt":null,"claimCount":0,"notes":null,"zealyId":null,"categoryId":null,
        "taskKinds":null,"claimLimit":0,"locked":0,"source":"manual"}"""
    )
    private val COMMUNITY_DEFAULTS = JSONObject(
        """{"sprintName":null,"sprintEndsAt":null,"prize":null,"hue":268,"notify":1,"autoSync":1,"lastSyncAt":null,"syncError":null}"""
    )

    /**
     * Session check. First exactly GET /api/users/me. zealy.io itself never calls "me" on api-v2:
     * its client reads userId from the `user_metadata` cookie and calls /api/users/{userId}, so on a
     * non-auth failure (e.g. 400) we try that too. If the cookie isn't accepted and zealy.io kept a
     * token in web storage, the same two calls are retried with Authorization: Bearer.
     * Only 401/403 count as "session expired"; anything else is reported as a request error.
     */
    /**
     * v2.4.2: when the user id is known from the cookie, GET /users/<id> is the only call (what zealy.io
     * does). /users/me is only tried when the id is unknown, and never again once it answered 400.
     */
    fun ensureUser(ctx: Context): Pair<String?, ZealyApi.Resp> {
        val cookieId = SessionStore.userIdFromCookie(ctx) ?: State.userId
        val modes = buildList {
            add(SessionStore.authMode)
            if (SessionStore.bearer(ctx) != null) add(if (SessionStore.authMode == "bearer") "cookie" else "bearer")
        }
        var first: ZealyApi.Resp? = null
        var allAuth = true
        for (mode in modes) {
            val attempts = mutableListOf<() -> ZealyApi.Resp>()
            if (cookieId != null) attempts.add { ZealyApi.user(ctx, cookieId, mode) }
            else if (!State.meUnsupported) attempts.add { ZealyApi.me(ctx, mode) }
            for (call in attempts) {
                val r = call()
                if (first == null) first = r
                if (r.skipped) return null to r // paused: nothing was sent
                if (r.code == 400 && r.url.endsWith("/users/me")) State.meUnsupported = true
                if (r.ok) {
                    val me = r.body as? JSONObject
                    val id = me?.optString("id")?.ifEmpty { null } ?: cookieId
                    State.userId = id
                    State.userName = me?.optString("name")?.ifEmpty { null } ?: me?.optString("displayName")?.ifEmpty { null }
                    if (mode != SessionStore.authMode) SessionStore.saveAuthMode(ctx, mode)
                    Session.onSuccess(ctx)
                    return id to r
                }
                if (r.code == 429 || Zealy403.isChallenge(r)) return null to r // don't try the other auth mode into a block
                if (!r.authError) allAuth = false
            }
        }
        val r = first ?: ZealyApi.Resp(400, null, "no user id in the session cookie", "${ZealyApi.A2}/users/me")
        if (allAuth && r.code == 401) Session.onAuthFailure(ctx) // 403 is classified by the caller
        return null to r
    }

    /** User-facing text: only 401/403 say "expired"; 400 etc. show the status and the first 300 chars. */
    fun describeFailure(r: ZealyApi.Resp) =
        if (r.authError) "Zealy session expired (${r.code})" else "Zealy request error: ${r.describe()}"

    /**
     * Full sync. [only] restricts it to one subdomain.
     *
     * v2.4.2 error rules (Fix 4). One community can never block the others:
     *   - 429 anywhere: Backoff.hit, stop the sweep, full sync every 60 min until restart (slowFullSync).
     *   - 403 on a community request (questboard, sprint, community, XP): "no access" for that community and
     *     endpoint, skipped for 6 h, the sweep goes on. No pause, no backoff, no session failure.
     *   - 403 that is a block: a bot-protection page, 3 different communities in a row with a questboard 403,
     *     or a 403 on users/<id> / the community list. Then Backoff.hit and stop, without slowFullSync.
     *     A non-challenge 403 on users/<id> / the community list also counts as a session problem.
     *   - automatic requests during a pause aren't sent (ZealyGate): the sweep just stops.
     * Kept from v2.4.1: [respectPause] (automatic syncs don't start while paused), [wakeLock] renewed
     * per community, whatever was already fetched is kept. Manual syncs (ZealyGate.manual) ignore the
     * 6-hour skip and force a fresh community list.
     */
    fun syncAll(ctx: Context, only: String? = null, onlyAutoSync: Boolean = false, respectPause: Boolean = false,
                wakeLock: android.os.PowerManager.WakeLock? = null): Result {
        if (!SessionStore.hasSession(ctx)) return Result(false, "Zealy is not connected")
        if (respectPause && State.paused()) return Result(false, "Paused: ${State.pauseReason ?: "Zealy rate limit"}")
        if (!State.syncFlag.compareAndSet(false, true)) return Result(false, "A sync is already running")
        QuestPilotPlugin.emitStatus(ctx)
        val manual = ZealyGate.isManual
        var stopReason: String? = null
        var consecutive403 = 0
        /** Stops the sweep. [rateLimit] = a real 429 (sets the 60-minute full sync). */
        fun stop(r: ZealyApi.Resp, reason: String, rateLimit: Boolean, authProblem: Boolean = false) {
            if (stopReason != null) return
            stopReason = reason
            if (r.skipped) { EventLog.add("sync", "paused: sweep stopped, nothing sent"); return }
            Backoff.hit(ctx, r.code, reason)
            if (authProblem) Session.onAuthFailure(ctx)
            if (rateLimit && only == null) State.slowFullSync = true
            EventLog.add("sync", Zealy403.line(r, "sweep stopped ($reason), paused until ${DbStore.localClock(State.pausedUntil)}"))
        }
        /** Account-level request (users/<id>, community list). true = sweep must stop. */
        fun accountBlocked(r: ZealyApi.Resp): Boolean = when {
            r.skipped -> { stop(r, "paused", false); true }
            r.code == 429 -> { stop(r, "rate limit (429)", true); true }
            Zealy403.isChallenge(r) -> { stop(r, "blocked: bot-protection page (403)", false); true }
            r.code == 403 -> { stop(r, "403 on ${Zealy403.path(r.url)}", false, authProblem = true); true }
            else -> false
        }
        /**
         * Community request. Returns "ok" (use it), "skip" (no access / failed: carry on) or "stop".
         * [counts]: a 403 here counts toward "3 communities in a row" (questboard only: when the questboard
         * of the same community just answered 200, a sprint / XP 403 is clearly not a block).
         */
        fun communityResult(sub: String, ep: String, r: ZealyApi.Resp, counts: Boolean): String {
            if (r.skipped) { stop(r, "paused", false); return "stop" }
            if (r.code == 429) { stop(r, "rate limit (429)", true); return "stop" }
            if (Zealy403.isChallenge(r)) { stop(r, "blocked: bot-protection page (403)", false); return "stop" }
            if (r.code == 403) {
                EventLog.add("sync", Zealy403.line(r, "$sub skipped, the sweep goes on"))
                NoAccess.mark(ctx, sub, ep)
                if (counts && ++consecutive403 >= 3) { stop(r, "blocked: 3 communities in a row answered 403", false); return "stop" }
                return "skip"
            }
            if (r.ok) { NoAccess.clear(ctx, sub, ep); if (counts) consecutive403 = 0 }
            return if (r.ok) "ok" else "skip"
        }
        try {
            val (userId, meResp) = ensureUser(ctx)
            if (userId == null) {
                accountBlocked(meResp)
                return Result(false, if (meResp.skipped) "Paused: ${State.pauseReason ?: "Zealy rate limit"}" else describeFailure(meResp))
            }
            val db = DbStore.read()
            val ignored = db.getJSONObject("settings").optJSONArray("ignoredSubdomains").toStringSet()
            val targets = linkedMapOf<String, String>()
            if (only == null) {
                // shared 30-minute cache with the message monitor; a manual "Sync now" refreshes it
                val (lr, list) = CommunityCache.get(ctx, userId, force = manual)
                if (lr != null && accountBlocked(lr)) return Result(false, "Sync stopped: $stopReason")
                if (lr != null && !lr.ok && list.isEmpty()) return Result(false, "Couldn't list your communities: ${lr.describe()}")
                list.filter { it.first.lowercase() !in ignored }.forEach { targets[it.first] = it.second }
            }
            val comms = db.getJSONArray("communities")
            for (i in 0 until comms.length()) {
                val c = comms.getJSONObject(i)
                val sub = c.optString("subdomain")
                if (only != null && !sub.equals(only, true)) continue
                if (onlyAutoSync && c.optInt("autoSync", 1) != 1) { targets.remove(sub); continue }
                if (!targets.containsKey(sub)) targets[sub] = c.optString("name", sub)
            }
            if (only != null && targets.isEmpty()) targets[only] = only

            val fetched = mutableListOf<JSONObject>()
            val failed = mutableMapOf<String, String>()
            val now0 = System.currentTimeMillis()
            for ((sub, name0) in targets) {
                if (stopReason != null) break
                wakeLock?.let { try { it.acquire(10 * 60_000L) } catch (_: Exception) {} } // renew between communities
                if (NoAccess.skip(ctx, sub, "questboard")) {
                    failed[sub] = NoAccess.text(ctx, sub) ?: "No access to the questboard (403)"
                    continue
                }
                val qb = ZealyApi.questboard(ctx, sub)
                val qbRes = communityResult(sub, "questboard", qb, counts = true)
                if (qbRes == "stop") break
                val modules = ZealyApi.modules(qb)
                if (qbRes == "skip" || modules == null) {
                    failed[sub] = if (qb.code == 403) "No access to the questboard (403)" else "Couldn't read questboard: ${qb.describe()}"
                    if (qb.code == 401) Session.onAuthFailure(ctx)
                    Thread.sleep(Random.nextLong(1000, 2000))
                    continue
                }
                val p = JSONObject().put("subdomain", sub).put("name", name0).put("questboard", modules).put("userXp", JSONObject.NULL)
                val saved = findCommunity(db, sub)
                // Fix 3: the sprint endpoint only when needed (full sweep). Skipped while the saved sprint runs
                // for more than 2 more hours and was checked less than 6 hours ago.
                val savedEnd = UnlockClock.parseTime(saved?.opt("sprintEndsAt"))
                val checkedAt = saved?.optLong("sprintCheckedAt", 0L) ?: 0L
                val sprintFresh = only == null && !manual && savedEnd != null && savedEnd - now0 > SPRINT_SKIP_IF_ENDS_AFTER_MS &&
                    now0 - checkedAt < SPRINT_RECHECK_MS
                var freshEnd: Long? = null
                if (!sprintFresh && !NoAccess.skip(ctx, sub, "sprint")) {
                    val sp = ZealyApi.sprint(ctx, sub)
                    when (communityResult(sub, "sprint", sp, counts = false)) {
                        "stop" -> { fetched.add(p); break }
                        "ok" -> {
                            // only a readable answer replaces the saved sprint (a failed request used to erase it)
                            p.put("sprint", sp.body ?: JSONObject.NULL).put("sprintCheckedAt", System.currentTimeMillis())
                            freshEnd = UnlockClock.parseTime(((sp.body as? JSONObject)?.optJSONArray("data")?.optJSONObject(0))?.opt("endingAt"))
                        }
                    }
                }
                if (name0 == sub && !NoAccess.skip(ctx, sub, "community")) {
                    val cr = ZealyApi.community(ctx, sub)
                    when (communityResult(sub, "community", cr, counts = false)) {
                        "stop" -> { fetched.add(p); break }
                        "ok" -> (cr.body as? JSONObject)?.optString("name")?.ifEmpty { null }?.let { p.put("name", it) }
                    }
                }
                // Your real XP: every time for communities with a running sprint; for the others only when the
                // saved value is older than 2 hours. Otherwise the previous value and the estimate are kept.
                val sprintRunning = (if (p.has("sprint")) freshEnd else savedEnd ?: 0L)?.let { it > now0 } == true
                val xpAt = UnlockClock.parseTime(saved?.opt("userXpAt")) ?: 0L
                if ((sprintRunning || now0 - xpAt > XP_REFRESH_MS || saved?.isNull("userXp") != false) && !NoAccess.skip(ctx, sub, "xp")) {
                    Thread.sleep(Random.nextLong(500, 1000))
                    val ur = ZealyApi.communityUser(ctx, sub, userId)
                    when (communityResult(sub, "xp", ur, counts = false)) {
                        "stop" -> { fetched.add(p); break }
                        "ok" -> (try { xpFromProfile(ur.body) } catch (_: Exception) { null })?.let { p.put("userXp", it) }
                    }
                }
                fetched.add(p)
                Backoff.ok()
                Thread.sleep(Random.nextLong(1000, 2000))
            }
            val results = DbStore.mutate { d ->
                val out = mutableListOf<JSONObject>()
                for (p in fetched) out.add(apply(d, p))
                for ((sub, err) in failed) {
                    findCommunity(d, sub)?.put("syncError", err) // old statuses are kept
                    out.add(JSONObject().put("subdomain", sub).put("name", sub).put("added", 0).put("updated", 0).put("error", err))
                }
                out
            }
            // v2.4.4: task details (ids, X post link, actions) for X / visit tasks, so Pre-click works for locked
            // tasks too. Once per quest (recurring: once a day), at most 8 per sweep, through the shared gate.
            if (stopReason == null && DbStore.pref(DbStore.read(), "fetchTaskDetails", true)) {
                var budget = 25
                loop@ for (p in fetched) {
                    val sub = p.optString("subdomain")
                    val mods = p.optJSONArray("questboard") ?: continue
                    var perCom = 0
                    for (m in 0 until mods.length()) {
                        val list = mods.optJSONObject(m)?.optJSONArray("quests") ?: continue
                        for (k in 0 until list.length()) {
                            if (budget <= 0) break@loop
                            if (perCom >= 15) continue@loop
                            val zq = list.optJSONObject(k) ?: continue
                            if (zq.optBoolean("claimed") || zq.optBoolean("completed")) continue
                            val ts = zq.optJSONArray("tasks")
                            val types = (0 until (ts?.length() ?: 0)).map { ts!!.optJSONObject(it)?.optString("type") ?: "" }
                            // X / visit tasks, and every locked task (its tasks are only known from the details)
                            if (!TaskDetails.wants(types) && !zq.optBoolean("locked") && types.isNotEmpty()) continue
                            val zid = zq.optString("id").ifEmpty { null } ?: continue
                            val recurring = zq.optString("recurrence") in setOf("daily", "weekly", "monthly")
                            if (!TaskDetails.due(ctx, zid, recurring)) continue
                            Thread.sleep(Random.nextLong(700, 1500))
                            val r = TaskDetails.fetch(ctx, sub, zid)
                            budget--; perCom++
                            if (r.skipped) break@loop
                            if (r.code == 429) { stop(r, "rate limit (429)", true); break@loop }
                            if (Zealy403.isChallenge(r)) { stop(r, "blocked: bot-protection page (403)", false); break@loop }
                        }
                    }
                }
            }
            State.lastSyncAt = System.currentTimeMillis()
            if (only == null) {
                State.lastFullSyncAt = State.lastSyncAt
                if (stopReason == null && fetched.isNotEmpty()) State.fullSyncOkAt = State.lastSyncAt
            }
            if (stopReason != null) return Result(false, "Sync stopped: $stopReason. Kept ${fetched.size} communit${if (fetched.size == 1) "y" else "ies"}", results)
            val ok = fetched.isNotEmpty() || targets.isEmpty()
            return Result(ok, if (ok) null else failed.values.firstOrNull(), results)
        } finally {
            State.syncFlag.set(false)
            QuestPilotPlugin.emitStatus(ctx)
        }
    }

    private const val SPRINT_SKIP_IF_ENDS_AFTER_MS = 2 * 60 * 60_000L
    private const val SPRINT_RECHECK_MS = 6 * 60 * 60_000L
    private const val XP_REFRESH_MS = 2 * 60 * 60_000L

    fun findCommunity(db: JSONObject, sub: String): JSONObject? {
        val arr = db.getJSONArray("communities")
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("subdomain").equals(sub, true)) return arr.getJSONObject(i)
        return null
    }

    private fun docText(n: Any?): String = when (n) {
        null, JSONObject.NULL -> ""
        is String -> n
        is JSONObject -> if (n.has("text")) n.optString("text") else {
            val content = n.optJSONArray("content")
            val sep = if (n.optString("type") == "paragraph" || n.optString("type") == "listItem") "\n" else ""
            if (content == null) "" else (0 until content.length()).joinToString(sep) { docText(content.opt(it)) }
        }
        else -> ""
    }

    // ---------------------------------------------------------------- v2.4.3 Part 1: links in the description

    private val URL_RX = Regex("https?://[^\\s<>\"'()\\[\\]{}]+")
    private val LINK_KEYS = listOf("href", "url", "src", "link", "tweetUrl", "tweet", "value")

    /**
     * Every URL in the same rich-text document docText reads, with its label: link marks (href), href/url/src
     * attributes on button / embed / tweet nodes, and plain-text URLs. Order kept, duplicates removed.
     */
    fun docLinks(n: Any?): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        fun clean(u: String) = u.trim().trimEnd('.', ',', ';', ':', '!', '?')
        fun walk(v: Any?, depth: Int) {
            if (depth > 30) return
            when (v) {
                is String -> {
                    val t = v.trim()
                    if (t.startsWith("{") || t.startsWith("[")) {
                        val j = try { if (t.startsWith("{")) JSONObject(t) else JSONArray(t) } catch (_: Exception) { null }
                        if (j != null) { walk(j, depth + 1); return }
                    }
                    URL_RX.findAll(v).forEach { out.add(clean(it.value) to v.replace(it.value, "").trim().take(120)) }
                }
                is JSONObject -> {
                    val text = v.optString("text", "")
                    v.optJSONArray("marks")?.let { marks ->
                        for (i in 0 until marks.length()) {
                            val a = marks.optJSONObject(i)?.optJSONObject("attrs") ?: continue
                            LINK_KEYS.forEach { k -> a.optString(k).takeIf { it.startsWith("http") }?.let { out.add(clean(it) to text.trim().take(120)) } }
                        }
                    }
                    v.optJSONObject("attrs")?.let { a ->
                        val label = docText(v).trim().ifEmpty { a.optString("label").ifEmpty { a.optString("text") } }
                        LINK_KEYS.forEach { k -> a.optString(k).takeIf { it.startsWith("http") }?.let { out.add(clean(it) to label.take(120)) } }
                    }
                    if (text.isNotEmpty()) URL_RX.findAll(text).forEach { out.add(clean(it.value) to text.replace(it.value, "").trim().take(120)) }
                    v.optJSONArray("content")?.let { walk(it, depth + 1) }
                }
                is JSONArray -> for (i in 0 until v.length()) walk(v.opt(i), depth + 1)
            }
        }
        walk(n, 0)
        return out.distinctBy { it.first }
    }

    private fun isX(host: String?) = host?.lowercase()?.removePrefix("www.")?.removePrefix("mobile.") in setOf("x.com", "twitter.com")
    private val RESERVED_X = setOf("i", "intent", "home", "explore", "search", "hashtag", "settings", "messages", "notifications", "share", "compose")

    /**
     * {kind: like | repost | follow | post | other, url, label} for a quest. The kind comes from the task types when
     * they say it (like / retweet / follow / tweetReact), otherwise from the label words and the URL shape.
     * A post link with no hint at all gives both Like and Repost (the buttons only open the X page).
     */
    fun xLinks(tasks: JSONArray?, description: Any?): JSONArray {
        val types = (0 until (tasks?.length() ?: 0)).map { tasks!!.optJSONObject(it)?.optString("type")?.lowercase() ?: "" }
        return classifyLinks(types, docLinks(description), docText(description))
    }

    /**
     * v2.4.3: the same classification for links from any source: the description (sync), the task settings the
     * Zealy page loads, or the X buttons / embedded post on the Zealy page. [text] = words around them.
     */
    fun classifyLinks(types: List<String>, links: List<Pair<String, String>>, text: String, fromPage: Boolean = false): JSONArray {
        val description = text
        val tLike = types.any { "like" in it }
        val tRepost = types.any { "retweet" in it || "repost" in it }
        val tReact = types.any { "react" in it }
        val tFollow = types.any { "follow" in it }
        val out = JSONArray()
        val seen = mutableSetOf<String>()
        fun add(kind: String, url: String, label: String) { if (seen.add("$kind|$url")) out.put(JSONObject().put("kind", kind).put("url", url).put("label", label)) }
        val allText = text.lowercase()
        for ((url, label) in links) {
            val u = try { Uri.parse(url) } catch (_: Exception) { null } ?: continue
            if (!isX(u.host)) {
                if (fromPage) continue // the Zealy page has many unrelated links: only X links are taken from it
                // visit-site / Discord / Telegram / any other link: a "Visit" button (not Zealy itself, not images)
                val h = u.host?.lowercase() ?: ""
                val img = Regex("(?i)\\.(png|jpe?g|gif|webp|svg|mp4|mov)$").containsMatchIn(u.path ?: "")
                if (!img && !h.endsWith("zealy.io") && out.length() < 20) add("other", url, label)
                continue
            }
            val segs = u.pathSegments
            val lab = (label + " " + allText).lowercase()
            val first = segs.firstOrNull()?.lowercase()
            when {
                first == "intent" && segs.getOrNull(1) in setOf("like", "favorite") ->
                    u.getQueryParameter("tweet_id")?.let { add("like", "https://x.com/intent/like?tweet_id=$it", label) } ?: add("like", url, label)
                first == "intent" && segs.getOrNull(1) == "retweet" ->
                    u.getQueryParameter("tweet_id")?.let { add("repost", "https://x.com/intent/retweet?tweet_id=$it", label) } ?: add("repost", url, label)
                first == "intent" && segs.getOrNull(1) in setOf("tweet", "post") && u.getQueryParameter("in_reply_to")?.all { it.isDigit() } == true -> {
                    // the Reply button: it carries the post id, so Like and Repost can be built from it
                    val id = u.getQueryParameter("in_reply_to")!!
                    add("post", "https://x.com/i/status/$id", label)
                    add("like", "https://x.com/intent/like?tweet_id=$id", label)
                    add("repost", "https://x.com/intent/retweet?tweet_id=$id", label)
                }
                first == "intent" && segs.getOrNull(1) in setOf("follow", "user") -> add("follow", url, label)
                segs.indexOf("status") >= 0 && segs.getOrNull(segs.indexOf("status") + 1)?.all { it.isDigit() } == true -> {
                    val id = segs[segs.indexOf("status") + 1]
                    add("post", url, label)
                    var like = tLike || tReact || Regex("\\blike").containsMatchIn(lab)
                    var repost = tRepost || tReact || Regex("\\b(repost|retweet|rt)\\b").containsMatchIn(lab)
                    if (!like && !repost) { like = true; repost = true }
                    if (like) add("like", "https://x.com/intent/like?tweet_id=$id", label)
                    if (repost) add("repost", "https://x.com/intent/retweet?tweet_id=$id", label)
                }
                !fromPage && segs.size == 1 && first != null && first !in RESERVED_X && Regex("^[A-Za-z0-9_]{1,15}$").matches(segs[0]) ->
                    add("follow", "https://x.com/${segs[0]}", label)
                else -> if (!fromPage) add("other", url, label)
            }
        }
        // a Follow task naming @handle in the text, without a profile link
        if (tFollow && (0 until out.length()).none { out.getJSONObject(it).optString("kind") == "follow" }) {
            Regex("(?<![A-Za-z0-9_])@([A-Za-z0-9_]{1,15})\\b").find(description)?.let {
                add("follow", "https://x.com/intent/follow?screen_name=${it.groupValues[1]}", "@${it.groupValues[1]}")
            }
        }
        return out
    }

    private fun taskType(tasks: JSONArray?, recurrence: String): String {
        val kinds = (0 until (tasks?.length() ?: 0)).map { tasks!!.optJSONObject(it)?.optString("type") ?: "" }
        fun has(re: String) = kinds.any { Regex(re, RegexOption.IGNORE_CASE).containsMatchIn(it) }
        return when {
            has("^file$|image|upload") -> "image"
            has("twitter|tweet") -> "twitter"
            has("discord") -> "discord"
            has("telegram") -> "telegram"
            has("quiz") -> "quiz"
            has("invite") -> "invite"
            has("evm|solana|onchain|nft|token|wallet") -> "onchain"
            has("^text$|input|number|poll|^form$") -> "text"
            has("url|link|visit") -> "link"
            recurrence != "once" -> "daily"
            else -> "other"
        }
    }

    fun questUrl(sub: String, zq: JSONObject): String {
        val cat = zq.optString("categoryId")
        return "https://zealy.io/cw/$sub/questboard" + (if (cat.isNotEmpty() && cat != "null") "/$cat" else "") + "/" + zq.optString("id")
    }

    fun xpOf(zq: JSONObject): Int {
        var xp = 0
        val r = zq.optJSONArray("rewards") ?: return 0
        for (i in 0 until r.length()) r.optJSONObject(i)?.let { if (it.optString("type") == "xp") xp += it.optInt("value") }
        return xp
    }

    /** XP out of a community profile response: top level, or inside one wrapper object. Null when it isn't there. */
    fun xpFromProfile(body: Any?): Int? {
        val o = body as? JSONObject ?: return null
        fun num(j: JSONObject?): Int? {
            val v = j?.opt("xp")
            return if (v is Number) v.toInt() else null
        }
        num(o)?.let { return it }
        for (k in listOf("data", "user", "member", "me", "result")) num(o.optJSONObject(k))?.let { return it }
        return null
    }

    /** Merge one community payload {subdomain,name,questboard,sprint,userXp?}. */
    fun apply(db: JSONObject, p: JSONObject): JSONObject {
        val sub = p.getString("subdomain")
        val name = p.optString("name", sub)
        var com = findCommunity(db, sub)
        val sprintArr = (p.opt("sprint") as? JSONObject)?.optJSONArray("data")
        val sprint = sprintArr?.optJSONObject(0)
        if (com == null) {
            com = JSONObject(COMMUNITY_DEFAULTS.toString())
                .put("id", DbStore.nextId(db, "communities")).put("name", name).put("subdomain", sub).put("hue", Random.nextInt(360))
            db.getJSONArray("communities").put(com)
        } else if (name.isNotEmpty() && name != sub) com.put("name", name)
        (p.opt("userXp") as? Number)?.let { com.put("userXp", it.toInt()).put("userXpAt", DbStore.nowIso()) }
        if (p.has("sprint")) {
            com.put("sprintName", sprint?.optString("name")?.trim()?.ifEmpty { null } ?: JSONObject.NULL)
            com.put("sprintEndsAt", sprint?.opt("endingAt") ?: JSONObject.NULL)
            var prize: Any = JSONObject.NULL
            if (sprint != null) {
                val rt = docText(sprint.opt("rewards")).trim()
                if (rt.isNotEmpty()) prize = if (rt.length > 120) rt.take(117) + "..." else rt
                else if (sprint.optLong("usdcPool") > 0) prize = "$" + "%,d".format(sprint.optLong("usdcPool") / 100)
            }
            com.put("prize", prize)
        }
        if (p.has("sprintCheckedAt")) com.put("sprintCheckedAt", p.optLong("sprintCheckedAt"))
        com.put("lastSyncAt", DbStore.nowIso()).put("syncError", JSONObject.NULL)

        val comId = com.getInt("id")
        val quests = db.getJSONArray("quests")
        val now = System.currentTimeMillis()
        var added = 0
        var updated = 0
        val modules = p.optJSONArray("questboard") ?: JSONArray()
        val lockedRows = mutableListOf<JSONObject>()
        val resolved = mutableSetOf<String>()
        val rawRows = mutableMapOf<String, JSONObject>()
        for (m in 0 until modules.length()) {
            val list = modules.optJSONObject(m)?.optJSONArray("quests") ?: continue
            for (k in 0 until list.length()) {
                val zq = list.optJSONObject(k) ?: continue
                val zid = zq.optString("id")
                if (zid.isEmpty()) continue
                var rec: JSONObject? = null
                for (j in 0 until quests.length()) {
                    val q = quests.getJSONObject(j)
                    if (q.optInt("communityId") == comId && q.optString("zealyId") == zid) { rec = q; break }
                }
                val recurrence = zq.optString("recurrence").let { if (it in setOf("daily", "weekly", "monthly")) it else "once" }
                val claimed = zq.optBoolean("claimed")
                val completed = zq.optBoolean("completed")
                val inReview = zq.optBoolean("inReview")
                val locked = zq.optBoolean("locked")
                val done = claimed || completed
                // A2 order: claimed/completed -> done, inReview -> pending, otherwise todo (locked is shown from zealy.locked)
                val status = if (done) "done" else if (inReview) "pending" else "todo"
                val zealy = JSONObject()
                    .put("claimed", claimed).put("completed", completed).put("inReview", inReview).put("locked", locked)
                    .put("opened", if (zq.has("opened")) zq.opt("opened") else JSONObject.NULL)
                    .put("openAt", zq.opt("openAt") ?: JSONObject.NULL)
                    .put("retryAt", zq.opt("retryAt") ?: JSONObject.NULL)
                    .put("canRetry", zq.opt("canRetry") ?: JSONObject.NULL)
                    .put("conditionOperator", zq.opt("conditionOperator") ?: JSONObject.NULL)
                    .put("conditions", zq.optJSONArray("conditions") ?: JSONArray())
                    .put("syncedAt", now)
                // Any "opens at / unlocks at / starts at" field Zealy sends on the quest itself.
                val times = JSONObject()
                zq.keys().forEach { k ->
                    if (QUEST_TIME_RX.containsMatchIn(k)) {
                        val v = zq.opt(k)
                        if (v is String || v is Number) times.put(k, v)
                    }
                }
                if (times.length() > 0) zealy.put("questTimes", times)
                // One-time quest that was locked and is now open: remember when it unlocked (a fixed timestamp).
                if (rec != null && recurrence == "once" && !done && !locked) {
                    val oldZ = rec.optJSONObject("zealy")
                    val carried = oldZ?.opt("lockedUntil")?.takeIf { it != JSONObject.NULL }
                    if (carried != null) zealy.put("lockedUntil", carried)
                    else if (oldZ?.optBoolean("locked") == true) {
                        val was = if (rec.isNull("unlockAt")) 0L else rec.optLong("unlockAt")
                        zealy.put("lockedUntil", if (was in 1..now) was else now)
                    }
                }
                // Locked -> unlocked: "Unlocked" alert right away, for every community (not only the watchlist).
                if (rec != null && locked.not() && !done && rec.optJSONObject("zealy")?.optBoolean("locked") == true) {
                    val prevSeen = rec.optJSONObject("zealy")?.optLong("syncedAt") ?: 0L
                    DbStore.addAlert(db, "quest-unlocked", "Unlocked: ${zq.optString("name").ifEmpty { "Quest" }}", name,
                        rec.optInt("id"), comId, "qunl-$sub-$zid-$prevSeen", questUrl(sub, zq))
                }
                if (locked && !done) {
                    val probe = JSONObject().put("source", "zealy").put("recurrence", recurrence).put("zealy", zealy)
                    if (UnlockClock.unlockAt(probe, 0) == null) lockedRows.add(LockedDebug.row(sub, name, zq)) else resolved.add(zid)
                } else resolved.add(zid)
                val kinds = zq.optJSONArray("tasks")?.let { t -> (0 until t.length()).joinToString(",") { t.optJSONObject(it)?.optString("type") ?: "" } }
                val fields = JSONObject()
                    .put("title", zq.optString("name").ifEmpty { "Quest" })
                    .put("type", taskType(zq.optJSONArray("tasks"), recurrence))
                    .put("recurrence", recurrence).put("xp", xpOf(zq)).put("url", questUrl(sub, zq))
                    .put("zealyId", zid).put("categoryId", zq.optString("categoryId").ifEmpty { null } ?: JSONObject.NULL)
                    .put("taskKinds", kinds?.ifEmpty { null } ?: JSONObject.NULL)
                    .put("claimLimit", zq.optInt("claimLimit")).put("locked", if (locked) 1 else 0)
                    .put("source", "zealy").put("zealy", zealy).put("status", status)
                val descr = docText(zq.opt("description")).trim()
                if (descr.isNotEmpty()) fields.put("notes", descr.take(1500))
                // v2.4.3: Like / Repost / Follow links from the description (already in this response)
                val xl = try { xLinks(zq.optJSONArray("tasks"), zq.opt("description")) } catch (_: Exception) { JSONArray() }
                fields.put("xLinks", if (xl.length() > 0) xl else JSONObject.NULL)
                val hasXTask = kinds?.contains(Regex("(?i)twitter|tweet")) == true
                val hasXLink = (0 until xl.length()).any { xl.getJSONObject(it).optString("kind") != "other" }
                if (hasXTask || hasXLink) rawRows[zid] = JSONObject().put("at", System.currentTimeMillis()).put("subdomain", sub)
                    .put("title", zq.optString("name")).put("tasks", zq.opt("tasks") ?: JSONObject.NULL)
                    .put("description", zq.opt("description") ?: JSONObject.NULL).put("xLinks", xl)
                if (rec == null) {
                    rec = JSONObject(QUEST_DEFAULTS.toString())
                    fields.keys().forEach { rec.put(it, fields.get(it)) }
                    rec.put("id", DbStore.nextId(db, "quests")).put("communityId", comId)
                    if (done) rec.put("claimCount", 1)
                    if (done && recurrence != "once") rec.put("lastClaimedAt", DbStore.nowIso())
                    quests.put(rec)
                    added++
                } else {
                    val wasDone = rec.optString("status") == "done"
                    fields.keys().forEach { rec.put(it, fields.get(it)) }
                    if (done && !wasDone) {
                        rec.put("claimCount", rec.optInt("claimCount") + 1)
                        rec.put("lastClaimedAt", DbStore.nowIso())
                    }
                    updated++
                }
            }
        }
        QuestPilotApp.ctx?.let { c -> try { LockedDebug.record(c, sub, lockedRows, resolved) } catch (_: Exception) {} }
        QuestPilotApp.ctx?.let { c -> try { RawQuests.putAll(c, rawRows) } catch (_: Exception) {} }
        return JSONObject().put("subdomain", sub).put("name", com.optString("name")).put("added", added).put("updated", updated)
    }

    private val QUEST_TIME_RX = Regex("(?i)^(unlock|open|start|availab|lockeduntil|visiblefrom)")
}

fun JSONArray?.toStringSet(): Set<String> {
    if (this == null) return emptySet()
    return (0 until length()).map { optString(it).lowercase() }.filter { it.isNotEmpty() }.toSet()
}

/** Session health shared by sync and the monitors. */
object Session {
    fun onSuccess(ctx: Context) {
        State.authFailures = 0
        if (State.sessionExpired) {
            State.sessionExpired = false
            QuestPilotPlugin.emitStatus(ctx)
        }
    }

    /** B2: repeated 401/403 = expired session -> "Zealy session expired, tap to reconnect." */
    fun onAuthFailure(ctx: Context) {
        State.authFailures = State.authFailures + 1
        if (State.authFailures >= 3 && !State.sessionExpired) {
            State.sessionExpired = true
            DbStore.mutate { db ->
                DbStore.addAlert(db, "session", "Zealy session expired, tap to reconnect.", "Monitoring is paused until you reconnect Zealy.",
                    null, null, "session-" + System.currentTimeMillis() / 60000, null, null, push = false)
            }
            Notifications.sessionExpired(ctx)
            QuestPilotPlugin.emitStatus(ctx)
        }
    }
}
