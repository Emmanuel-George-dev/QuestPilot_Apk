package io.questpilot.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.ImageButton
import android.widget.Toast
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/** Zealy WebView screen shared by the timed claim flow (A3) and normal "open in Zealy" taps. */
@SuppressLint("SetJavaScriptEnabled")
object ZealyWeb {
    @Volatile private var ua: String? = null

    /**
     * One User-Agent for the WebView and the HTTP client: the device's Chrome for Android string
     * without the WebView markers ("; wv", "Version/4.0"), ASCII only so it is a valid header.
     */
    fun userAgent(ctx: Context): String = ua ?: run {
        val raw = try { android.webkit.WebSettings.getDefaultUserAgent(ctx) } catch (_: Exception) { "" }
        var s = raw.replace("; wv)", ")").replace(Regex(" Version/\\d+(\\.\\d+)* "), " ")
        s = s.filter { it.code in 0x20..0x7e }.replace(Regex("\\s+"), " ").trim()
        if (!s.contains("Chrome/")) s = "Mozilla/5.0 (Linux; Android ${android.os.Build.VERSION.RELEASE}; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36"
        s.also { ua = it }
    }

    fun configure(w: WebView) {
        w.settings.userAgentString = userAgent(w.context)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.databaseEnabled = true
        w.settings.loadWithOverviewMode = true
        w.settings.useWideViewPort = true
        w.settings.mediaPlaybackRequiresUserGesture = true
        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
    }

    fun isZealy(u: Uri?) = u?.host?.let { it == "zealy.io" || it.endsWith(".zealy.io") } == true
}

/** A3: a WebView created 3 seconds before unlock while the app is in the background. */
object ClaimPreloader {
    private var web: WebView? = null
    private var url: String? = null
    private var basis: Long = 0
    private val main = Handler(Looper.getMainLooper())

    fun preload(ctx: Context, u: String, unlockAt: Long) = main.post {
        try {
            release()
            SessionStore.injectIntoWebView(ctx)
            val w = WebView(MutableContextWrapper(ctx.applicationContext))
            ZealyWeb.configure(w)
            w.webViewClient = WebViewClient()
            w.loadUrl(u)
            web = w; url = u; basis = unlockAt
            main.postDelayed({ if (web === w) { release(); if (ClaimActivity.openCount <= 0) SessionStore.clearWebViewCookies() } }, 10 * 60_000L)
        } catch (_: Exception) {
        }
    }

    fun take(u: String, unlockAt: Long): WebView? {
        val w = web ?: return null
        if (url != u || basis != unlockAt) return null
        web = null; url = null
        return w
    }

    fun release() {
        web?.destroy()
        web = null; url = null
    }
}

class ClaimActivity : Activity() {
    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_MODE = "mode"
        const val EXTRA_QUESTS = "questIds"
        const val EXTRA_UNLOCK = "unlockAt"
        const val EXTRA_TITLE = "title"
        const val EXTRA_QUEST_ID = "questId"
        /** Watches the page's own network calls: a successful POST to a ".../claim" URL is only a hint that starts the status check. */
        private const val CLAIM_HOOK_JS = "(function(){if(window.__qpClaimHook)return;window.__qpClaimHook=true;" +
            "var rx=/zealy\\.io\\/[^?#]*\\/claim(?:[/?#]|$)/i;" +
            "function hit(m,u,ok){try{if(ok&&/^(POST|PUT|PATCH)$/i.test(m||'GET')&&rx.test(String(u)))QPBridge.claimed(String(u));}catch(e){}}" +
            "var of=window.fetch;if(of)window.fetch=function(i,n){var u=(typeof i==='string')?i:(i&&i.url)||'';var m=(n&&n.method)||(i&&i.method)||'GET';" +
            "return of.apply(this,arguments).then(function(r){hit(m,u,r&&r.ok);return r;});};" +
            "var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;" +
            "XMLHttpRequest.prototype.open=function(m,u){this.__qpm=m;this.__qpu=u;return xo.apply(this,arguments);};" +
            "XMLHttpRequest.prototype.send=function(){var x=this;x.addEventListener('load',function(){hit(x.__qpm,x.__qpu,x.status>=200&&x.status<300);});return xs.apply(this,arguments);};})();"
        /** Notices your own tap on the page's Claim button (only starts a status check, never presses anything). */
        private const val CLAIM_TAP_JS = "(function(){if(window.__qpClaimTap)return;window.__qpClaimTap=true;" +
            "document.addEventListener('click',function(e){try{var b=e.target&&e.target.closest&&e.target.closest('button,[role=button]');" +
            "if(b&&/^\\s*claim\\b/i.test(b.innerText||b.textContent||''))QPBridge.claimTapped();}catch(x){}},true);})();"
        /** Real status check after a claim: one community's questboard, every ~4 s, for at most 40 s. */
        private const val CLAIM_CHECK_EVERY_MS = 4_000L
        private const val CLAIM_CHECK_MAX_MS = 40_000L
        private const val REQ_CHOOSER = 4711
        /** Retry the whole fill once if the page still wasn't unlocked right after the unlock second. */
        private const val UNLOCK_RETRY_WINDOW_MS = 20_000L
        @Volatile var openCount = 0

        fun intent(ctx: Context, questIds: IntArray, unlockAt: Long, mode: String) =
            Intent(ctx, ClaimActivity::class.java).putExtra(EXTRA_QUESTS, questIds).putExtra(EXTRA_UNLOCK, unlockAt).putExtra(EXTRA_MODE, mode)
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private var web: WebView? = null
    private lateinit var overlay: LinearLayout
    private lateinit var countdown: TextView
    private lateinit var heading: TextView
    private lateinit var nextBtn: Button
    private var lastClaimEventAt = 0L
    @Volatile private var onScreen = false // true while this screen is visible and in use
    // ---- claim status check (reads the quest's real status from Zealy) ----
    @Volatile private var claimCheckGen = 0 // bumped to stop a running check
    private var claimCheckQuestId = -1 // quest the running check is for (-1 = none)
    @Volatile private var pageUrl: String? = null // URL currently shown in the visible page
    private var queue = mutableListOf<JSONObject>()
    private var index = 0
    private var unlockAt = 0L
    private var loadedBeforeUnlock = false
    private var revealed = false
    // ---- next-quest preload (2nd page waits ready while you claim the 1st) ----
    private var nextWeb: WebView? = null
    private var nextReady = false
    private var nextIndex = -1
    private var nextLoadedBeforeUnlock = false
    // autofill state of the waiting page (it is filled while hidden; you only tap Claim)
    private var nextJob: AutofillJob? = null
    private var nextFillPending = false
    private var nextRetried = false
    private var nextReportJson: String? = null
    private var nextPhotoCursor = 0
    // ---- autofill state ----
    private var job: AutofillJob? = null
    private var fillPending = false
    private var fillRetried = false
    private var photoCursor = 0
    private var armedPhoto: java.io.File? = null
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private lateinit var banner: LinearLayout
    private lateinit var bannerText: TextView
    private lateinit var bannerPhoto: Button
    private val touchedSubs = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openCount++
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        getSystemService(KeyguardManager::class.java)?.requestDismissKeyguard(this, null)
        buildUi()
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        onScreen = true
    }

    override fun onPause() {
        onScreen = false
        stopClaimCheck()
        super.onPause()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0b0b0f")) }
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0b0b0f"))
            isClickable = true
        }
        heading = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(dp(24), 0, dp(24), dp(12)) }
        countdown = TextView(this).apply { setTextColor(Color.parseColor("#e05aae")); textSize = 44f; typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER }
        val hint = TextView(this).apply {
            setTextColor(Color.parseColor("#9a9aa5")); textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(24), dp(12), dp(24), 0)
            text = "The claim page is loading in the background and opens the second the quest unlocks."
        }
        overlay.addView(heading); overlay.addView(countdown); overlay.addView(hint)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#151519"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val close = Button(this).apply { text = "Close"; setOnClickListener { finish() } }
        nextBtn = Button(this).apply { text = "Next"; visibility = View.GONE; setOnClickListener { showNext() } }
        val spacer = View(this)
        bar.addView(close); bar.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f)); bar.addView(nextBtn)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val webHolder = FrameLayout(this).apply { id = View.generateViewId(); tag = "holder" }
        banner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#3a1030"))
            setPadding(dp(12), dp(6), dp(4), dp(6))
            visibility = View.GONE
        }
        bannerText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f
            text = "Couldn't autofill, tap to copy text"
            setOnClickListener { copySavedText(true) }
        }
        bannerPhoto = Button(this).apply { text = "Saved photo"; textSize = 12f; isAllCaps = false; setOnClickListener { pickSavedPhoto() } }
        val bannerClose = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
            setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Dismiss"
            setOnClickListener { banner.visibility = View.GONE }
        }
        banner.addView(bannerText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        banner.addView(bannerPhoto)
        banner.addView(bannerClose, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(banner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(webHolder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay.visibility = View.GONE
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, insets ->
            @Suppress("DEPRECATION")
            v.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
            insets
        }
    }

    private fun holder(): FrameLayout = root.findViewWithTag("holder")

    private fun attachWeb(w: WebView) {
        web?.let { holder().removeView(it); it.destroy() }
        stopClaimCheck()
        pageUrl = w.url
        (w.context as? MutableContextWrapper)?.baseContext = this
        ZealyWeb.configure(w)
        w.removeJavascriptInterface("QPBridge")
        w.addJavascriptInterface(Bridge(w), "QPBridge")
        w.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean =
                onFileChooser(view, cb, params)
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if (ZealyWeb.isZealy(u) || u.scheme == "about") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true // X / Discord / Telegram links open in their apps
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                if (view === web) pageUrl = url
            }

            override fun onPageFinished(view: WebView, url: String) {
                view.evaluateJavascript(CLAIM_HOOK_JS, null)
                view.evaluateJavascript(CLAIM_TAP_JS, null)
                if (view === web) pageUrl = url
                if (!revealed) { loadedBeforeUnlock = true; return } // preloading: fill only after unlock + refresh
                maybeFill()
            }
        }
        holder().addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web = w
    }

    private fun handle(i: Intent) {
        // A new unlock while you are working through a list: it never interrupts the claim in progress.
        // Limited-slot ("First N only") tasks go first, then tasks whose sprint is about to end, then everything else in order.
        if ((i.getStringExtra(EXTRA_MODE) ?: "browse") == "claim" && onScreen && web != null && queue.isNotEmpty()) {
            val db = DbStore.read()
            val have = queue.map { it.optInt("id") }.toSet()
            val fresh = (i.getIntArrayExtra(EXTRA_QUESTS) ?: intArrayOf()).filter { it !in have }
                .mapNotNull { if (DevTools.isTestId(it)) DevTools.testQuest(this, it) else DbStore.quest(db, it) }
            if (fresh.isNotEmpty()) {
                fresh.forEach { touchedSubs.add(subOf(it.optString("url"))) }
                val nowMs = System.currentTimeMillis()
                val soonLimit = nowMs + 24 * 3_600_000L
                fun endOf(q: JSONObject): Long {
                    val e = UnlockClock.parseTime(DbStore.community(db, q.optInt("communityId"))?.opt("sprintEndsAt"))
                    return if (e != null && e > nowMs) e else Long.MAX_VALUE
                }
                // 0 = limited slots, 1 = sprint ends within 24 h, 2 = everything else
                fun tier(q: JSONObject) = when {
                    q.optInt("claimLimit") > 0 -> 0
                    endOf(q) <= soonLimit -> 1
                    else -> 2
                }
                // Inside a tier: same order as the home page (sprint ending first, daily before weekly, more XP, earlier unlock).
                val periods = mapOf("daily" to 0, "weekly" to 1, "monthly" to 2)
                val order = Comparator<JSONObject> { a, b ->
                    var r = tier(a).compareTo(tier(b))
                    if (r == 0) r = endOf(a).compareTo(endOf(b))
                    if (r == 0) r = (periods[a.optString("recurrence")] ?: 3).compareTo(periods[b.optString("recurrence")] ?: 3)
                    if (r == 0) r = b.optInt("xp").compareTo(a.optInt("xp"))
                    if (r == 0) r = a.optLong("unlockAt").compareTo(b.optLong("unlockAt"))
                    r
                }
                var nextChanged = false
                for (q in fresh.sortedWith(order)) {
                    var pos = index + 1
                    while (pos < queue.size && order.compare(queue[pos], q) <= 0) pos++
                    queue.add(pos, q)
                    if (pos == index + 1) nextChanged = true
                }
                updateNext()
                if (nextChanged) discardNext()
                if (nextWeb == null) preloadNext() // the next page is now a different task, or the list had ended
                val head = queue.getOrNull(index + 1)
                val name = head?.optString("title") ?: fresh[0].optString("title")
                toast(
                    if (nextChanged && head != null && tier(head) == 0) "Limited-slot task first: $name is next"
                    else if (nextChanged && head != null && tier(head) == 1) "Sprint ending soon: $name is next"
                    else "New claim added: ${fresh[0].optString("title")}"
                )
            }
            Notifications.cancel(this, Notifications.ID_CLAIM)
            if (DevTools.ENABLED) Notifications.cancel(this, DevTools.ID_TEST_CLAIM)
            return
        }
        SessionStore.injectIntoWebView(this)
        val mode = i.getStringExtra(EXTRA_MODE) ?: "browse"
        banner.visibility = View.GONE
        fillRetried = false
        if (mode == "claim") {
            unlockAt = i.getLongExtra(EXTRA_UNLOCK, 0L)
            val ids = i.getIntArrayExtra(EXTRA_QUESTS) ?: intArrayOf()
            val db = DbStore.read()
            queue = ids.toList().mapNotNull { if (DevTools.isTestId(it)) DevTools.testQuest(this, it) else DbStore.quest(db, it) }.toMutableList()
            index = 0
            if (queue.isEmpty()) { finish(); return }
            val first = queue[0]
            val url = first.optString("url").ifEmpty { "https://zealy.io" }
            touchedSubs.add(subOf(url))
            heading.text = first.optString("title")
            revealed = false
            loadedBeforeUnlock = false
            val pre = ClaimPreloader.take(url, unlockAt)
            if (pre != null) { attachWeb(pre); loadedBeforeUnlock = true } else { attachWeb(WebView(MutableContextWrapper(this))); web!!.loadUrl(url) }
            setJob(first.optInt("id"))
            updateNext()
            preloadNext()
            if (System.currentTimeMillis() < unlockAt) {
                overlay.visibility = View.VISIBLE
                tick()
                // reveal + refresh exactly at the unlock time
                main.postAtTime({ reveal() }, SystemClock.uptimeMillis() + (unlockAt - System.currentTimeMillis()))
            } else reveal()
            Notifications.cancel(this, Notifications.ID_CLAIM)
            if (DevTools.ENABLED) Notifications.cancel(this, DevTools.ID_TEST_CLAIM)
        } else {
            val url = i.getStringExtra(EXTRA_URL) ?: "https://zealy.io"
            touchedSubs.add(subOf(url))
            overlay.visibility = View.GONE
            revealed = true
            val qid = i.getIntExtra(EXTRA_QUEST_ID, 0)
            if (qid > 0) setJob(qid) else { job = null; fillPending = false }
            attachWeb(WebView(MutableContextWrapper(this)))
            web!!.loadUrl(url)
            discardNext()
            val runIds = i.getIntArrayExtra(EXTRA_QUESTS)
            if (qid > 0 && runIds != null && runIds.size > 1 && runIds[0] == qid) {
                // Claim run from the home page: keep the rest of the list here so Next works.
                val db = DbStore.read()
                unlockAt = 0L
                queue = runIds.toList().mapNotNull { DbStore.quest(db, it) }.toMutableList()
                index = 0
                updateNext()
                preloadNext()
            } else {
                queue.clear(); updateNext()
            }
        }
        val alertId = i.getIntExtra("alertId", 0)
        if (alertId > 0) Executors.newSingleThreadExecutor().execute {
            DbStore.mutate { db -> DbStore.findById(db.getJSONArray("alerts"), alertId)?.put("read", 1) }
        }
    }

    private fun tick() {
        if (revealed) return
        val left = unlockAt - System.currentTimeMillis()
        countdown.text = if (left > 0) String.format("%.1fs", left / 1000.0) else "0.0s"
        main.postDelayed({ tick() }, 100)
    }

    private fun reveal() {
        if (revealed) return
        revealed = true
        overlay.visibility = View.GONE
        if (loadedBeforeUnlock) web?.reload() // refresh once at the exact unlock time
        // The waiting page was loaded before unlock: refresh it too, so it is open and ready when you tap Next.
        if (nextLoadedBeforeUnlock) nextWeb?.let { nextReady = false; it.reload() }
        nextLoadedBeforeUnlock = false
    }

    /**
     * Load the following quest's page in a WebView that sits behind the visible one, and fill it
     * there (after unlock) so that tapping Next only leaves the Claim tap.
     */
    private fun preloadNext() {
        discardNext()
        val q = queue.getOrNull(index + 1) ?: return
        val url = q.optString("url").ifEmpty { "https://zealy.io" }
        try {
            val w = WebView(MutableContextWrapper(this))
            ZealyWeb.configure(w)
            w.removeJavascriptInterface("QPBridge")
            w.addJavascriptInterface(Bridge(w), "QPBridge")
            w.webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean =
                    onFileChooser(view, cb, params)
            }
            w.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                    val u = req.url
                    return !(ZealyWeb.isZealy(u) || u.scheme == "about") // never open other apps from the waiting page
                }

                override fun onPageFinished(view: WebView, url: String) {
                    view.evaluateJavascript(CLAIM_HOOK_JS, null)
                    view.evaluateJavascript(CLAIM_TAP_JS, null)
                    if (nextWeb !== view) return
                    nextReady = true
                    if (revealed) fillNext() // before unlock nothing is filled: the refresh at unlock comes first
                }
            }
            nextJob = try { Autofill.prepare(this, q.optInt("id"), markUsed = false) } catch (_: Exception) { null }
            nextFillPending = nextJob != null
            nextRetried = false
            nextReportJson = null
            nextPhotoCursor = 0
            nextWeb = w
            nextIndex = index + 1
            nextReady = false
            nextLoadedBeforeUnlock = System.currentTimeMillis() < unlockAt
            // Added at the bottom of the stack: the visible page covers it and keeps all touches.
            holder().addView(w, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            w.loadUrl(url)
        } catch (_: Exception) {
            discardNext()
        }
    }

    private fun discardNext() {
        nextWeb?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        nextWeb = null
        nextReady = false
        nextIndex = -1
        nextLoadedBeforeUnlock = false
        nextJob = null
        nextFillPending = false
        nextRetried = false
        nextReportJson = null
        nextPhotoCursor = 0
    }

    /** Same fill as maybeFill(), for the waiting page. */
    private fun fillNext() {
        val j = nextJob ?: return
        if (!nextFillPending || !revealed) return
        val w = nextWeb ?: return
        if (!Autofill.matches(j, w.url)) return // another page: never fill
        nextFillPending = false
        val js = Autofill.script(this) ?: return
        val cfg = Autofill.selectors(this)
        val payload = try { Autofill.payload(j) } catch (_: Exception) { Autofill.payload(j, emptyList()) }
        w.evaluateJavascript(js, null)
        w.evaluateJavascript("window.__qpFill($cfg, $payload)", null)
    }

    /** Fill result from the waiting page. Kept until you tap Next, then shown exactly like a normal result. */
    private fun onNextReport(json: String) {
        val j = nextJob ?: return
        val w = nextWeb ?: return
        if (!Autofill.matches(j, w.url)) return
        val r = try { JSONObject(json) } catch (_: Exception) { return }
        if (r.optBoolean("blocked")) return
        val missing = r.optString("text") == "missing" || r.optString("photo") == "missing"
        if (!r.optBoolean("manual") && missing && unlockAt > 0 && !nextRetried &&
            System.currentTimeMillis() - unlockAt in 0..UNLOCK_RETRY_WINDOW_MS) {
            nextRetried = true // Zealy can still serve the locked page right after unlock: refresh and try once more
            nextFillPending = true
            w.reload()
            return
        }
        nextReportJson = json
    }

    /**
     * The status check confirmed the claim on Zealy. Only with Auto-next on and more claims waiting:
     * move on after a short pause. The Next button always works on its own.
     */
    private fun onClaimDetected() {
        val now = SystemClock.uptimeMillis()
        if (now - lastClaimEventAt < 5000) return // one claim = one move
        lastClaimEventAt = now
        // The Auto-next switch lives on the home page's claim run card (preference autoNextClaim).
        if (!DbStore.pref(DbStore.read(), "autoNextClaim", false) || index + 1 >= queue.size) return
        val at = index
        toast("Claimed. Moving to the next one…")
        main.postDelayed({ if (index == at) showNext() }, 1800)
    }

    /**
     * Real status check: after the network hint or your own Claim tap, read the quest's status from
     * Zealy's questboard (the same request and the same ZealySync.apply() that a sync uses, run on a
     * throwaway copy so nothing is saved). Confirmed when the status becomes done/pending or its
     * unlock time moves to the next day. Silent on any failure: never an auth failure, never a logout.
     */
    private fun startClaimCheck() {
        if (!onScreen || index + 1 >= queue.size) return // nothing to move to
        val q0 = queue.getOrNull(index) ?: return
        val qid = q0.optInt("id")
        if (claimCheckQuestId == qid) return // already checking this claim
        if (DevTools.isTestId(qid) || q0.optString("source") == "test") return
        val db = try { DbStore.read() } catch (_: Exception) { return }
        if (!DbStore.pref(db, "autoNextClaim", false)) return
        val local = DbStore.quest(db, qid) ?: return
        val zid = local.optString("zealyId").takeIf { it.isNotEmpty() && !local.isNull("zealyId") } ?: return
        val com = DbStore.community(db, local.optInt("communityId")) ?: return
        val sub = com.optString("subdomain").ifEmpty { return }
        val comName = com.optString("name", sub)
        val tz = db.optJSONObject("settings")?.optInt("tzOffset", 0) ?: 0
        val beforeStatus = local.optString("status")
        val beforeUnlock = try { UnlockClock.unlockAt(local, tz) } catch (_: Exception) { null }
        val gen = ++claimCheckGen
        claimCheckQuestId = qid
        val atIndex = index
        val ctx = applicationContext
        val started = SystemClock.uptimeMillis()
        fun live() = gen == claimCheckGen && onScreen && pageUrl?.contains(zid) == true
        Thread {
            try {
                while (SystemClock.uptimeMillis() - started < CLAIM_CHECK_MAX_MS) {
                    Thread.sleep(CLAIM_CHECK_EVERY_MS + kotlin.random.Random.nextLong(0, 800))
                    if (!live()) return@Thread // closed, Next tapped, or another task is showing: stop
                    val confirmed = try {
                        val qb = ZealyApi.questboard(ctx, sub)
                        val modules = ZealyApi.modules(qb)
                        if (!qb.ok || modules == null) false // silent: never Session.onAuthFailure here
                        else {
                            val copy = JSONObject(DbStore.read().toString())
                            ZealySync.apply(copy, JSONObject().put("subdomain", sub).put("name", comName).put("questboard", modules))
                            val now = System.currentTimeMillis()
                            val after = DbStore.quest(copy, qid)
                            val st = after?.optString("status")
                            val unlock = after?.let { UnlockClock.unlockAt(it, tz) }
                            val day = 86_400_000L
                            val baseDay = (beforeUnlock?.takeIf { it > now } ?: now) / day
                            (st != beforeStatus && (st == "done" || st == "pending")) ||
                                (unlock != null && unlock > now && unlock / day > baseDay)
                        }
                    } catch (_: Exception) { false }
                    if (confirmed) {
                        main.post { if (gen == claimCheckGen && index == atIndex) { stopClaimCheck(); onClaimDetected() } }
                        return@Thread
                    }
                }
            } catch (_: Exception) {
            } finally {
                main.post { if (gen == claimCheckGen) claimCheckQuestId = -1 }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun stopClaimCheck() {
        claimCheckGen++
        claimCheckQuestId = -1
    }

    private fun updateNext() {
        val more = queue.size - index - 1
        nextBtn.visibility = if (more > 0) View.VISIBLE else View.GONE
        nextBtn.text = "Next ($more)"
    }

    private fun showNext() {
        if (index + 1 >= queue.size) return
        stopClaimCheck()
        index++
        val q = queue[index]
        val url = q.optString("url").ifEmpty { "https://zealy.io" }
        touchedSubs.add(subOf(url))
        banner.visibility = View.GONE
        fillRetried = false
        val pre = nextWeb
        if (pre != null && nextIndex == index) {
            // The page is already loaded and filled: take over its autofill state and show it.
            val report = nextReportJson
            job = nextJob
            job?.let { try { Autofill.commitUsed(it) } catch (_: Exception) {} } // "use once" entry is used now, as you opened the page
            fillPending = nextFillPending
            fillRetried = nextRetried
            photoCursor = nextPhotoCursor
            armedPhoto = null
            nextWeb = null; nextReady = false; nextIndex = -1; nextLoadedBeforeUnlock = false
            nextJob = null; nextFillPending = false; nextRetried = false; nextReportJson = null; nextPhotoCursor = 0
            (pre.parent as? ViewGroup)?.removeView(pre)
            attachWeb(pre)
            if (report != null) onFillReport(report) // "Filled in. Check it, then tap Claim yourself."
            else if (fillPending) maybeFill()        // not filled yet: finishes right away
        } else {
            setJob(q.optInt("id"))
            web?.loadUrl(url)
        }
        updateNext()
        preloadNext() // get the one after it ready too
    }

    // ------------------------------------------------------------------ autofill

    private fun setJob(questId: Int) {
        job = try { Autofill.prepare(this, questId) } catch (_: Exception) { null }
        fillPending = job != null
        photoCursor = 0
        armedPhoto = null
    }

    private fun maybeFill() {
        val j = job ?: return
        if (!fillPending || !revealed) return
        val w = web ?: return
        if (!Autofill.matches(j, w.url)) return // another page: never fill
        fillPending = false
        val js = Autofill.script(this) ?: return
        val cfg = Autofill.selectors(this)
        val payload = try { Autofill.payload(j) } catch (_: Exception) { Autofill.payload(j, emptyList()) }
        w.evaluateJavascript(js, null)
        w.evaluateJavascript("window.__qpFill($cfg, $payload)", null)
    }

    /** Result from qp-fill.js. Only trusted while the main frame is the opened zealy.io quest. */
    inner class Bridge(private val owner: WebView? = null) {
        @JavascriptInterface
        fun claimed(url: String) {
            // Only a hint: it starts the real status check, which alone decides whether to move on.
            main.post { if (owner == null || owner === web) startClaimCheck() }
        }

        /** You tapped the page's Claim button yourself: start reading the real status. */
        @JavascriptInterface
        fun claimTapped() {
            main.post { if (owner == null || owner === web) startClaimCheck() }
        }

        @JavascriptInterface
        fun report(json: String) {
            main.post {
                when {
                    owner == null || owner === web -> onFillReport(json)
                    owner === nextWeb -> onNextReport(json) // the waiting page, still hidden
                }
            }
        }
    }

    private fun onFillReport(json: String) {
        val j = job ?: return
        if (!Autofill.matches(j, web?.url)) return
        val r = try { JSONObject(json) } catch (_: Exception) { return }
        if (r.optBoolean("blocked")) return
        val textMissing = r.optString("text") == "missing"
        val photoMissing = r.optString("photo") == "missing"
        if (r.optBoolean("manual")) {
            if (!photoMissing) { banner.visibility = View.GONE; toast("Saved photo attached. Check it, then tap Claim.") }
            return
        }
        if (!textMissing && !photoMissing) {
            banner.visibility = View.GONE
            toast("Filled in. Check it, then tap Claim yourself.")
            return
        }
        // A3: right after unlock Zealy can still serve the locked page; reload and try once more.
        if (unlockAt > 0 && !fillRetried && System.currentTimeMillis() - unlockAt in 0..UNLOCK_RETRY_WINDOW_MS) {
            fillRetried = true
            fillPending = true
            web?.reload()
            return
        }
        showBanner(textMissing, photoMissing)
    }

    private fun showBanner(textMissing: Boolean, photoMissing: Boolean) {
        val j = job ?: return
        val hasText = !j.text.isNullOrBlank()
        bannerText.text = when {
            textMissing && hasText -> "Couldn't autofill, tap to copy text"
            else -> "Couldn't attach the photo automatically"
        }
        bannerText.isClickable = hasText
        bannerPhoto.visibility = if (j.photos.isNotEmpty()) View.VISIBLE else View.GONE
        bannerPhoto.text = if (j.photos.size > 1) "Saved photos" else "Saved photo"
        banner.visibility = View.VISIBLE
        if (textMissing && hasText) copySavedText(false)
    }

    private fun copySavedText(tapped: Boolean) {
        val t = job?.text?.takeIf { it.isNotBlank() } ?: return
        getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("QuestPilot saved text", t))
        if (tapped) toast("Saved text copied. Long-press the answer box on Zealy and paste.")
    }

    /** Banner button: choose a saved photo, attach it now if possible, and use it for the next file picker. */
    private fun pickSavedPhoto() {
        val j = job ?: return
        if (j.photos.isEmpty()) return
        val use = { f: java.io.File ->
            armedPhoto = f
            val w = web
            if (w != null && Autofill.matches(j, w.url)) {
                val js = Autofill.script(this)
                if (js != null) {
                    w.evaluateJavascript(js, null)
                    w.evaluateJavascript("window.__qpAttach(${Autofill.selectors(this)}, ${Autofill.payload(j, listOf(f))})", null)
                }
            }
            toast("If it isn't attached yet, tap the upload box on Zealy: your saved photo is picked automatically.")
        }
        if (j.photos.size == 1) use(j.photos[0])
        else AlertDialog.Builder(this)
            .setTitle("Saved photos")
            .setItems(j.photos.mapIndexed { i, f -> "Photo ${i + 1} (${f.name.takeLast(12)})" }.toTypedArray()) { _, which -> use(j.photos[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** WebView file picker: return the saved photo automatically, otherwise show the system picker. */
    private fun onFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
        val hidden = view === nextWeb
        if (!hidden) { chooserCallback?.onReceiveValue(null); chooserCallback = null }
        val j = if (hidden) nextJob else job
        val accept = params.acceptTypes.joinToString(",").lowercase()
        val acceptsImages = accept.isBlank() || accept.contains("image") || accept.contains("*") || Regex("\\.(jpe?g|png|webp)").containsMatchIn(accept)
        if (j != null && j.photos.isNotEmpty() && acceptsImages && Autofill.matches(j, view.url)) {
            val files = (if (hidden) null else armedPhoto?.let { listOf(it) })
                ?: if (params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) j.photos
                else listOf(j.photos[(if (hidden) nextPhotoCursor++ else photoCursor++) % j.photos.size])
            if (!hidden) armedPhoto = null
            try {
                cb.onReceiveValue(files.map { SavedPhotos.uri(this, it) }.toTypedArray())
                if (!hidden) {
                    banner.visibility = View.GONE
                    toast("Saved photo attached. Check it, then tap Claim.")
                }
                return true
            } catch (_: Exception) {
            }
        }
        if (hidden) { cb.onReceiveValue(null); return true } // never open the system picker from the waiting page
        chooserCallback = cb
        return try {
            @Suppress("DEPRECATION")
            startActivityForResult(params.createIntent(), REQ_CHOOSER)
            true
        } catch (_: Exception) {
            chooserCallback = null
            false
        }
    }

    @Deprecated("Activity result for the WebView file picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_CHOOSER) {
            chooserCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooserCallback = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    /** Test quests (debug builds) never trigger a sync of the real data. */
    private fun subOf(url: String) = if (queue.getOrNull(index)?.optString("source") == "test") "" else subOf0(url)
    private fun subOf0(url: String) = Regex("zealy\\.io/cw/([^/?#]+)").find(url)?.groupValues?.get(1) ?: ""

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        stopClaimCheck()
        SessionStore.captureFromWebView(this) // keep refreshed tokens
        web?.destroy()
        web = null
        discardNext()
        openCount--
        if (openCount <= 0) SessionStore.clearWebViewCookies()
        // A2: status only changes after a successful sync. Re-sync the communities we touched.
        val subs = touchedSubs.filter { it.isNotEmpty() }
        val ctx = applicationContext
        if (subs.isNotEmpty() && SessionStore.hasSession(ctx)) Executors.newSingleThreadExecutor().execute {
            Thread.sleep(2000)
            for (s in subs) ZealySync.syncAll(ctx, s)
        }
        super.onDestroy()
    }
}
