package io.questpilot.app

import android.content.Context
import android.net.Uri
import android.util.Base64
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Saved photos live as files in app storage (files/saved-photos), so they survive restarts and
 * app updates and never travel with each save of the data document. The document only keeps
 * `{id, name, thumb}` per photo. Sync never touches submissions or these files.
 */
object SavedPhotos {
    private fun dir(ctx: Context) = File(ctx.filesDir, "saved-photos").apply { mkdirs() }

    fun save(ctx: Context, dataUrl: String, name: String): String {
        val b64 = dataUrl.substringAfter("base64,", dataUrl)
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val ext = if (dataUrl.startsWith("data:image/png")) "png" else "jpg"
        val id = "${UUID.randomUUID()}.$ext"
        File(dir(ctx), id).writeBytes(bytes)
        return id
    }

    fun file(ctx: Context, id: String): File? = File(dir(ctx), File(id).name).takeIf { it.isFile }

    fun uri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    /** Remove photo files no submission refers to (only ones older than an hour, so a save in flight is safe). */
    fun gc(ctx: Context) {
        val db = DbStore.read()
        val used = mutableSetOf<String>()
        val subs = db.optJSONArray("submissions") ?: JSONArray()
        for (i in 0 until subs.length()) {
            val ims = subs.optJSONObject(i)?.optJSONArray("images") ?: continue
            for (k in 0 until ims.length()) ims.optJSONObject(k)?.optString("id")?.takeIf { it.isNotEmpty() }?.let { used.add(it) }
        }
        val cutoff = System.currentTimeMillis() - 3600_000L
        dir(ctx).listFiles()?.forEach { if (it.name !in used && it.lastModified() < cutoff) it.delete() }
    }
}

/** Saved content prepared for one opened quest. */
class AutofillJob(
    val questId: Int,
    val title: String,
    /** Zealy quest id the page path must contain (null for manual/test quests without one). */
    val expectPath: String?,
    /** The exact page that was opened; used when there's no Zealy quest id. */
    val expectUrl: String,
    val text: String?,
    val photos: List<File>,
    /** A "use once" entry that was picked but not yet marked used (see Autofill.commitUsed). */
    val pendingSubId: Int? = null,
) {
    val hasContent get() = !text.isNullOrBlank() || photos.isNotEmpty()
}

object Autofill {
    private const val SELECTORS_ASSET = "public/zealy-selectors.json"

    /** Page selectors live in one file: public/zealy-selectors.json (bundled into the app). */
    fun selectors(ctx: Context): String = try {
        JSONObject(ctx.assets.open(SELECTORS_ASSET).bufferedReader().readText()).toString()
    } catch (_: Exception) {
        """{"scope":["[role=dialog]","main"],"textInputs":["textarea","[contenteditable=true]","input[type=text]","input[type=url]","input:not([type])"],"excludeTextInputs":["[type=search]"],"fileInputs":["input[type=file]"],"dropZones":[],"retryMs":10000,"pollMs":300}"""
    }

    fun script(ctx: Context): String? = try { ctx.assets.open("qp-fill.js").bufferedReader().readText() } catch (_: Exception) { null }

    /**
     * Builds the job for a quest the user opened. One-time queued entries are marked used here;
     * "every claim" saved entries are never modified. The quest itself is never modified (A2).
     */
    fun prepare(ctx: Context, questId: Int, markUsed: Boolean = true): AutofillJob? {
        val db0 = DbStore.read()
        // Debug-build test quest: borrows a real quest's saved content read-only (never marks anything used).
        val testQ = if (DevTools.isTestId(questId)) DevTools.testQuest(ctx, questId) ?: return null else null
        val q = testQ ?: DbStore.quest(db0, questId) ?: return null
        val sourceId = testQ?.optInt("testSourceQuestId", 0)?.takeIf { it > 0 && !testQ.isNull("testSourceQuestId") }
        val contentQuest = sourceId?.let { DbStore.quest(db0, it) } ?: q
        val cid = contentQuest.optInt("id")
        var picked: JSONObject? = if (testQ != null && sourceId == null) null else pick(db0, cid)
        var pendingSubId: Int? = null
        if (!markUsed && testQ == null && picked?.optInt("repeat") == 0) {
            // Waiting page: read the entry but leave it unused until the page is actually shown (commitUsed).
            pendingSubId = picked?.optInt("id")
        } else if (testQ == null && picked?.optInt("repeat") == 0) {
            DbStore.mutate { db ->
                picked = pick(db, cid)
                picked?.let { if (it.optInt("repeat") == 0) it.put("usedAt", DbStore.nowIso()) }
            }
        }
        val s = picked
        var text = s?.let { if (it.isNull("text")) null else it.optString("text") }?.takeIf { it.isNotBlank() }
        val photos = s?.let { photosOf(ctx, it) } ?: emptyList()
        if (testQ != null && s == null) text = "QuestPilot autofill test" // test without saved content: shows the banner
        if (text == null && photos.isEmpty()) return null
        val zid = contentQuest.optString("zealyId").takeIf { it.isNotEmpty() && !contentQuest.isNull("zealyId") }
        val url = q.optString("url").ifEmpty { contentQuest.optString("url") }
        return AutofillJob(questId, q.optString("title"), zid, url, text, photos, pendingSubId)
    }

    /** Mark the "use once" entry of a job that was prepared with markUsed = false. Every-claim entries are never touched. */
    fun commitUsed(job: AutofillJob) {
        val sid = job.pendingSubId ?: return
        DbStore.mutate { db ->
            val sub = DbStore.findById(db.getJSONArray("submissions"), sid)
            if (sub != null && sub.optInt("repeat") == 0 && sub.isNull("usedAt")) sub.put("usedAt", DbStore.nowIso())
        }
    }

    private fun pick(db: JSONObject, cid: Int): JSONObject? {
        val subs = db.getJSONArray("submissions")
        val list = (0 until subs.length()).map { subs.getJSONObject(it) }.filter { it.optInt("questId") == cid }
        return list.firstOrNull { it.optInt("repeat") == 0 && it.isNull("usedAt") } ?: list.firstOrNull { it.optInt("repeat") == 1 }
    }

    private fun photosOf(ctx: Context, s: JSONObject): List<File> {
        val out = mutableListOf<File>()
        val ims = s.optJSONArray("images")
        if (ims != null && ims.length() > 0) {
            for (k in 0 until ims.length()) {
                val im = ims.optJSONObject(k) ?: continue
                val id = im.optString("id")
                if (id.isNotEmpty() && !im.isNull("id")) SavedPhotos.file(ctx, id)?.let { out.add(it) }
                else if (!im.isNull("data") && im.optString("data").isNotEmpty()) out.add(tempFile(ctx, im.optString("data"), im.optString("name", "photo.jpg")))
            }
        } else if (!s.isNull("image") && s.optString("image").isNotEmpty()) {
            out.add(tempFile(ctx, s.optString("image"), s.optString("imageName", "photo.jpg")))
        }
        return out
    }

    /** Older entries kept the photo inline: give the WebView a real file for it. */
    private fun tempFile(ctx: Context, dataUrl: String, name: String): File {
        val d = File(ctx.cacheDir, "autofill").apply { mkdirs() }
        val f = File(d, name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "photo.jpg" })
        f.writeBytes(Base64.decode(dataUrl.substringAfter("base64,", dataUrl), Base64.DEFAULT))
        return f
    }

    /** Safety gate: zealy.io only, and only the quest page that was opened. */
    fun matches(job: AutofillJob, current: String?): Boolean {
        val u = current?.let { Uri.parse(it) } ?: return false
        if (!ZealyWeb.isZealy(u)) return false
        return if (job.expectPath != null) (u.path ?: "").contains(job.expectPath)
        else strip(current).startsWith(strip(job.expectUrl))
    }

    private fun strip(u: String) = u.substringBefore('#').substringBefore('?').trimEnd('/')

    fun mimeOf(f: File) = if (f.name.endsWith(".png", true)) "image/png" else "image/jpeg"

    /** Payload for qp-fill.js. Photos go in as data URLs for the DataTransfer fallback. */
    fun payload(job: AutofillJob, photos: List<File> = job.photos): String {
        val arr = JSONArray()
        for (f in photos) {
            val b64 = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
            arr.put(JSONObject().put("name", f.name).put("mime", mimeOf(f)).put("data", "data:${mimeOf(f)};base64,$b64"))
        }
        return JSONObject()
            .put("expectPath", job.expectPath ?: JSONObject.NULL)
            .put("expectUrl", strip(job.expectUrl))
            .put("text", job.text ?: JSONObject.NULL)
            .put("images", arr)
            .toString()
    }
}
