package io.questpilot.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.webkit.CookieManager
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Zealy session cookies, encrypted with an AES-GCM key that lives in the Android Keystore.
 * Nothing else about the account (no password) is ever stored.
 */
object SessionStore {
    private const val ALIAS = "questpilot_session_key"
    private const val PREFS = "qp_session"
    /** Order matters: the first value seen for a cookie name wins (dedupe by name). */
    val ZEALY_URLS = listOf("https://zealy.io", "https://api-v2.zealy.io", "https://api-v1.zealy.io")

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(out, Base64.NO_WRAP)
    }

    private fun decrypt(enc: String): String? = try {
        val (iv, data) = enc.split(":", limit = 2)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
        String(c.doFinal(Base64.decode(data, Base64.NO_WRAP)), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }

    @Volatile private var cache: MutableMap<String, String>? = null

    @Synchronized
    fun cookies(ctx: Context): MutableMap<String, String> {
        cache?.let { return it }
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("c", null)
        val map = mutableMapOf<String, String>()
        raw?.let { decrypt(it) }?.let { s ->
            val o = JSONObject(s)
            o.keys().forEach { k -> map[k] = o.getString(k) }
        }
        cache = map
        return map
    }

    @Synchronized
    private fun persist(ctx: Context, map: Map<String, String>) {
        cache = map.toMutableMap()
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (map.isEmpty()) sp.remove("c") else sp.putString("c", encrypt(JSONObject(map).toString()))
        sp.apply()
    }

    fun hasSession(ctx: Context) = cookies(ctx).isNotEmpty()

    /** "name=value; name2=value2": one line, no quotes added, no duplicates, header-safe characters only. */
    fun cookieHeader(ctx: Context): String = buildHeader(cookies(ctx))

    fun buildHeader(map: Map<String, String>): String =
        map.entries.mapNotNull { (k, v) -> cleanPair(k, v) }.joinToString("; ") { "${it.first}=${it.second}" }

    private val NAME_OK = Regex("^[!#$%&'*+.^_`|~0-9A-Za-z-]+$")

    /** Drops broken pairs; strips CR/LF, control and non-ASCII characters (they'd make the header invalid). */
    private fun cleanPair(name: String, value: String): Pair<String, String>? {
        val n = name.trim()
        if (n.isEmpty() || !NAME_OK.matches(n)) return null
        // keep the value exactly as the browser would send it, minus anything that can't go in a header line
        val v = value.trim().filter { it.code in 0x21..0x7e && it != ';' }
        return n to v
    }

    /** Cookie names only (values hidden), for the debug log. */
    fun cookieNames(ctx: Context): List<String> = cookies(ctx).keys.toList()

    /**
     * Reads the WebView jar for zealy.io, api-v2 and api-v1 (CookieManager returns HttpOnly cookies
     * too), keeping the first value per name.
     */
    fun readWebViewCookies(): LinkedHashMap<String, String> {
        val cm = CookieManager.getInstance()
        val map = LinkedHashMap<String, String>()
        for (u in ZEALY_URLS) {
            cm.getCookie(u)?.split(";")?.forEach { kv ->
                val i = kv.indexOf('=')
                if (i > 0) {
                    val name = kv.substring(0, i).trim()
                    if (name.isNotEmpty() && !map.containsKey(name)) cleanPair(name, kv.substring(i + 1))?.let { map[it.first] = it.second }
                }
            }
        }
        return map
    }

    // ---- token from web storage (only used if zealy.io keeps one there; see ZealyLoginActivity) ----
    @Synchronized
    fun setBearer(ctx: Context, token: String?) {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (token.isNullOrBlank()) sp.remove("t") else sp.putString("t", encrypt(token))
        sp.apply()
    }

    fun bearer(ctx: Context): String? = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("t", null)?.let { decrypt(it) }

    /** "cookie" (default, what zealy.io itself does) or "bearer" when only the storage token works. */
    var authMode: String = "cookie"
        @Synchronized get
        @Synchronized set

    fun loadAuthMode(ctx: Context) {
        authMode = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("mode", "cookie") ?: "cookie"
    }

    fun saveAuthMode(ctx: Context, mode: String) {
        authMode = mode
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("mode", mode).apply()
    }

    /** userId from the non-secret `user_metadata` JWT cookie Zealy sets for its web app. */
    fun userIdFromCookie(ctx: Context): String? {
        val jwt = cookies(ctx)["user_metadata"] ?: return null
        return try {
            val part = jwt.split(".")[1]
            val json = String(Base64.decode(part, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING))
            JSONObject(json).optString("userId").ifEmpty { null }
        } catch (e: Exception) {
            null
        }
    }

    /** Read cookies from the WebView cookie jar into encrypted storage. */
    fun captureFromWebView(ctx: Context): Boolean {
        val map = readWebViewCookies()
        if (map.isEmpty() || !map.containsKey("user_metadata")) return false
        persist(ctx, map)
        return true
    }

    /** Merge Set-Cookie headers returned by the API (token refresh). */
    fun mergeSetCookie(ctx: Context, headers: List<String>?) {
        if (headers.isNullOrEmpty()) return
        val map = cookies(ctx).toMutableMap()
        var changed = false
        for (h in headers) {
            val first = h.split(";")[0]
            val i = first.indexOf('=')
            if (i <= 0) continue
            val name = first.substring(0, i).trim()
            val value = first.substring(i + 1).trim()
            val expired = Regex("(?i)max-age=0|expires=Thu, 01 Jan 1970").containsMatchIn(h)
            if (expired || value.isEmpty()) {
                if (map.remove(name) != null) changed = true
            } else if (map[name] != value) {
                map[name] = value; changed = true
            }
        }
        if (changed) persist(ctx, map)
    }

    /** Put the session into the WebView cookie jar, only while a Zealy WebView is open. */
    fun injectIntoWebView(ctx: Context) {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        for ((k, v) in cookies(ctx)) {
            cm.setCookie("https://zealy.io", "$k=$v; Domain=.zealy.io; Path=/; Secure")
        }
        cm.flush()
    }

    /** Clear the plain WebView cookie jar so the session only exists encrypted. */
    fun clearWebViewCookies() {
        val cm = CookieManager.getInstance()
        cm.removeAllCookies(null)
        cm.flush()
    }

    fun clear(ctx: Context) {
        persist(ctx, emptyMap())
        setBearer(ctx, null)
        saveAuthMode(ctx, "cookie")
        clearWebViewCookies()
    }
}
