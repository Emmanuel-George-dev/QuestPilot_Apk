package io.questpilot.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

object Notifications {
    const val CH_MONITOR = "monitoring"
    const val CH_ALERTS = "alerts"
    const val CH_CLAIM = "claim"
    const val ID_MONITOR = 1
    const val ID_SESSION = 2
    const val ID_CLAIM = 3

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MONITOR, "Monitoring Zealy", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Persistent notification while QuestPilot watches Zealy"
            setShowBadge(false)
        })
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "Quest alerts", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "New quests, unlocks, messages, deadlines"
        })
        nm.createNotificationChannel(NotificationChannel(CH_CLAIM, "Claim now (full screen)", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Opens the claim page the second a daily quest unlocks"
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
    }

    fun canPost(ctx: Context) =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun mutable() = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    /** Tap target: opens a Zealy link inside QuestPilot's signed-in Zealy view. */
    fun openUrlIntent(ctx: Context, url: String?, reqCode: Int, alertId: Int = 0, questId: Int = 0): PendingIntent {
        val i = if (url.isNullOrEmpty()) Intent(ctx, MainActivity::class.java)
        else Intent(ctx, ClaimActivity::class.java).putExtra(ClaimActivity.EXTRA_URL, url).putExtra(ClaimActivity.EXTRA_MODE, "browse")
        // With the quest id, the opened page autofills that quest's saved content (one-time tasks too).
        if (questId > 0 && !url.isNullOrEmpty()) i.putExtra(ClaimActivity.EXTRA_QUEST_ID, questId)
        i.putExtra("alertId", alertId).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, reqCode, i, mutable())
    }

    fun post(ctx: Context, id: Int, title: String, body: String, url: String?, channel: String = CH_ALERTS, questId: Int = 0) {
        if (!canPost(ctx)) return
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_qp)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openUrlIntent(ctx, url, id, id, questId))
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }

    /** Posts a stored alert as a system notification. */
    fun postAlert(ctx: Context, a: JSONObject) {
        val db = DbStore.read()
        val cid = a.optInt("communityId", 0)
        if (cid > 0 && DbStore.community(db, cid)?.optInt("notify", 1) == 0) return
        val url = a.optString("url").takeIf { it.isNotEmpty() && it != "null" }
        val qid = if (a.isNull("questId")) 0 else a.optInt("questId")
        post(ctx, 1000 + a.optInt("id") % 100000, a.optString("title"), a.optString("body"), url, questId = qid)
    }

    fun sessionExpired(ctx: Context) {
        if (!canPost(ctx)) return
        val pi = PendingIntent.getActivity(ctx, ID_SESSION, Intent(ctx, ZealyLoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), mutable())
        val n = NotificationCompat.Builder(ctx, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_qp)
            .setContentTitle("Zealy session expired, tap to reconnect.")
            .setContentText("Monitoring is paused until you reconnect.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(ID_SESSION, n)
    }

    fun cancel(ctx: Context, id: Int) = ctx.getSystemService(NotificationManager::class.java).cancel(id)
}

object Telegram {
    /** Always off the main thread (alarm receivers call this). */
    fun sendAlerts(ctx: Context, alerts: List<JSONObject>) {
        if (alerts.isEmpty()) return
        Thread { for (a in alerts) send(ctx, a.optString("title") + "\n" + a.optString("body")) }.start()
    }

    fun send(ctx: Context, text: String): Pair<Boolean, String?> {
        val s = DbStore.read().getJSONObject("settings")
        val token = s.optString("tgToken")
        val chat = s.optString("tgChat")
        if (token.isEmpty() || chat.isEmpty()) return false to "Telegram is not set up"
        return try {
            val conn = java.net.URL("https://api.telegram.org/bot$token/sendMessage").openConnection() as java.net.HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(JSONObject().put("chat_id", chat).put("text", text).toString().toByteArray()) }
            val ok = conn.responseCode in 200..299
            conn.disconnect()
            ok to if (ok) null else "Telegram rejected the message. Check the bot token and chat id."
        } catch (e: Exception) {
            false to (e.message ?: "Network error")
        }
    }
}
