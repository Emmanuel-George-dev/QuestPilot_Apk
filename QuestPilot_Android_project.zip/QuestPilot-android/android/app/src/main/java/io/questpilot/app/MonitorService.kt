package io.questpilot.app

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * C: foreground service with a persistent "Monitoring Zealy" notification.
 * B2 quest polling every 3 min and B3 message polling every 5 min run on separate exact alarms
 * (so they keep running in Doze and while the app is closed). Restarted after reboot by BootReceiver.
 */
class MonitorService : Service() {
    companion object {
        const val ACTION_START = "io.questpilot.START"
        const val ACTION_STOP = "io.questpilot.STOP"
        const val ACTION_QUESTS = "io.questpilot.TICK_QUESTS"
        const val ACTION_MESSAGES = "io.questpilot.TICK_MESSAGES"
        /** v2.4: the quest tick runs about once a minute; QuestMonitor picks which communities are due (3-4 min each, staggered). */
        const val QUEST_INTERVAL = 60_000L
        /**
         * v2.4.1: the message tick runs about every 75 s and MessageMonitor takes at most 4 due communities
         * per tick (tracked every 5 min, untracked every 15 min), so there is never a burst.
         */
        const val MESSAGE_INTERVAL = 60_000L
        /** Full sync (sprints, XP, community list). Default 30 min; Settings can make it 60. */
        const val FULL_SYNC_INTERVAL = 30 * 60_000L
        const val FULL_SYNC_SLOW = 60 * 60_000L

        /** 30 or 60 min from Settings; 60 until the next app restart after any 429/403 in a full sync. */
        fun fullSyncInterval(): Long {
            if (State.slowFullSync) return FULL_SYNC_SLOW
            val m = try { DbStore.prefs(DbStore.read()).optInt("fullSyncMinutes", 30) } catch (_: Exception) { 30 }
            return if (m >= 60) FULL_SYNC_SLOW else FULL_SYNC_INTERVAL
        }
        @Volatile var running = false

        /** "Watching 8 communities with a running sprint, each about every 4 min" with the real numbers. */
        fun watchSummary(): String = try {
            val db = DbStore.read()
            val n = QuestMonitor.targets(db).size
            val sprints = QuestMonitor.activeSprintCount(db)
            val every = QuestMonitor.realIntervalMin(db)
            val what = if (QuestMonitor.sprintOnly(db)) {
                if (n == sprints) "$n communit${if (n == 1) "y" else "ies"} with a running sprint" else "$n communities ($sprints with a running sprint)"
            } else "$n communit${if (n == 1) "y" else "ies"}"
            "Watching $what, each about every $every min"
        } catch (_: Exception) { "Watching Zealy" }

        fun start(ctx: Context) {
            if (!State.monitoringEnabled || !SessionStore.hasSession(ctx)) return
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java).setAction(ACTION_START))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            cancelTicks(ctx)
            ctx.stopService(Intent(ctx, MonitorService::class.java))
            running = false
            QuestPilotPlugin.emitStatus(ctx)
        }

        private fun tickIntent(ctx: Context, action: String, req: Int, create: Boolean): PendingIntent? {
            val i = Intent(ctx, MonitorService::class.java).setAction(action)
            val f = PendingIntent.FLAG_IMMUTABLE or if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
            return PendingIntent.getForegroundService(ctx, req, i, f)
        }

        /** Next tick times (memory). Opening the app again doesn't reschedule ticks that are still coming. */
        @Volatile private var nextQuestAt = 0L
        @Volatile private var nextMessageAt = 0L

        /** v2.4.2 Fix 2: first quest tick +30 s, first message tick +90 s, each with jitter, never together. */
        const val FIRST_QUEST_DELAY = 30_000L
        const val FIRST_MESSAGE_DELAY = 90_000L
        /** The automatic full sync waits 5 min after the process started (60 s if no full sync ever succeeded). */
        const val FULL_SYNC_START_DELAY = 5 * 60_000L
        const val FIRST_FULL_SYNC_DELAY = 60_000L

        fun fullSyncAllowedAt(): Long =
            State.processStartAt + if (State.fullSyncOkAt == 0L) FIRST_FULL_SYNC_DELAY else FULL_SYNC_START_DELAY

        fun scheduleTick(ctx: Context, action: String, at: Long) {
            if (action == ACTION_QUESTS) nextQuestAt = at else nextMessageAt = at
            val req = if (action == ACTION_QUESTS) 9001 else 9002
            AlarmScheduler.setAlarm(ctx, at, tickIntent(ctx, action, req, true)!!)
        }

        fun cancelTicks(ctx: Context) {
            nextQuestAt = 0L
            nextMessageAt = 0L
            val am = ctx.getSystemService(AlarmManager::class.java)
            tickIntent(ctx, ACTION_QUESTS, 9001, false)?.let { am.cancel(it) }
            tickIntent(ctx, ACTION_MESSAGES, 9002, false)?.let { am.cancel(it) }
        }
    }

    private val exec = Executors.newSingleThreadExecutor()
    /** v2.4.1: the full sync has its own thread, so a long sweep never blocks quest or message checks. */
    private val syncExec = Executors.newSingleThreadExecutor()
    private val questBusy = AtomicBoolean(false)
    private val messageBusy = AtomicBoolean(false)
    private val syncBusy = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (intent?.action == ACTION_STOP || !State.monitoringEnabled || !SessionStore.hasSession(this)) {
            stop(this)
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        QuestPilotPlugin.emitStatus(this)
        when (intent?.action) {
            ACTION_QUESTS -> runCycle(questBusy) { QuestMonitor.run(this) }.also { next(ACTION_QUESTS) }
            ACTION_MESSAGES -> {
                runCycle(messageBusy) { MessageMonitor.run(this) }
                val now = System.currentTimeMillis()
                // v2.4.2: never right after start (5 min, or 60 s before the first successful full sync)
                if (now >= fullSyncAllowedAt() && now - State.lastFullSyncAt > fullSyncInterval()) runFullSync()
                next(ACTION_MESSAGES)
            }
            else -> { // start / restart (app opened, reboot, app update)
                // v2.4.2: opening the app calls start() every time. Ticks that are still coming are kept, so
                // opening the app no longer fires a quest check at +5 s and a message check at +25 s.
                val now = System.currentTimeMillis()
                if (nextQuestAt < now - 60_000L) scheduleTick(this, ACTION_QUESTS, now + FIRST_QUEST_DELAY + Random.nextLong(0, 15_000))
                if (nextMessageAt < now - 60_000L) scheduleTick(this, ACTION_MESSAGES, now + FIRST_MESSAGE_DELAY + Random.nextLong(0, 30_000))
            }
        }
        return START_STICKY
    }

    private fun paused() = State.paused()

    /** Automatic full sync: checks the pause first, 10-minute wake lock renewed between communities. */
    private fun runFullSync() {
        if (paused() || !syncBusy.compareAndSet(false, true)) return
        syncExec.execute {
            val wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "QuestPilot:fullsync")
            wl.setReferenceCounted(false)
            wl.acquire(10 * 60_000L)
            try {
                ZealySync.syncAll(this, onlyAutoSync = true, respectPause = true, wakeLock = wl)
            } catch (_: Exception) {
            } finally {
                syncBusy.set(false)
                if (wl.isHeld) wl.release()
                updateNotification()
                QuestPilotPlugin.emitStatus(this)
            }
        }
    }

    private fun next(action: String) {
        val now = System.currentTimeMillis()
        val base = if (action == ACTION_QUESTS) QUEST_INTERVAL + Random.nextLong(0, 10_000) else MESSAGE_INTERVAL + Random.nextLong(0, 30_000) // ~60-90 s
        val at = maxOf(now + base, if (State.pausedUntil > now) State.pausedUntil + Random.nextLong(1_000, 15_000) else 0L)
        scheduleTick(this, action, at)
    }

    private fun runCycle(flag: AtomicBoolean, work: () -> Unit) {
        if (paused() || !flag.compareAndSet(false, true)) return
        exec.execute {
            val wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "QuestPilot:poll")
            wl.acquire(4 * 60_000L)
            try {
                work()
            } catch (_: Exception) {
            } finally {
                flag.set(false)
                if (wl.isHeld) wl.release()
                updateNotification()
                QuestPilotPlugin.emitStatus(this)
            }
        }
    }

    private fun text(): String {
        val now = System.currentTimeMillis()
        return when {
            State.sessionExpired -> "Zealy session expired, tap to reconnect"
            State.pausedUntil > now -> "Paused (${State.pauseReason ?: "Zealy rate limit"}) · resumes ${DbStore.localClock(State.pausedUntil)}"
            else -> watchSummary() + (if (State.slowFullSync) " · full sync every 60 min (rate limit)" else "") +
                maxOf(State.lastQuestPollAt, State.lastSyncAt).let { if (it > 0) " · last check ${DbStore.localClock(it)}" else "" }
        }
    }

    private fun build() = NotificationCompat.Builder(this, Notifications.CH_MONITOR)
        .setSmallIcon(R.drawable.ic_stat_qp)
        .setContentTitle("Monitoring Zealy")
        .setContentText(text())
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        .build()

    private fun goForeground() {
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, Notifications.ID_MONITOR, build(), type)
    }

    private fun updateNotification() {
        if (Notifications.canPost(this)) getSystemService(NotificationManager::class.java).notify(Notifications.ID_MONITOR, build())
    }

    override fun onDestroy() {
        running = false
        exec.shutdown()
        syncExec.shutdown()
        super.onDestroy()
    }
}

/** 429/403 backoff: pause 5 minutes, doubling while it repeats. */
object Backoff {
    @Volatile private var graceArmed = false
    @Volatile private var graceUsed = false

    /**
     * Pause after a real rate limit or block. [reason] is shown in the status line.
     * v2.4.2: a 403 block within 3 minutes of process start gets exactly one retry after its pause at the
     * same level, before the next level (10 min, 20 min, ...) is counted.
     */
    fun hit(ctx: Context, code: Int, reason: String? = null) {
        val now = System.currentTimeMillis()
        val level = if (graceArmed) { graceArmed = false; maxOf(1, State.backoffLevel) } else State.backoffLevel + 1
        if (code == 403 && !graceUsed && now - State.processStartAt < 3 * 60_000L) { graceArmed = true; graceUsed = true }
        State.backoffLevel = level
        val wait = (5 * 60_000L shl (level - 1).coerceAtMost(5)) // 5, 10, 20, 40, 80, 160 min
        State.pausedUntil = now + wait
        State.pauseReason = reason ?: "Zealy answered $code"
        QuestPilotPlugin.emitStatus(ctx)
    }

    fun ok() {
        if (State.backoffLevel != 0 || State.pausedUntil != 0L) {
            State.backoffLevel = 0
            State.pausedUntil = 0
            State.pauseReason = null
        }
    }
}
