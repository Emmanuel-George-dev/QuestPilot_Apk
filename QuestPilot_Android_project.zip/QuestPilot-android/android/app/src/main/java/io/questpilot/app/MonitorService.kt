package io.questpilot.app

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * C: foreground service with a persistent "Monitoring Zealy" notification.
 * B2 quest polling every 3 min and B3 message polling every 5 min run on separate exact alarms
 * (so they keep running in Doze and while the app is closed). Restarted after reboot by BootReceiver.
 */
class MonitorService : Service() {
    companion object {
        const val ACTION_START = "io.questpilot.START"
        const val ACTION_STOP = "io.questpilot.STOP"
        const val ACTION_QUESTS = "io.questpilot.TICK_QUESTS"
        const val ACTION_MESSAGES = "io.questpilot.TICK_MESSAGES"
        const val QUEST_INTERVAL = 180_000L
        const val MESSAGE_INTERVAL = 300_000L
        const val FULL_SYNC_INTERVAL = 30 * 60_000L
        @Volatile var running = false

        fun start(ctx: Context) {
            if (!State.monitoringEnabled || !SessionStore.hasSession(ctx)) return
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java).setAction(ACTION_START))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            cancelTicks(ctx)
            ctx.stopService(Intent(ctx, MonitorService::class.java))
            running = false
            QuestPilotPlugin.emitStatus(ctx)
        }

        private fun tickIntent(ctx: Context, action: String, req: Int, create: Boolean): PendingIntent? {
            val i = Intent(ctx, MonitorService::class.java).setAction(action)
            val f = PendingIntent.FLAG_IMMUTABLE or if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
            return PendingIntent.getForegroundService(ctx, req, i, f)
        }

        fun scheduleTick(ctx: Context, action: String, at: Long) {
            val req = if (action == ACTION_QUESTS) 9001 else 9002
            AlarmScheduler.setAlarm(ctx, at, tickIntent(ctx, action, req, true)!!)
        }

        fun cancelTicks(ctx: Context) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            tickIntent(ctx, ACTION_QUESTS, 9001, false)?.let { am.cancel(it) }
            tickIntent(ctx, ACTION_MESSAGES, 9002, false)?.let { am.cancel(it) }
        }
    }

    private val exec = Executors.newSingleThreadExecutor()
    private val questBusy = AtomicBoolean(false)
    private val messageBusy = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (intent?.action == ACTION_STOP || !State.monitoringEnabled || !SessionStore.hasSession(this)) {
            stop(this)
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        QuestPilotPlugin.emitStatus(this)
        when (intent?.action) {
            ACTION_QUESTS -> runCycle(questBusy) { QuestMonitor.run(this) }.also { next(ACTION_QUESTS) }
            ACTION_MESSAGES -> runCycle(messageBusy) {
                MessageMonitor.run(this)
                if (System.currentTimeMillis() - State.lastFullSyncAt > FULL_SYNC_INTERVAL && !paused()) ZealySync.syncAll(this, onlyAutoSync = true)
            }.also { next(ACTION_MESSAGES) }
            else -> { // start / restart
                val now = System.currentTimeMillis()
                scheduleTick(this, ACTION_QUESTS, now + 5_000)
                scheduleTick(this, ACTION_MESSAGES, now + 25_000)
            }
        }
        return START_STICKY
    }

    private fun paused() = State.pausedUntil > System.currentTimeMillis() || State.sessionExpired

    private fun next(action: String) {
        val now = System.currentTimeMillis()
        val base = if (action == ACTION_QUESTS) QUEST_INTERVAL + Random.nextLong(0, 20_000) else MESSAGE_INTERVAL + Random.nextLong(0, 30_000)
        val at = maxOf(now + base, if (State.pausedUntil > now) State.pausedUntil + Random.nextLong(1_000, 15_000) else 0L)
        scheduleTick(this, action, at)
    }

    private fun runCycle(flag: AtomicBoolean, work: () -> Unit) {
        if (paused() || !flag.compareAndSet(false, true)) return
        exec.execute {
            val wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "QuestPilot:poll")
            wl.acquire(4 * 60_000L)
            try {
                work()
            } catch (_: Exception) {
            } finally {
                flag.set(false)
                if (wl.isHeld) wl.release()
                updateNotification()
                QuestPilotPlugin.emitStatus(this)
            }
        }
    }

    private fun text(): String {
        val now = System.currentTimeMillis()
        return when {
            State.sessionExpired -> "Zealy session expired, tap to reconnect"
            State.pausedUntil > now -> "Paused after Zealy rate limit · resumes ${DbStore.localClock(State.pausedUntil)}"
            else -> {
                val n = DbStore.read().getJSONObject("settings").optJSONArray("watchlist")?.length() ?: 0
                val last = maxOf(State.lastQuestPollAt, State.lastSyncAt)
                "Watching $n communities · messages from all" + if (last > 0) " · last check ${DbStore.localClock(last)}" else ""
            }
        }
    }

    private fun build() = NotificationCompat.Builder(this, Notifications.CH_MONITOR)
        .setSmallIcon(R.drawable.ic_stat_qp)
        .setContentTitle("Monitoring Zealy")
        .setContentText(text())
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        .build()

    private fun goForeground() {
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, Notifications.ID_MONITOR, build(), type)
    }

    private fun updateNotification() {
        if (Notifications.canPost(this)) getSystemService(NotificationManager::class.java).notify(Notifications.ID_MONITOR, build())
    }

    override fun onDestroy() {
        running = false
        exec.shutdown()
        super.onDestroy()
    }
}

/** 429/403 backoff: pause 5 minutes, doubling while it repeats. */
object Backoff {
    fun hit(ctx: Context, code: Int) {
        val level = State.backoffLevel + 1
        State.backoffLevel = level
        val wait = (5 * 60_000L shl (level - 1).coerceAtMost(5)) // 5, 10, 20, 40, 80, 160 min
        State.pausedUntil = System.currentTimeMillis() + wait
        State.pauseReason = "Zealy answered $code"
        QuestPilotPlugin.emitStatus(ctx)
    }

    fun ok() {
        if (State.backoffLevel != 0 || State.pausedUntil != 0L) {
            State.backoffLevel = 0
            State.pausedUntil = 0
            State.pauseReason = null
        }
    }
}
