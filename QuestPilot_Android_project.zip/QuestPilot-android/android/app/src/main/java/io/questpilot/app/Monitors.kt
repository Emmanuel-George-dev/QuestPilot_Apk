package io.questpilot.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.random.Random

/** Saved baselines for B2 and last-seen message ids for B3. */
object MonitorState {
    private val lock = Any()
    private fun file(ctx: Context) = File(ctx.filesDir, "monitor-state.json")
    fun read(ctx: Context): JSONObject = synchronized(lock) {
        try { JSONObject(file(ctx).readText()) } catch (e: Exception) { JSONObject() }
    }.also { s ->
        for (k in listOf("quests", "messages", "communityCache")) if (s.optJSONObject(k) == null) s.put(k, JSONObject())
    }

    fun write(ctx: Context, s: JSONObject) = synchronized(lock) {
        val tmp = File(ctx.filesDir, "monitor-state.json.tmp")
        tmp.writeText(s.toString())
        tmp.renameTo(file(ctx))
    }
}

private fun jitterSleep() = Thread.sleep(Random.nextLong(1000, 2000) + Random.nextLong(0, 400))

/** Returns false if the poll must stop (rate limit / auth problem). */
private fun handleErrors(ctx: Context, r: ZealyApi.Resp): Boolean {
    if (r.code == 429 || r.code == 403) {
        Backoff.hit(ctx, r.code)
        if (r.code == 403) Session.onAuthFailure(ctx)
        return false
    }
    if (r.code == 401) {
        Session.onAuthFailure(ctx)
        return false
    }
    return true
}

/** B2: watchlist questboards every 3 minutes. */
object QuestMonitor {
    fun run(ctx: Context) {
        val db = DbStore.read()
        val watch = db.getJSONObject("settings").optJSONArray("watchlist").toStringSet().toList().take(3)
        if (watch.isEmpty()) { State.lastQuestPollAt = System.currentTimeMillis(); return }
        val state = MonitorState.read(ctx)
        val base = state.getJSONObject("quests")
        for ((i, sub) in watch.withIndex()) {
            if (i > 0) jitterSleep()
            val r = ZealyApi.questboard(ctx, sub)
            if (!handleErrors(ctx, r)) break
            val modules = ZealyApi.modules(r)
            if (!r.ok || modules == null) continue // failed: skip this run, keep saved data
            val current = JSONObject()
            for (m in 0 until modules.length()) {
                val qs = modules.optJSONObject(m)?.optJSONArray("quests") ?: continue
                for (k in 0 until qs.length()) {
                    val zq = qs.optJSONObject(k) ?: continue
                    val id = zq.optString("id")
                    if (id.isEmpty()) continue
                    current.put(id, JSONObject().put("name", zq.optString("name")).put("xp", ZealySync.xpOf(zq))
                        .put("locked", zq.optBoolean("locked")).put("url", ZealySync.questUrl(sub, zq)))
                }
            }
            if (current.length() == 0) continue // empty: skip, never overwrite the baseline
            Backoff.ok()
            Session.onSuccess(ctx)
            val prev = base.optJSONObject(sub)
            val tracked = ZealySync.findCommunity(db, sub)
            val communityName = tracked?.optString("name")?.ifEmpty { null } ?: sub
            DbStore.mutate { d ->
                if (prev != null) {
                    val cid = ZealySync.findCommunity(d, sub)?.optInt("id")
                    current.keys().forEach { id ->
                        val q = current.getJSONObject(id)
                        val before = prev.optJSONObject(id)
                        if (before == null) {
                            DbStore.addAlert(d, "quest-new", "New quest: ${q.optString("name")}, ${q.optInt("xp")} XP, $communityName",
                                communityName, null, cid, "qnew-$sub-$id", q.optString("url"))
                        } else if (before.optBoolean("locked") && !q.optBoolean("locked")) {
                            DbStore.addAlert(d, "quest-unlocked", "Quest unlocked: ${q.optString("name")}", communityName,
                                null, cid, "qunl-$sub-$id-${System.currentTimeMillis() / 60000}", q.optString("url"))
                        }
                    }
                }
                // keep tracked communities' statuses fresh from the same successful fetch
                if (tracked != null) ZealySync.apply(d, JSONObject().put("subdomain", sub).put("name", communityName).put("questboard", modules))
            }
            base.put(sub, current) // first run = baseline, no alerts
            MonitorState.write(ctx, state)
        }
        State.lastQuestPollAt = System.currentTimeMillis()
    }
}

/** B3: notifications from every joined community, every 5 minutes. */
object MessageMonitor {
    private const val COMMUNITY_CACHE_MS = 30 * 60_000L

    fun run(ctx: Context) {
        val userId = State.userId ?: SessionStore.userIdFromCookie(ctx) ?: ZealySync.ensureUser(ctx).first ?: return
        val state = MonitorState.read(ctx)
        val cache = state.getJSONObject("communityCache")
        var list = cache.optJSONArray("list")
        if (list == null || System.currentTimeMillis() - cache.optLong("at") > COMMUNITY_CACHE_MS) {
            val (r, comms) = ZealyApi.myCommunities(ctx, userId)
            if (!handleErrors(ctx, r)) return
            if (comms.isNotEmpty()) {
                list = JSONArray().apply { comms.forEach { put(JSONObject().put("subdomain", it.first).put("name", it.second)) } }
                cache.put("list", list).put("at", System.currentTimeMillis())
                MonitorState.write(ctx, state)
            }
        }
        if (list == null || list.length() == 0) { State.lastMessagePollAt = System.currentTimeMillis(); return }
        val seenAll = state.getJSONObject("messages")
        for (i in 0 until list.length()) {
            if (i > 0) jitterSleep()
            val c = list.getJSONObject(i)
            val sub = c.optString("subdomain")
            val r = ZealyApi.notifications(ctx, sub, userId)
            if (!handleErrors(ctx, r)) break
            if (!r.ok) continue
            val items = (r.body as? JSONObject)?.optJSONArray("items") ?: continue
            Backoff.ok()
            Session.onSuccess(ctx)
            val seen = seenAll.optJSONArray(sub)
            val seenSet = seen.toRawSet()
            val ids = (0 until items.length()).mapNotNull { items.optJSONObject(it) }.filter { it.optString("id").isNotEmpty() }
            if (seen == null) { // first run for this community: baseline, no alerts
                seenAll.put(sub, JSONArray(ids.map { it.optString("id") }))
                MonitorState.write(ctx, state)
                continue
            }
            val fresh = ids.filter { it.optString("id") !in seenSet }
            if (fresh.isEmpty()) continue
            val name = c.optString("name").ifEmpty { sub }
            DbStore.mutate { d ->
                val cid = ZealySync.findCommunity(d, sub)?.optInt("id")
                for (n in fresh.reversed()) {
                    val (line, url) = describe(sub, n)
                    DbStore.addAlert(d, "message", name, line, null, cid, "msg-$sub-${n.optString("id")}", url)
                }
            }
            val merged = JSONArray()
            (fresh.map { it.optString("id") } + seenSet).distinct().take(200).forEach { merged.put(it) }
            seenAll.put(sub, merged)
            MonitorState.write(ctx, state)
        }
        State.lastMessagePollAt = System.currentTimeMillis()
    }

    /** First line of a Zealy notification + the page it should open. */
    fun describe(sub: String, n: JSONObject): Pair<String, String> {
        val type = n.optString("type")
        val d = n.optJSONObject("data") ?: JSONObject()
        val board = "https://zealy.io/cw/$sub/questboard"
        fun str(vararg keys: String) = keys.firstNotNullOfOrNull { k -> d.optString(k).takeIf { it.isNotBlank() && it != "null" } }
        val comment = str("comment", "message", "text")
        val text = when (type) {
            "review" -> {
                val quest = d.optJSONObject("resource")?.optString("name")?.ifEmpty { null } ?: str("questName") ?: "your quest"
                val st = str("status", "mark") ?: "reviewed"
                val verdict = when (st) { "success" -> "approved"; "fail" -> "rejected"; else -> st }
                "Claim $verdict: $quest" + (comment?.let { " — $it" } ?: "")
            }
            "manual-xp" -> "You received ${d.optInt("value")} XP" + (comment?.let { " — $it" } ?: "")
            "partnership-requested" -> comment ?: "New partnership request from ${str("communityName") ?: "a community"}"
            "partnership-accepted" -> "Partnership accepted" + (str("communityName")?.let { " by $it" } ?: "")
            "invite-accepted" -> "Someone joined with your invite"
            else -> comment ?: type.replace('-', ' ').replaceFirstChar { it.uppercase() }
        }
        val claimId = str("claimId", "claimedQuestId")
        val url = if (claimId != null) "https://zealy.io/cw/$sub/inbox/$claimId" else board
        return text.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().take(200) to url
    }
}

fun JSONArray?.toRawSet(): Set<String> {
    if (this == null) return emptySet()
    return (0 until length()).map { optString(it) }.toSet()
}
