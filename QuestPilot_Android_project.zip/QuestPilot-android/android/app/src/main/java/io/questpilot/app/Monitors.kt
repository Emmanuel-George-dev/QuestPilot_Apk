package io.questpilot.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.random.Random

/** Saved baselines for B2 and last-seen message ids for B3. */
object MonitorState {
    private val lock = Any()
    private fun file(ctx: Context) = File(ctx.filesDir, "monitor-state.json")
    fun read(ctx: Context): JSONObject = synchronized(lock) {
        try { JSONObject(file(ctx).readText()) } catch (e: Exception) { JSONObject() }
    }.also { s ->
        for (k in listOf("quests", "messages", "communityCache", "polledAt", "msgPolledAt")) if (s.optJSONObject(k) == null) s.put(k, JSONObject())
    }

    fun write(ctx: Context, s: JSONObject) = synchronized(lock) {
        val tmp = File(ctx.filesDir, "monitor-state.json.tmp")
        tmp.writeText(s.toString())
        tmp.renameTo(file(ctx))
    }
}

private fun jitterSleep() = Thread.sleep(Random.nextLong(1000, 2000) + Random.nextLong(0, 400))

/** Counts consecutive 403s from different communities within one monitor run. */
class RunGuard { var consecutive403 = 0 }

/**
 * v2.4.2: the same 403 rule as the full sync. Returns false if the poll must stop.
 *   - 429, a bot-protection page, or 3 different communities in a row answering 403: Backoff.hit, stop.
 *   - 403 on one community's request ([sub] + [ep]): that community is marked "no access", skipped for
 *     6 h, and the run goes on with the others. No pause, no Session.onAuthFailure.
 *   - 403 on an account request ([sub] null: the community list): backoff + session problem, as before.
 *   - 401: session problem, stop (as before). Paused (request not sent): stop.
 */
internal fun handleErrors(ctx: Context, r: ZealyApi.Resp, sub: String? = null, ep: String = "", guard: RunGuard? = null): Boolean {
    if (r.skipped) return false
    if (r.code == 429) {
        Backoff.hit(ctx, 429, "rate limit (429)")
        EventLog.add("monitor", Zealy403.line(r, "checks stopped, paused until ${DbStore.localClock(State.pausedUntil)}"))
        return false
    }
    if (r.code == 403) {
        when {
            Zealy403.isChallenge(r) -> Backoff.hit(ctx, 403, "blocked: bot-protection page (403)")
            sub == null -> { Backoff.hit(ctx, 403, "403 on ${Zealy403.path(r.url)}"); Session.onAuthFailure(ctx) }
            else -> {
                NoAccess.mark(ctx, sub, ep)
                val n = (guard?.consecutive403 ?: 0) + 1
                guard?.consecutive403 = n
                if (n < 3) {
                    EventLog.add("monitor", Zealy403.line(r, "$sub skipped for 6 h, the others go on"))
                    return true
                }
                Backoff.hit(ctx, 403, "blocked: 3 communities in a row answered 403")
            }
        }
        EventLog.add("monitor", Zealy403.line(r, "checks stopped (${State.pauseReason}), paused until ${DbStore.localClock(State.pausedUntil)}"))
        return false
    }
    if (r.code == 401) {
        Session.onAuthFailure(ctx)
        return false
    }
    if (r.ok && sub != null) { guard?.consecutive403 = 0; NoAccess.clear(ctx, sub, ep) }
    return true
}

/**
 * B2 (v2.4.1): fast, staggered questboard checks, only for communities that matter right now.
 * The service ticks about once a minute; each tick polls only the communities that are due:
 *   - communities with a locked quest that has no known unlock time: every 3 minutes
 *   - communities with a running sprint (saved sprintEndsAt in the future) and the watchlist: every 4 minutes (+ jitter)
 * Every other auto-synced community is refreshed only by the automatic full sync (30 min by default),
 * which also refreshes sprintEndsAt, so a newly started sprint joins this cycle after the next full sync.
 * Settings "Only watch communities with a running sprint" off = every auto-synced community, as in v2.4.0.
 * At most [PER_TICK] communities per tick, with a pause between them. Alarms never depend on this polling.
 */
object QuestMonitor {
    const val LOCKED_EVERY_MS = 3 * 60_000L
    const val NORMAL_EVERY_MS = 4 * 60_000L
    const val PER_TICK = 4

    fun sprintOnly(db: JSONObject) = DbStore.pref(db, "sprintOnlyWatch", true)

    private fun sprintRunning(c: JSONObject, now: Long) = (UnlockClock.parseTime(c.opt("sprintEndsAt")) ?: 0L) > now

    fun activeSprintCount(db: JSONObject): Int {
        val now = System.currentTimeMillis()
        val comms = db.getJSONArray("communities")
        return (0 until comms.length()).count { comms.getJSONObject(it).let { c -> c.optInt("autoSync", 1) == 1 && sprintRunning(c, now) } }
    }

    /**
     * Real time between two checks of one community: max(floor, N / 4) minutes, because a tick (about one
     * a minute) takes at most 4. The floor is the due interval: 4 min, or 3 when every target is a
     * locked-without-timer community. Above 16 communities the shown interval grows with N.
     */
    fun realIntervalMin(db: JSONObject): Int {
        val t = targets(db)
        val floor = if (t.isNotEmpty() && t.values.all { it == LOCKED_EVERY_MS }) 3 else 4
        return maxOf(floor, (t.size + PER_TICK - 1) / PER_TICK)
    }

    /** Subdomains to poll, with their interval. */
    fun targets(db: JSONObject): LinkedHashMap<String, Long> {
        val out = linkedMapOf<String, Long>()
        val now = System.currentTimeMillis()
        val onlySprints = sprintOnly(db)
        val comms = db.getJSONArray("communities")
        val quests = db.getJSONArray("quests")
        val lockedNoTime = mutableSetOf<Int>()
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            val z = q.optJSONObject("zealy") ?: continue
            if (z.optBoolean("locked") && !z.optBoolean("claimed") && !z.optBoolean("completed") && q.isNull("unlockAt")) lockedNoTime.add(q.optInt("communityId"))
        }
        for (i in 0 until comms.length()) {
            val c = comms.getJSONObject(i)
            if (c.optInt("autoSync", 1) != 1) continue
            val sub = c.optString("subdomain")
            if (sub.isEmpty()) continue
            val locked = c.optInt("id") in lockedNoTime
            if (onlySprints && !locked && !sprintRunning(c, now)) continue // refreshed by the full sync only
            out[sub.lowercase()] = if (locked) LOCKED_EVERY_MS else NORMAL_EVERY_MS
        }
        for (w in db.getJSONObject("settings").optJSONArray("watchlist").toStringSet()) if (!out.containsKey(w)) out[w] = NORMAL_EVERY_MS
        return out
    }

    fun run(ctx: Context) {
        val db = DbStore.read()
        val all = targets(db)
        val now0 = System.currentTimeMillis()
        if (all.isEmpty()) { State.lastQuestPollAt = now0; return }
        val state = MonitorState.read(ctx)
        val base = state.getJSONObject("quests")
        val polled = state.optJSONObject("polledAt") ?: JSONObject().also { state.put("polledAt", it) }
        // Due = interval passed (each community gets its own jitter so they spread out). Oldest first.
        val due = all.entries.filter { (sub, every) ->
            val jitter = (sub.hashCode() and 0x7fffffff) % 40_000L
            now0 - polled.optLong(sub, 0L) >= every - 20_000L + jitter && !NoAccess.skip(ctx, sub, "questboard")
        }.sortedBy { polled.optLong(it.key, 0L) }.take(PER_TICK).map { it.key }
        val guard = RunGuard()
        for ((i, sub) in due.withIndex()) {
            if (i > 0) jitterSleep()
            if (!pollOne(ctx, sub, base, guard)) break
            polled.put(sub, System.currentTimeMillis())
            MonitorState.write(ctx, state)
        }
        State.lastQuestPollAt = System.currentTimeMillis()
        if (due.isNotEmpty()) try { AlarmScheduler.verify(ctx) } catch (_: Exception) {}
    }

    /** One community's questboard. Returns false when polling must stop (rate limit / auth). */
    fun pollOne(ctx: Context, sub: String, base: JSONObject, guard: RunGuard = RunGuard()): Boolean {
        val r = ZealyApi.questboard(ctx, sub)
        if (!handleErrors(ctx, r, sub, "questboard", guard)) return false
        val modules = ZealyApi.modules(r)
        if (!r.ok || modules == null) return true // failed: skip this one, keep saved data
        val current = JSONObject()
        for (m in 0 until modules.length()) {
            val qs = modules.optJSONObject(m)?.optJSONArray("quests") ?: continue
            for (k in 0 until qs.length()) {
                val zq = qs.optJSONObject(k) ?: continue
                val id = zq.optString("id")
                if (id.isEmpty()) continue
                current.put(id, JSONObject().put("name", zq.optString("name")).put("xp", ZealySync.xpOf(zq))
                    .put("locked", zq.optBoolean("locked")).put("url", ZealySync.questUrl(sub, zq)))
            }
        }
        if (current.length() == 0) return true // empty: skip, never overwrite the baseline
        Backoff.ok()
        Session.onSuccess(ctx)
        val prev = base.optJSONObject(sub)
        val db = DbStore.read()
        val tracked = ZealySync.findCommunity(db, sub)
        val communityName = tracked?.optString("name")?.ifEmpty { null } ?: sub
        DbStore.mutate { d ->
            if (prev != null) {
                val cid = ZealySync.findCommunity(d, sub)?.optInt("id")
                current.keys().forEach { id ->
                    val q = current.getJSONObject(id)
                    val before = prev.optJSONObject(id)
                    if (before == null) {
                        DbStore.addAlert(d, "quest-new", "New quest: ${q.optString("name")}, ${q.optInt("xp")} XP, $communityName",
                            communityName, null, cid, "qnew-$sub-$id", q.optString("url"))
                    } else if (tracked == null && before.optBoolean("locked") && !q.optBoolean("locked")) {
                        // Tracked communities get their "Unlocked" alert from ZealySync.apply (same fetch, below).
                        DbStore.addAlert(d, "quest-unlocked", "Unlocked: ${q.optString("name")}", communityName,
                            null, cid, "qunl-$sub-$id-${System.currentTimeMillis() / 60000}", q.optString("url"))
                    }
                }
            }
            // keep tracked communities' statuses fresh from the same successful fetch
            if (tracked != null) ZealySync.apply(d, JSONObject().put("subdomain", sub).put("name", communityName).put("questboard", modules))
        }
        base.put(sub, current) // first run = baseline, no alerts
        return true
    }
}

/** B3: notifications from every joined community, every 5 minutes. */
/**
 * B3 (v2.4.1): messages, staggered and capped like QuestMonitor. Each joined community has its own
 * last-polled time; every tick (about 75 s) takes at most [PER_TICK] due communities, oldest first,
 * with the jitter pause between them. Tracked communities: every 5 min. Untracked joined communities:
 * every 15 min. 429/403 stops the run. The first read of a community is a baseline (no alerts).
 */
object MessageMonitor {
    private const val TRACKED_EVERY_MS = 5 * 60_000L
    private const val UNTRACKED_EVERY_MS = 15 * 60_000L
    private const val PER_TICK = 4

    fun run(ctx: Context) {
        val userId = State.userId ?: SessionStore.userIdFromCookie(ctx) ?: ZealySync.ensureUser(ctx).first ?: return
        val state = MonitorState.read(ctx)
        // v2.4.2: the same cached community list as the full sync (requested once per 30 min, not twice)
        val (cr, comms) = CommunityCache.get(ctx, userId)
        if (cr != null && !handleErrors(ctx, cr)) return
        val list = JSONArray().apply { comms.forEach { put(JSONObject().put("subdomain", it.first).put("name", it.second)) } }
        if (list.length() == 0) { State.lastMessagePollAt = System.currentTimeMillis(); return }
        val seenAll = state.getJSONObject("messages")
        val polled = state.optJSONObject("msgPolledAt") ?: JSONObject().also { state.put("msgPolledAt", it) }
        val db = DbStore.read()
        val now0 = System.currentTimeMillis()
        val due = (0 until list.length()).map { list.getJSONObject(it) }.filter { c ->
            val sub = c.optString("subdomain")
            if (sub.isEmpty()) return@filter false
            val every = if (ZealySync.findCommunity(db, sub) != null) TRACKED_EVERY_MS else UNTRACKED_EVERY_MS
            now0 - polled.optLong(sub, 0L) >= every - 15_000L && !NoAccess.skip(ctx, sub, "notifications")
        }.sortedBy { polled.optLong(it.optString("subdomain"), 0L) }.take(PER_TICK)
        val guard = RunGuard()
        for ((i, c) in due.withIndex()) {
            if (i > 0) jitterSleep()
            val sub = c.optString("subdomain")
            val r = ZealyApi.notifications(ctx, sub, userId)
            if (!handleErrors(ctx, r, sub, "notifications", guard)) break
            polled.put(sub, System.currentTimeMillis())
            if (!r.ok) { MonitorState.write(ctx, state); continue }
            val items = (r.body as? JSONObject)?.optJSONArray("items")
            if (items == null) { MonitorState.write(ctx, state); continue }
            Backoff.ok()
            Session.onSuccess(ctx)
            val seen = seenAll.optJSONArray(sub)
            val seenSet = seen.toRawSet()
            val ids = (0 until items.length()).mapNotNull { items.optJSONObject(it) }.filter { it.optString("id").isNotEmpty() }
            if (seen == null) { // first run for this community: baseline, no alerts
                seenAll.put(sub, JSONArray(ids.map { it.optString("id") }))
                MonitorState.write(ctx, state)
                continue
            }
            val fresh = ids.filter { it.optString("id") !in seenSet }
            if (fresh.isEmpty()) { MonitorState.write(ctx, state); continue }
            val name = c.optString("name").ifEmpty { sub }
            DbStore.mutate { d ->
                val cid = ZealySync.findCommunity(d, sub)?.optInt("id")
                for (n in fresh.reversed()) {
                    val (line, url) = describe(sub, n)
                    DbStore.addAlert(d, "message", name, line, null, cid, "msg-$sub-${n.optString("id")}", url)
                }
            }
            val merged = JSONArray()
            (fresh.map { it.optString("id") } + seenSet).distinct().take(200).forEach { merged.put(it) }
            seenAll.put(sub, merged)
            MonitorState.write(ctx, state)
        }
        State.lastMessagePollAt = System.currentTimeMillis()
    }

    /** First line of a Zealy notification + the page it should open. */
    fun describe(sub: String, n: JSONObject): Pair<String, String> {
        val type = n.optString("type")
        val d = n.optJSONObject("data") ?: JSONObject()
        val board = "https://zealy.io/cw/$sub/questboard"
        fun str(vararg keys: String) = keys.firstNotNullOfOrNull { k -> d.optString(k).takeIf { it.isNotBlank() && it != "null" } }
        val comment = str("comment", "message", "text")
        val text = when (type) {
            "review" -> {
                val quest = d.optJSONObject("resource")?.optString("name")?.ifEmpty { null } ?: str("questName") ?: "your quest"
                val st = str("status", "mark") ?: "reviewed"
                val verdict = when (st) { "success" -> "approved"; "fail" -> "rejected"; else -> st }
                "Claim $verdict: $quest" + (comment?.let { " — $it" } ?: "")
            }
            "manual-xp" -> "You received ${d.optInt("value")} XP" + (comment?.let { " — $it" } ?: "")
            "partnership-requested" -> comment ?: "New partnership request from ${str("communityName") ?: "a community"}"
            "partnership-accepted" -> "Partnership accepted" + (str("communityName")?.let { " by $it" } ?: "")
            "invite-accepted" -> "Someone joined with your invite"
            else -> comment ?: type.replace('-', ' ').replaceFirstChar { it.uppercase() }
        }
        val claimId = str("claimId", "claimedQuestId")
        val url = if (claimId != null) "https://zealy.io/cw/$sub/inbox/$claimId" else board
        return text.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().take(200) to url
    }
}

fun JSONArray?.toRawSet(): Set<String> {
    if (this == null) return emptySet()
    return (0 until length()).map { optString(it) }.toSet()
}
