package io.questpilot.app

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * A1 + A3 timing (v2.4). Every pending notification is stored with the unlock timestamp ("basis")
 * it was computed from. Right before firing, the receiver recomputes the unlock time with
 * UnlockClock.unlockAt(); if it no longer matches (to the second), the alarm is dropped silently.
 * Everything is cancelled and rebuilt whenever the data changes (sync, edit, monitor), and
 * [verify] re-arms every expected alarm after each poll so none can go missing.
 *
 * Stages, for EVERY quest with a known future unlock time (daily, weekly, monthly and one-time).
 * Quests unlocking in the same second share one alarm per stage:
 *   n10     : unlock - 10 min  -> normal notification          (pref stage10m)
 *   n5      : unlock - 5 min   -> normal notification          (pref stage5m)
 *   fs10    : unlock - 10 s    -> full-screen countdown screen  (pref stage10s, autopilot)
 *   claim   : unlock - 3 s     -> claim page loads behind the countdown, revealed + refreshed at 0 (pref stage3s, autopilot)
 *   ready   : unlock           -> "claimable now" (only when neither fs10 nor claim is used)
 *   recheck : unlock + 1.5 s   -> sync only that community; retried every 30 s for 5 min (Zealy quests)
 */
object AlarmScheduler {
    private const val FILE = "alarms.json"
    const val EXTRA_KEY = "key"
    private val lock = Any()
    /** Stages that use setAlarmClock (most reliable, exempt from Doze and OEM batching). */
    private val CRITICAL = setOf("fs10", "claim", "ready")

    fun canExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    fun setAlarm(ctx: Context, at: Long, pi: PendingIntent, critical: Boolean = false) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        try {
            if (canExact(ctx)) {
                if (critical) {
                    val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                    am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
                } else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)
    fun entries(ctx: Context): JSONArray = try {
        JSONArray(file(ctx).readText())
    } catch (e: Exception) {
        JSONArray()
    }

    private fun saveEntries(ctx: Context, arr: JSONArray) = file(ctx).writeText(arr.toString())

    /** Keys that already fired, so a rebuild never repeats a notification for the same basis. */
    private fun firedFile(ctx: Context) = File(ctx.filesDir, "alarms-fired.json")
    private fun fired(ctx: Context): JSONObject = try { JSONObject(firedFile(ctx).readText()) } catch (e: Exception) { JSONObject() }
    fun markFired(ctx: Context, key: String) = synchronized(lock) {
        val f = fired(ctx)
        val now = System.currentTimeMillis()
        val keep = JSONObject()
        f.keys().forEach { k -> if (now - f.optLong(k) < 86_400_000L) keep.put(k, f.optLong(k)) }
        keep.put(key, now)
        firedFile(ctx).writeText(keep.toString())
    }

    private fun pending(ctx: Context, key: String, req: Int, create: Boolean): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction("io.questpilot.ALARM.$key").putExtra(EXTRA_KEY, key)
        val flags = PendingIntent.FLAG_IMMUTABLE or (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(ctx, req, i, flags)
    }

    /** Stage switches (Settings > Notification stages). All on by default. */
    fun stage(db: JSONObject, k: String) = DbStore.pref(db, k, true)

    fun rescheduleAll(ctx: Context) = synchronized(lock) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        // 1. cancel everything pending
        val old = entries(ctx)
        for (i in 0 until old.length()) {
            val e = old.getJSONObject(i)
            pending(ctx, e.getString("key"), e.getInt("req"), false)?.let { am.cancel(it); it.cancel() }
        }
        // 2. rebuild from the single unlock function's output
        val db = DbStore.read()
        val now = System.currentTimeMillis()
        val groups = sortedMapOf<Long, MutableList<JSONObject>>() // key = unlock second
        val quests = db.getJSONArray("quests")
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            // v2.4: one-time quests are no longer skipped. Any quest with a known future unlock gets alarms.
            val c = DbStore.community(db, q.optInt("communityId"))
            if (c?.optInt("notify", 1) == 0) continue
            val t = if (q.isNull("unlockAt")) 0L else q.optLong("unlockAt")
            if (t <= now) continue
            groups.getOrPut(t / 1000) { mutableListOf() }.add(q)
        }
        val out = JSONArray()
        val done = fired(ctx)
        fun add(kind: String, basis: Long, fireAt: Long, qs: List<JSONObject>, test: Boolean = false) {
            if (fireAt <= now) return
            val pre = if (test) "test-" else ""
            val key = "$pre$kind-$basis"
            if (done.has(key) || (kind == "ready" && (done.has("${pre}claim-$basis") || done.has("${pre}fs10-$basis")))) return
            val req = key.hashCode() and 0x7fffffff
            val ids = JSONArray().apply { qs.forEach { put(it.getInt("id")) } }
            out.put(JSONObject().put("key", key).put("kind", kind).put("basis", basis).put("fireAt", fireAt).put("req", req).put("questIds", ids).put("test", test))
            setAlarm(ctx, fireAt, pending(ctx, key, req, true)!!, kind in CRITICAL)
        }
        val autopilot = DbStore.pref(db, "autopilot", true)
        fun stages(t: Long, qs: List<JSONObject>, test: Boolean) {
            val left = t - now
            if (stage(db, "stage10m") && left > 10 * 60_000L + 5_000L) add("n10", t, t - 10 * 60_000L, qs, test)
            if (stage(db, "stage5m") && left > 5 * 60_000L + 5_000L) add("n5", t, t - 5 * 60_000L, qs, test)
            val fs = autopilot && stage(db, "stage10s")
            val claim = autopilot && stage(db, "stage3s")
            if (fs && left > 10_000L) add("fs10", t, t - 10_000L, qs, test)
            if (claim && left > 3_000L) add("claim", t, t - 3_000L, qs, test)
            val usedFs = fs && left > 10_000L
            val usedClaim = claim && left > 3_000L
            if (!usedFs && !usedClaim) add("ready", t, t, qs, test)
            if (!test && qs.any { it.optString("source") == "zealy" }) add("recheck", t, t + 1_500L, qs, false)
        }
        for ((_, qs) in groups) {
            val t = qs.minOf { it.optLong("unlockAt") }
            stages(t, qs, false)
        }
        // Sprint alarms come from the stored end time alone: they fire even if no sync has run.
        val comms = db.optJSONArray("communities") ?: JSONArray()
        for (i in 0 until comms.length()) {
            val c = comms.getJSONObject(i)
            if (c.optInt("notify", 1) == 0) continue
            val end = UnlockClock.parseTime(c.opt("sprintEndsAt")) ?: continue
            if (end <= now) continue
            fun addSprint(kind: String, fireAt: Long) {
                if (fireAt <= now) return
                val key = "$kind-${c.optInt("id")}-$end"
                if (done.has(key)) return
                val req = key.hashCode() and 0x7fffffff
                out.put(JSONObject().put("key", key).put("kind", kind).put("basis", end).put("fireAt", fireAt).put("req", req)
                    .put("questIds", JSONArray()).put("communityId", c.optInt("id")).put("test", false))
                setAlarm(ctx, fireAt, pending(ctx, key, req, true)!!)
            }
            addSprint("sprintsoon", end - 86_400_000L)
            addSprint("sprintend", end)
        }
        // Debug builds only: the fake test quest, kept apart from real data (DevTools is a no-op stub in release).
        if (DevTools.ENABLED) for (tq in DevTools.testQuests(ctx)) {
            val t = UnlockClock.unlockAt(tq, 0) ?: continue
            if (t - now <= 0) continue
            stages(t, listOf(tq), true)
        }
        saveEntries(ctx, out)
    }

    /**
     * A6: after each sync, compare the scheduled alarms with what is expected and re-arm them.
     * Setting an alarm with the same PendingIntent replaces it, so this is safe to run any time;
     * any alarm the system dropped (force-stop, OEM cleaner) comes back.
     */
    fun verify(ctx: Context) = synchronized(lock) {
        val now = System.currentTimeMillis()
        val arr = entries(ctx)
        var rearmed = 0
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val at = e.optLong("fireAt")
            if (at <= now) continue
            val key = e.getString("key")
            val req = e.getInt("req")
            if (pending(ctx, key, req, false) == null) rearmed++
            setAlarm(ctx, at, pending(ctx, key, req, true)!!, e.optString("kind") in CRITICAL)
        }
        if (rearmed > 0) EventLog.add("alarms", "re-armed $rearmed missing alarm(s)")
    }

    /** Quest (or, in test mode, the quest it imitates) has saved content that autofill will use. */
    fun hasSaved(db: JSONObject, q: JSONObject): Boolean {
        val cid = q.optInt("testSourceQuestId", 0).takeIf { it > 0 && !q.isNull("testSourceQuestId") } ?: q.optInt("id")
        val subs = db.optJSONArray("submissions") ?: return false
        for (i in 0 until subs.length()) {
            val s = subs.optJSONObject(i) ?: continue
            if (s.optInt("questId") == cid && (s.optInt("repeat") == 1 || s.isNull("usedAt"))) return true
        }
        return false
    }

    fun removeEntry(ctx: Context, key: String): JSONObject? = synchronized(lock) {
        val arr = entries(ctx)
        val keep = JSONArray()
        var found: JSONObject? = null
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            if (e.getString("key") == key) found = e else keep.put(e)
        }
        saveEntries(ctx, keep)
        found
    }

    /** Debug line data: next scheduled notification per quest. */
    fun nextFor(ctx: Context): Map<Int, Pair<Long, String>> {
        val m = mutableMapOf<Int, Pair<Long, String>>()
        val arr = entries(ctx)
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val ids = e.getJSONArray("questIds")
            for (j in 0 until ids.length()) {
                val id = ids.getInt(j)
                val at = e.getLong("fireAt")
                if (m[id] == null || at < m[id]!!.first) m[id] = at to e.getString("kind")
            }
        }
        return m
    }

    fun fmtIn(ms: Long): String {
        val s = ((ms + 999) / 1000).coerceAtLeast(0)
        return when {
            s < 60 -> "$s s"
            s < 3600 -> "${(s + 59) / 60} min"
            else -> "${s / 3600}h ${(s % 3600) / 60}m"
        }
    }
}

/**
 * A3: re-check at unlock time. Syncs only the communities of the quests that just unlocked, then
 * updates them. If the sync fails, or Zealy still reports the quest as locked, it tries again every
 * 30 seconds for 5 minutes (each retry is its own exact alarm, so it works with the app closed).
 */
object UnlockRecheck {
    const val RETRY_MS = 30_000L
    const val WINDOW_MS = 5 * 60_000L

    fun intent(ctx: Context, subs: List<String>, ids: IntArray, basis: Long, attempt: Int): PendingIntent {
        val i = Intent(ctx, RecheckReceiver::class.java).setAction("io.questpilot.RECHECK.$basis")
            .putExtra("subs", subs.toTypedArray()).putExtra("ids", ids).putExtra("basis", basis).putExtra("attempt", attempt)
        return PendingIntent.getBroadcast(ctx, ("recheck-$basis".hashCode() and 0x7fffffff), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    /** Runs on a background thread. */
    fun run(ctx: Context, subs: List<String>, ids: IntArray, basis: Long, attempt: Int) {
        if (!SessionStore.hasSession(ctx)) return
        var ok = true
        for (s in subs.distinct()) {
            // v2.4.1: unlock-time sync respects the rate-limit pause (it is retried every 30 s for 5 min anyway)
            var r = ZealySync.syncAll(ctx, s, respectPause = true)
            if (!r.ok && r.error?.contains("already running") == true) { Thread.sleep(4_000); r = ZealySync.syncAll(ctx, s, respectPause = true) }
            if (State.paused()) { ok = false; break }
            if (!r.ok) ok = false
        }
        val db = DbStore.read()
        val stillLocked = ids.toList().mapNotNull { DbStore.quest(db, it) }.filter { q ->
            val z = q.optJSONObject("zealy")
            z != null && !z.optBoolean("claimed") && !z.optBoolean("completed") && (z.optBoolean("locked") || z.opt("opened") == false)
        }
        val now = System.currentTimeMillis()
        EventLog.add("recheck", "attempt ${attempt + 1} for ${subs.joinToString()}: sync ${if (ok) "ok" else "failed"}, still locked ${stillLocked.size}")
        if ((!ok || stillLocked.isNotEmpty()) && now + RETRY_MS <= basis + WINDOW_MS) {
            AlarmScheduler.setAlarm(ctx, now + RETRY_MS, intent(ctx, subs, ids, basis, attempt + 1))
        }
    }

    fun subsOf(db: JSONObject, ids: IntArray): List<String> = ids.toList().mapNotNull { DbStore.quest(db, it) }
        .filter { it.optString("source") == "zealy" }
        .mapNotNull { DbStore.community(db, it.optInt("communityId"))?.optString("subdomain")?.ifEmpty { null } }
        .distinct()
}

class RecheckReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val subs = intent.getStringArrayExtra("subs")?.toList() ?: return
        val ids = intent.getIntArrayExtra("ids") ?: intArrayOf()
        val basis = intent.getLongExtra("basis", 0L)
        val attempt = intent.getIntExtra("attempt", 0)
        val pending = goAsync()
        Thread {
            try { UnlockRecheck.run(ctx, subs, ids, basis, attempt) } catch (_: Exception) {} finally { pending.finish() }
        }.start()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val key = intent.getStringExtra(AlarmScheduler.EXTRA_KEY) ?: return
        val entry = AlarmScheduler.removeEntry(ctx, key) ?: return // cancelled meanwhile
        AlarmScheduler.markFired(ctx, key)
        val basis = entry.getLong("basis")
        val kind = entry.getString("kind")
        if (entry.optBoolean("test")) { if (DevTools.ENABLED) fireTest(ctx, kind, basis, entry.getJSONArray("questIds")); return }
        if (kind == "sprintsoon" || kind == "sprintend") { fireSprint(ctx, kind, basis, entry.optInt("communityId")); return }
        val db = DbStore.read()
        val tz = db.getJSONObject("settings").optInt("tzOffset", 0)
        val ids = entry.getJSONArray("questIds")
        // Recompute right before firing; drop silently if the unlock time moved (compared to the second).
        val valid = (0 until ids.length()).mapNotNull { DbStore.quest(db, ids.getInt(it)) }
            .filter { q -> UnlockClock.unlockAt(q, tz)?.let { it / 1000 == basis / 1000 } == true }
        if (kind == "recheck") {
            val all = (0 until ids.length()).map { ids.getInt(it) }.toIntArray()
            val subs = UnlockRecheck.subsOf(db, all)
            if (subs.isEmpty()) return
            val pending = goAsync()
            Thread { try { UnlockRecheck.run(ctx, subs, all, basis, 0) } catch (_: Exception) {} finally { pending.finish() } }.start()
            return
        }
        if (valid.isEmpty()) return
        val now = System.currentTimeMillis()
        val first = valid[0]
        val comm = DbStore.community(db, first.optInt("communityId"))?.optString("name") ?: "QuestPilot"
        val title = if (valid.size == 1) first.optString("title") else "${valid.size} quests"
        val qids = valid.map { it.getInt("id") }.toIntArray()
        when (kind) {
            "n10", "n5", "soon" -> {
                val verb = if (valid.size == 1) "unlocks" else "unlock"
                DbStore.mutate { d ->
                    for (q in valid) DbStore.addAlert(d, "soon", q.optString("title"), "Unlocks ${DbStore.localClock(basis)} · ${DbStore.community(d, q.optInt("communityId"))?.optString("name") ?: ""}",
                        q.optInt("id"), q.optInt("communityId"), "$kind-${q.optInt("id")}-$basis", q.optString("url").ifEmpty { null }, basis, push = false)
                }
                val head = "$title $verb in ${AlarmScheduler.fmtIn(basis - now)}"
                Notifications.post(ctx, (if (kind == "n10") 600 else 500) + (basis / 1000 % 100).toInt(), head,
                    if (valid.size == 1) "$comm · ${DbStore.localClock(basis)}" else valid.joinToString(" · ") { it.optString("title") },
                    first.optString("url").ifEmpty { null }, questId = if (valid.size == 1) first.optInt("id") else 0)
                Telegram.sendAlerts(ctx, listOf(JSONObject().put("title", head).put("body", comm)))
            }
            "fs10" -> {
                // 10 s before: full-screen countdown screen. The claim page itself starts loading at -3 s.
                if (QuestPilotApp.isForeground || ClaimActivity.openCount > 0) {
                    ctx.startActivity(ClaimActivity.intent(ctx, qids, basis, "claim").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else claimNotification(ctx, qids, basis, title, comm, fullScreen = true, countdown = true)
            }
            "claim", "ready" -> {
                DbStore.mutate { d ->
                    for (q in valid) DbStore.addAlert(d, "due", "Claim open: ${q.optString("title")}", DbStore.community(d, q.optInt("communityId"))?.optString("name") ?: "",
                        q.optInt("id"), q.optInt("communityId"), "due-${q.optInt("id")}-$basis", q.optString("url").ifEmpty { null }, basis, push = false)
                }
                if (kind == "claim" && ClaimActivity.activeBasis / 1000 == basis / 1000 && ClaimActivity.openCount > 0) {
                    // The countdown screen from the 10 s stage is open: it loads the page itself right now.
                } else if (kind == "claim" && QuestPilotApp.isForeground) {
                    ctx.startActivity(ClaimActivity.intent(ctx, qids, basis, "claim").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else {
                    if (kind == "claim") ClaimPreloader.preload(ctx, first.optString("url"), basis)
                    claimNotification(ctx, qids, basis, title, comm, fullScreen = kind == "claim")
                }
                Telegram.sendAlerts(ctx, listOf(JSONObject().put("title", "Claim open: $title").put("body", comm)))
            }
        }
    }

    /** Sprint ends soon (24 h) / sprint ended, straight from the countdown. */
    private fun fireSprint(ctx: Context, kind: String, basis: Long, cid: Int) {
        val db = DbStore.read()
        val c = DbStore.community(db, cid) ?: return
        if (c.optInt("notify", 1) == 0) return
        val end = UnlockClock.parseTime(c.opt("sprintEndsAt"))
        // A sync after the end may already have replaced or cleared the sprint: "ended" still holds.
        // If the end moved to a later time (extended or new sprint), drop silently.
        if (kind == "sprintsoon" && end != basis) return
        if (kind == "sprintend" && end != null && end != basis) return
        val name = c.optString("name")
        val sprint = c.optString("sprintName").ifEmpty { "Sprint" }
        val url = "https://zealy.io/cw/${c.optString("subdomain")}/leaderboard"
        val title: String
        val body: String
        val key: String
        if (kind == "sprintend") {
            title = "$name: sprint ended"
            body = "$sprint ended ${DbStore.localClock(basis)}"
            key = "sprint-end-$cid-$basis"
        } else {
            title = "$name: sprint ends soon"
            body = "$sprint ends ${DbStore.localClock(basis)}"
            key = "sprint-24h-$cid-${c.opt("sprintEndsAt")}" // same key as the scanner's alert: never twice
        }
        DbStore.mutate { d -> DbStore.addAlert(d, "sprint", title, body, null, cid, key, url, push = false) } ?: return
        Notifications.post(ctx, 200000 + cid * 2 + (if (kind == "sprintend") 1 else 0), title, body, url)
        Telegram.sendAlerts(ctx, listOf(JSONObject().put("title", title).put("body", body)))
    }

    /**
     * Debug builds: the fake quest. Same recompute-and-compare and the same claim flow, but
     * nothing is written to the real data, nothing goes to Telegram, and notifications are
     * labelled [Test] on their own channel.
     */
    private fun fireTest(ctx: Context, kind: String, basis: Long, ids: JSONArray) {
        val valid = (0 until ids.length()).mapNotNull { DevTools.testQuest(ctx, ids.getInt(it)) }.filter { UnlockClock.unlockAt(it, 0)?.let { t -> t / 1000 == basis / 1000 } == true }
        val q = valid.firstOrNull() ?: return
        val now = System.currentTimeMillis()
        val comm = q.optString("communityName", "Test")
        when (kind) {
            "n10", "n5", "soon" -> Notifications.post(ctx, DevTools.ID_TEST_SOON, "[Test] ${q.optString("title")} unlocks in ${AlarmScheduler.fmtIn(basis - now)}",
                "$comm · test mode, debug build only", null, DevTools.CH_TEST)
            "fs10" -> {
                val qids = intArrayOf(q.optInt("id"))
                if (QuestPilotApp.isForeground || ClaimActivity.openCount > 0) ctx.startActivity(ClaimActivity.intent(ctx, qids, basis, "claim").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                else claimNotification(ctx, qids, basis, "[Test] ${q.optString("title")}", comm, fullScreen = true, id = DevTools.ID_TEST_CLAIM, countdown = true)
            }
            "claim", "ready" -> {
                val qids = intArrayOf(q.optInt("id"))
                if (kind == "claim" && ClaimActivity.activeBasis / 1000 == basis / 1000 && ClaimActivity.openCount > 0) {
                } else if (kind == "claim" && QuestPilotApp.isForeground) {
                    ctx.startActivity(ClaimActivity.intent(ctx, qids, basis, "claim").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else {
                    if (kind == "claim") ClaimPreloader.preload(ctx, q.optString("url"), basis)
                    claimNotification(ctx, qids, basis, "[Test] ${q.optString("title")}", comm, fullScreen = kind == "claim", id = DevTools.ID_TEST_CLAIM)
                }
            }
        }
    }

    private fun claimNotification(ctx: Context, qids: IntArray, basis: Long, title: String, comm: String, fullScreen: Boolean, id: Int = Notifications.ID_CLAIM, countdown: Boolean = false) {
        if (!Notifications.canPost(ctx)) return
        val pi = PendingIntent.getActivity(ctx, id, ClaimActivity.intent(ctx, qids, basis, "claim").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(ctx, Notifications.CH_CLAIM)
            .setSmallIcon(R.drawable.ic_stat_qp)
            .setContentTitle(if (countdown) "Unlocking: $title" else "Claim now: $title")
            .setContentText(if (countdown) "$comm · unlocks in 10 s, tap to open the countdown" else if (fullScreen) "$comm · page is loading, tap to open" else "$comm · tap to open the claim page")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setTimeoutAfter(15 * 60_000L)
            .setContentIntent(pi)
        if (fullScreen) b.setFullScreenIntent(pi, true)
        ctx.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}
