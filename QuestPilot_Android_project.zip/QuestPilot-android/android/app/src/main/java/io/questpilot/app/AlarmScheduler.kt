package io.questpilot.app

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * A1 + A3 timing. Every pending notification is stored with the unlock timestamp ("basis")
 * it was computed from. Right before firing, the receiver recomputes the unlock time with
 * UnlockClock.unlockAt(); if it no longer matches, the alarm is dropped silently.
 * Everything is cancelled and rebuilt whenever the data changes (sync, edit, monitor).
 *
 *   soon  : unlock - 5 min (or halfway when less than 5 min is left)  -> "unlocks in N min"
 *   claim : unlock - 3 s  (autopilot + auto-open)  -> hidden preload, reveal + refresh at unlock
 *   ready : unlock        (autopilot or auto-open off) -> "claimable now"
 */
object AlarmScheduler {
    private const val FILE = "alarms.json"
    const val EXTRA_KEY = "key"
    private val lock = Any()

    fun canExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    fun setAlarm(ctx: Context, at: Long, pi: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)
    fun entries(ctx: Context): JSONArray = try {
        JSONArray(file(ctx).readText())
    } catch (e: Exception) {
        JSONArray()
    }

    private fun saveEntries(ctx: Context, arr: JSONArray) = file(ctx).writeText(arr.toString())

    /** Keys that already fired, so a rebuild never repeats a notification for the same basis. */
    private fun firedFile(ctx: Context) = File(ctx.filesDir, "alarms-fired.json")
    private fun fired(ctx: Context): JSONObject = try { JSONObject(firedFile(ctx).readText()) } catch (e: Exception) { JSONObject() }
    fun markFired(ctx: Context, key: String) = synchronized(lock) {
        val f = fired(ctx)
        val now = System.currentTimeMillis()
        val keep = JSONObject()
        f.keys().forEach { k -> if (now - f.optLong(k) < 86_400_000L) keep.put(k, f.optLong(k)) }
        keep.put(key, now)
        firedFile(ctx).writeText(keep.toString())
    }

    private fun pending(ctx: Context, key: String, req: Int, create: Boolean): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction("io.questpilot.ALARM.$key").putExtra(EXTRA_KEY, key)
        val flags = PendingIntent.FLAG_IMMUTABLE or (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(ctx, req, i, flags)
    }

    fun rescheduleAll(ctx: Context) = synchronized(lock) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        // 1. cancel everything pending
        val old = entries(ctx)
        for (i in 0 until old.length()) {
            val e = old.getJSONObject(i)
            pending(ctx, e.getString("key"), e.getInt("req"), false)?.let { am.cancel(it); it.cancel() }
        }
        // 2. rebuild from the single unlock function's output
        val db = DbStore.read()
        val autopilot = DbStore.pref(db, "autopilot", true)
        val autoOpen = DbStore.pref(db, "autoOpenTabs", true)
        val now = System.currentTimeMillis()
        val groups = sortedMapOf<Long, MutableList<JSONObject>>()
        val quests = db.getJSONArray("quests")
        for (i in 0 until quests.length()) {
            val q = quests.getJSONObject(i)
            if (q.optString("recurrence") == "once") continue
            val c = DbStore.community(db, q.optInt("communityId"))
            if (c?.optInt("notify", 1) == 0) continue
            val t = if (q.isNull("unlockAt")) 0L else q.optLong("unlockAt")
            if (t <= now) continue
            groups.getOrPut(t) { mutableListOf() }.add(q)
        }
        val out = JSONArray()
        val done = fired(ctx)
        fun add(kind: String, basis: Long, fireAt: Long, qs: List<JSONObject>, test: Boolean = false) {
            val pre = if (test) "test-" else ""
            val key = "$pre$kind-$basis"
            if (done.has(key) || (kind == "ready" && done.has("${pre}claim-$basis"))) return
            val req = key.hashCode() and 0x7fffffff
            val ids = JSONArray().apply { qs.forEach { put(it.getInt("id")) } }
            out.put(JSONObject().put("key", key).put("kind", kind).put("basis", basis).put("fireAt", fireAt).put("req", req).put("questIds", ids).put("test", test))
            setAlarm(ctx, fireAt, pending(ctx, key, req, true)!!)
        }
        for ((t, qs) in groups) {
            val left = t - now
            val soonAt = if (left > 5 * 60_000L + 5_000L) t - 5 * 60_000L else if (left > 20_000L) now + left / 2 else 0L
            if (soonAt > 0) add("soon", t, soonAt, qs)
            // Saved content always gets the 3-second preload + autofill at unlock.
            val wantsClaim = (autopilot && autoOpen && qs.any { it.optInt("autoOpen", 1) == 1 }) || qs.any { hasSaved(db, it) }
            if (wantsClaim && left > 3_000L) add("claim", t, t - 3_000L, qs)
            else add("ready", t, t, qs)
        }
        // Sprint alarms come from the stored end time alone: they fire even if no sync has run.
        val comms = db.optJSONArray("communities") ?: JSONArray()
        for (i in 0 until comms.length()) {
            val c = comms.getJSONObject(i)
            if (c.optInt("notify", 1) == 0) continue
            val end = UnlockClock.parseTime(c.opt("sprintEndsAt")) ?: continue
            if (end <= now) continue
            fun addSprint(kind: String, fireAt: Long) {
                if (fireAt <= now) return
                val key = "$kind-${c.optInt("id")}-$end"
                if (done.has(key)) return
                val req = key.hashCode() and 0x7fffffff
                out.put(JSONObject().put("key", key).put("kind", kind).put("basis", end).put("fireAt", fireAt).put("req", req)
                    .put("questIds", JSONArray()).put("communityId", c.optInt("id")).put("test", false))
                setAlarm(ctx, fireAt, pending(ctx, key, req, true)!!)
            }
            addSprint("sprintsoon", end - 86_400_000L)
            addSprint("sprintend", end)
        }
        // Debug builds only: the fake test quest, kept apart from real data (DevTools is a no-op stub in release).
        if (DevTools.ENABLED) for (tq in DevTools.testQuests(ctx)) {
            val t = UnlockClock.unlockAt(tq, 0) ?: continue
            val left = t - now
            if (left <= 0) continue
            val soonAt = if (left > 5 * 60_000L + 5_000L) t - 5 * 60_000L else if (left > 20_000L) now + left / 2 else 0L
            if (soonAt > 0) add("soon", t, soonAt, listOf(tq), test = true)
            if (left > 3_000L) add("claim", t, t - 3_000L, listOf(tq), test = true) else add("ready", t, t, listOf(tq), test = true)
        }
        saveEntries(ctx, out)
    }

    /** Quest (or, in test mode, the quest it imitates) has saved content that autofill will use. */
    private fun hasSaved(db: JSONObject, q: JSONObject): Boolean {
        val cid = q.optInt("testSourceQuestId", 0).takeIf { it > 0 && !q.isNull("testSourceQuestId") } ?: q.optInt("id")
        val subs = db.optJSONArray("submissions") ?: return false
        for (i in 0 until subs.length()) {
            val s = subs.optJSONObject(i) ?: continue
            if (s.optInt("questId") == cid && (s.optInt("repeat") == 1 || s.isNull("usedAt"))) return true
        }
        return false
    }

    fun removeEntry(ctx: Context, key: String): JSONObject? = synchronized(lock) {
        val arr = entries(ctx)
        val keep = JSONArray()
        var found: JSONObject? = null
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            if (e.getString("key") == key) found = e else keep.put(e)
        }
        saveEntries(ctx, keep)
        found
    }

    /** Debug line data: next scheduled notification per quest. */
    fun nextFor(ctx: Context): Map<Int, Pair<Long, String>> {
        val m = mutableMapOf<Int, Pair<Long, String>>()
        val arr = entries(ctx)
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val ids = e.getJSONArray("questIds")
            for (j in 0 until ids.length()) {
                val id = ids.getInt(j)
                val at = e.getLong("fireAt")
                if (m[id] == null || at < m[id]!!.first) m[id] = at to e.getString("kind")
            }
        }
        return m
    }

    fun fmtIn(ms: Long): String {
        val s = ((ms + 999) / 1000).coerceAtLeast(0)
        return when {
            s < 60 -> "$s s"
            s < 3600 -> "${(s + 59) / 60} min"
            else -> "${s / 3600}h ${(s % 3600) / 60}m"
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val key = intent.getStringExtra(AlarmScheduler.EXTRA_KEY) ?: return
        val entry = AlarmScheduler.removeEntry(ctx, key) ?: return // cancelled meanwhile
        AlarmScheduler.markFired(ctx, key)
        val basis = entry.getLong("basis")
        val kind = entry.getString("kind")
        if (entry.optBoolean("test")) { if (DevTools.ENABLED) fireTest(ctx, kind, basis, entry.getJSONArray("questIds")); return }
        if (kind == "sprintsoon" || kind == "sprintend") { fireSprint(ctx, kind, basis, entry.optInt("communityId")); return }
        val db = DbStore.read()
        val tz = db.getJSONObject("settings").optInt("tzOffset", 0)
        val ids = entry.getJSONArray("questIds")
        // Recompute right before firing; drop silently if the unlock time moved.
        val valid = (0 until ids.length()).mapNotNull { DbStore.quest(db, ids.getInt(it)) }
            .filter { UnlockClock.unlockAt(it, tz) == basis }
        if (valid.isEmpty()) return
        val now = System.currentTimeMillis()
        val first = valid[0]
        val comm = DbStore.community(db, first.optInt("communityId"))?.optString("name") ?: "QuestPilot"
        val title = if (valid.size == 1) first.optString("title") else "${valid.size} quests"
        when (kind) {
            "soon" -> {
                val verb = if (valid.size == 1) "unlocks" else "unlock"
                DbStore.mutate { d ->
                    for (q in valid) DbStore.addAlert(d, "soon", q.optString("title"), "Unlocks ${DbStore.localClock(basis)} · ${DbStore.community(d, q.optInt("communityId"))?.optString("name") ?: ""}",
                        q.optInt("id"), q.optInt("communityId"), "soon-${q.optInt("id")}-$basis", q.optString("url").ifEmpty { null }, basis, push = false)
                }
                Notifications.post(ctx, 500 + (basis / 1000 % 1000).toInt(), "$title $verb in ${AlarmScheduler.fmtIn(basis - now)}",
                    if (valid.size == 1) comm else valid.joinToString(" · ") { it.optString("title") }, first.optString("url").ifEmpty { null })
                Telegram.sendAlerts(ctx, listOf(JSONObject().put("title", "$title $verb in ${AlarmScheduler.fmtIn(basis - now)}").put("body", comm)))
            }
            "claim", "ready" -> {
                DbStore.mutate { d ->
                    for (q in valid) DbStore.addAlert(d, "due", "Claim open: ${q.optString("title")}", DbStore.community(d, q.optInt("communityId"))?.optString("name") ?: "",
                        q.optInt("id"), q.optInt("communityId"), "due-${q.optInt("id")}-$basis", q.optString("url").ifEmpty { null }, basis, push = false)
                }
                val qids = valid.map { it.getInt("id") }.toIntArray()
                if (kind == "claim" && QuestPilotApp.isForeground) {
                    ctx.startActivity(ClaimActivity.intent(ctx, qids, basis, "claim").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else {
                    if (kind == "claim") ClaimPreloader.preload(ctx, first.optString("url"), basis)
                    claimNotification(ctx, qids, basis, title, comm, fullScreen = kind == "claim")
                }
                Telegram.sendAlerts(ctx, listOf(JSONObject().put("title", "Claim open: $title").put("body", comm)))
            }
        }
    }

    /** Sprint ends soon (24 h) / sprint ended, straight from the countdown. */
    private fun fireSprint(ctx: Context, kind: String, basis: Long, cid: Int) {
        val db = DbStore.read()
        val c = DbStore.community(db, cid) ?: return
        if (c.optInt("notify", 1) == 0) return
        val end = UnlockClock.parseTime(c.opt("sprintEndsAt"))
        // A sync after the end may already have replaced or cleared the sprint: "ended" still holds.
        // If the end moved to a later time (extended or new sprint), drop silently.
        if (kind == "sprintsoon" && end != basis) return
        if (kind == "sprintend" && end != null && end != basis) return
        val name = c.optString("name")
        val sprint = c.optString("sprintName").ifEmpty { "Sprint" }
        val url = "https://zealy.io/cw/${c.optString("subdomain")}/leaderboard"
        val title: String
        val body: String
        val key: String
        if (kind == "sprintend") {
            title = "$name: sprint ended"
            body = "$sprint ended ${DbStore.localClock(basis)}"
            key = "sprint-end-$cid-$basis"
        } else {
            title = "$name: sprint ends soon"
            body = "$sprint ends ${DbStore.localClock(basis)}"
            key = "sprint-24h-$cid-${c.opt("sprintEndsAt")}" // same key as the scanner's alert: never twice
        }
        DbStore.mutate { d -> DbStore.addAlert(d, "sprint", title, body, null, cid, key, url, push = false) } ?: return
        Notifications.post(ctx, 200000 + cid * 2 + (if (kind == "sprintend") 1 else 0), title, body, url)
        Telegram.sendAlerts(ctx, listOf(JSONObject().put("title", title).put("body", body)))
    }

    /**
     * Debug builds: the fake quest. Same recompute-and-compare and the same claim flow, but
     * nothing is written to the real data, nothing goes to Telegram, and notifications are
     * labelled [Test] on their own channel.
     */
    private fun fireTest(ctx: Context, kind: String, basis: Long, ids: JSONArray) {
        val valid = (0 until ids.length()).mapNotNull { DevTools.testQuest(ctx, ids.getInt(it)) }.filter { UnlockClock.unlockAt(it, 0) == basis }
        val q = valid.firstOrNull() ?: return
        val now = System.currentTimeMillis()
        val comm = q.optString("communityName", "Test")
        when (kind) {
            "soon" -> Notifications.post(ctx, DevTools.ID_TEST_SOON, "[Test] ${q.optString("title")} unlocks in ${AlarmScheduler.fmtIn(basis - now)}",
                "$comm · test mode, debug build only", null, DevTools.CH_TEST)
            "claim", "ready" -> {
                val qids = intArrayOf(q.optInt("id"))
                if (kind == "claim" && QuestPilotApp.isForeground) {
                    ctx.startActivity(ClaimActivity.intent(ctx, qids, basis, "claim").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } else {
                    if (kind == "claim") ClaimPreloader.preload(ctx, q.optString("url"), basis)
                    claimNotification(ctx, qids, basis, "[Test] ${q.optString("title")}", comm, fullScreen = kind == "claim", id = DevTools.ID_TEST_CLAIM)
                }
            }
        }
    }

    private fun claimNotification(ctx: Context, qids: IntArray, basis: Long, title: String, comm: String, fullScreen: Boolean, id: Int = Notifications.ID_CLAIM) {
        if (!Notifications.canPost(ctx)) return
        val pi = PendingIntent.getActivity(ctx, id, ClaimActivity.intent(ctx, qids, basis, "claim").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(ctx, Notifications.CH_CLAIM)
            .setSmallIcon(R.drawable.ic_stat_qp)
            .setContentTitle("Claim now: $title")
            .setContentText(if (fullScreen) "$comm · page is loading, tap to open" else "$comm · tap to open the claim page")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setTimeoutAfter(15 * 60_000L)
            .setContentIntent(pi)
        if (fullScreen) b.setFullScreenIntent(pi, true)
        ctx.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
}
