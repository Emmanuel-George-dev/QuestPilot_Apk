// QuestPilot autofill. Fills saved content into the open Zealy quest page.
// It NEVER clicks Claim or Submit: the user does the final tap.
// Selectors come from public/zealy-selectors.json (passed in as `cfg`).
(function () {
  if (window.__qpFill) return;

  const report = (r) => { try { window.QPBridge && QPBridge.report(JSON.stringify(r)); } catch (e) {} };

  // Safety: only zealy.io, only the quest that was opened.
  const allowed = (d) => {
    if (!/(^|\.)zealy\.io$/i.test(location.hostname)) return false;
    if (d.expectPath) return location.pathname.indexOf(d.expectPath) !== -1;
    const here = (location.origin + location.pathname).replace(/\/+$/, "");
    return here.indexOf(d.expectUrl) === 0;
  };

  const visible = (e) => {
    if (!e || !e.isConnected) return false;
    const r = e.getClientRects();
    if (!r.length) return false;
    const s = getComputedStyle(e);
    return s.visibility !== "hidden" && s.display !== "none" && Number(s.opacity) !== 0;
  };
  const any = (el, sels) => (sels || []).some((s) => { try { return el.matches(s); } catch (e) { return false; } });
  const all = (root, sels) => {
    const out = [];
    for (const s of sels || []) { try { root.querySelectorAll(s).forEach((e) => out.includes(e) || out.push(e)); } catch (e) {} }
    return out;
  };
  const scope = (cfg) => {
    for (const s of cfg.scope || []) {
      let els = [];
      try { els = [...document.querySelectorAll(s)].filter(visible); } catch (e) {}
      if (els.length) return els[els.length - 1];
    }
    return document;
  };

  const findText = (cfg) => {
    for (const root of [scope(cfg), document]) {
      const el = all(root, cfg.textInputs).find((e) => visible(e) && !e.disabled && !e.readOnly && !any(e, cfg.excludeTextInputs));
      if (el) return el;
    }
    return null;
  };

  const setText = (el, text) => {
    el.focus();
    if (el.isContentEditable) {
      document.execCommand("selectAll", false);
      document.execCommand("insertText", false, text);
    } else {
      // Native value setter so React's value tracker registers the change.
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, text);
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur && setTimeout(() => el.dispatchEvent(new Event("blur", { bubbles: true })), 0);
    const v = el.isContentEditable ? el.innerText : el.value;
    return (v || "").trim() === String(text).trim();
  };

  const toFile = (im) => {
    const m = String(im.data).match(/^data:([^;]+);base64,(.*)$/);
    const bin = atob(m ? m[2] : im.data);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return new File([u], im.name || "photo.jpg", { type: im.mime || (m && m[1]) || "image/jpeg" });
  };

  // DataTransfer fallback: put the saved photos straight into the page's file input(s).
  const attach = (cfg, images) => {
    const inputs = [...new Set([...all(scope(cfg), cfg.fileInputs), ...all(document, cfg.fileInputs)])].filter((i) => !i.disabled);
    const files = images.map(toFile);
    if (inputs.length) {
      let k = 0;
      inputs.forEach((inp, idx) => {
        const dt = new DataTransfer();
        if (inp.multiple) files.forEach((f) => dt.items.add(f));
        else if (files[Math.min(idx, files.length - 1)]) dt.items.add(files[Math.min(idx, files.length - 1)]);
        inp.files = dt.files;
        inp.dispatchEvent(new Event("input", { bubbles: true }));
        inp.dispatchEvent(new Event("change", { bubbles: true }));
        if (inp.files && inp.files.length) k++;
      });
      if (k) return true;
    }
    const zone = all(scope(cfg), cfg.dropZones).find(visible);
    if (zone) {
      const dt = new DataTransfer();
      files.forEach((f) => dt.items.add(f));
      ["dragenter", "dragover", "drop"].forEach((t) => zone.dispatchEvent(new DragEvent(t, { bubbles: true, cancelable: true, dataTransfer: dt })));
      return true;
    }
    return false;
  };

  // Retries until each element exists (the quest page renders in steps), up to cfg.retryMs.
  window.__qpFill = function (cfg, d) {
    if (!allowed(d)) { report({ blocked: true }); return; }
    const want = { text: !!d.text, photo: !!(d.images && d.images.length) };
    const done = { text: false, photo: false };
    const end = Date.now() + (cfg.retryMs || 10000);
    let timer = null, obs = null, finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      clearInterval(timer);
      obs && obs.disconnect();
      report({
        text: !want.text ? "none" : done.text ? "filled" : "missing",
        photo: !want.photo ? "none" : done.photo ? "attached" : "missing",
      });
    };
    const step = () => {
      if (finished) return;
      if (!allowed(d)) { finished = true; clearInterval(timer); obs && obs.disconnect(); report({ blocked: true }); return; }
      try {
        if (want.text && !done.text) { const el = findText(cfg); if (el) done.text = setText(el, d.text); }
        if (want.photo && !done.photo) done.photo = attach(cfg, d.images);
      } catch (e) {}
      if ((done.text || !want.text) && (done.photo || !want.photo)) finish();
      else if (Date.now() > end) finish();
    };
    obs = new MutationObserver(() => step());
    obs.observe(document.documentElement, { childList: true, subtree: true });
    timer = setInterval(step, cfg.pollMs || 300);
    step();
  };

  // Manual "use saved photo" from the banner.
  window.__qpAttach = function (cfg, d) {
    if (!allowed(d)) { report({ blocked: true }); return; }
    let ok = false;
    try { ok = attach(cfg, d.images || []); } catch (e) {}
    report({ manual: true, photo: ok ? "attached" : "missing", text: "none" });
  };
})();
