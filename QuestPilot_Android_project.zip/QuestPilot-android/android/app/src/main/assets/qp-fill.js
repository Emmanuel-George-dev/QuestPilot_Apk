// QuestPilot autofill. Fills saved content into the open Zealy quest page.
// It NEVER clicks Claim or Submit: the user does the final tap.
// Selectors come from public/zealy-selectors.json (passed in as `cfg`).
// v2.4: every step is reported (QPBridge.step) for the on-screen debug line, the photo is set with
// native change/input events, then React's own onChange, then a simulated drop on the drop zone,
// and success means an upload request or a preview was actually seen.
(function () {
  if (window.__qpFill) return;

  const report = (r) => { try { window.QPBridge && QPBridge.report(JSON.stringify(r)); } catch (e) {} };
  const step = (m) => { try { window.QPBridge && QPBridge.step && QPBridge.step(String(m)); } catch (e) {} };

  // ---- upload detection: any POST/PUT with a file body, or to an upload-looking URL ----
  let uploadSeenAt = 0;
  const looksUpload = (u, body) => {
    try {
      if (body && (body instanceof FormData || body instanceof Blob || body instanceof File || body instanceof ArrayBuffer)) return true;
    } catch (e) {}
    return /upload|\/file|storage|s3\.|amazonaws|presign|signed|cloudinary|imgix|\/media/i.test(String(u || ""));
  };
  const seen = (u) => { if (!uploadSeenAt) { uploadSeenAt = Date.now(); step("upload started: " + String(u || "").split("?")[0].slice(0, 80)); } };
  try {
    const of = window.fetch;
    if (of && !of.__qpUp) {
      const f = function (i, n) {
        try {
          const m = (n && n.method) || (i && i.method) || "GET";
          const u = typeof i === "string" ? i : (i && i.url) || "";
          if (/^(POST|PUT|PATCH)$/i.test(m) && looksUpload(u, n && n.body)) seen(u);
        } catch (e) {}
        return of.apply(this, arguments);
      };
      f.__qpUp = true;
      window.fetch = f;
    }
    const xo = XMLHttpRequest.prototype.open, xs = XMLHttpRequest.prototype.send;
    if (!xs.__qpUp) {
      XMLHttpRequest.prototype.open = function (m, u) { this.__qpUm = m; this.__qpUu = u; return xo.apply(this, arguments); };
      const s2 = function (b) { try { if (/^(POST|PUT|PATCH)$/i.test(this.__qpUm || "") && looksUpload(this.__qpUu, b)) seen(this.__qpUu); } catch (e) {} return xs.apply(this, arguments); };
      s2.__qpUp = true;
      XMLHttpRequest.prototype.send = s2;
    }
  } catch (e) {}

  // Safety: only zealy.io, only the quest that was opened.
  const allowed = (d) => {
    if (!/(^|\.)zealy\.io$/i.test(location.hostname)) return false;
    if (d.expectPath) return location.pathname.indexOf(d.expectPath) !== -1;
    const here = (location.origin + location.pathname).replace(/\/+$/, "");
    return here.indexOf(d.expectUrl) === 0;
  };

  const visible = (e) => {
    if (!e || !e.isConnected) return false;
    const r = e.getClientRects();
    if (!r.length) return false;
    const s = getComputedStyle(e);
    return s.visibility !== "hidden" && s.display !== "none" && Number(s.opacity) !== 0;
  };
  const any = (el, sels) => (sels || []).some((s) => { try { return el.matches(s); } catch (e) { return false; } });
  const all = (root, sels) => {
    const out = [];
    for (const s of sels || []) { try { root.querySelectorAll(s).forEach((e) => out.includes(e) || out.push(e)); } catch (e) {} }
    return out;
  };
  const scope = (cfg) => {
    for (const s of cfg.scope || []) {
      let els = [];
      try { els = [...document.querySelectorAll(s)].filter(visible); } catch (e) {}
      if (els.length) return els[els.length - 1];
    }
    return document;
  };

  const findText = (cfg) => {
    for (const root of [scope(cfg), document]) {
      const el = all(root, cfg.textInputs).find((e) => visible(e) && !e.disabled && !e.readOnly && !any(e, cfg.excludeTextInputs));
      if (el) return el;
    }
    return null;
  };

  const setText = (el, text) => {
    el.focus();
    if (el.isContentEditable) {
      document.execCommand("selectAll", false);
      document.execCommand("insertText", false, text);
    } else {
      // Native value setter so React's value tracker registers the change.
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(el, text);
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur && setTimeout(() => el.dispatchEvent(new Event("blur", { bubbles: true })), 0);
    const v = el.isContentEditable ? el.innerText : el.value;
    return (v || "").trim() === String(text).trim();
  };

  const toFile = (im) => {
    const m = String(im.data).match(/^data:([^;]+);base64,(.*)$/);
    const bin = atob(m ? m[2] : im.data);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return new File([u], im.name || "photo.jpg", { type: im.mime || (m && m[1]) || "image/jpeg", lastModified: Date.now() });
  };

  const fileInputs = (cfg) => [...new Set([...all(scope(cfg), cfg.fileInputs), ...all(document, cfg.fileInputs)])].filter((i) => !i.disabled);

  // A preview image (blob:/data: src) inside the quest area = the page accepted the file.
  const previewCount = (cfg) => {
    try { return [...scope(cfg).querySelectorAll("img")].filter((i) => /^(blob:|data:image)/.test(i.getAttribute("src") || "")).length; } catch (e) { return 0; }
  };

  // React keeps its handlers on the element (__reactProps$xxx). Calling onChange directly helps when
  // the synthetic event system ignores a programmatic change on a file input.
  const reactChange = (inp) => {
    try {
      const k = Object.keys(inp).find((x) => x.indexOf("__reactProps$") === 0);
      const p = k && inp[k];
      if (p && typeof p.onChange === "function") {
        const ev = new Event("change", { bubbles: true });
        p.onChange({ target: inp, currentTarget: inp, nativeEvent: ev, type: "change", bubbles: true, preventDefault() {}, stopPropagation() {}, persist() {}, isDefaultPrevented: () => false, isPropagationStopped: () => false });
        return true;
      }
    } catch (e) {}
    return false;
  };

  const dropZoneFor = (cfg, inp) => {
    // nearest ancestor of the input that looks like a drop zone, else a configured drop zone in scope
    let n = inp && inp.parentElement;
    for (let i = 0; n && i < 6; i++, n = n.parentElement) {
      if (any(n, cfg.dropZones) || n.getAttribute("role") === "presentation" || n.getAttribute("role") === "button" || /drop|upload/i.test(n.className || "")) return n;
    }
    return all(scope(cfg), cfg.dropZones).find(visible) || (inp && inp.parentElement) || null;
  };

  const simulateDrop = (zone, files) => {
    const dt = new DataTransfer();
    files.forEach((f) => dt.items.add(f));
    ["dragenter", "dragover", "drop"].forEach((t) => {
      let ev;
      try { ev = new DragEvent(t, { bubbles: true, cancelable: true, dataTransfer: dt }); } catch (e) { ev = new Event(t, { bubbles: true, cancelable: true }); }
      if (!ev.dataTransfer) { try { Object.defineProperty(ev, "dataTransfer", { value: dt }); } catch (e) {} }
      zone.dispatchEvent(ev);
    });
  };

  // Sets the photo on the page. Calls back with "attached" (upload or preview seen), "unconfirmed"
  // (file set but the page showed nothing) or "missing" (no file input / drop zone on the page).
  const attach = (cfg, images, done) => {
    const inputs = fileInputs(cfg);
    const files = images.map(toFile);
    step("photo file(s) ready: " + files.map((f) => f.name + " " + Math.round(f.size / 1024) + "KB").join(", "));
    const zone0 = all(scope(cfg), cfg.dropZones).find(visible);
    if (!inputs.length && !zone0) { step("no file input or drop zone found"); done("missing"); return; }
    step("input found: " + inputs.length + " file input(s)" + (zone0 ? ", drop zone yes" : ""));
    const before = previewCount(cfg);
    const ok = () => uploadSeenAt > 0 || previewCount(cfg) > before;
    let k = 0;
    inputs.forEach((inp, idx) => {
      try {
        const dt = new DataTransfer();
        if (inp.multiple) files.forEach((f) => dt.items.add(f));
        else if (files[Math.min(idx, files.length - 1)]) dt.items.add(files[Math.min(idx, files.length - 1)]);
        inp.files = dt.files;
        if (inp.files && inp.files.length) k++;
        inp.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        inp.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      } catch (e) { step("setting files failed: " + e); }
    });
    if (k) step("file set on " + k + " input(s), change + input sent");
    const wait = (ms, next) => {
      const end = Date.now() + ms;
      const t = setInterval(() => { if (ok() || Date.now() > end) { clearInterval(t); next(); } }, 150);
    };
    wait(1500, () => {
      if (ok()) { step(uploadSeenAt ? "upload confirmed" : "preview shown"); done("attached"); return; }
      const r = inputs.map(reactChange).some(Boolean);
      if (r) step("React onChange called directly");
      wait(r ? 1500 : 0, () => {
        if (ok()) { step(uploadSeenAt ? "upload confirmed" : "preview shown"); done("attached"); return; }
        const zone = dropZoneFor(cfg, inputs[0]) || zone0;
        if (zone) { step("simulating drop on " + (zone.tagName || "?").toLowerCase() + (zone.className ? "." + String(zone.className).split(" ")[0] : "")); simulateDrop(zone, files); }
        wait(2500, () => {
          if (ok()) { step(uploadSeenAt ? "upload confirmed" : "preview shown"); done("attached"); return; }
          step("no upload or preview seen. Tap the upload box: the saved photo is returned automatically.");
          done(k ? "unconfirmed" : "missing");
        });
      });
    });
  };

  // Retries until each element exists (the quest page renders in steps), up to cfg.retryMs.
  window.__qpFill = function (cfg, d) {
    if (!allowed(d)) { step("blocked: not the opened quest page"); report({ blocked: true }); return; }
    const want = { text: !!d.text, photo: !!(d.images && d.images.length) };
    const done = { text: false, photo: null };
    let photoBusy = false;
    const end = Date.now() + (cfg.retryMs || 10000);
    let timer = null, obs = null, finished = false;
    step("page ready, looking for: " + [want.text && "text box", want.photo && "upload"].filter(Boolean).join(" + "));
    const finish = () => {
      if (finished) return;
      finished = true;
      clearInterval(timer);
      obs && obs.disconnect();
      report({
        text: !want.text ? "none" : done.text ? "filled" : "missing",
        photo: !want.photo ? "none" : done.photo || "missing",
      });
    };
    const settled = () => (done.text || !want.text) && (done.photo !== null || !want.photo);
    const stepOnce = () => {
      if (finished) return;
      if (!allowed(d)) { finished = true; clearInterval(timer); obs && obs.disconnect(); report({ blocked: true }); return; }
      try {
        if (want.text && !done.text) { const el = findText(cfg); if (el) { done.text = setText(el, d.text); step(done.text ? "text filled" : "text box found but value did not stick"); } }
        if (want.photo && done.photo === null && !photoBusy && (fileInputs(cfg).length || all(scope(cfg), cfg.dropZones).find(visible))) {
          photoBusy = true;
          attach(cfg, d.images, (r) => { done.photo = r; photoBusy = false; if (settled()) finish(); });
        }
      } catch (e) { step("error: " + e); }
      if (settled()) finish();
      else if (Date.now() > end && !photoBusy) {
        if (want.photo && done.photo === null) step("no file input appeared within " + Math.round((cfg.retryMs || 10000) / 1000) + " s");
        finish();
      }
    };
    obs = new MutationObserver(() => stepOnce());
    obs.observe(document.documentElement, { childList: true, subtree: true });
    timer = setInterval(stepOnce, cfg.pollMs || 300);
    stepOnce();
  };

  // Manual "use saved photo" from the banner.
  window.__qpAttach = function (cfg, d) {
    if (!allowed(d)) { report({ blocked: true }); return; }
    step("manual attach");
    try { attach(cfg, d.images || [], (r) => report({ manual: true, photo: r, text: "none" })); } catch (e) { report({ manual: true, photo: "missing", text: "none" }); }
  };
})();
