# QuestPilot for Android (v2.3.0)

QuestPilot as a standalone Android app. There is no server: a Capacitor shell runs the
QuestPilot web UI, and native Kotlin code handles the Zealy session, polling, exact alarms
and notifications.

The web UI under `src/` was rebuilt as readable React + TypeScript from the compiled
`assets/app.js` in `Emmanuel-George-dev/QuestPilot-app`, because that repo has no original
source. Screens, Tailwind design tokens, components and copy follow the compiled app. Data
is still the `questpilot-db-v1` document (`{seq, communities, quests, alerts, submissions,
settings}`) from `local-api.js`. New fields were only added, never renamed or removed.

---

## Build the APK

Requirements:

- Node.js 22 or newer (Capacitor 8 CLI requires it)
- JDK 21
- Android SDK with platform 36 and build-tools 36. Android Studio installs these; so does `sdkmanager "platforms;android-36" "build-tools;36.0.0" "platform-tools"`

There are two build types. **Debug** includes the test tools; **release** contains none of them.

```bash
npm install
cd android && echo "sdk.dir=/path/to/Android/sdk" > local.properties && cd ..   # once; Android Studio does this for you

# Debug APK (test mode, fake quest, debug panel, "Clear test data")
npm run apk:debug
#   -> android/app/build/outputs/apk/debug/app-debug.apk   (app name "QuestPilot Debug")

# Release APK (no test or debug features at all)
npm run apk:release
#   -> android/app/build/outputs/apk/release/app-release.apk  (or app-release-unsigned.apk without a keystore)
```

Copy the APK to the phone and install it. You need to allow installing from unknown sources.
To open the project in Android Studio, run `npm run android`, then pick the build variant
(debug or release) and use Build > Build APK(s).

**Signing the release.** Create a keystore once and keep it safe; every update must be signed
with the same key:

```bash
keytool -genkeypair -v -keystore android/questpilot.jks -alias questpilot -keyalg RSA -keysize 2048 -validity 10000
```

Then create `android/keystore.properties`. This file and the keystore are git-ignored.

```
storeFile=questpilot.jks
storePassword=...
keyAlias=questpilot
keyPassword=...
```

The debug and release APKs use the same package name but different signing keys, so Android
won't install one over the other. Uninstall the debug app before installing the release.

### How test tools stay out of release

| Layer | Debug build | Release build |
|---|---|---|
| Web UI | `npm run build:devtools` (`vite --mode devtools`, `.env.devtools` sets `VITE_QP_DEVTOOLS=1`) is copied to `android/app/src/debug/assets/public` and overrides the main bundle. It includes `src/devtools/DevToolsSection.tsx`: Test mode, Debug: daily unlocks, Clear test data | `npm run build`: `DEV_TOOLS` is the constant `false`, so the lazy import of `src/devtools/` is removed and that code is not in the bundle |
| Native | `src/debug/java/.../DevTools.kt` (real test mode, `ENABLED = BuildConfig.DEBUG = true`) | `src/release/java/.../DevTools.kt`: a no-op stub. The plugin's test methods return "Not available in release builds" |
| Gradle guard | none | `mergeReleaseAssets` fails the build if any debug marker ("Fake unlock in 1 minute", "Clear test data", "Debug: daily unlocks", ...) appears in the release assets, and the release `DevTools.kt` must be the stub |

There is no demo or seed data anywhere in the app. A new install starts empty.

---

## First launch

1. A setup sheet asks for **notifications**, **Alarms & reminders** (exact alarms),
   **full-screen notifications** (Android 14+), and **Battery: Unrestricted**. It also
   shows autostart instructions for Xiaomi, Oppo/Realme/OnePlus, Samsung and
   Huawei/Honor, plus a button that tries to open that brand's autostart screen. You can
   reopen all of this under Settings > Permissions.
2. Go to **Settings > Zealy account > Connect Zealy** and log in to zealy.io in the window
   that opens. Email, Discord or X login work. Google sign-in usually refuses to run inside
   app WebViews, and wallet login needs a wallet app. Once Zealy sets its session cookies,
   QuestPilot copies them into encrypted storage (AES-GCM key in the Android Keystore),
   clears the WebView cookie jar, checks the session with `/users/me`, imports all your
   communities and starts monitoring.
3. The status line on the Today screen shows **Monitoring active / Paused / Session
   expired** and **Last synced**, and has a start/stop switch.

---

## Zealy connection (v2.3.0)

- **Login detection.** After you log in, QuestPilot waits until the WebView is on a logged-in zealy.io page (not `/login`, OTP, verify or callback pages) and Zealy has set `user_metadata`. Then it calls `CookieManager.flush()`, waits about a second, and reads the cookies.
- **Cookie header.** Cookies are read for `https://zealy.io`, `https://api-v2.zealy.io` and `https://api-v1.zealy.io`, deduplicated by name (first wins), and sent as one line `name=value; name2=value2` with no quotes added and no line breaks or invalid characters.
- **Requests** (OkHttp) send `Cookie`, `User-Agent` (the same Chrome for Android string the WebView now uses, without the `; wv` / `Version/4.0` markers), `Origin: https://zealy.io`, `Referer: https://zealy.io/` and `Accept: application/json`. GET requests have no body. Redirects are not followed.
- **Session check.** First exactly `GET https://api-v2.zealy.io/api/users/me`. zealy.io's own client never calls `me` on api-v2: it decodes `userId` from the `user_metadata` cookie and calls `/api/users/{userId}`. So if `/me` fails with a non-auth error (such as 400), QuestPilot tries `/api/users/{userId}` too.
- **Web storage token.** After login, localStorage and sessionStorage are checked for keys containing token/auth/jwt/session/access. If one holds a JWT, it's stored encrypted, and the checks are retried with `Authorization: Bearer …` only if the cookie isn't accepted. The mode that works is remembered.
- **Two-sided check.** During login the same URLs are also fetched inside the logged-in WebView (`fetch(…, {credentials: "include"})`), and both results are shown, so you can see whether Zealy or the app's request is the problem.
- **Errors.** Only 401/403 mean "session expired / not logged in". A 400 (or any other error) is shown as a request error with the status and the first 300 characters of the response, with a Retry button. It never asks you to log in again.
- **Debug build only:** Settings → "Debug: connection log" lists every Zealy request (URL, status, response snippet; cookie values and JWTs hidden) and has a **Test connection** button that runs the OkHttp and in-WebView checks side by side. Release builds record nothing, and the release asset guard fails if this screen leaks into the release bundle.

## What changed

### A1: one unlock time for everything
- `UnlockClock.unlockAt()` (Kotlin) is the only function that computes an unlock time. It
  returns an absolute UTC timestamp, 0 (available now) or null (locked). It reads the
  Zealy questboard fields:
  - `opened:false` + `openAt`. This is the value Zealy's own UI uses for "resets in".
  - `date` conditions (`>` / `>=`).
  - `retryAt` cooldowns.
  - The recurrence reset as a fallback: 00:00 UTC daily, Monday weekly, 1st of the month
    monthly.

  The result never depends on "now".
- Every save writes that value to `quest.unlockAt`. The countdown, the in-app alerts, the
  calendar export and the system notifications all read it. The web code has no other
  calculation.
- Remaining time is always `unlockAt - Date.now()` (or `System.currentTimeMillis()`), never
  a stored relative value. "Soon" alerts store an absolute time, and the Alerts screen
  shows a live countdown.
- Every alarm is stored with its basis timestamp in `alarms.json`. Right before firing,
  `AlarmReceiver` recomputes `unlockAt` and silently drops the alarm if the value changed.
  Every data change (sync, monitor, edit, test) cancels and rebuilds all alarms.
- (Debug builds) Settings > **Debug: daily unlocks** shows, for each daily quest, the unlock timestamp,
  the time left and the next scheduled notification (time and kind).
- Root cause of the false "unlocks in 1 minute": the old build had two different unlock
  calculations. The page used the browser timezone and `local-api.js` used `tzOffset`
  (default 0). Both were based on a rolling `lastClaimedAt + 24h` that was set when you
  tapped, not on Zealy's 00:00 UTC reset. On top of that, alert text was frozen when the
  alert was created, and `fmtLeft` clamped anything short to "1 min".

### A2: status only from Zealy
- Order: claimed/completed → Complete, inReview → In review, locked → Locked, otherwise
  Open (`questStatus()` in `src/lib/quest.ts`, and the same rule in `ZealySync.apply`).
- Opening a task only opens its link. The old code ran the claim mutation from `launch()`
  and from the card's Open button, which set once-quests to "pending". That is removed.
  The status menu items now appear only on manual (non-Zealy) quests, and the local API
  refuses to change the status of Zealy quests.
- Statuses are written only after a successful fetch. A failed fetch only sets
  `syncError`, so the old statuses stay. Closing the in-app Zealy page triggers a re-sync
  of that community.

### A3: claim page 3 seconds early
- An exact alarm (`setExactAndAllowWhileIdle`) fires at **unlock − 3 s**.
- **App open:** `ClaimActivity` opens right away. The WebView loads the claim page
  (`https://zealy.io/cw/<subdomain>/questboard/<questId>`) behind a countdown overlay,
  then at the exact unlock time the overlay disappears and the page reloads once.
- **App in background or screen off:** `ClaimPreloader` starts loading the page in a
  hidden WebView, and a high-priority **full-screen notification** (CATEGORY_ALARM) opens
  `ClaimActivity` with the preloaded WebView. On a locked screen Android shows it
  directly; otherwise it is one tap.
- If several quests unlock at the same second, a **Next** button walks through them.
  Prepared submissions are filled in automatically, using the same fill logic as the old
  bookmarklet.
- When autopilot or auto-open is off, a "Claimable now" notification fires at the unlock
  time instead.

### B1 / B2: watchlist and Zealy Monitor
- Settings > **Watchlist & Zealy Monitor** (`#/monitor`). Up to 3 subdomains. Adding a
  fourth shows a warning, and the local API enforces the limit too.
- `MonitorService` polls `https://api-v1.zealy.io/communities/<sub>/questboard/v2` every
  3 minutes plus 0–20 s jitter, waiting 1–2 s plus jitter between communities.
- The first run per community saves a baseline without alerts. A failed or empty fetch is
  skipped and the baseline is kept.
- Alerts: "New quest: <name>, <XP> XP, <community>" and "Quest unlocked: <name>". Tapping
  opens the quest in the signed-in Zealy view. The alert history is on the Monitor
  screen and in Alerts.
- A 429 or 403 pauses monitoring for 5 minutes, doubling each time it repeats. Three
  401/403 responses in a row trigger "Zealy session expired, tap to reconnect."

### B3: messages from all your communities
- The Zealy web app has **no separate "messages" or "announcements" feed endpoint**. What
  zealy.io's bell and inbox use is the ts-rest contract `notification.list`:
  `GET https://api-v2.zealy.io/api/communities/<subdomain>/users/<userId>/notifications?limit=20`
  → `{ items: [{ id, read, createdAt, type, data }], nextCursor, totalUnread }`.
  Its types include `review` (claim approved or rejected, with the reviewer's comment),
  `manual-xp`, `partnership-requested` (with message), `invite-accepted`, and several
  reward-distribution types. QuestPilot polls this endpoint for **every community you
  joined** every 5 minutes, on its own timer separate from quest polling.
- The first run per community saves the current IDs without alerts. After that each new ID
  becomes a notification showing the community name and the first line of the message.
  Tapping opens `/cw/<sub>/inbox/<claimId>` for reviews, otherwise the questboard.
- Community Discord or Telegram announcements are not available from any Zealy endpoint, so
  QuestPilot cannot alert on those.

### C: standalone app
- Foreground service (`specialUse`) with a persistent "Monitoring Zealy" notification. It
  restarts after a reboot or app update (`BootReceiver`), and alarms are rebuilt when the
  time or timezone changes.
- The bookmarklet, the "Sync from Zealy" paste dialog and the file import are removed.
  Connect Zealy and Reconnect Zealy replace them.
- Data is saved in `files/questpilot-db-v1.json` in the same format. The web UI reads and
  writes it through the `QuestPilot` Capacitor plugin, with optimistic revision checks so
  a background sync never overwrites your edits.

### Saved submissions with autofill (v2.1)
- **Save content per quest.** Use the "Save for autofill" chip on a quest card, or the menu item
  "Saved submissions". It's offered on quests with a text task (text, URL, number) or a file/photo
  task, and on manual/test quests. You can save a text and one or more photos from your gallery.
  Quests with saved content show a **Saved** badge.
- **Storage.** Each photo is stored once as a file in app storage (`files/saved-photos/`). The
  `submissions` table in `questpilot-db-v1` keeps only `images: [{id, name, thumb}]`, plus
  `image`/`thumb`/`imageName` mirroring the first photo for older builds. Sync never reads or
  writes submissions, and app updates keep `files/`. "Every claim" entries are never modified.
  Optional one-time entries ("Use once only") are marked used when the quest is opened.
- **Autofill on open.** Opening a quest always uses the app's own signed-in WebView
  (`ClaimActivity`), never an external browser. Once the page finishes loading, `qp-fill.js`:
  - for text, waits for the answer box (MutationObserver plus polling, up to 10 s), sets the
    value with the native value setter, then dispatches `input` and `change`;
  - for photos, answers the page's file chooser (`onShowFileChooser`) with the saved photo(s);
    as a fallback, it places them in the page's `<input type=file>` with `DataTransfer`.

  It **never clicks Claim or Submit**.
- **Fallback banner.** If autofill fails, a banner reads "Couldn't autofill, tap to copy text" and
  the saved text is copied to the clipboard. A "Saved photo(s)" button lets you pick a saved photo
  manually: it tries to attach the photo now and arms the next file picker to return it.
- **With the daily timer.** A quest with saved content and an unlock time always gets the
  unlock − 3 s preload, even when auto-open is off. The page refreshes at the unlock second and
  is filled right after. If Zealy still serves the locked page, the app reloads and tries once
  more within 20 s.
- **Safety.** Autofill runs only on zealy.io and only on the opened quest: the path must contain
  that quest's Zealy id, or match the opened URL for manual/test quests. Both the native and the
  JS side check this. Opening or filling a quest never changes its status.
- **Selectors.** All page selectors are in **`public/zealy-selectors.json`**. If Zealy changes
  its layout, edit that file and run `npm run build && npx cap sync android`, then rebuild.
- **Test (debug build).** In Settings > Test mode > "Autofill test", pick a quest with saved
  content. The fake unlock then opens that quest's real page 3 s early and autofills at unlock.
  Pick "No saved content" to see the "Couldn't autofill" banner on the questboard page.

### Test mode (debug build only)
Settings > **Test mode > Fake unlock in 1 minute** creates a fake daily quest that unlocks 60
seconds later. It is isolated from your real data:

- It lives in its own file (`files/devtools/test-quests.json`) with a negative id. It is never
  written to `questpilot-db-v1`, so it never appears in Today, Tasks or the alert history. As a
  guard, any test quest that reaches the real data is stripped on every save and at startup.
- Its alarms use separate `test-*` keys. Its notifications go to their own "Test mode (debug
  build)" channel, are titled `[Test]`, never go to Telegram, and never trigger a Zealy sync.
- It uses the same single unlock function, the same recompute-before-firing check and the same
  claim screen as real quests. If it borrows a real quest's saved content, that content is
  only read, never marked used.

In that minute you should see:

- the test card's countdown, the debug line and the `[Test]` "soon" notification (about 30 s
  before unlock) all agreeing;
- at unlock − 3 s, the claim page loading behind the overlay;
- at the unlock second, the overlay disappearing, the page refreshing and autofill running.

Repeat the test with the app closed or the screen off to check the full-screen notification
path. **Clear test data** removes the fake quest, its alarms, `[Test]` notifications,
temporary autofill files, and any test rows an older build may have left in the real data.

---

## Project layout

```
src/                         rebuilt web UI (React 18, TanStack Query, wouter hash routes, Tailwind)
  lib/store.ts               questpilot-db-v1 document, synced with native storage
  lib/api.ts                 the original /api/* routes, ported from local-api.js
  lib/quest.ts               getUnlockTimestamp (reads quest.unlockAt), questStatus, formatting
  pages/                     Today, Tasks, Sprints, Alerts, Settings, Monitor
android/app/src/main/java/io/questpilot/app/
  UnlockClock.kt             A1 single unlock-time function
  AlarmScheduler.kt          A1/A3 exact alarms with basis check (+ AlarmReceiver)
  ClaimActivity.kt           A3 claim WebView, preloader, in-app Zealy browser
  ZealySync.kt               questboard import, A2 status rules, session health
  Monitors.kt                B2 QuestMonitor, B3 MessageMonitor, baselines
  MonitorService.kt          foreground service, polling timers, 429/403 backoff
  SessionStore.kt            Keystore-encrypted Zealy cookies
  ZealyLoginActivity.kt      Connect / Reconnect Zealy
  QuestPilotPlugin.kt        Capacitor bridge used by the web UI
  DbStore.kt                 data file, alert scanner
  BootReceiver.kt, Notifications.kt, QuestPilotApp.kt, MainActivity.kt
```

---

## Caveats

- Zealy has no public API for user sessions. QuestPilot calls the same endpoints zealy.io
  calls from your browser, with your own cookies. If Zealy changes those endpoints or adds
  extra request checks, sync and monitoring will report errors until the app is updated.
- From the build machine, the logged-in responses could not be verified, because
  unauthenticated requests get 403. The field names come from Zealy's web app schemas.
- Android Doze can delay background polling on some phones even with exact alarms. Battery
  "Unrestricted" and the brand autostart settings matter. The claim alarm itself is exact.
- On Android 14+, exact alarms and full-screen notifications must be allowed in system
  settings; the setup sheet links there. If exact alarms are denied, the app falls back to
  inexact alarms, and the debug panel shows "NOT allowed".
- Zealy's terms may not allow automated access to its API. The app only reads data at a
  low rate and never submits a claim for you, but you use it at your own risk.
